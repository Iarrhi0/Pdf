using System.Diagnostics;
using ChapterSearchPdfV3.Models;
using ChapterSearchPdfV3.Services;
using Microsoft.Web.WebView2.WinForms;

namespace ChapterSearchPdfV3;

public sealed class MainForm : Form
{
    private readonly WebView2 _browser = new() { Dock = DockStyle.Fill };
    private readonly TextBox _url = new() { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle };
    private readonly Label _header = new() { Text = "Chapter Search PDF   PC v3.0.1 • WEBVIEW2 NATIVE • PHONE x10", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 11, FontStyle.Bold) };
    private readonly Label _pageStatus = new() { Text = "Initialisation…", Dock = DockStyle.Right, Width = 280, TextAlign = ContentAlignment.MiddleRight };
    private readonly ListView _queueList = new() { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, HideSelection = false };
    private readonly Label _queueSummary = new() { Dock = DockStyle.Top, Height = 46, Padding = new Padding(8), Font = new Font("Segoe UI", 9, FontStyle.Bold) };
    private readonly Label _metrics = new() { Dock = DockStyle.Bottom, Height = 52, Padding = new Padding(8), Font = new Font("Consolas", 9) };
    private readonly System.Windows.Forms.Timer _uiTimer = new() { Interval = 700 };

    private RendererPool? _renderers;
    private DownloadManager? _downloads;
    private MultiSiteSearchService? _search;
    private readonly CpuMonitor _cpu = new();
    private bool _closing;

    public MainForm()
    {
        Text = "Chapter Search PDF V3";
        Width = 1500; Height = 900; StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(8, 13, 25); ForeColor = Color.White;
        MinimumSize = new Size(1100, 700);

        BuildUi();
        Shown += async (_, _) => await InitializeAsync();
        FormClosing += OnClosing;
        _uiTimer.Tick += (_, _) => RefreshQueueAndMetrics();
    }

    private void BuildUi()
    {
        var headerPanel = new Panel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(12, 4, 12, 4), BackColor = Color.FromArgb(8, 17, 39) };
        headerPanel.Controls.Add(_header); headerPanel.Controls.Add(_pageStatus);

        var nav = new TableLayoutPanel { Dock = DockStyle.Top, Height = 48, ColumnCount = 6, Padding = new Padding(8, 5, 8, 5), BackColor = Color.FromArgb(8, 17, 39) };
        nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 44)); nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 44)); nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 44)); nav.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90)); nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 0));
        var back = Btn("←", 0); var forward = Btn("→", 0); var refresh = Btn("↻", 0); var open = Btn("Ouvrir", 0);
        _url.BackColor = Color.FromArgb(14, 25, 46); _url.ForeColor = Color.White; _url.Font = new Font("Segoe UI", 10);
        nav.Controls.Add(back, 0, 0); nav.Controls.Add(forward, 1, 0); nav.Controls.Add(refresh, 2, 0); nav.Controls.Add(_url, 3, 0); nav.Controls.Add(open, 4, 0);
        back.Click += (_, _) => { if (_browser.CanGoBack) _browser.GoBack(); }; forward.Click += (_, _) => { if (_browser.CanGoForward) _browser.GoForward(); }; refresh.Click += (_, _) => _browser.Reload(); open.Click += (_, _) => Navigate();
        _url.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Navigate(); } };

        var actions = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(8, 3, 8, 3), BackColor = Color.FromArgb(8, 17, 39), WrapContents = false, AutoScroll = true };
        var pdf = ActionBtn("↓ PDF du chapitre", Color.FromArgb(72, 101, 255));
        var analyze = ActionBtn("☰ Analyser la série", Color.FromArgb(103, 76, 222));
        var next = ActionBtn("→ Télécharger la suite", Color.FromArgb(20, 135, 89));
        var search = ActionBtn("Recherche multi-site", Color.FromArgb(34, 50, 79));
        var folder = ActionBtn("Dossier PDF", Color.FromArgb(34, 50, 79));
        actions.Controls.AddRange([pdf, analyze, next, search, folder]);
        pdf.Click += async (_, _) => await AddCurrentChapterAsync(); analyze.Click += async (_, _) => await AnalyzeSeriesAsync(false); next.Click += async (_, _) => await AnalyzeSeriesAsync(true); search.Click += (_, _) => OpenSearch(); folder.Click += (_, _) => OpenDownloadsFolder();

        _queueList.BackColor = Color.FromArgb(12, 22, 40); _queueList.ForeColor = Color.White; _queueList.BorderStyle = BorderStyle.None;
        _queueList.Columns.Add("#", 38); _queueList.Columns.Add("Tâche", 190); _queueList.Columns.Add("État", 90); _queueList.Columns.Add("Progression", 110); _queueList.Columns.Add("Vitesse", 78);

        var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(10, 18, 33), Padding = new Padding(8) };
        var rightTitle = new Label { Dock = DockStyle.Top, Height = 34, Text = "File multi séries — clique sur une tâche", Font = new Font("Segoe UI", 10, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        var globalButtons = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 42, WrapContents = false };
        var pauseAll = SmallBtn("Pause tout");
        var resumeAll = SmallBtn("Reprendre tout");
        var retryErrors = SmallBtn("Réessayer erreurs");
        var clear = SmallBtn("Effacer terminés");
        globalButtons.Controls.AddRange([pauseAll, resumeAll, retryErrors, clear]);
        pauseAll.Click += (_, _) => _downloads?.PauseAll(); resumeAll.Click += (_, _) => _downloads?.ResumeAll(); retryErrors.Click += (_, _) => _downloads?.RetryErrors(); clear.Click += (_, _) => _downloads?.ClearFinished();

        var taskButtons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 82, Padding = new Padding(0, 4, 0, 4), WrapContents = true };
        var pause = SmallBtn("⏸ Pause");
        var resume = SmallBtn("▶ Reprendre");
        var retry = SmallBtn("↻ Relancer");
        var stop = SmallBtn("■ Arrêter");
        var remove = SmallBtn("🗑 Supprimer");
        var openFile = SmallBtn("Dossier");
        taskButtons.Controls.AddRange([pause, resume, retry, stop, remove, openFile]);
        pause.Click += (_, _) => WithSelectedJob(id => _downloads?.Pause(id)); resume.Click += (_, _) => WithSelectedJob(id => _downloads?.Resume(id)); retry.Click += (_, _) => WithSelectedJob(id => _downloads?.Retry(id)); stop.Click += (_, _) => WithSelectedJob(id => _downloads?.Stop(id)); remove.Click += (_, _) => WithSelectedJob(id => _downloads?.Remove(id)); openFile.Click += (_, _) => OpenSelectedFolder();

        right.Controls.Add(_queueList); right.Controls.Add(taskButtons); right.Controls.Add(_metrics); right.Controls.Add(_queueSummary); right.Controls.Add(globalButtons); right.Controls.Add(rightTitle);

        var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterWidth = 4, BackColor = Color.FromArgb(29, 42, 66), Panel2MinSize = 410 };
        split.SplitterDistance = 1030; split.Panel1.Controls.Add(_browser); split.Panel2.Controls.Add(right);

        Controls.Add(split); Controls.Add(actions); Controls.Add(nav); Controls.Add(headerPanel);
    }

    private async Task InitializeAsync()
    {
        try
        {
            _pageStatus.Text = "WebView2…";
            _renderers = new RendererPool(this, 3);
            await _renderers.InitializeAsync();
            await _browser.EnsureCoreWebView2Async(_renderers.Environment);
            _browser.CoreWebView2.Settings.UserAgent = RendererPool.AndroidUserAgent;
            _browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
            _browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
            _browser.CoreWebView2.SourceChanged += (_, _) => BeginInvoke(new Action(() => { _url.Text = _browser.Source?.ToString() ?? ""; }));
            _browser.CoreWebView2.NavigationCompleted += (_, e) => BeginInvoke(new Action(() => { _pageStatus.Text = e.IsSuccess ? "Page chargée • Moteur 5 prêt" : $"Erreur page : {e.WebErrorStatus}"; }));
            _browser.CoreWebView2.Navigate("about:blank");
            _downloads = new DownloadManager(_renderers);
            _downloads.Changed += () => { if (!_closing && IsHandleCreated) BeginInvoke(new Action(RefreshQueueAndMetrics)); };
            _search = new MultiSiteSearchService();
            _uiTimer.Start();
            _pageStatus.Text = "Prêt • 10 DOWN • 3 RENDER";
        }
        catch (Exception ex)
        {
            _pageStatus.Text = "Initialisation impossible";
            MessageBox.Show(this, ex.Message + "\n\nVérifie que Microsoft Edge WebView2 Runtime est installé.", "Chapter Search PDF V3", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void Navigate()
    {
        if (_browser.CoreWebView2 is null) return;
        var raw = _url.Text.Trim(); if (!raw.Contains("://")) raw = "https://" + raw;
        if (Uri.TryCreate(raw, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) _browser.CoreWebView2.Navigate(u.AbsoluteUri);
        else MessageBox.Show(this, "URL invalide.");
    }

    private async Task AddCurrentChapterAsync()
    {
        if (_renderers is null || _downloads is null || _browser.Source is null) return;
        try
        {
            _pageStatus.Text = "Préparation du chapitre…";
            var info = await _renderers.FindSeriesPageAsync(_browser.Source.ToString());
            var title = "Chapitre courant";
            var n = ExtractNumber(_browser.Source.ToString()); if (n is not null) title = $"Chapitre {n.Value:g}";
            _downloads.Add([new ChapterCandidate { Number = n ?? 0, Title = title, Url = _browser.Source.ToString(), Series = info.Series, Source = "current" }]);
            _pageStatus.Text = "Chapitre ajouté à la file";
        }
        catch (Exception ex) { _pageStatus.Text = ex.Message; }
    }

    private async Task AnalyzeSeriesAsync(bool addDirectly)
    {
        if (_renderers is null || _downloads is null || _browser.Source is null) return;
        try
        {
            _pageStatus.Text = "Analyse stricte de la série…";
            var url = _browser.Source.ToString();
            var chapters = await _renderers.AnalyzeSeriesAsync(url);
            if (chapters.Count == 0)
            {
                var info = await _renderers.FindSeriesPageAsync(url);
                if (!string.Equals(info.Url, url, StringComparison.OrdinalIgnoreCase)) chapters = await _renderers.AnalyzeSeriesAsync(info.Url);
            }
            if (chapters.Count == 0) { _pageStatus.Text = "Aucun vrai chapitre détecté"; return; }
            _pageStatus.Text = $"Série • {chapters.Count} chapitre(s) cohérent(s)";
            if (addDirectly)
            {
                var current = ExtractNumber(url);
                var list = current is null ? chapters : chapters.Where(c => c.Number >= current.Value).ToList();
                _downloads.Add(list);
            }
            else
            {
                using var form = new SeriesSelectionForm(chapters, $"{chapters[0].Series} — {chapters.Count} chapitres");
                if (form.ShowDialog(this) == DialogResult.OK) _downloads.Add(form.SelectedChapters);
            }
        }
        catch (Exception ex) { _pageStatus.Text = "Analyse : " + ex.Message; }
    }

    private void OpenSearch()
    {
        if (_search is null) return;
        using var form = new SearchForm(_search);
        if (form.ShowDialog(this) == DialogResult.OK && form.SelectedUrl is { } u)
        {
            _url.Text = u; Navigate();
        }
    }

    private void RefreshQueueAndMetrics()
    {
        if (_downloads is null) return;
        int? selected = _queueList.SelectedItems.Count > 0 && _queueList.SelectedItems[0].Tag is int sid ? sid : null;
        var jobs = _downloads.Snapshot();
        _queueList.BeginUpdate(); _queueList.Items.Clear();
        foreach (var j in jobs)
        {
            var progress = j.Pages > 0 ? $"{j.Page}/{j.Pages} ({j.Page * 100 / Math.Max(1, j.Pages)}%)" : "—";
            var speed = j.SpeedMbps > 0 ? $"{j.SpeedMbps:0.0} MB/s" : "—";
            var item = new ListViewItem([j.Id.ToString(), $"{j.Series} • {j.Title}", StateText(j), progress, speed]) { Tag = j.Id };
            item.ForeColor = j.State switch { JobState.Error => Color.FromArgb(255, 95, 120), JobState.Saved => Color.FromArgb(71, 210, 135), JobState.Paused => Color.FromArgb(245, 183, 70), _ => Color.White };
            _queueList.Items.Add(item);
            if (selected == j.Id) item.Selected = true;
        }
        _queueList.EndUpdate();
        var active = jobs.Count(j => j.State is JobState.Render or JobState.Engine5 or JobState.Download or JobState.Pdf);
        var down = jobs.Count(j => j.State == JobState.Download);
        var saved = jobs.Count(j => j.State == JobState.Saved);
        var error = jobs.Count(j => j.State == JobState.Error);
        _queueSummary.Text = $"{active}/10 actifs • {down} DOWN • {saved} OK • {error} erreur(s) • {jobs.Count} total";
        var m = _cpu.Sample();
        _metrics.Text = $"CPU app {m.AppCpu,5:0.0}%   CPU PC {m.SystemCpu,5:0.0}%\nRAM app {m.RamMb,6:0} Mo   DOWN {down}/10   RENDER max 3";
    }

    private static string StateText(DownloadJob j) => j.State == JobState.Error ? "ERROR" : j.Phase;
    private void WithSelectedJob(Action<int> action) { if (_queueList.SelectedItems.Count > 0 && _queueList.SelectedItems[0].Tag is int id) action(id); }
    private void OpenSelectedFolder()
    {
        if (_downloads is null || _queueList.SelectedItems.Count == 0 || _queueList.SelectedItems[0].Tag is not int id) return;
        var job = _downloads.Snapshot().FirstOrDefault(x => x.Id == id); if (job is null) return;
        var dir = !string.IsNullOrWhiteSpace(job.Target) ? Path.GetDirectoryName(job.Target) : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "Chapter Search PDF", job.Series);
        if (dir is not null) { Directory.CreateDirectory(dir); Process.Start(new ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true }); }
    }
    private void OpenDownloadsFolder()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "Chapter Search PDF"); Directory.CreateDirectory(dir); Process.Start(new ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private static double? ExtractNumber(string text)
    {
        var m = System.Text.RegularExpressions.Regex.Match(text, @"(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# /]*(\d+(?:\.\d+)?)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        return m.Success && double.TryParse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture, out var n) ? n : null;
    }

    private static Button Btn(string text, int width) => new() { Text = text, Dock = DockStyle.Fill, Width = width, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(22, 38, 66), ForeColor = Color.White, Margin = new Padding(2) };
    private static Button ActionBtn(string text, Color color) => new() { Text = text, AutoSize = true, Height = 38, FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(3) };
    private static Button SmallBtn(string text) => new() { Text = text, AutoSize = true, Height = 30, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(33, 49, 77), ForeColor = Color.White, Margin = new Padding(2) };

    private void OnClosing(object? sender, FormClosingEventArgs e)
    {
        if (_closing) return;
        _closing = true; _uiTimer.Stop();
        _downloads?.Dispose(); _search?.Dispose();
        if (_renderers is not null) _renderers.DisposeAsync().AsTask().GetAwaiter().GetResult();
    }
}
