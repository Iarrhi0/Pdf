# Chapter Search PDF V3.0.1 — Build Fix

Cette révision corrige les erreurs de compilation C# observées dans GitHub Actions :

- collision entre la propriété `RendererPool.Environment` et `System.Environment` ;
- déclarations `var` multiples invalides dans `MainForm.cs`.

Les fonctions V3 restent inchangées.

# Chapter Search PDF PC V3 — WebView2 Native / Phone x10

V3 remplace complètement Electron. Il n'y a **plus de Chromium embarqué dans le programme**, plus de Node.js et plus de Sharp.
Le navigateur intégré utilise Microsoft Edge WebView2 déjà présent sur Windows.

## Architecture

- Interface Windows native WinForms (.NET 8)
- 1 WebView2 visible pour naviguer
- pool de 3 WebView2 cachés pour le rendu JavaScript des chapitres
- APK40 + véritable Engine 5 Java porté depuis l'ancienne application
- détection stricte des chapitres de la même série
- 10 jobs de chapitres simultanés
- 1 flux image séquentiel par chapitre = jusqu'à 10 transferts réseau en parallèle
- HttpClient partagé avec connexions TCP/TLS réutilisées
- cookies + Referer + User-Agent Android issus de la session WebView2
- PDF écrit page par page directement sur disque
- JPEG conservé sans recompression
- conversion WebP/PNG seulement si nécessaire, limitée à 2 conversions simultanées

## Contrôle individuel des tâches

Clique une tâche puis utilise :

- Pause
- Reprendre
- Relancer / Reload
- Arrêter
- Supprimer
- Ouvrir le dossier

Une page réseau qui échoue est retentée trois fois. Si elle échoue encore, V3 rerend le chapitre, renouvelle les cookies et les URLs via APK40/Engine 5 puis retente avant de déclarer une erreur.

## Recherche

La recherche multi-site n'utilise pas le navigateur pour chaque source : les recherches HTTP sont lancées jusqu'à 8 sources en parallèle. MangaDex et Comick utilisent leur API, les autres utilisent en priorité la recherche interne du site.

## CPU / RAM

Le panneau droit affiche CPU de l'application, CPU global, RAM, nombre de DOWN et limite de renderers.
Les 10 téléchargements n'impliquent pas 10 navigateurs : après extraction, les WebView2 sont immédiatement rendus au pool.

## Build GitHub Actions

Le workflow `.github/workflows/build-windows-v3.yml` génère :

- `LIGHT` : beaucoup plus petit, nécessite .NET 8 Desktop Runtime installé.
- `STANDALONE` : inclut .NET 8, plus gros mais ne nécessite pas d'installation .NET.

Les deux utilisent WebView2 installé sur Windows et n'embarquent pas un runtime Chromium/Electron.
