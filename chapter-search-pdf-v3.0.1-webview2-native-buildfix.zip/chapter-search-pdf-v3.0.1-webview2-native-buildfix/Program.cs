using ChapterSearchPdfV3.Services;

namespace ChapterSearchPdfV3;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
