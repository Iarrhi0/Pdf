# HTML Images vers PDF V19

Version locale stable avec nettoyage et audit des doublons.

## Nouveautés V19
- Normalisation de la largeur des images selon la moyenne du document.
- Tri naturel des chapitres et conservation des sous-dossiers.
- Détection SHA-256 des doublons strictement identiques.
- Suppression automatique des doublons exacts dans la sortie principale.
- Détection des répétitions de même chapitre / nom proche.
- Création d'un sous-dossier spécial `DOUBLONS_A_VERIFIER/`.
- Création d'un `RAPPORT_DOUBLONS.txt` indiquant :
  - le fichier écarté ;
  - le fichier conservé ;
  - la raison de la détection.
- Le nom HTML/MHT source reste placé en premier dans le nom du PDF.
- Les PDF valides restent classés dans la sortie principale.
