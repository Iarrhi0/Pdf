# Chapter PDF Manual Safe V4.5 — Full Source Fix

## Ce qui change
La V4.4 pouvait prendre un mauvais compteur `x / y` trouvé ailleurs dans la page
et croire qu'un chapitre ne contenait que 3 sources.

La V4.5 ne déduit plus le nombre de sources depuis ce type de compteur.

Pour Ortega :
- récupère toutes les vraies URL `/api/chapters/.../image/<n>.jpg` présentes dans le lecteur ;
- les trie par numéro ;
- télécharge chacune une seule fois ;
- n'essaie pas `image/18`, `image/19`, etc. si ces URL ne sont pas exposées ;
- ne tronque plus le chapitre à cause d'un faux compteur ;
- refuse le PDF si une source attendue échoue ;
- conserve le découpage mobile des longues bandes.

## Nom
`Set_It!_001.pdf`
`Set_It!_002.pdf`

Le mot `Chapitre` a été retiré.

## Sortie
Téléchargements/PDF_CONVERTIS/
