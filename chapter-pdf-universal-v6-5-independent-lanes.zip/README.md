# V6.5 — Independent Lanes

Deux files totalement indépendantes.

À partir du chapitre 24 :
- File A : 24 -> 26 -> 28 -> 30...
- File B : 25 -> 27 -> 29 -> 31...

Chaque file suit :
1. Multi-Engine / téléchargement ;
2. création PDF ;
3. enregistrement immédiat ;
4. confirmation Android ;
5. passage immédiat au chapitre +2.

Si 24 termine avant 25, 24 s'enregistre puis File A part immédiatement sur 26.
File B continue 25 et, une fois terminé, part sur 27.

Aucune file n'attend l'autre.
