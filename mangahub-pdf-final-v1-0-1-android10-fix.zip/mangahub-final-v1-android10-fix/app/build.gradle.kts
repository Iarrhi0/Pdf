plugins { id("com.android.application") }

android {
    namespace = "com.mangahub.pdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mangahub.pdf"
        minSdk = 24
        targetSdk = 35
        versionCode = 21
        versionName = "1.0.1-android10-fix"
    }

    buildTypes { release { isMinifyEnabled = false } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
