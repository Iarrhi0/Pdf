package com.mangahub.pdf;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService pool = Executors.newFixedThreadPool(10);
    private static final String UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.addJavascriptInterface(new Bridge(), "AndroidNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void callback(String fn, String json) {
        runOnUiThread(() -> webView.evaluateJavascript("window." + fn + "(" + json + ")", null));
    }

    public class Bridge {
        @JavascriptInterface public void search(String query) {
            pool.execute(() -> {
                try { callback("onSearchResults", searchAll(query)); }
                catch (Exception e) { callback("onSearchResults", obj("error", e.getMessage())); }
            });
        }
        @JavascriptInterface public void details(String url, String source) {
            pool.execute(() -> {
                try { callback("onDetails", getDetails(url, source)); }
                catch (Exception e) { callback("onDetails", obj("error", e.getMessage())); }
            });
        }
        @JavascriptInterface public void download(String chapterUrl, String seriesTitle, String chapterLabel) {
            pool.execute(() -> downloadChapter(chapterUrl, seriesTitle, chapterLabel));
        }
        @JavascriptInterface public String loadJobs() {
            return getPreferences(MODE_PRIVATE).getString("jobs", "[]");
        }
        @JavascriptInterface public void saveJobs(String json) {
            getPreferences(MODE_PRIVATE).edit().putString("jobs", json).apply();
        }
        @JavascriptInterface public void fetchExtensionIndex(String url) {
            pool.execute(() -> {
                try { callback("onExtensionIndex", quote(fetch(url))); }
                catch (Exception e) { callback("onExtensionIndex", obj("error", e.getMessage())); }
            });
        }
    }

    private String searchAll(String q) throws Exception {
        List<String> items = new ArrayList<>();
        String enc = URLEncoder.encode(q, "UTF-8");
        String[] urls = {
                "https://sushiscan.net/?s=" + enc,
                "https://sushiscan.fr/?s=" + enc
        };
        for (String u: urls) {
            try { collectSearch(fetch(u), "SushiScan", q, items); } catch (Exception ignored) {}
        }
        // Ortega is kept as a direct connector with tolerant endpoint discovery.
        String[] ortega = {
                "https://ortegascans.com/?s=" + enc,
                "https://ortegascans.fr/?s=" + enc,
                "https://ortegascans.com/search/" + enc
        };
        for (String u: ortega) {
            try { collectSearch(fetch(u), "OrtegaScans", q, items); } catch (Exception ignored) {}
        }
        LinkedHashSet<String> unique = new LinkedHashSet<>(items);
        return "{\"items\":[" + String.join(",", unique) + "]}";
    }

    private void collectSearch(String html, String source, String query, List<String> out) {
        Pattern p = Pattern.compile("(?is)<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>");
        Matcher m = p.matcher(html);
        String q = normalize(query);
        int count = 0;
        while (m.find() && count < 60) {
            String href = decode(m.group(1));
            String text = strip(m.group(2));
            if (text.length() < 2 || !normalize(text).contains(q)) continue;
            if (!href.startsWith("http")) continue;
            if (href.contains("/tag/") || href.contains("/genre") || href.contains("/author") || href.contains("#")) continue;
            String image = findNearbyImage(html, m.start(), m.end());
            out.add("{\"title\":"+quote(text)+",\"url\":"+quote(href)+",\"source\":"+quote(source)+",\"image\":"+quote(image)+"}");
            count++;
        }
    }

    private String getDetails(String url, String source) throws Exception {
        String html = fetch(url);
        String title = first(html, "(?is)<h1[^>]*>(.*?)</h1>");
        if (title.isEmpty()) title = first(html, "(?is)<title[^>]*>(.*?)</title>");
        title = strip(title).replace("- SushiScan", "").trim();
        String cover = first(html, "(?is)<img[^>]+(?:class=[\\\"'][^\\\"']*(?:poster|cover|thumb)[^\\\"']*[\\\"'][^>]+)?src=[\\\"']([^\\\"']+)[\\\"']");
        if (cover.isEmpty()) cover = first(html, "(?is)<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)");

        Pattern p = Pattern.compile("(?is)<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>");
        Matcher m = p.matcher(html);
        List<String> ch = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        while (m.find()) {
            String href = decode(m.group(1));
            String label = strip(m.group(2));
            String all = (href + " " + label).toLowerCase(Locale.ROOT);
            if (!(all.contains("chapitre") || all.contains("chapter") || all.matches(".*\\bch\\.?\\s*\\d+.*"))) continue;
            if (!href.startsWith("http") || seen.contains(href)) continue;
            seen.add(href);
            if (label.isEmpty()) label = href;
            ch.add("{\"label\":"+quote(label)+",\"url\":"+quote(href)+"}");
        }
        return "{\"title\":"+quote(title)+",\"source\":"+quote(source)+",\"url\":"+quote(url)+",\"cover\":"+quote(cover)+",\"chapters\":["+String.join(",", ch)+"]}";
    }

    private void downloadChapter(String chapterUrl, String seriesTitle, String chapterLabel) {
        String job = sha1(chapterUrl);
        try {
            status(job, "ANALYSE", 0, chapterLabel, "Analyse de la page");
            String html = fetch(chapterUrl);
            List<String> imgs = extractReaderImages(html, chapterUrl);
            if (imgs.isEmpty()) throw new IOException("Aucune image de lecture détectée");
            File dir = new File(getCacheDir(), "chapters/" + job); if (!dir.exists()) dir.mkdirs();
            List<File> pages = new ArrayList<>();
            int done = 0;
            for (int i=0;i<imgs.size();i++) {
                File f = new File(dir, String.format(Locale.US, "%04d.img", i+1));
                if (!f.exists() || f.length() < 1024) downloadFile(imgs.get(i), chapterUrl, f);
                pages.add(f); done++;
                status(job, "DOWNLOAD", (done*80)/imgs.size(), chapterLabel, done + "/" + imgs.size() + " pages");
            }
            status(job, "PDF", 85, chapterLabel, "Création PDF");
            File pdf = new File(getCacheDir(), job + ".part.pdf");
            buildPdf(pages, pdf);
            String name = safe(seriesTitle) + "_" + safeChapter(chapterLabel) + ".pdf";
            savePdf(pdf, name);
            status(job, "SAVED", 100, chapterLabel, name);
        } catch (Exception e) {
            String msg = e.getMessage()==null?e.toString():e.getMessage();
            String state = (msg.contains("403")||msg.contains("429")) ? "BLOQUE" : "ERREUR";
            status(job, state, 0, chapterLabel, msg);
        }
    }

    private List<String> extractReaderImages(String html, String baseUrl) {
        LinkedHashSet<String> all = new LinkedHashSet<>();
        Matcher m = Pattern.compile("(?is)<img[^>]+(?:src|data-src|data-lazy-src)=[\\\"']([^\\\"']+)[\\\"']").matcher(html);
        while (m.find()) {
            String u = absolute(baseUrl, decode(m.group(1)));
            String l = u.toLowerCase(Locale.ROOT);
            if (!u.startsWith("http")) continue;
            if (l.contains("logo")||l.contains("avatar")||l.contains("icon")||l.contains("emoji")||l.contains("banner")||l.contains("ads")) continue;
            if (l.matches(".*\\.(jpg|jpeg|png|webp)(\\?.*)?$")) all.add(u);
        }
        Matcher j = Pattern.compile("(?is)[\\\"'](https?:\\/\\/[^\\\"']+?\\.(?:jpg|jpeg|png|webp)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
        while (j.find()) all.add(decode(j.group(1).replace("\\/","/")));
        return new ArrayList<>(all);
    }

    private void downloadFile(String url, String referer, File out) throws Exception {
        HttpURLConnection c = open(url, referer);
        int code = c.getResponseCode(); if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " image");
        try (InputStream in = new BufferedInputStream(c.getInputStream()); OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
            byte[] b = new byte[65536]; int n; while ((n=in.read(b))!=-1) os.write(b,0,n);
        } finally { c.disconnect(); }
    }

    private void buildPdf(List<File> pages, File out) throws Exception {
        PdfDocument doc = new PdfDocument(); int pageNo=1;
        try {
            for (File f: pages) {
                Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath()); if (bm==null) continue;
                int w=bm.getWidth(), h=bm.getHeight();
                int max=14000; if (w>max || h>max) { double sc=Math.min((double)max/w,(double)max/h); w=(int)(w*sc); h=(int)(h*sc); }
                PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder(Math.max(1,w), Math.max(1,h), pageNo++).create();
                PdfDocument.Page p=doc.startPage(pi); Canvas c=p.getCanvas(); c.drawBitmap(bm,null,new android.graphics.Rect(0,0,w,h),null); doc.finishPage(p); bm.recycle();
            }
            try (FileOutputStream fos=new FileOutputStream(out)) { doc.writeTo(fos); fos.getFD().sync(); }
        } finally { doc.close(); }
    }

    private void savePdf(File src, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MangaHub PDF"); v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(uri==null) throw new IOException("Impossible de créer le PDF");
            try(OutputStream os=getContentResolver().openOutputStream(uri); InputStream in=new FileInputStream(src)){ byte[] b=new byte[65536]; int n; while((n=in.read(b))!=-1) os.write(b,0,n); }
            v.clear(); v.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,v,null,null);
        } else {
            File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"MangaHub PDF"); if(!dir.exists()) dir.mkdirs();
            try(InputStream in=new FileInputStream(src); OutputStream os=new FileOutputStream(new File(dir,name))){byte[]b=new byte[65536];int n;while((n=in.read(b))!=-1)os.write(b,0,n);}        }
    }

    private void status(String id,String state,int pct,String label,String message){ callback("onJobStatus","{\"id\":"+quote(id)+",\"state\":"+quote(state)+",\"progress\":"+pct+",\"label\":"+quote(label)+",\"message\":"+quote(message)+"}"); }

    private String fetch(String url) throws Exception {
        HttpURLConnection c=open(url,url); int code=c.getResponseCode(); if(code<200||code>=400) throw new IOException("HTTP "+code);
        InputStream in=code>=300?c.getErrorStream():c.getInputStream(); ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[]b=new byte[32768]; int n; while((n=in.read(b))!=-1)o.write(b,0,n); c.disconnect(); return new String(o.toByteArray(), StandardCharsets.UTF_8);
    }
    private HttpURLConnection open(String url,String referer) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(18000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true); c.setRequestProperty("User-Agent",UA); c.setRequestProperty("Accept","text/html,image/avif,image/webp,image/*,*/*;q=0.8"); c.setRequestProperty("Referer",referer); return c; }

    private String findNearbyImage(String html,int s,int e){ int a=Math.max(0,s-1000), b=Math.min(html.length(),e+1000); return first(html.substring(a,b),"(?is)<img[^>]+(?:src|data-src)=[\\\"']([^\\\"']+)[\\\"']"); }
    private String first(String s,String regex){Matcher m=Pattern.compile(regex).matcher(s);return m.find()?decode(m.group(1)):"";}
    private String strip(String s){return decode(s.replaceAll("(?is)<[^>]+>"," ").replaceAll("\\s+"," ").trim());}
    private String decode(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#039;","'").replace("&lt;","<").replace("&gt;",">");}
    private String normalize(String s){return java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").replaceAll("[^a-z0-9]+"," ").trim();}
    private String absolute(String base,String u){try{return new URL(new URL(base),u).toString();}catch(Exception e){return u;}}
    private String safe(String s){return s.replaceAll("[\\\\/:*?\"<>|]+"," ").trim().replaceAll("\\s+","_");}
    private String safeChapter(String s){Matcher m=Pattern.compile("(\\d+(?:\\.\\d+)?)").matcher(s);return m.find()?String.format(Locale.US,"%03d",(int)Double.parseDouble(m.group(1))):safe(s);}
    private String sha1(String s){try{MessageDigest md=MessageDigest.getInstance("SHA-1");byte[]d=md.digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:d)b.append(String.format("%02x",x));return b.toString();}catch(Exception e){return Integer.toHexString(s.hashCode());}}
    private String quote(String s){if(s==null)s="";return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","")+"\"";}
    private String obj(String k,String v){return "{\""+k+"\":"+quote(v)+"}";}

    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack(); else super.onBackPressed(); }
}
