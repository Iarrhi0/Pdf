# v2.6 Fast x6 / 18

- 6 chapitres peuvent rester en téléchargement simultanément.
- 3 pages sont récupérées en parallèle par chapitre.
- 18 requêtes image maximum globalement.
- 1 seul renderer Chromium APK40 est réutilisé pour l’analyse afin de limiter CPU/RAM.
- HTTP/HTTPS keep-alive réutilise les connexions TCP/TLS.
- Cache cookies court (20 s) pour éviter une lecture du cookie jar à chaque image.
- Le PDF reste streamé sur disque par fenêtres de 3 pages : le chapitre entier n’est jamais gardé en RAM.
- JPEG : intégration directe, sans recompression.
- Formats nécessitant Sharp : conversion lourde sérialisée à 1 thread.

Cette version consomme un peu plus de RAM réseau que v2.5 (jusqu’à 18 images en vol), mais reste beaucoup plus légère qu’une architecture avec plusieurs Chromium.
