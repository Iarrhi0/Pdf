# Chapter Search PDF PC v2.6 — APK40 Fast x6 / 18

Même fonctions que v2.5, mais téléchargement accéléré : jusqu’à 6 chapitres actifs, 3 pages en parallèle par chapitre, 18 connexions image globales, connexions HTTP keep-alive et PDF streaming.

Le renderer APK40 reste unique et réutilisé pour ne pas multiplier Chromium. Les conversions d’images lourdes restent limitées à un thread.
