# Chapter Search PDF PC v2.1 — JAVA5 fidèle

Cette version porte le vrai moteur 5 Java de l’ancienne application (`MainActivity.java`).

- JAVA E1 à E5 portés fidèlement
- E5 = isolation/tri du bloc lecteur/API, pas validation réseau
- Chromium sert de WebView PC pour rendre JS/lazy loading
- file multi-séries conservée
- récupération des images avec cookies / Referer / User-Agent
- fallback session V4.6 seulement si JAVA5 reste trop faible

Voir `JAVA5_PORT.md` pour le détail.
