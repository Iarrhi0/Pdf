# HTML Images vers PDF V20

## Reprise intelligente
Quand le même dossier est importé une nouvelle fois :
- chaque fichier source reçoit une empreinte SHA-256 ;
- l'application compare cette empreinte avec l'historique local du navigateur ;
- un fichier déjà enregistré/téléchargé avec succès est ignoré ;
- un fichier ayant échoué est automatiquement réessayé ;
- les nouveaux fichiers sont traités normalement ;
- la conversion reprend donc directement avec la suite.

L'historique est lié au navigateur/téléphone. Si les données du site sont effacées, l'historique est perdu.

## Autres fonctions conservées
- normalisation de la largeur des images selon la moyenne du document ;
- tri intelligent des chapitres ;
- suppression des doublons exacts par contenu ;
- dossier DOUBLONS_A_VERIFIER ;
- conservation des sous-dossiers ;
- nom du HTML/MHT source en premier ;
- conversions simultanées ;
- téléchargement de chaque PDF fini ;
- ZIP final de secours.
