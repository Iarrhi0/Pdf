# Chapter PDF Manual Safe V4

Cette version privilégie la stabilité plutôt que l'automatisation.

## Flux
- colle un chapitre ;
- touche **Télécharger ce chapitre** ;
- l'application traite uniquement ce chapitre ;
- le PDF est enregistré ;
- **Chapitre suivant** devient disponible ;
- ce bouton change seulement l'URL ;
- tu relances ensuite manuellement le téléchargement.

## Réduction des risques
- une seule WebView locale ;
- aucune page distante rendue dans une WebView ;
- aucun enchaînement automatique ;
- aucun préchargement du chapitre suivant ;
- aucune conversion parallèle ;
- une seule image réseau à la fois ;
- deux essais maximum par image ;
- timeout par requête ;
- ressources image libérées immédiatement après conversion ;
- aucune limite volontaire de 20 images ;
- `onRenderProcessGone` reste intercepté côté Android.

## Sortie
Téléchargements/PDF_CONVERTIS/

Compatible avec `unzip-and-build-apk.yml`.
