# Chapter PDF Manual Safe V4.8 — Multi-Engine Scan

## Nouvelle logique Ortega

Le HTML n'expose parfois que les 5 premières images.

La V4.8 utilise les premières images uniquement pour déduire le modèle API,
puis recherche activement toutes les images du chapitre par blocs :

- moteur 1 : images 1 à 5
- moteur 2 : images 6 à 10
- moteur 3 : images 11 à 15
- moteur 4 : images 16 à 20
- etc.

Chaque moteur teste son bloc avec une concurrence limitée à 2 requêtes à la fois.

## Arrêt
La recherche s'arrête lorsque :
- un bloc entier ne contient plus aucune image valide après qu'au moins une image
  du chapitre a déjà été trouvée ;
- ou un nombre final fiable est fourni ;
- ou le plafond de sécurité de 250 images est atteint.

Ortega peut répondre 403 au lieu de 404 pour une image inexistante :
un bloc entièrement 403 après des blocs valides est donc traité comme fin de chapitre,
pas comme CAPTCHA.

## Vérification
- aucune lacune autorisée entre image 1 et la dernière image trouvée ;
- une image manquante au milieu est retentée ;
- si elle reste absente, aucun PDF incomplet n'est produit ;
- toutes les images sont triées numériquement.

## Conversion
Chaque image Ortega réelle est ensuite convertie.
Une image longue peut devenir plusieurs pages PDF mobiles.
Toutes les pages sont assemblées dans un seul PDF.

Exemple :
`17 images Ortega -> 35 pages PDF`

Nom :
`Set_It!_001.pdf`
