package eu.kanade.tachiyomi.extension

import eu.kanade.domain.base.BasePreferences
import eu.kanade.domain.source.service.SourcePreferences
import eu.kanade.tachiyomi.extension.model.InstallStep
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import logcat.LogPriority
import mihon.domain.extension.repository.ExtensionStoreRepository
import tachiyomi.core.common.preference.PreferenceStore
import tachiyomi.core.common.util.system.logcat
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * MangaHub bootstrap for Kahon/Mihon extensions.
 *
 * The stock Kahon experience intentionally starts without third-party extension stores.
 * MangaHub is a downloader-first build, so we preconfigure the known compatible stores,
 * enable the languages exposed by them, and privately install available extensions in the
 * background. Sources therefore appear progressively in Browse/Global Search without the
 * user having to paste repository URLs or approve each APK installation.
 *
 * Repositories are still remote/dynamic: when they add or update an extension, Kahon's normal
 * extension manager sees it. We do not hardcode individual manga websites here.
 */
object MangaHubExtensionBootstrap {

    private const val PREF_BOOTSTRAP_COMPLETE = "mangahub_extension_bootstrap_complete_v2"

    // Kahon/Mihon compatible stores. Keep URLs as repository indexes/descriptors so the store
    // can update itself without requiring a MangaHub APK update.
    val DEFAULT_STORES = listOf(
        "https://github.com/keiyoushi/extensions/raw/repo/index.pb",
        "https://github.com/yuzono/manga-repo/raw/repo/index.pb",
        "https://raw.githubusercontent.com/Poulpiix/Extension-Tachimanga-FR/refs/heads/main/index.min.json",
        "https://raw.githubusercontent.com/marbou92/MHRepo/main/repo.json",
    )

    suspend fun run() {
        val preferenceStore = Injekt.get<PreferenceStore>()
        val done = preferenceStore.getBoolean(PREF_BOOTSTRAP_COMPLETE, false)

        val repository = Injekt.get<ExtensionStoreRepository>()
        DEFAULT_STORES.forEach { url ->
            repository.insert(url)
                .onFailure { error ->
                    logcat(LogPriority.WARN, error) { "MangaHub: failed to add extension store $url" }
                }
        }
        repository.refreshAll()

        val extensionManager = Injekt.get<ExtensionManager>()
        extensionManager.findAvailableExtensions()

        // Show every language represented by an available extension in Browse/Global Search.
        val sourcePreferences = Injekt.get<SourcePreferences>()
        val available = extensionManager.getAvailableExtensionsNow()
        val allLanguages = available
            .flatMap { ext -> ext.sources.map { it.lang } }
            .filter { it.isNotBlank() }
            .toSet()
        if (allLanguages.isNotEmpty()) {
            sourcePreferences.enabledLanguages.set(sourcePreferences.enabledLanguages.get() + allLanguages)
        }

        // Private install avoids Android's package-installer confirmation for every extension.
        Injekt.get<BasePreferences>().extensionInstaller.set(BasePreferences.ExtensionInstaller.PRIVATE)

        if (done) return

        val installedPackages = extensionManager.getInstalledExtensionsNow()
            .mapTo(mutableSetOf()) { it.pkgName }
        val missing = available.filterNot { it.pkgName in installedPackages }

        // Limit downloads: there can be hundreds of extensions. Sources appear as each APK is
        // installed; the app remains usable while the bootstrap continues in the background.
        val semaphore = Semaphore(3)
        coroutineScope {
            missing.map { extension ->
                async {
                    semaphore.withPermit {
                        try {
                            val terminal = extensionManager.installExtension(extension)
                                .first { step -> step.isCompleted() }
                            if (terminal == InstallStep.Error) {
                                logcat(LogPriority.WARN) {
                                    "MangaHub: extension install failed: ${extension.pkgName}"
                                }
                            }
                        } catch (error: Throwable) {
                            logcat(LogPriority.WARN, error) {
                                "MangaHub: extension install crashed: ${extension.pkgName}"
                            }
                        }
                    }
                }
            }.awaitAll()
        }

        // Refresh once more so newly installed sources and update statuses are in sync.
        extensionManager.findAvailableExtensions()
        preferenceStore.getBoolean(PREF_BOOTSTRAP_COMPLETE, false).set(true)
    }
}
