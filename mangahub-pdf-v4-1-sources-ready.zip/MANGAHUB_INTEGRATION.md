# MangaHub PDF 4.0 — Kahon Runtime

Full Kahon source tree with MangaHub PDF integrated into the native downloader.

- Real Kahon/Mihon extension manager and extension-store runtime retained.
- Dynamic extension APK install/update/uninstall remains intact.
- 10 logical chapter jobs by default, including multiple chapters from one source.
- Extension page parser is authoritative; MangaHub AUTO ENGINE provides a generic HTML fallback.
- One chapter = one PDF.
- `.part.pdf` is renamed to final `.pdf` only after successful PDF creation.
- Existing PDF/CBZ files are recognized as completed downloads.
- Kahon page cache/retry/resume logic remains in use.
- CAPTCHA/Cloudflare is not bypassed; Kahon WebView/network verification remains responsible for manual verification.
