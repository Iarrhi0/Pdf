# MangaHub PDF 4.0 — Full Kahon Edition

This ZIP is a complete Android project. `gradlew` is at the ZIP root.

Core behavior:
- full Kahon/Mihon source + extension manager/store runtime;
- install/update/remove compatible extension APKs dynamically;
- browse/search through installed extension sources;
- 10 concurrent chapter jobs with immediate slot refill;
- extension page parser first, MangaHub generic AUTO ENGINE fallback second;
- persistent Kahon temporary page downloads/resume;
- one PDF per chapter;
- `.part.pdf` -> `.pdf` finalization;
- existing PDF/CBZ recognized as already downloaded;
- manual Cloudflare/CAPTCHA behavior remains handled by Kahon; no bypass.

GitHub Actions workflow included: `.github/workflows/build-mangahub-pdf.yml` (JDK 25).


## V4.1 - Sources Ready

MangaHub now bootstraps compatible Kahon/Mihon extension stores automatically on first launch.
Configured stores:
- Keiyoushi (v2 protobuf index)
- Yuzono (v2 protobuf index)
- Poulpiix FR
- MHExtensions / MHRepo

The app refreshes the stores, enables all source languages, switches extension installation to Kahon PRIVATE mode, and installs missing extensions in the background with a maximum of 3 concurrent APK downloads. Sources appear progressively in Browse / Global Search. No repository URL needs to be pasted manually.

This remains dynamic: individual website URLs are provided by the extension APKs, not hardcoded in MangaHub.
