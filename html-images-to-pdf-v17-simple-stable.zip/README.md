# V17 simplifiée et stable

Cette version supprime la configuration de backend et les proxys publics.

## Principe
- Fichiers HTML/MHT/ZIP : conversion locale, fiable et utilisable hors ligne une fois la page chargée.
- Dossier intelligent : tri naturel, chapitres, doublons, sortie PDF et ZIP.
- PDF dans pages : téléchargement uniquement quand le site autorise l’accès direct depuis le navigateur.
- Site chapitres : analyse directe uniquement. Si le site bloque CORS, un message clair recommande le mode fichier/ZIP.
- Parallélisme site limité à 2 chapitres et 2 images par chapitre pour réduire les erreurs 429 et la charge mémoire.

## GitHub Pages
Dépose index.html et le dossier vendor à la racine du site, ou utilise ton workflow actuel qui extrait le ZIP.
