# Chapter Search PDF PC v1.8 — Performance / anti-blocage

Cette version corrige les blocages observés sur les gros tomes et les files multi-séries.

## Changements principaux

- File multi-séries conservée, mais concurrence adaptative : 6 slots chapitre, 3 max par série/site.
- 3 analyses de chapitres simultanées au maximum.
- Les fenêtres cachées d’analyse ne téléchargent plus les centaines d’images du lecteur.
- Timeout d’analyse à 14 s et timeout image à 12 s.
- 3 PDF/téléchargements lourds simultanés maximum.
- 14 requêtes images globales et 3 pages simultanées par chapitre.
- Sharp limité à 2 threads et cache mémoire borné.
- L’interface n’est plus mise à jour après chaque page : snapshots de file limités à environ 3 fois/seconde.
- Les mises à jour PDF sont regroupées par blocs, ce qui réduit fortement l’IPC et les reconstructions DOM.
- Un PDF déjà présent est détecté et marqué immédiatement comme terminé.
- Déduplication des URL renforcée.
- Le compteur worker affiche maintenant les chapitres réellement actifs et non les workers dormants.

L’objectif n’est pas le nombre maximal de tâches théoriques, mais le débit réel sans saturer RAM, CPU, réseau ni le site distant.
