const FORCE_LAZY_LOAD = String.raw`(function(){try{
  document.querySelectorAll('img').forEach(function(i){
    ['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){var v=i.getAttribute(a);if(v&&!i.src)i.src=v;});
    i.loading='eager';
  });
  window.scrollTo(0,document.body.scrollHeight);
  return 'ok';
}catch(e){return 'err';}})();`;

const EXTRACT_MULTI_ENGINE = String.raw`(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function chapNo(s){var m=(s||'').match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=(s||'').match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?m[1]:''}
  function bad(u){u=(u||'').toLowerCase();return !u||u.indexOf('data:')===0||/(logo|avatar|icon|sprite|emoji|advert|banner|tracking|pixel|favicon|header|footer|cover|thumbnail|thumb|gravatar)/.test(u)}
  function add(arr,u,order,score,src){u=abs(u);if(!u||bad(u))return;arr.push({url:u,order:order||0,score:score||0,src:src||''})}
  function fromImg(arr,i,order,score,src){
    add(arr,i.currentSrc||i.src,order,score,src);
    ['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){add(arr,i.getAttribute(a),order,score-2,src)});
    var ss=i.getAttribute('srcset')||i.getAttribute('data-srcset')||'';ss.split(',').forEach(function(x){add(arr,x.trim().split(/\s+/)[0],order,score-4,src)});
  }
  var E1=[],E2=[],E3=[],E4=[];
  var sels=['.reading-content','.page-break','#readerarea','.reader-area','.readerarea','.ts_reader','.chapter-content','.chapter-images','.container-chapter-reader','.reading-detail','.viewer','.viewer_img','.episode-body','.webtoon-reader','.chapterbody','.chapter-body','.manga-reader','.comic-reader','main'];
  var best=null,bestCount=0,bestSel='';
  sels.forEach(function(s){document.querySelectorAll(s).forEach(function(el){var c=0;el.querySelectorAll('img').forEach(function(i){var w=i.naturalWidth||+i.getAttribute('width')||0,h=i.naturalHeight||+i.getAttribute('height')||0,u=i.currentSrc||i.src||i.getAttribute('data-src')||'';if(!bad(u)&&(!(w&&h)||(w>=180&&h>=180)))c++});if(c>bestCount){best=el;bestCount=c;bestSel=s}})});
  if(best){var n=0;best.querySelectorAll('img').forEach(function(i){var r=i.getBoundingClientRect(),w=i.naturalWidth||r.width||0,h=i.naturalHeight||r.height||0;if((w&&h)&&(w<180||h<180))return;fromImg(E1,i,n++,100,'reader:'+bestSel)});best.querySelectorAll('source').forEach(function(s){var z=s.srcset||s.getAttribute('data-srcset')||'';z.split(',').forEach(function(x){add(E1,x.trim().split(/\s+/)[0],n++,90,'source')})})}

  var allImgs=[].slice.call(document.querySelectorAll('img'));var g=0;
  allImgs.forEach(function(i){var r=i.getBoundingClientRect(),w=i.naturalWidth||r.width||0,h=i.naturalHeight||r.height||0,u=i.currentSrc||i.src||i.getAttribute('data-src')||'';if(bad(u))return;var area=(w||0)*(h||0),score=25;if(w>=400)score+=15;if(h>=500)score+=20;if(area>250000)score+=15;if(r.width>document.documentElement.clientWidth*.45)score+=10;if(i.closest('main,article,.reader,.reading-content,.chapter-content,.viewer,#readerarea,.ts_reader'))score+=18;if(w&&h&&(w<140||h<140))return;fromImg(E2,i,Math.max(0,Math.round((r.top+window.scrollY)*10)+g++),score,'geometry')});

  var scriptOrder=0;document.querySelectorAll('script').forEach(function(sc){var t=sc.textContent||'';var re=/(https?:\/\/[^\s'"<>]+?\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?[^\s'"<>]*)?)/ig,m,k=0;while((m=re.exec(t))&&k<1200){var u=m[1].replace(/\\u002F/g,'/').replace(/\\\//g,'/');var score=30;if(/(chapter|chapitre|manga|comic|webtoon|uploads|images|reader)/i.test(u))score+=20;add(E3,u,scriptOrder++,score,'script');k++}});

  try{var perf=performance.getEntriesByType('resource')||[];var po=0;perf.forEach(function(e){var u=e.name||'';if(bad(u))return;var looks=/\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?|$)/i.test(u)||/(image|img|chapter|reader|page)/i.test(u);if(!looks)return;var score=35;if(e.initiatorType==='img')score+=25;if((e.transferSize||e.decodedBodySize||0)>100000)score+=10;add(E4,u,Math.round(e.startTime*10)+po++,score,'performance:'+e.initiatorType)})}catch(e){}

  var engines=[{id:'E1',weight:100,a:E1},{id:'E2',weight:65,a:E2},{id:'E3',weight:35,a:E3},{id:'E4',weight:50,a:E4}];
  var map={};engines.forEach(function(en){var seen={};en.a.forEach(function(x,idx){if(seen[x.url])return;seen[x.url]=1;var z=map[x.url]||(map[x.url]={url:x.url,score:0,hits:0,orders:[],sources:[]});z.score+=en.weight+(x.score||0);z.hits++;z.orders.push([en.id,x.order==null?idx:x.order]);z.sources.push(en.id)})});
  var merged=Object.keys(map).map(function(k){var z=map[k];if(z.hits>1)z.score+=(z.hits-1)*45;var preferred=z.orders.find(function(o){return o[0]==='E1'})||z.orders.find(function(o){return o[0]==='E2'})||z.orders[0];z.order=preferred?preferred[1]:999999;return z}).sort(function(a,b){if(a.order!==b.order)return a.order-b.order;return b.score-a.score});
  var title=norm(document.title),url=location.href,n=chapNo(title)||chapNo(url),h1=norm((document.querySelector('h1')||{}).textContent);var rawSeries=h1||title;rawSeries=rawSeries.replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()||'Série';var label=n?((/(tome|volume|vol)/i.test(title+' '+url)?'Tome ':'Chapitre ')+n):norm(title).replace(rawSeries,'').replace(/^[-|–—: ]+|[-|–—: ]+$/g,'')||'Chapitre';
  var chapterSignal=!!n||/(chapter|chapitre|episode|reader|lecture|scan|tome|volume)/i.test(url+' '+title);
  var images=merged.filter(function(x){return x.score>=95||x.hits>=2}).slice(0,1000).map(function(x){return x.url});if(images.length<2)images=merged.slice(0,1000).map(function(x){return x.url});
  return JSON.stringify({ok:images.length>=2&&chapterSignal,reason:images.length>=2?'':'Moins de 2 images candidates',series:rawSeries,chapter:label,number:n,reader:bestSel||'multi-engine',count:images.length,images:images,engine:'E5-HYBRID',engineStats:{E1:E1.length,E2:E2.length,E3:E3.length,E4:E4.length,E5:images.length},candidates:merged.slice(0,1200)});
})();`;

const EXTRACT_CHAPTER_PAYLOAD = EXTRACT_MULTI_ENGINE;

const EXTRACT_CHAPTERS = String.raw`(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function num(t,h){var s=(t||'')+' '+(h||'');var m=s.match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=s.match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?parseFloat(m[1]):null}
  function canon(h){try{var u=new URL(h,location.href);u.hash='';['utm_source','utm_medium','utm_campaign','ref'].forEach(function(k){u.searchParams.delete(k)});if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/+$/,'/');return u.href}catch(e){return h}}
  var origin=location.origin,byNumber={};
  function add(h,t,source,node){
    var original=abs(h);if(!original)return;var u;try{u=new URL(original);if(u.origin!==origin)return}catch(e){return}
    var n=num(t,original);if(n===null||isNaN(n))return;
    var label=norm(t)||('Chapitre '+n),url=canon(original),score=0,signal=label+' '+url;
    if(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*\d/i.test(signal))score+=45;
    if(node&&node.closest&&node.closest('.chapters,.chapter-list,.listing-chapters_wrap,.wp-manga-chapter,.eplister,.episodelist,.list-chapter,.version-chap,.c-tabs-item__content,.page-listing-item'))score+=35;
    if(original.indexOf('#')>=0)score-=30;if(u.search)score-=12;
    if(/\/(?:prev|next)\/?$/i.test(u.pathname)||/\b(?:précédent|precedent|suivant|next|previous)\b/i.test(label))score-=55;
    score-=Math.min(20,Math.floor(url.length/80));
    var key=String(n),candidate={number:n,title:label,url:url,source:source||'dom',score:score};var prev=byNumber[key];
    if(!prev||candidate.score>prev.score||(candidate.score===prev.score&&candidate.url.length<prev.url.length))byNumber[key]=candidate;
  }
  document.querySelectorAll('a[href]').forEach(function(a){add(a.getAttribute('href'),a.innerText||a.textContent,'dom',a)});
  document.querySelectorAll('script').forEach(function(sc){var t=sc.textContent||'',re=/(https?:\/\/[^\s'"<>]+(?:chapter|chapitre|episode|tome|volume|scan)[^\s'"<>]*)/ig,m,k=0;while((m=re.exec(t))&&k<1600){add(m[1].replace(/\\u002F/g,'/'),'','script',null);k++}});
  var out=Object.keys(byNumber).map(function(k){return byNumber[k]}).filter(function(x){return x.score>-20}).sort(function(a,b){return a.number-b.number});
  var h1=norm((document.querySelector('h1')||{}).textContent),series=h1||norm(document.title);series=series.replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').trim()||'Série';
  out.forEach(function(x){x.series=series;var type=/(tome|volume|vol)/i.test(x.title+' '+x.url)?'Tome':'Chapitre';x.title=type+' '+x.number;delete x.score});
  return JSON.stringify(out.slice(0,4000));
})();`;

const FIND_SERIES_PAGE = String.raw`(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function clean(s){return norm(s).replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()}
  var current=location.href,origin=location.origin,h1=norm((document.querySelector('h1')||{}).textContent),title=norm(document.title),wanted=clean(h1)||clean(title),candidates=[];
  document.querySelectorAll('a[href]').forEach(function(a){var u=abs(a.getAttribute('href')),t=norm(a.innerText||a.textContent);if(!u||u===current||!t)return;try{if(new URL(u).origin!==origin)return}catch(e){return}if(/^(accueil|home|précédent|precedent|suivant|next|previous|retour|back)$/i.test(t))return;var score=0,ct=clean(t);if(wanted&&ct&&ct.toLowerCase()===wanted.toLowerCase())score+=100;if(wanted&&t.toLowerCase().includes(wanted.toLowerCase()))score+=55;if(a.closest('.breadcrumb,.breadcrumbs,.c-breadcrumb,.post-breadcrumb,.entry-header,.post-title,nav'))score+=35;if(/manga|series|serie|webtoon|comic|title|oeuvre|work/i.test(u))score+=18;if(!/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*\d/i.test(t+' '+u))score+=12;if(score>0)candidates.push({url:u,text:t,score:score})});candidates.sort(function(a,b){return b.score-a.score});return JSON.stringify({wanted:wanted,candidate:candidates[0]||null,all:candidates.slice(0,12)});
})();`;

module.exports = { FORCE_LAZY_LOAD, EXTRACT_CHAPTER_PAYLOAD, EXTRACT_CHAPTERS, FIND_SERIES_PAGE, EXTRACT_MULTI_ENGINE };
