plugins { id("com.android.application") }

android {
    namespace = "com.mangahub.pdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mangahub.pdf"
        minSdk = 24
        targetSdk = 35
        versionCode = 33
        versionName = "2.3.0-auto-engine"
    }

    buildTypes { release { isMinifyEnabled = false } }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
