package com.mangahub.pdf;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService pool = Executors.newFixedThreadPool(10);
    private static final String UA = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36";
    private final Set<String> inFlight = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.addJavascriptInterface(new Bridge(), "AndroidNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void callback(String fn, String json) {
        runOnUiThread(() -> webView.evaluateJavascript("window." + fn + "(" + json + ")", null));
    }

    public class Bridge {
        @JavascriptInterface public void search(String query) {
            pool.execute(() -> {
                try { callback("onSearchResults", searchAll(query)); }
                catch (Exception e) { callback("onSearchResults", obj("error", e.getMessage())); }
            });
        }

        @JavascriptInterface public void details(String url, String source) {
            pool.execute(() -> {
                try { callback("onDetails", getDetails(url, source)); }
                catch (Exception e) { callback("onDetails", obj("error", e.getMessage())); }
            });
        }

        @JavascriptInterface public String jobId(String chapterUrl) {
            return sha1(chapterUrl);
        }

        @JavascriptInterface public void download(String chapterUrl, String seriesTitle, String chapterLabel) {
            queueNativeDownload(chapterUrl, seriesTitle, chapterLabel);
        }

        @JavascriptInterface public void downloadBatch(String chaptersJson, String seriesTitle) {
            try {
                JSONArray a = new JSONArray(chaptersJson);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject x = a.getJSONObject(i);
                    String url = x.optString("url", "");
                    String label = x.optString("label", "Chapitre");
                    if (!url.isEmpty()) queueNativeDownload(url, seriesTitle, label);
                }
            } catch (Exception e) {
                callback("onBatchMessage", obj("error", e.getMessage()));
            }
        }

        @JavascriptInterface public String loadJobs() {
            return getPreferences(MODE_PRIVATE).getString("jobs", "[]");
        }

        @JavascriptInterface public void saveJobs(String json) {
            getPreferences(MODE_PRIVATE).edit().putString("jobs", json).apply();
        }

        @JavascriptInterface public void fetchExtensionIndex(String url) {
            pool.execute(() -> {
                try { callback("onExtensionIndex", quote(fetch(url))); }
                catch (Exception e) { callback("onExtensionIndex", obj("error", e.getMessage())); }
            });
        }
    }

    private void queueNativeDownload(String chapterUrl, String seriesTitle, String chapterLabel) {
        final String id = sha1(chapterUrl);
        if (!inFlight.add(id)) {
            status(id, "QUEUED", 0, chapterLabel, "Déjà présent dans la file");
            return;
        }
        status(id, "QUEUED", 0, chapterLabel, "En attente d’un slot");
        pool.execute(() -> {
            try { downloadChapter(chapterUrl, seriesTitle, chapterLabel); }
            finally { inFlight.remove(id); }
        });
    }

    private String searchAll(String q) throws Exception {
        List<String> items = Collections.synchronizedList(new ArrayList<String>());
        LinkedHashMap<String,String> states = new LinkedHashMap<>();
        String enc = URLEncoder.encode(q, "UTF-8");
        String slug = slugify(q);

        // Each source has search endpoints plus a deterministic catalogue fallback.
        SearchSource[] sources = new SearchSource[] {
            new SearchSource("SushiScan", new String[]{
                "https://sushiscan.fr/?s=" + enc,
                "https://sushiscan.net/?s=" + enc,
                "https://sushiscan.fr/catalogue/" + slug + "/",
                "https://sushiscan.net/catalogue/" + slug + "/"
            }),
            new SearchSource("OrtegaScans", new String[]{
                "https://ortegascans.fr/serie/" + slug,
                "https://ortegascans.fr/?s=" + enc
            }),
            new SearchSource("Mangas-Origines", new String[]{
                "https://mangas-origines.fr/?s=" + enc,
                "https://mangas-origines.fr/oeuvre/" + slug + "/"
            }),
            new SearchSource("ToonFR", new String[]{
                "https://toonfr.com/?s=" + enc,
                "https://toonfr.com/webtoon/" + slug + "/"
            }),
            new SearchSource("HentaiZone", new String[]{
                "https://hentaizone.xyz/?s=" + enc,
                "https://hentaizone.xyz/manga/" + slug + "/"
            })
        };

        java.util.concurrent.ExecutorService searchPool = Executors.newFixedThreadPool(5);
        List<java.util.concurrent.Future<String>> futures = new ArrayList<>();

        for (SearchSource src : sources) {
            futures.add(searchPool.submit(() -> {
                int before;
                synchronized(items){ before=items.size(); }
                String lastError = "";
                for (String u : src.urls) {
                    try {
                        String html = fetch(u);
                        int foundBefore;
                        synchronized(items){ foundBefore=items.size(); }
                        collectSearch(html, src.name, q, items, u);

                        // Catalogue/direct page fallback: if this URL is clearly a
                        // series page and its title matches, add it as a result.
                        if (isSeriesPage(html, u, q)) {
                            String title = extractPageTitle(html);
                            String cover = extractCover(html, u);
                            String item = "{\"title\":"+quote(title)+",\"url\":"+quote(u)+",\"source\":"+quote(src.name)+",\"image\":"+quote(cover)+"}";
                            synchronized(items){ if(!items.contains(item)) items.add(item); }
                        }

                        synchronized(items){
                            if(items.size()>foundBefore) return src.name + "|OK";
                        }
                    } catch(Exception ex) {
                        lastError = ex.getMessage()==null ? ex.getClass().getSimpleName() : ex.getMessage();
                    }
                }
                synchronized(items){
                    if(items.size()>before) return src.name + "|OK";
                }
                return src.name + "|" + (lastError.isEmpty() ? "AUCUN_RESULTAT" : "INDISPONIBLE");
            }));
        }

        for (java.util.concurrent.Future<String> f : futures) {
            try {
                String r=f.get(35, java.util.concurrent.TimeUnit.SECONDS);
                int p=r.indexOf('|');
                if(p>0) states.put(r.substring(0,p),r.substring(p+1));
            } catch(Exception ex) {}
        }
        searchPool.shutdownNow();

        // Deduplicate by normalized source + URL, not by raw JSON string.
        LinkedHashMap<String,String> unique = new LinkedHashMap<>();
        synchronized(items){
            for(String it:items){
                try{
                    JSONObject o=new JSONObject(it);
                    String key=o.optString("source")+"|"+o.optString("url");
                    unique.put(key,it);
                }catch(Exception ignored){}
            }
        }

        List<String> stateJson=new ArrayList<>();
        for(Map.Entry<String,String> x:states.entrySet()){
            stateJson.add("{\"source\":"+quote(x.getKey())+",\"state\":"+quote(x.getValue())+"}");
        }
        return "{\"items\":[" + String.join(",", unique.values()) + "],\"sources\":[" + String.join(",",stateJson) + "]}";
    }

    private static class SearchSource {
        String name; String[] urls;
        SearchSource(String n,String[] u){name=n;urls=u;}
    }

    private String slugify(String s){
        String n=java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}","")
                .replaceAll("[^a-z0-9]+","-")
                .replaceAll("(^-|-$)","");
        return n;
    }

    private boolean isSeriesPage(String html,String url,String query){
        String lower=html.toLowerCase(Locale.ROOT);
        String uq=url.toLowerCase(Locale.ROOT);
        if(!(uq.contains("/serie/")||uq.contains("/catalogue/")||uq.contains("/oeuvre/")||uq.contains("/webtoon/")||uq.contains("/manga/"))) return false;
        String title=normalize(extractPageTitle(html));
        String q=normalize(query);
        return !title.isEmpty() && (title.contains(q) || q.contains(title));
    }

    private String extractPageTitle(String html){
        String t=first(html,"(?is)<h1[^>]*>(.*?)</h1>");
        if(t.isEmpty()) t=first(html,"(?is)<meta[^>]+property=[\\\"']og:title[\\\"'][^>]+content=[\\\"']([^\\\"']+)");
        if(t.isEmpty()) t=first(html,"(?is)<title[^>]*>(.*?)</title>");
        return strip(t).replace("- SushiScan","").replace("- Scans vf | Ortega Scans","").trim();
    }

    private String extractCover(String html,String base){
        String c=first(html,"(?is)<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)");
        if(c.isEmpty()) c=first(html,"(?is)<img[^>]+(?:class=[\\\"'][^\\\"']*(?:poster|cover|thumb)[^\\\"']*[\\\"'][^>]+)?(?:src|data-src)=[\\\"']([^\\\"']+)[\\\"']");
        return c.isEmpty()?"":absolute(base,c);
    }

    private void collectSearch(String html, String source, String query, List<String> out, String baseUrl) {
        Pattern p = Pattern.compile("(?is)<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>");
        Matcher m = p.matcher(html);
        String q = normalize(query);
        int count = 0;
        while (m.find() && count < 80) {
            String href = absolute(baseUrl, decode(m.group(1)));
            String text = strip(m.group(2));
            if (text.length() < 2 || !normalize(text).contains(q)) continue;
            if (!href.startsWith("http")) continue;
            String hl=href.toLowerCase(Locale.ROOT);
            if (hl.contains("/tag/") || hl.contains("/genre") || hl.contains("/author") || href.contains("#") ||
                hl.contains("/chapter/") || hl.contains("/chapitre-")) continue;
            String image = findNearbyImage(html, m.start(), m.end());
            if(!image.isEmpty()) image=absolute(baseUrl,image);
            out.add("{\"title\":"+quote(text)+",\"url\":"+quote(href)+",\"source\":"+quote(source)+",\"image\":"+quote(image)+"}");
            count++;
        }
    }

    private String getDetails(String url, String source) throws Exception {
        String html = fetch(url);
        String title = first(html, "(?is)<h1[^>]*>(.*?)</h1>");
        if (title.isEmpty()) title = first(html, "(?is)<title[^>]*>(.*?)</title>");
        title = strip(title).replace("- SushiScan", "").trim();
        String cover = first(html, "(?is)<img[^>]+(?:class=[\\\"'][^\\\"']*(?:poster|cover|thumb)[^\\\"']*[\\\"'][^>]+)?src=[\\\"']([^\\\"']+)[\\\"']");
        if (cover.isEmpty()) cover = first(html, "(?is)<meta[^>]+property=[\\\"']og:image[\\\"'][^>]+content=[\\\"']([^\\\"']+)");

        Pattern p = Pattern.compile("(?is)<a[^>]+href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>");
        Matcher m = p.matcher(html);
        List<String> ch = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        while (m.find()) {
            String href = decode(m.group(1));
            String label = strip(m.group(2));
            String all = (href + " " + label).toLowerCase(Locale.ROOT);
            if (!(all.contains("chapitre") || all.contains("chapter") || all.matches(".*\\bch\\.?\\s*\\d+.*"))) continue;
            if (!href.startsWith("http") || seen.contains(href)) continue;
            seen.add(href);
            if (label.isEmpty()) label = href;
            ch.add("{\"label\":"+quote(label)+",\"url\":"+quote(href)+"}");
        }
        return "{\"title\":"+quote(title)+",\"source\":"+quote(source)+",\"url\":"+quote(url)+",\"cover\":"+quote(cover)+",\"chapters\":["+String.join(",", ch)+"]}";
    }

    private void downloadChapter(String chapterUrl, String seriesTitle, String chapterLabel) {
        String job = sha1(chapterUrl);
        try {
            status(job, "ANALYSE", 0, chapterLabel, "Analyse de la page");
            String html = fetch(chapterUrl);
            String accessState = classifyAccess(html);
            if ("PREMIUM".equals(accessState)) {
                status(job, "PREMIUM", 0, chapterLabel, "Chapitre verrouillé / premium");
                return;
            }
            if ("FIN".equals(accessState)) {
                status(job, "FIN", 0, chapterLabel, "Chapitre inexistant ou non publié");
                return;
            }
            EngineResult er = selectBestEngine(html, chapterUrl);
            List<String> imgs = er.images;
            if (imgs.isEmpty()) throw new IOException("Aucun moteur n’a détecté de vraies pages");
            status(job, "ANALYSE", 5, chapterLabel, "AUTO ENGINE → " + er.name + " · " + imgs.size() + " pages · " + er.elapsedMs + " ms");
            File dir = new File(getCacheDir(), "chapters/" + job); if (!dir.exists()) dir.mkdirs();
            List<File> pages = new ArrayList<>();
            int done = 0;
            for (int i=0;i<imgs.size();i++) {
                File f = new File(dir, String.format(Locale.US, "%04d.img", i+1));
                if (!f.exists() || f.length() < 1024) downloadFileWithRetry(imgs.get(i), chapterUrl, f);
                pages.add(f); done++;
                status(job, "DOWNLOAD", (done*80)/imgs.size(), chapterLabel, done + "/" + imgs.size() + " pages");
            }
            List<File> filteredPages = filterReaderPages(pages);
            if (filteredPages.isEmpty()) throw new IOException("Aucune vraie page de scan après filtrage");
            status(job, "PDF", 85, chapterLabel, "Création PDF · " + filteredPages.size() + " pages retenues");
            File pdf = new File(getCacheDir(), job + ".part.pdf");
            buildPdf(filteredPages, pdf);
            String name = safe(seriesTitle) + "_" + safeChapter(chapterLabel) + ".pdf";
            savePdf(pdf, name);
            status(job, "SAVED", 100, chapterLabel, name);
        } catch (Exception e) {
            String msg = e.getMessage()==null?e.toString():e.getMessage();
            String state = (msg.contains("403")||msg.contains("429")) ? "BLOQUE" : "ERREUR";
            status(job, state, 0, chapterLabel, msg);
        }
    }

    private static class EngineResult {
        String name; List<String> images; long elapsedMs; int score;
        EngineResult(String n,List<String> i,long ms,int sc){name=n;images=i;elapsedMs=ms;score=sc;}
    }

    private EngineResult selectBestEngine(String html, String baseUrl) {
        List<EngineResult> all = new ArrayList<>();
        String host = "";
        try { host = new URL(baseUrl).getHost().toLowerCase(Locale.ROOT); } catch(Exception ignored) {}
        String preferred = getPreferences(MODE_PRIVATE).getString("engine_"+host, "");

        // The previous winner is tested first, then every engine competes.
        int[] order = {5,1,2,3,4};
        if (!preferred.isEmpty()) {
            try { int p=Integer.parseInt(preferred); order=new int[]{p,5,1,2,3,4}; } catch(Exception ignored) {}
        }
        LinkedHashSet<Integer> unique = new LinkedHashSet<>(); for(int x:order) unique.add(x);
        for(int engine:unique) {
            long t=System.currentTimeMillis();
            List<String> imgs=extractWithEngine(html,baseUrl,engine);
            long ms=Math.max(1,System.currentTimeMillis()-t);
            int score=engineScore(imgs,ms,engine,baseUrl);
            all.add(new EngineResult("Moteur "+engine,imgs,ms,score));
            // Fast path: preferred/source engine has a strong continuous chapter block.
            if ((String.valueOf(engine).equals(preferred) || engine==5) && imgs.size()>=8 && score>=850) break;
        }
        EngineResult best=new EngineResult("Aucun",new ArrayList<>(),0,-9999);
        for(EngineResult r:all) if(r.score>best.score) best=r;
        if(!best.images.isEmpty()) {
            String n=best.name.replace("Moteur ","");
            getPreferences(MODE_PRIVATE).edit().putString("engine_"+host,n).apply();
        }
        return best;
    }

    private int engineScore(List<String> imgs,long ms,int engine,String baseUrl) {
        if(imgs==null || imgs.isEmpty()) return -10000;
        int score=Math.min(60,imgs.size())*18;
        score-=Math.min(350,(int)(ms/3));
        if(imgs.size()>=8) score+=220;
        if(engine==5) score+=120; // source/API reader block is normally the cleanest
        return score;
    }

    private List<String> extractWithEngine(String html,String baseUrl,int engine) {
        LinkedHashMap<String,Candidate> map=new LinkedHashMap<>(); int pos=0;
        if(engine==1){
            Matcher m=Pattern.compile("(?is)<img\\b[^>]*?\\bsrc\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*>").matcher(html);
            while(m.find()) addCandidate(map,m.group(1),baseUrl,1,pos++);
        } else if(engine==2){
            Matcher m=Pattern.compile("(?is)<(?:img|source)\\b[^>]*?\\b(?:data-src|data-original|data-lazy-src|data-url|data-image|data-cfsrc|data-echo|data-lazy)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*>").matcher(html);
            while(m.find()) addCandidate(map,m.group(1),baseUrl,2,pos++);
            Matcher ss=Pattern.compile("(?is)\\b(?:srcset|data-srcset)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']").matcher(html);
            while(ss.find()) for(String part:ss.group(1).split(",")) addCandidate(map,part.trim().split("\\s+")[0],baseUrl,2,pos++);
        } else if(engine==3){
            Matcher m=Pattern.compile("(?is)[\\\"'](?:url|src|image|image_url|imageUrl|page|file)[\\\"']\\s*:\\s*[\\\"']([^\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
            while(m.find()) addCandidate(map,m.group(1).replace("\\/","/"),baseUrl,3,pos++);
        } else if(engine==4){
            Matcher m=Pattern.compile("(?is)<a\\b[^>]*?href\\s*=\\s*[\\\"']([^\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
            while(m.find()) addCandidate(map,m.group(1),baseUrl,4,pos++);
            Matcher css=Pattern.compile("(?is)url\\(\\s*[\\\"']?([^\\)\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\)\\\"']*)?)[\\\"']?\\s*\\)").matcher(html);
            while(css.find()) addCandidate(map,css.group(1),baseUrl,4,pos++);
        } else {
            // Source-specific engine: Ortega API blocks and SushiScan reader CDN.
            List<String> generic=extractReaderImages(html,baseUrl);
            String b=baseUrl.toLowerCase(Locale.ROOT);
            for(String u:generic){
                String l=u.toLowerCase(Locale.ROOT);
                if((b.contains("sushiscan") && l.contains("yaoiscan.fr/")) ||
                   (b.contains("ortega") && (l.contains("/api/chapters/") || l.contains("/image/"))) ||
                   (!b.contains("sushiscan") && !b.contains("ortega"))) addCandidate(map,u,baseUrl,5,pos++);
            }
        }
        List<Candidate> cs=new ArrayList<>(map.values());
        cs.sort((a,b)->{int ia=imageIndex(a.url),ib=imageIndex(b.url);if(ia>=0&&ib>=0&&ia!=ib)return Integer.compare(ia,ib);return Integer.compare(a.position,b.position);});
        LinkedHashSet<String> out=new LinkedHashSet<>();
        for(Candidate c:cs) if(!looksDecorative(c.url.toLowerCase(Locale.ROOT))) out.add(c.url);
        return new ArrayList<>(out);
    }

    private List<String> extractReaderImages(String html, String baseUrl) {
        // Multi-Engine port inspired by the proven Chapter PDF Downloader pipeline.
        // E1: reader DOM/src, E2: lazy/srcset/noscript, E3: JSON/JS,
        // E4: anchors/CSS, E5: source-specific/API ordering + cleanup.
        LinkedHashMap<String, Candidate> map = new LinkedHashMap<>();
        int pos = 0;

        // Engine 1 — normal reader <img src>.
        Matcher e1 = Pattern.compile("(?is)<img\\b[^>]*?\\bsrc\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*>").matcher(html);
        while (e1.find()) addCandidate(map, e1.group(1), baseUrl, 1, pos++);

        // Engine 2 — lazy attributes, srcset, picture/source and noscript.
        Matcher e2 = Pattern.compile("(?is)<(?:img|source)\\b[^>]*?\\b(?:data-src|data-original|data-lazy-src|data-url|data-image|data-cfsrc|data-echo|data-lazy)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*>").matcher(html);
        while (e2.find()) addCandidate(map, e2.group(1), baseUrl, 2, pos++);
        Matcher srcset = Pattern.compile("(?is)\\b(?:srcset|data-srcset)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']").matcher(html);
        while (srcset.find()) {
            for (String part : srcset.group(1).split(",")) {
                String u = part.trim().split("\\s+")[0];
                addCandidate(map, u, baseUrl, 2, pos++);
            }
        }
        Matcher noscript = Pattern.compile("(?is)<noscript[^>]*>(.*?)</noscript>").matcher(html);
        while (noscript.find()) {
            Matcher im = Pattern.compile("(?is)(?:src|data-src)\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']").matcher(noscript.group(1));
            while (im.find()) addCandidate(map, im.group(1), baseUrl, 2, pos++);
        }

        // Engine 3 — raw HTML / JSON / JavaScript reader configs.
        Matcher e3 = Pattern.compile("(?is)[\\\"']((?:https?:)?\\\\?/\\\\?/[^\\\"']+?\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
        while (e3.find()) addCandidate(map, e3.group(1).replace("\\/", "/"), baseUrl, 3, pos++);
        Matcher e3b = Pattern.compile("(?is)[\\\"'](?:url|src|image|image_url|imageUrl|page|file)[\\\"']\\s*:\\s*[\\\"']([^\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
        while (e3b.find()) addCandidate(map, e3b.group(1).replace("\\/", "/"), baseUrl, 3, pos++);

        // Engine 4 — direct image links and CSS url().
        Matcher e4 = Pattern.compile("(?is)<a\\b[^>]*?href\\s*=\\s*[\\\"']([^\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\\"']*)?)[\\\"']").matcher(html);
        while (e4.find()) addCandidate(map, e4.group(1), baseUrl, 4, pos++);
        Matcher css = Pattern.compile("(?is)url\\(\\s*[\\\"']?([^\\)\\\"']+\\.(?:jpe?g|png|webp|avif)(?:\\?[^\\)\\\"']*)?)[\\\"']?\\s*\\)").matcher(html);
        while (css.find()) addCandidate(map, css.group(1), baseUrl, 4, pos++);

        List<Candidate> candidates = new ArrayList<>(map.values());

        // Engine 5 — if Ortega/API chapter images are present, isolate and numerically sort
        // that continuous reader block instead of mixing logos/recommendations.
        List<Candidate> api = new ArrayList<>();
        for (Candidate c : candidates) {
            if (c.url.matches("(?i).*\\/api\\/chapters\\/[^/]+\\/[^/]+\\/image\\/\\d+\\.(?:jpe?g|png|webp|avif)(?:\\?.*)?$")) {
                api.add(c);
            }
        }
        if (!api.isEmpty()) {
            api.sort(Comparator.comparingInt(c -> imageIndex(c.url)));
            candidates = api;
        } else {
            List<Candidate> sushiReader = new ArrayList<>();
            if (baseUrl.toLowerCase(Locale.ROOT).contains("sushiscan")) {
                for (Candidate c : candidates) {
                    String u = c.url.toLowerCase(Locale.ROOT);
                    if (u.contains("yaoiscan.fr/") || u.matches(".*://s\\d+\\.yaoiscan\\.fr/.*")) {
                        sushiReader.add(c);
                    }
                }
            }
            if (!sushiReader.isEmpty()) {
                sushiReader.sort((a,b) -> {
                    int ia=imageIndex(a.url), ib=imageIndex(b.url);
                    if(ia>=0 && ib>=0 && ia!=ib) return Integer.compare(ia,ib);
                    return Integer.compare(a.position,b.position);
                });
                candidates = sushiReader;
            } else {
                candidates.sort((a,b) -> {
                    int ia = imageIndex(a.url), ib = imageIndex(b.url);
                    if (ia >= 0 && ib >= 0 && ia != ib) return Integer.compare(ia, ib);
                    return Integer.compare(a.position, b.position);
                });
            }
        }

        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (Candidate c : candidates) {
            String l = c.url.toLowerCase(Locale.ROOT);
            if (looksDecorative(l)) continue;
            out.add(c.url);
        }
        return new ArrayList<>(out);
    }

    private static class Candidate {
        String url; int engine; int position;
        Candidate(String u, int e, int p) { url=u; engine=e; position=p; }
    }

    private void addCandidate(Map<String,Candidate> map, String raw, String base, int engine, int position) {
        if (raw == null) return;
        String v = decode(raw.trim()).replace("\\/", "/");
        if (v.startsWith("//")) {
            try { v = new URL(base).getProtocol() + ":" + v; } catch(Exception ignored) {}
        }
        String u = absolute(base, v);
        if (u == null || !u.startsWith("http")) return;
        String l = u.toLowerCase(Locale.ROOT);
        if (!l.matches(".*\\.(jpg|jpeg|png|webp|avif)(\\?.*)?$")) return;
        String key = u.replaceAll("#.*$", "");
        if (!map.containsKey(key)) map.put(key, new Candidate(u, engine, position));
    }

    private boolean looksDecorative(String l) {
        return l.contains("logo") || l.contains("avatar") || l.contains("icon") ||
               l.contains("emoji") || l.contains("banner") || l.contains("adsense") ||
               l.contains("/ads/") || l.contains("/ad/") || l.contains("advert") ||
               l.contains("publicite") || l.contains("promo") || l.contains("sponsor") ||
               l.contains("sprite") || l.contains("placeholder") || l.contains("loading") ||
               l.contains("spacer") || l.contains("favicon") || l.contains("recommend") ||
               l.contains("related") || l.contains("thumbnail") || l.contains("thumb");
    }

    private int imageIndex(String u) {
        Matcher m = Pattern.compile("(?i)(?:/image/|[_\\-/])(\\d{1,4})(?:\\.(?:jpe?g|png|webp|avif)|[_\\-])").matcher(u);
        int last = -1;
        while (m.find()) {
            try { last = Integer.parseInt(m.group(1)); } catch(Exception ignored) {}
        }
        return last;
    }

    private String classifyAccess(String html) {
        String t = strip(html).toLowerCase(Locale.ROOT);
        if (t.matches("(?s).*(premium chapter|chapitre premium|subscription required|subscribe to read|unlock chapter|purchase chapter|paywall|vip chapter|contenu verrouill[eé]).*")) return "PREMIUM";
        if (t.matches("(?s).*(chapter not found|chapitre introuvable|page not found|404 not found|ce chapitre n.existe pas|chapitre non disponible).*")) return "FIN";
        return "OK";
    }

    private void downloadFileWithRetry(String url, String referer, File out) throws Exception {
        Exception last = null;
        for (int attempt=1; attempt<=3; attempt++) {
            try {
                downloadFile(url, referer, out);
                Bitmap bm = BitmapFactory.decodeFile(out.getAbsolutePath());
                if (bm == null || bm.getWidth() < 120 || bm.getHeight() < 120) {
                    if (bm != null) bm.recycle();
                    out.delete();
                    throw new IOException("Réponse image invalide");
                }
                bm.recycle();
                return;
            } catch (Exception e) {
                last = e;
                if (out.exists()) out.delete();
                try { Thread.sleep(600L * attempt); } catch (InterruptedException ignored) {}
            }
        }
        throw last == null ? new IOException("Image inaccessible") : last;
    }

    private void downloadFile(String url, String referer, File out) throws Exception {
        HttpURLConnection c = open(url, referer);
        int code = c.getResponseCode(); if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " image");
        try (InputStream in = new BufferedInputStream(c.getInputStream()); OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
            byte[] b = new byte[65536]; int n; while ((n=in.read(b))!=-1) os.write(b,0,n);
        } finally { c.disconnect(); }
    }

    private List<File> filterReaderPages(List<File> input) {
        class G {
            File f; int w,h; long area;
            G(File f,int w,int h){this.f=f;this.w=w;this.h=h;this.area=(long)w*h;}
        }
        List<G> gs=new ArrayList<>();
        for(File f:input){
            BitmapFactory.Options o=new BitmapFactory.Options();
            o.inJustDecodeBounds=true;
            BitmapFactory.decodeFile(f.getAbsolutePath(),o);
            if(o.outWidth>0 && o.outHeight>0) gs.add(new G(f,o.outWidth,o.outHeight));
        }
        if(gs.size()<=3){
            List<File> all=new ArrayList<>();
            for(G g:gs) all.add(g.f);
            return all;
        }

        List<Long> areas=new ArrayList<>();
        List<Integer> widths=new ArrayList<>();
        for(G g:gs){areas.add(g.area);widths.add(g.w);}
        Collections.sort(areas);
        Collections.sort(widths);
        long medianArea=areas.get(areas.size()/2);
        int medianWidth=widths.get(widths.size()/2);

        List<File> out=new ArrayList<>();
        for(G g:gs){
            double ratio=(double)g.h/Math.max(1,g.w);
            boolean tiny = g.w < Math.max(220,(int)(medianWidth*0.45)) ||
                           g.area < Math.max(90000L,(long)(medianArea*0.22));
            boolean banner = ratio < 0.48 && g.w > medianWidth*0.70;
            boolean narrowThumb = g.w < medianWidth*0.58 && g.area < medianArea*0.55;
            if(tiny || banner || narrowThumb) continue;
            out.add(g.f);
        }

        if(out.size() < Math.max(2, gs.size()/2)){
            out.clear();
            for(G g:gs){
                double ratio=(double)g.h/Math.max(1,g.w);
                if(g.w>=220 && g.h>=220 && ratio>=0.45) out.add(g.f);
            }
        }
        return out;
    }

    private void buildPdf(List<File> pages, File out) throws Exception {
        PdfDocument doc = new PdfDocument(); int pageNo=1;
        try {
            for (File f: pages) {
                Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath()); if (bm==null) continue;
                int w=bm.getWidth(), h=bm.getHeight();
                int max=14000; if (w>max || h>max) { double sc=Math.min((double)max/w,(double)max/h); w=(int)(w*sc); h=(int)(h*sc); }
                PdfDocument.PageInfo pi = new PdfDocument.PageInfo.Builder(Math.max(1,w), Math.max(1,h), pageNo++).create();
                PdfDocument.Page p=doc.startPage(pi); Canvas c=p.getCanvas(); c.drawBitmap(bm,null,new android.graphics.Rect(0,0,w,h),null); doc.finishPage(p); bm.recycle();
            }
            try (FileOutputStream fos=new FileOutputStream(out)) { doc.writeTo(fos); fos.getFD().sync(); }
        } finally { doc.close(); }
    }

    private void savePdf(File src, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MangaHub PDF"); v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(uri==null) throw new IOException("Impossible de créer le PDF");
            try(OutputStream os=getContentResolver().openOutputStream(uri); InputStream in=new FileInputStream(src)){ byte[] b=new byte[65536]; int n; while((n=in.read(b))!=-1) os.write(b,0,n); }
            v.clear(); v.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(uri,v,null,null);
        } else {
            File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"MangaHub PDF"); if(!dir.exists()) dir.mkdirs();
            try(InputStream in=new FileInputStream(src); OutputStream os=new FileOutputStream(new File(dir,name))){byte[]b=new byte[65536];int n;while((n=in.read(b))!=-1)os.write(b,0,n);}        }
    }

    private void status(String id,String state,int pct,String label,String message){ callback("onJobStatus","{\"id\":"+quote(id)+",\"state\":"+quote(state)+",\"progress\":"+pct+",\"label\":"+quote(label)+",\"message\":"+quote(message)+"}"); }

    private String fetch(String url) throws Exception {
        HttpURLConnection c=open(url,url); int code=c.getResponseCode(); if(code<200||code>=400) throw new IOException("HTTP "+code);
        InputStream in=code>=300?c.getErrorStream():c.getInputStream(); ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[]b=new byte[32768]; int n; while((n=in.read(b))!=-1)o.write(b,0,n); c.disconnect(); return new String(o.toByteArray(), StandardCharsets.UTF_8);
    }
    private HttpURLConnection open(String url,String referer) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(18000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true); c.setRequestProperty("User-Agent",UA); c.setRequestProperty("Accept","text/html,image/avif,image/webp,image/*,*/*;q=0.8"); c.setRequestProperty("Referer",referer); return c; }

    private String findNearbyImage(String html,int s,int e){ int a=Math.max(0,s-1000), b=Math.min(html.length(),e+1000); return first(html.substring(a,b),"(?is)<img[^>]+(?:src|data-src)=[\\\"']([^\\\"']+)[\\\"']"); }
    private String first(String s,String regex){Matcher m=Pattern.compile(regex).matcher(s);return m.find()?decode(m.group(1)):"";}
    private String strip(String s){return decode(s.replaceAll("(?is)<[^>]+>"," ").replaceAll("\\s+"," ").trim());}
    private String decode(String s){return s.replace("&amp;","&").replace("&quot;","\"").replace("&#039;","'").replace("&lt;","<").replace("&gt;",">");}
    private String normalize(String s){return java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT),java.text.Normalizer.Form.NFD).replaceAll("\\p{M}","").replaceAll("[^a-z0-9]+"," ").trim();}
    private String absolute(String base,String u){try{return new URL(new URL(base),u).toString();}catch(Exception e){return u;}}
    private String safe(String s){return s.replaceAll("[\\\\/:*?\"<>|]+"," ").trim().replaceAll("\\s+","_");}
    private String safeChapter(String s){Matcher m=Pattern.compile("(\\d+(?:\\.\\d+)?)").matcher(s);return m.find()?String.format(Locale.US,"%03d",(int)Double.parseDouble(m.group(1))):safe(s);}
    private String sha1(String s){try{MessageDigest md=MessageDigest.getInstance("SHA-1");byte[]d=md.digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte x:d)b.append(String.format("%02x",x));return b.toString();}catch(Exception e){return Integer.toHexString(s.hashCode());}}
    private String quote(String s){if(s==null)s="";return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","")+"\"";}
    private String obj(String k,String v){return "{\""+k+"\":"+quote(v)+"}";}

    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack(); else super.onBackPressed(); }
}
