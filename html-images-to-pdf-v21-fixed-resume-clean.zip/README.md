# HTML Images vers PDF V21

Version corrigée après audit du JavaScript.

## Corrections critiques
- correction de l’erreur `resumeEnabled is not defined`;
- correction des balises script mal fermées qui pouvaient faire ignorer des fonctions dans Chrome;
- une seule implémentation des fonctions de reprise et de doublons;
- reprise intelligente vérifiée par empreinte SHA-256;
- les fichiers déjà terminés sont ignorés lors du prochain import du même dossier;
- les fichiers ayant échoué sont réessayés;
- bouton pour effacer l’historique de reprise;
- les doublons strictement identiques sont supprimés automatiquement de la sortie principale;
- `DOUBLONS_A_VERIFIER/` contient le rapport et seulement les variantes suspectes non strictement identiques;
- rapports de reprise et de doublons également écrits dans le vrai dossier de sortie quand le navigateur l’autorise;
- tri, classement, normalisation des images, téléchargement immédiat et ZIP final conservés.
