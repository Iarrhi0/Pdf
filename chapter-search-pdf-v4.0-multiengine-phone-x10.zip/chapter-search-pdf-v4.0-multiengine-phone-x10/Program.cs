using ChapterSearchPdfV3.Services;

namespace ChapterSearchPdfV3;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        StartupLogger.Initialize();
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => StartupLogger.Fatal("UI", e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) => StartupLogger.Fatal("APPDOMAIN", e.ExceptionObject as Exception ?? new Exception(e.ExceptionObject?.ToString()));
        TaskScheduler.UnobservedTaskException += (_, e) => { StartupLogger.Log("TASK", e.Exception); e.SetObserved(); };

        try
        {
            ApplicationConfiguration.Initialize();
            StartupLogger.Log("BOOT", "ApplicationConfiguration OK");
            Application.Run(new MainForm());
        }
        catch (Exception ex)
        {
            StartupLogger.Fatal("STARTUP", ex);
        }
    }
}
