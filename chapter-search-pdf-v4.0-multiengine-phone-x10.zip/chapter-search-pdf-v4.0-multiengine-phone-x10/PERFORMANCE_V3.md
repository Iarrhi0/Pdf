# Réglages performance V3

- Chapitres actifs : 10
- Renderers JavaScript : 3
- Téléchargement par chapitre : 1 page à la fois
- Connexions serveur disponibles : 20
- Recherche multi-site : 8 sources en parallèle
- Conversion image : 2 maximum
- PDF : streaming page par page
- UI : rafraîchissement 700 ms
- User-Agent render/download : Android
- Retry image : 3
- Recovery chapitre : 1 rerender complet avant ERROR

Objectif : conserver la vitesse et la tolérance de l'app téléphone tout en évitant de faire correspondre 10 téléchargements à 10 navigateurs lourds.
