# Chapter Search PDF PC V4.0 — Multi-Analyse + Phone x10

Version Windows native .NET 8 + WebView2.

Le moteur de chapitre conserve APK40 + ENGINE5-JAVA. L'analyse de série utilise maintenant cinq stratégies S1→S5 et un adaptateur SushiScan/Madara. Le téléchargement reproduit la tolérance Android: chaque candidat image est validé indépendamment; une mauvaise page est ignorée au lieu d'arrêter le chapitre entier.

## Build GitHub
Utiliser `.github/workflows/build-windows-v4.yml` ou remplacer votre `.github/workflows/build-windows.yml` par le workflow fourni séparément.

Artifacts:
- `Chapter-Search-PDF-V4-LIGHT-x64`
- `Chapter-Search-PDF-V4-STANDALONE-x64`

Le fichier exécutable est `ChapterSearchPdfV4.exe`.
