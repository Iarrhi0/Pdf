# Pipeline V3

Navigation visible (WebView2)
        |
Analyse série stricte
        |
10 jobs maximum
        |
3 renderers WebView2 partagés
        |
DOM principal -> lazy load -> APK40 -> E1/E2/E3/E4 -> ENGINE 5 JAVA
        |
renderer libéré immédiatement
        |
10 téléchargements HTTP simultanés
(1 page à la fois par chapitre)
        |
validation / conversion seulement si nécessaire
        |
PDF streaming sur disque

## Pourquoi cette architecture

La V2 Electron pouvait multiplier les processus renderer et garder des buffers d'images lourds. V3 sépare le rendu JavaScript, qui coûte du CPU/RAM, du transfert réseau, qui peut rester largement parallèle sans ouvrir dix navigateurs.
