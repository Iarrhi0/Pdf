# Chapter Search PDF V4.0

## Moteur de série réellement multi-moteur
- S1: conteneurs de chapitres explicites (Madara/SushiScan/générique)
- S2: listes déroulantes `select/option` et attributs data-url
- S3: URLs appartenant strictement à la même série
- S4: navigation Précédent/Suivant
- S5: URLs cohérentes trouvées dans le HTML/JSON rendu
- Les résultats sont fusionnés par numéro avec priorité aux sources les plus fiables.
- Depuis un chapitre SushiScan, la V4 suit le breadcrumb / lien « Tous les chapitres sont dans … » vers la fiche série.

## Téléchargement PHONE MODE x10
- 10 chapitres peuvent rester actifs simultanément.
- Une image 403/404/429, HTML ou non décodable est IGNORÉE; le chapitre continue.
- Pas de rerender après une seule mauvaise page.
- Recovery APK40 + JAVA5 seulement si le passage complet fournit moins de 2 vraies pages.
- HTTP 416 est rejoué une fois, comme dans l'APK.
- États visibles: `DOWN 17/40 • 16 OK • 1 IGN` puis `SAVED • 39/40 pages`.

## Rendu WebView2
- `ConnectionAborted` et `OperationCanceled` ne sont plus considérés comme fatals si le DOM principal arrive.
- APK40 et ENGINE5-JAVA restent actifs pour chaque chapitre.

## Performance
- WebView2 natif: pas d'Electron/Chromium embarqué.
- 3 renderers max, 10 téléchargements de chapitres actifs.
- PDF en streaming disque, conversions limitées à 2.
