(function(){try{
  document.querySelectorAll('img').forEach(function(i){
    ['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){var v=i.getAttribute(a);if(v&&!i.src)i.src=v;});
    i.loading='eager';
  });
  window.scrollTo(0,document.body.scrollHeight);
  return 'ok';
}catch(e){return 'err';}})();