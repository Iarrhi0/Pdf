(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function chapNo(s){var m=(s||'').match(/(?:chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=(s||'').match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?m[1]:''}
  function bad(u){u=(u||'').toLowerCase();return !u||u.indexOf('data:')===0||/(logo|avatar|icon|sprite|emoji|advert|banner|tracking|pixel|favicon|header|footer|cover|thumbnail|thumb)/.test(u)}
  function imgLike(i){var w=i.naturalWidth||parseInt(i.getAttribute('width')||'0')||0,h=i.naturalHeight||parseInt(i.getAttribute('height')||'0')||0;var u=i.currentSrc||i.src||i.getAttribute('data-src')||i.getAttribute('data-lazy-src')||'';if(bad(u))return false;if(w&&h&&(w<220||h<220))return false;return true}
  var sels=['.reading-content','.page-break','#readerarea','.reader-area','.readerarea','.ts_reader','.chapter-content','.chapter-images','.container-chapter-reader','.reading-detail','.viewer','.viewer_img','.episode-body','.webtoon-reader','.chapterbody','.chapter-body','.manga-reader','.comic-reader','main'];
  var best=null,bestCount=0,bestSel='';sels.forEach(function(s){document.querySelectorAll(s).forEach(function(el){var c=0;el.querySelectorAll('img').forEach(function(i){if(imgLike(i))c++});if(c>bestCount){best=el;bestCount=c;bestSel=s}})});
  var title=norm(document.title);var url=location.href;var n=chapNo(title)||chapNo(url);var chapterSignal=!!n||/(chapter|chapitre|episode|reader|lecture|scan)/i.test(url+' '+title);
  if(!best||bestCount<2){if(!chapterSignal)return JSON.stringify({ok:false,reason:'Page non reconnue comme chapitre',images:[]});best=document.body;bestSel='body-fallback'}
  var out=[],seen={};function add(u){u=abs(u);if(!bad(u)&&!seen[u]){seen[u]=1;out.push(u)}}
  best.querySelectorAll('img').forEach(function(i){if(!imgLike(i))return;add(i.currentSrc||i.src);['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){add(i.getAttribute(a))});var ss=i.getAttribute('srcset')||i.getAttribute('data-srcset')||'';ss.split(',').forEach(function(x){add(x.trim().split(/\s+/)[0])})});
  best.querySelectorAll('source').forEach(function(s){var z=s.srcset||s.getAttribute('data-srcset')||'';z.split(',').forEach(function(x){add(x.trim().split(/\s+/)[0])})});
  best.querySelectorAll('[style]').forEach(function(el){var st=el.getAttribute('style')||'';var m=st.match(/url\(['"]?([^'")]+)['"]?\)/ig)||[];m.forEach(function(x){add(x.replace(/^url\(['"]?/i,'').replace(/['"]?\)$/,''))})});
  if(out.length<2&&chapterSignal){document.querySelectorAll('script').forEach(function(sc){var t=sc.textContent||'';var re=/(https?:\/\/[^\s'"<>]+?\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?[^\s'"<>]*)?)/ig,m,k=0;while((m=re.exec(t))&&k<500){var u=m[1].replace(/\\u002F/g,'/');if(/(chapter|chapitre|manga|comic|webtoon|uploads|images)/i.test(u))add(u);k++}})}
  var h1=norm((document.querySelector('h1')||{}).textContent);var rawSeries=h1||title;rawSeries=rawSeries.replace(/(?:[-|–—:]\s*)?(?:chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim();
  if(!rawSeries)rawSeries='Série';
  var label=n?('Chapitre '+n):norm(title).replace(rawSeries,'').replace(/^[-|–—: ]+|[-|–—: ]+$/g,'');if(!label)label='Chapitre';
  var strict=bestSel!=='body-fallback';var ok=out.length>=2&&(strict||chapterSignal);
  return JSON.stringify({ok:ok,reason:ok?'':('Seulement '+out.length+' page(s) valide(s) détectée(s)'),series:rawSeries,chapter:label,number:n,reader:bestSel,count:out.length,images:out});
})();