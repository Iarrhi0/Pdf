(function(){
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function decode(s){
    var x=(s||'').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/\\\//g,'/');
    try{x=decodeURIComponent(x)}catch(e){}
    return x;
  }
  function abs(raw){
    var v=decode((raw||'').trim());
    if(!v||/^data:|^blob:/i.test(v))return '';
    if(/^\/\//.test(v))v=location.protocol+v;
    try{return new URL(v,location.href).href}catch(e){return ''}
  }
  function decorative(u){
    var l=(u||'').toLowerCase();
    return l.indexOf('logo')>=0||l.indexOf('avatar')>=0||l.indexOf('icon')>=0||
      l.indexOf('emoji')>=0||l.indexOf('banner')>=0||l.indexOf('adsense')>=0||
      l.indexOf('/ads/')>=0||l.indexOf('sprite')>=0||l.indexOf('placeholder')>=0||
      l.indexOf('loading')>=0||l.indexOf('spacer')>=0||l.indexOf('favicon')>=0;
  }
  function imageIndex(u){
    var re=/(?:\/image\/|[_\-/])(\d{1,4})(?:\.(?:jpe?g|png|webp|avif)|[_\-])/ig,m,last=-1;
    while((m=re.exec(u||''))){var n=parseInt(m[1],10);if(!isNaN(n))last=n}
    return last;
  }
  function chapterNo(s){
    var m=(s||'').match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);
    if(!m)m=(s||'').match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);
    return m?parseFloat(m[1]):null;
  }
  var html=document.documentElement?document.documentElement.outerHTML:'';
  var map=new Map(),pos=0,stats={E1:0,E2:0,E3:0,E4:0,E5:0};
  function add(raw,engine,position){
    if(raw==null)return;
    var u=abs(raw);if(!u||!/^https?:/i.test(u))return;
    var l=u.toLowerCase();
    if(!/\.(?:jpg|jpeg|png|webp|avif)(?:\?.*)?$/i.test(l))return;
    var key=u.replace(/#.*$/,'');
    if(!map.has(key))map.set(key,{url:u,engine:engine,engines:[engine],position:position,index:imageIndex(u)});
    else{var c=map.get(key);if(c.engines.indexOf(engine)<0)c.engines.push(engine);if(position<c.position)c.position=position;}
  }

  // Engine 1 — exact Java principle: normal reader <img src>.
  var e1=/<img\b[^>]*?\bsrc\s*=\s*["']([^"']+)["'][^>]*>/gis,m;
  while((m=e1.exec(html)))add(m[1],1,pos++);
  stats.E1=Array.from(map.values()).filter(function(c){return c.engines.indexOf(1)>=0}).length;

  // Engine 2 — lazy attributes, srcset, picture/source and noscript.
  var e2=/<(?:img|source)\b[^>]*?\b(?:data-src|data-original|data-lazy-src|data-url|data-image|data-cfsrc|data-echo|data-lazy)\s*=\s*["']([^"']+)["'][^>]*>/gis;
  while((m=e2.exec(html)))add(m[1],2,pos++);
  var srcset=/\b(?:srcset|data-srcset)\s*=\s*["']([^"']+)["']/gis;
  while((m=srcset.exec(html))){m[1].split(',').forEach(function(part){var u=part.trim().split(/\s+/)[0];add(u,2,pos++)})}
  var nos=/<noscript[^>]*>([\s\S]*?)<\/noscript>/gi,nm;
  while((nm=nos.exec(html))){var im=/(?:src|data-src)\s*=\s*["']([^"']+)["']/gis,mm;while((mm=im.exec(nm[1])))add(mm[1],2,pos++)}
  stats.E2=Array.from(map.values()).filter(function(c){return c.engines.indexOf(2)>=0}).length;

  // Engine 3 — raw HTML / JSON / JavaScript reader configs.
  var e3=/["']((?:https?:)?\\?\/\\?\/[^"']+?\.(?:jpe?g|png|webp|avif)(?:\?[^"']*)?)["']/gis;
  while((m=e3.exec(html)))add((m[1]||'').replace(/\\\//g,'/'),3,pos++);
  var e3b=/["'](?:url|src|image|image_url|imageUrl|page|file)["']\s*:\s*["']([^"']+\.(?:jpe?g|png|webp|avif)(?:\?[^"']*)?)["']/gis;
  while((m=e3b.exec(html)))add((m[1]||'').replace(/\\\//g,'/'),3,pos++);
  stats.E3=Array.from(map.values()).filter(function(c){return c.engines.indexOf(3)>=0}).length;

  // Engine 4 — direct image links and CSS url().
  var e4=/<a\b[^>]*?href\s*=\s*["']([^"']+\.(?:jpe?g|png|webp|avif)(?:\?[^"']*)?)["']/gis;
  while((m=e4.exec(html)))add(m[1],4,pos++);
  var css=/url\(\s*["']?([^\)"']+\.(?:jpe?g|png|webp|avif)(?:\?[^\)"']*)?)["']?\s*\)/gis;
  while((m=css.exec(html)))add(m[1],4,pos++);
  stats.E4=Array.from(map.values()).filter(function(c){return c.engines.indexOf(4)>=0}).length;

  var candidates=Array.from(map.values());

  // Engine 5 — ORIGINAL JAVA LOGIC.
  // If Ortega/API chapter images are present, isolate ONLY that continuous reader block
  // and numerically sort it. Otherwise numerically sort page-like URLs, falling back to
  // the original extraction position. This is deliberately separate from network validation.
  var api=candidates.filter(function(c){
    return /\/api\/chapters\/[^/]+\/[^/]+\/image\/\d+\.(?:jpe?g|png|webp|avif)(?:\?.*)?$/i.test(c.url);
  });
  var mode='numeric-order';
  if(api.length){
    api.sort(function(a,b){return imageIndex(a.url)-imageIndex(b.url)});
    candidates=api; mode='api-reader-block';
  }else{
    candidates.sort(function(a,b){
      var ia=imageIndex(a.url),ib=imageIndex(b.url);
      if(ia>=0&&ib>=0&&ia!==ib)return ia-ib;
      return a.position-b.position;
    });
  }
  candidates=candidates.filter(function(c){return !decorative(c.url)});
  stats.E5=candidates.length;

  var out=[],seen={};
  candidates.forEach(function(c){var k=c.url.replace(/#.*$/,'');if(!seen[k]){seen[k]=1;out.push(c)}});
  var title=norm(document.title),h1=norm((document.querySelector('h1')||{}).textContent),n=chapterNo(title+' '+location.href+' '+h1);
  var rawSeries=h1||title||'Série';
  rawSeries=rawSeries.replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').trim()||'Série';
  var isVolume=/(tome|volume|vol\.?)/i.test(title+' '+location.href+' '+h1);
  var label=n?((isVolume?'Tome ':'Chapitre ')+n):(title.replace(rawSeries,'').replace(/^[-|–—: ]+|[-|–—: ]+$/g,'')||'Chapitre');
  var chapterSignal=!!n||/(chapter|chapitre|episode|reader|lecture|scan|tome|volume)/i.test(location.href+' '+title+' '+h1);
  return JSON.stringify({ok:out.length>0&&chapterSignal,series:rawSeries,chapter:label,number:n,isVolume:isVolume,chapterSignal:chapterSignal,finalUrl:location.href,candidates:out,engine:'JAVA5',engine5Mode:mode,engineStats:stats,htmlLength:html.length});
})();