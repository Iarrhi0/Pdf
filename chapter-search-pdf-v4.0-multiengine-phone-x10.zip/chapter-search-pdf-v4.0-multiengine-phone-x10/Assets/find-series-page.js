(function(){
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function clean(s){return norm(s).replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()}
  function slug(s){return clean(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')}
  function canon(h){try{var u=new URL(h,location.href);u.hash='';return u.href}catch(e){return ''}}

  var h1=norm((document.querySelector('h1')||{}).textContent), title=norm(document.title);
  var series=clean(h1)||clean(title)||'Série', wanted=slug(series);
  var p=location.pathname.split('/').filter(Boolean), heads=['porncomic','manga','comic','webtoon','title','series','manga-series','manhwa','manhua','comics','catalogue'];

  // Already on a known series/catalogue page.
  if(p.length>=2&&heads.indexOf(p[0].toLowerCase())>=0){
    // AllPornComic-like chapter URLs live below /porncomic/<series>/...
    if(p[0].toLowerCase()==='porncomic' && p.length>=2){
      return JSON.stringify({series:series,url:location.origin+'/'+p[0]+'/'+p[1]+'/',source:'family-path'});
    }
    if(p[0].toLowerCase()==='catalogue' || p.length===2){
      return JSON.stringify({series:series,url:location.href,source:'current-series-page'});
    }
  }

  var best=null;
  function consider(a,extra){
    if(!a)return;var u=canon(a.getAttribute('href'));if(!u)return;var x;try{x=new URL(u);if(x.origin!==location.origin)return}catch(e){return}
    var t=norm(a.innerText||a.textContent), path=x.pathname.toLowerCase(), score=extra||0;
    var parent=norm((a.parentElement||{}).innerText||'');
    if(/\/catalogue\//i.test(path))score+=40;
    if(a.closest&&a.closest('.breadcrumb,.breadcrumbs,.c-breadcrumb,.post-title,.chapter-title,.summary_content,.manga-title'))score+=15;
    if(/tous\s+les\s+chapitres\s+sont\s+dans|all\s+chapters\s+(?:are\s+)?in/i.test(parent+' '+t))score+=50;
    var st=slug(t);if(st&&wanted&&(st===wanted||st.indexOf(wanted)>=0||wanted.indexOf(st)>=0))score+=35;
    if(wanted&&path.indexOf('/'+wanted+'/')>=0)score+=25;
    if(/chapter|chapitre|tome|volume/i.test(t)&&!(/catalogue/.test(path)))score-=15;
    if(u===location.href)score-=20;
    if(score<25)return;
    if(!best||score>best.score)best={series:clean(t)||series,url:u,score:score,source:'page-link'};
  }
  document.querySelectorAll('a[href]').forEach(function(a){consider(a,0)});
  if(best)return JSON.stringify(best);

  // Site adapter: SushiScan/Madara FR has a stable /catalogue/<slug>/ series page.
  if(/(^|\.)sushiscan\.fr$/i.test(location.hostname) && wanted){
    return JSON.stringify({series:series,url:location.origin+'/catalogue/'+wanted+'/',source:'sushiscan-catalogue-adapter'});
  }
  return JSON.stringify({series:series,url:location.href,source:'current-fallback'});
})();
