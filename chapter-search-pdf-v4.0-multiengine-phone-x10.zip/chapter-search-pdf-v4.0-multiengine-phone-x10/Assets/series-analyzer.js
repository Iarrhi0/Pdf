(function(){
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function cleanSeries(s){return norm(s).replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()}
  function slug(s){return cleanSeries(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')}
  function canon(h){try{var u=new URL(h,location.href);u.hash='';['utm_source','utm_medium','utm_campaign','ref'].forEach(function(k){u.searchParams.delete(k)});return u.href}catch(e){return ''}}
  function number(t,u){var s=(t||'')+' '+(u||'');var m=s.match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(m)return parseFloat(m[1]);m=s.match(/(?:^|[-_\/])(\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?parseFloat(m[1]):null}
  function isChapterSignal(t,u){return /(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*\d/i.test((t||'')+' '+(u||''))}
  function listContainer(el){return !!(el&&el.closest&&el.closest('.chapters,.chapter-list,.listing-chapters_wrap,.wp-manga-chapter,.eplister,.episodelist,.list-chapter,.version-chap,.c-tabs-item__content,.page-listing-item,.chapter-listing,.episodes,.episode-list,.chapters-list,.manga-chapters,.chapter-list-wrap,.select-chapter,.chapter-select'))}
  function parasite(el){return !!(el&&el.closest&&el.closest('header,footer,nav,.menu,.related,.recommend,.recommendation,.similar,.sidebar,.widget,.popular,.latest,.recent'))}

  var origin=location.origin, current=canon(location.href);
  var h1=norm((document.querySelector('h1')||{}).textContent), title=norm(document.title), series=cleanSeries(h1)||cleanSeries(title)||'Série', seriesSlug=slug(series);
  var bodyText=norm((document.body||{}).innerText||'');
  var declaredLast=null, dm=bodyText.match(/(?:dernier|last)\s*(?:chapitre|chapter|tome|volume)?\s*[:#-]?\s*(\d+(?:\.\d+)?)/i);if(dm)declaredLast=parseFloat(dm[1]);
  var map={}, engineStats={S1:0,S2:0,S3:0,S4:0,S5:0};

  function sameSeriesPath(u){
    try{
      var x=new URL(u);if(x.origin!==origin)return false;
      var p=x.pathname.toLowerCase();
      if(seriesSlug && (p.indexOf('/'+seriesSlug+'-')>=0 || p.indexOf('/'+seriesSlug+'/')>=0 || p.indexOf(seriesSlug+'-chapter-')>=0 || p.indexOf(seriesSlug+'-chapitre-')>=0 || p.indexOf(seriesSlug+'-tome-')>=0 || p.indexOf(seriesSlug+'-volume-')>=0))return true;
      var parts=location.pathname.split('/').filter(Boolean), xp=x.pathname.split('/').filter(Boolean);
      if(parts.length>=2 && xp.length>=2 && /^(porncomic|manga|comic|webtoon|title|series|manga-series|manhwa|manhua|comics)$/i.test(parts[0]) && xp[0]===parts[0] && xp[1]===parts[1])return true;
      return false;
    }catch(e){return false}
  }

  function add(raw,text,source,score,el){
    var u=canon(raw);if(!u||u===current)return;var x;try{x=new URL(u);if(x.origin!==origin)return}catch(e){return}
    var n=number(text,u);if(n===null||isNaN(n))return;
    if(declaredLast!==null&&n>declaredLast+0.001)return;
    var sig=isChapterSignal(text,u), list=listContainer(el), same=sameSeriesPath(u);
    if(!sig&&!list&&!same)return;
    if(parasite(el)&&!same&&!list)return;
    var confidence=(score||0)+(same?30:0)+(list?25:0)+(sig?20:0);
    if(confidence<35)return;
    var isVol=/(tome|volume|vol\.?)/i.test((text||'')+' '+u);
    var cand={number:n,title:(isVol?'Tome ':'Chapitre ')+n,url:u,series:series,source:source,confidence:confidence};
    var key=String(n),old=map[key];if(!old||cand.confidence>old.confidence)map[key]=cand;
  }

  // S1: explicit chapter list containers (Madara/SushiScan and generic readers).
  document.querySelectorAll('.chapters a[href],.chapter-list a[href],.listing-chapters_wrap a[href],.wp-manga-chapter a[href],.eplister a[href],.episodelist a[href],.list-chapter a[href],.version-chap a[href],.c-tabs-item__content a[href],.chapter-listing a[href],.episodes a[href],.chapter-list-wrap a[href]').forEach(function(a){add(a.getAttribute('href'),norm(a.innerText||a.textContent),'S1-list',60,a);engineStats.S1++});

  // S2: chapter dropdown/select. SushiScan chapter pages often expose the whole series here.
  document.querySelectorAll('select option').forEach(function(o){var raw=o.value||o.getAttribute('data-url')||o.getAttribute('data-href');if(raw){add(raw,norm(o.textContent),'S2-select',70,o);engineStats.S2++}});
  document.querySelectorAll('[data-chapter-url],[data-url][class*="chapter"],[data-href][class*="chapter"]').forEach(function(el){add(el.getAttribute('data-chapter-url')||el.getAttribute('data-url')||el.getAttribute('data-href'),norm(el.textContent),'S2-data',65,el);engineStats.S2++});

  // S3: all same-series anchors, but only when URL/text really signals a numbered chapter.
  document.querySelectorAll('a[href]').forEach(function(a){var u=a.getAttribute('href'),t=norm(a.innerText||a.textContent);if(sameSeriesPath(canon(u))){add(u,t,'S3-series-path',55,a);engineStats.S3++}});

  // S4: previous / next navigation on an individual chapter page.
  document.querySelectorAll('a[href]').forEach(function(a){var t=norm(a.innerText||a.textContent),rel=(a.getAttribute('rel')||'');if(/(^|\s)(next|prev|previous)(\s|$)/i.test(rel)||/^(suivant|précédent|precedent|next|previous|chapitre suivant|chapitre précédent|next chapter|previous chapter)$/i.test(t)){add(a.getAttribute('href'),t,'S4-prevnext',80,a);engineStats.S4++}});

  // S5: URLs found in rendered HTML / JSON scripts, restricted to the same series slug.
  var html=document.documentElement?document.documentElement.outerHTML:'';
  var re=/(https?:\\?\/\\?\/[^"'<>\\s]+|\/[a-zA-Z0-9_\-\.\/]+(?:chapter|chapitre|tome|volume)[a-zA-Z0-9_\-\.\/?=&%]*)/ig,m,guard=0;
  while((m=re.exec(html))&&guard++<4000){var raw=(m[1]||'').replace(/\\\//g,'/');var u=canon(raw);if(u&&sameSeriesPath(u)){add(u,u,'S5-script',45,null);engineStats.S5++}}

  var out=Object.keys(map).map(function(k){return map[k]}).sort(function(a,b){return a.number-b.number});
  var next=null;document.querySelectorAll('a[href]').forEach(function(a){if(next)return;var t=norm(a.innerText||a.textContent),rel=(a.getAttribute('rel')||'');if(/(^|\s)next(\s|$)/i.test(rel)||/^(suivant|next|chapitre suivant|next chapter)$/i.test(t)){var u=canon(a.getAttribute('href'));if(u&&sameSeriesPath(u))next=u}});
  return JSON.stringify({series:series,seriesSlug:seriesSlug,declaredLast:declaredLast,chapters:out.slice(0,2500),next:next,current:current,engineStats:engineStats,mode:'MULTI-S1-S5'});
})();
