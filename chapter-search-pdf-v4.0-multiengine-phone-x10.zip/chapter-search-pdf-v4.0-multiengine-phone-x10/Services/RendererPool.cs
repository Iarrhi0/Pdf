using System.Collections.Concurrent;
using System.Text.Json;
using ChapterSearchPdfV3.Models;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace ChapterSearchPdfV3.Services;

public sealed class RendererPool : IAsyncDisposable
{
    public const string AndroidUserAgent = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36";
    private readonly Control _uiOwner;
    private readonly int _size;
    private readonly SemaphoreSlim _slots;
    private readonly ConcurrentQueue<WebView2> _available = new();
    private readonly List<WebView2> _all = [];
    private Form? _host;
    private CoreWebView2Environment? _environment;
    public CoreWebView2Environment Environment => _environment ?? throw new InvalidOperationException("RendererPool non initialisé");
    private string _lazy = "";
    private string _apk = "";
    private string _engine5 = "";
    private string _series = "";
    private string _findSeries = "";

    public RendererPool(Control uiOwner, int size = 3, CoreWebView2Environment? environment = null)
    {
        _uiOwner = uiOwner;
        _size = Math.Max(1, size);
        _slots = new SemaphoreSlim(_size, _size);
        _environment = environment;
    }

    public async Task InitializeAsync()
    {
        var assets = Path.Combine(AppContext.BaseDirectory, "Assets");
        _lazy = await File.ReadAllTextAsync(Path.Combine(assets, "lazy.js"));
        _apk = await File.ReadAllTextAsync(Path.Combine(assets, "apk40-extract.js"));
        _engine5 = await File.ReadAllTextAsync(Path.Combine(assets, "engine5-java.js"));
        _series = await File.ReadAllTextAsync(Path.Combine(assets, "series-analyzer.js"));
        _findSeries = await File.ReadAllTextAsync(Path.Combine(assets, "find-series-page.js"));

        if (_environment is null)
        {
            var dataDir = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "ChapterSearchPdfV4", "WebView2");
            Directory.CreateDirectory(dataDir);
            _environment = await CoreWebView2Environment.CreateAsync(null, dataDir, new CoreWebView2EnvironmentOptions("--autoplay-policy=user-gesture-required"));
        }

        await OnUiAsync(async () =>
        {
            _host = new Form
            {
                ShowInTaskbar = false,
                FormBorderStyle = FormBorderStyle.None,
                StartPosition = FormStartPosition.Manual,
                Location = new Point(-32000, -32000),
                Size = new Size(16, 16),
                Opacity = 0.01
            };
            _host.Show();

            for (var i = 0; i < _size; i++)
            {
                var web = new WebView2 { Dock = DockStyle.Fill, Visible = true };
                _host.Controls.Add(web);
                await web.EnsureCoreWebView2Async(_environment);
                Configure(web);
                _all.Add(web);
                _available.Enqueue(web);
            }
        });
    }

    private void Configure(WebView2 web)
    {
        var core = web.CoreWebView2;
        core.Settings.UserAgent = AndroidUserAgent;
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = false;
        core.IsMuted = true;
        core.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low;

        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.Media);
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.Font);
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (_, e) =>
        {
            try
            {
                var u = e.Request.Uri.ToLowerInvariant();
                var blockedTracker = u.Contains("doubleclick.net") || u.Contains("googlesyndication.com") || u.Contains("googleadservices.com") ||
                                     u.Contains("adservice.google.") || u.Contains("scorecardresearch.com") || u.Contains("googletagmanager.com") ||
                                     u.Contains("facebook.net/tr") || u.Contains("hotjar.com") || u.Contains("clarity.ms/collect");
                if (e.ResourceContext is CoreWebView2WebResourceContext.Media or CoreWebView2WebResourceContext.Font || blockedTracker)
                {
                    e.Response = _environment!.CreateWebResourceResponse(null, 204, "Blocked", "Content-Type: text/plain");
                }
            }
            catch { }
        };
    }

    public async Task<ExtractPayload> RenderChapterAsync(string url, CancellationToken token)
    {
        await _slots.WaitAsync(token);
        if (!_available.TryDequeue(out var web))
        {
            _slots.Release();
            throw new InvalidOperationException("Renderer indisponible");
        }
        try
        {
            await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Normal; return Task.CompletedTask; });
            return await OnUiAsync(() => RenderChapterOnUiAsync(web, url, token));
        }
        finally
        {
            try { await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low; return Task.CompletedTask; }); } catch { }
            _available.Enqueue(web);
            _slots.Release();
        }
    }

    public async Task<List<ChapterCandidate>> AnalyzeSeriesAsync(string url, CancellationToken token = default)
    {
        await _slots.WaitAsync(token);
        if (!_available.TryDequeue(out var web))
        {
            _slots.Release();
            throw new InvalidOperationException("Renderer indisponible");
        }
        try
        {
            await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Normal; return Task.CompletedTask; });
            return await OnUiAsync(async () =>
            {
                // V4: vraie analyse série multi-moteur. On analyse d'abord la page actuelle,
                // puis la vraie fiche série trouvée dans breadcrumb/catalogue quand elle diffère.
                var first = await AnalyzeSeriesPageOnUiAsync(web, url, token);
                var combined = new List<ChapterCandidate>(first);

                string seriesPage = url;
                try
                {
                    var rawFind = await web.CoreWebView2.ExecuteScriptAsync(_findSeries);
                    using var findDoc = JsonDocument.Parse(DecodeScriptString(rawFind));
                    seriesPage = GetString(findDoc.RootElement, "url") ?? url;
                }
                catch { }

                if (Uri.TryCreate(seriesPage, UriKind.Absolute, out var seriesUri) &&
                    Uri.TryCreate(url, UriKind.Absolute, out var currentUri) &&
                    (seriesUri.Scheme == "http" || seriesUri.Scheme == "https") &&
                    string.Equals(seriesUri.Host, currentUri.Host, StringComparison.OrdinalIgnoreCase) &&
                    !string.Equals(seriesUri.AbsoluteUri.TrimEnd('/'), currentUri.AbsoluteUri.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var second = await AnalyzeSeriesPageOnUiAsync(web, seriesUri.AbsoluteUri, token);
                        combined.AddRange(second);
                    }
                    catch { /* la page actuelle reste exploitable */ }
                }

                return MergeChapterCandidates(combined);
            });
        }
        finally
        {
            try { await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low; return Task.CompletedTask; }); } catch { }
            _available.Enqueue(web);
            _slots.Release();
        }
    }

    private async Task<List<ChapterCandidate>> AnalyzeSeriesPageOnUiAsync(WebView2 web, string url, CancellationToken token)
    {
        await NavigateToDomAsync(web, url, token);
        await web.CoreWebView2.ExecuteScriptAsync(_lazy);
        await Task.Delay(450, token);
        var raw = await web.CoreWebView2.ExecuteScriptAsync(_series);
        var json = DecodeScriptString(raw);
        using var doc = JsonDocument.Parse(json);
        var list = new List<ChapterCandidate>();
        if (doc.RootElement.TryGetProperty("chapters", out var chapters) && chapters.ValueKind == JsonValueKind.Array)
        {
            foreach (var c in chapters.EnumerateArray())
            {
                var candidate = new ChapterCandidate
                {
                    Number = GetDouble(c, "number") ?? 0,
                    Title = GetString(c, "title") ?? "Chapitre",
                    Url = GetString(c, "url") ?? "",
                    Series = GetString(c, "series") ?? "Série",
                    Source = GetString(c, "source") ?? "MULTI"
                };
                if (candidate.Number < 0) continue;
                if (Uri.TryCreate(candidate.Url, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) list.Add(candidate);
            }
        }
        return list;
    }

    private static List<ChapterCandidate> MergeChapterCandidates(IEnumerable<ChapterCandidate> items)
    {
        // Une seule URL cohérente par numéro. Les moteurs de liste/dropdown sont prioritaires
        // sur les déductions de scripts, sans jamais reconstruire une URL arbitraire.
        static int Rank(string source) => source switch
        {
            var s when s.StartsWith("S2", StringComparison.OrdinalIgnoreCase) => 5,
            var s when s.StartsWith("S1", StringComparison.OrdinalIgnoreCase) => 4,
            var s when s.StartsWith("S4", StringComparison.OrdinalIgnoreCase) => 3,
            var s when s.StartsWith("S3", StringComparison.OrdinalIgnoreCase) => 2,
            var s when s.StartsWith("S5", StringComparison.OrdinalIgnoreCase) => 1,
            _ => 0
        };

        var map = new Dictionary<double, ChapterCandidate>();
        foreach (var c in items.Where(x => x.Number >= 0 && Uri.IsWellFormedUriString(x.Url, UriKind.Absolute)))
        {
            if (!map.TryGetValue(c.Number, out var old) || Rank(c.Source) > Rank(old.Source)) map[c.Number] = c;
        }
        return map.Values.OrderBy(x => x.Number).ToList();
    }

    public async Task<(string Series, string Url)> FindSeriesPageAsync(string url, CancellationToken token = default)
    {
        await _slots.WaitAsync(token);
        if (!_available.TryDequeue(out var web)) { _slots.Release(); throw new InvalidOperationException("Renderer indisponible"); }
        try
        {
            await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Normal; return Task.CompletedTask; });
            return await OnUiAsync(async () =>
            {
                await NavigateToDomAsync(web, url, token);
                var raw = await web.CoreWebView2.ExecuteScriptAsync(_findSeries);
                using var doc = JsonDocument.Parse(DecodeScriptString(raw));
                return (GetString(doc.RootElement, "series") ?? "Série", GetString(doc.RootElement, "url") ?? url);
            });
        }
        finally { try { await OnUiAsync(() => { web.CoreWebView2.MemoryUsageTargetLevel = CoreWebView2MemoryUsageTargetLevel.Low; return Task.CompletedTask; }); } catch { } _available.Enqueue(web); _slots.Release(); }
    }

    private async Task<ExtractPayload> RenderChapterOnUiAsync(WebView2 web, string url, CancellationToken token)
    {
        await NavigateToDomAsync(web, url, token);
        await web.CoreWebView2.ExecuteScriptAsync(_lazy);
        await Task.Delay(550, token);

        var apkPayload = ParsePayload(await web.CoreWebView2.ExecuteScriptAsync(_apk), "APK40");
        var e5Payload = ParsePayload(await web.CoreWebView2.ExecuteScriptAsync(_engine5), "ENGINE5-JAVA");

        if (Math.Max(apkPayload.Images.Count, e5Payload.Images.Count) < 2)
        {
            await web.CoreWebView2.ExecuteScriptAsync(_lazy);
            await Task.Delay(900, token);
            apkPayload = ParsePayload(await web.CoreWebView2.ExecuteScriptAsync(_apk), "APK40");
            e5Payload = ParsePayload(await web.CoreWebView2.ExecuteScriptAsync(_engine5), "ENGINE5-JAVA");
        }

        // Le moteur téléphone reste prioritaire quand son lecteur est clairement identifié.
        // ENGINE5 Java prend le relais si son bloc cohérent contient davantage de pages.
        var chosen = e5Payload.Images.Count > apkPayload.Images.Count ? e5Payload : apkPayload;
        if (chosen.Images.Count < 2) throw new InvalidOperationException($"Extraction insuffisante : {chosen.Images.Count} page(s)");

        chosen.FinalUrl = web.Source?.ToString() ?? url;
        chosen.UserAgent = AndroidUserAgent;
        var cookies = await web.CoreWebView2.CookieManager.GetCookiesAsync(chosen.FinalUrl);
        chosen.CookieHeader = string.Join("; ", cookies.Select(c => $"{c.Name}={c.Value}"));
        return chosen;
    }

    private static async Task NavigateToDomAsync(WebView2 web, string url, CancellationToken token)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || (uri.Scheme != "http" && uri.Scheme != "https"))
            throw new InvalidOperationException("URL de chapitre invalide");

        var dom = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        var fatal = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);

        void DomHandler(object? s, CoreWebView2DOMContentLoadedEventArgs e) => dom.TrySetResult(true);
        void NavHandler(object? s, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess) return;
            // Android WebView continue à travailler quand une navigation/redirection est annulée.
            // V4 fait pareil : ConnectionAborted/OperationCanceled ne tuent plus un chapitre
            // si le DOM principal arrive malgré tout.
            var status = e.WebErrorStatus.ToString();
            if (status is "ConnectionAborted" or "OperationCanceled") return;
            fatal.TrySetResult($"LOAD: {status}");
        }

        web.CoreWebView2.DOMContentLoaded += DomHandler;
        web.CoreWebView2.NavigationCompleted += NavHandler;
        try
        {
            web.CoreWebView2.Navigate(uri.AbsoluteUri);
            var timeout = Task.Delay(TimeSpan.FromSeconds(120), token);
            var done = await Task.WhenAny(dom.Task, fatal.Task, timeout);
            token.ThrowIfCancellationRequested();
            if (done == fatal.Task)
            {
                // Donne encore un court délai au DOM : certains sites signalent d'abord une
                // erreur de navigation secondaire puis livrent tout de même le document principal.
                var grace = await Task.WhenAny(dom.Task, Task.Delay(1200, token));
                if (grace != dom.Task) throw new InvalidOperationException(await fatal.Task);
            }
            if (done == timeout) throw new TimeoutException("LOAD: aucun DOM principal après 120 s");
        }
        finally
        {
            web.CoreWebView2.DOMContentLoaded -= DomHandler;
            web.CoreWebView2.NavigationCompleted -= NavHandler;
        }
    }

    private static ExtractPayload ParsePayload(string raw, string fallbackEngine)
    {
        try
        {
            var json = DecodeScriptString(raw);
            using var doc = JsonDocument.Parse(json);
            var r = doc.RootElement;
            var p = new ExtractPayload
            {
                Ok = r.TryGetProperty("ok", out var ok) && ok.ValueKind == JsonValueKind.True,
                Series = GetString(r, "series") ?? "Série",
                Chapter = GetString(r, "chapter") ?? "Chapitre",
                Number = GetDouble(r, "number"),
                Reader = GetString(r, "reader") ?? "",
                Engine = GetString(r, "engine") ?? fallbackEngine
            };
            if (r.TryGetProperty("images", out var images) && images.ValueKind == JsonValueKind.Array)
                p.Images.AddRange(images.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).Where(x => Uri.IsWellFormedUriString(x, UriKind.Absolute)));
            if (r.TryGetProperty("candidates", out var candidates) && candidates.ValueKind == JsonValueKind.Array)
            {
                foreach (var x in candidates.EnumerateArray())
                {
                    if (x.ValueKind == JsonValueKind.String) p.Images.Add(x.GetString()!);
                    else if (x.ValueKind == JsonValueKind.Object && x.TryGetProperty("url", out var u) && u.ValueKind == JsonValueKind.String) p.Images.Add(u.GetString()!);
                }
            }
            p.Images = p.Images.Where(x => Uri.TryCreate(x, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https"))
                               .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return p;
        }
        catch
        {
            return new ExtractPayload { Ok = false, Engine = fallbackEngine };
        }
    }

    private static string DecodeScriptString(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw) || raw == "null") return "{}";
        try { return JsonSerializer.Deserialize<string>(raw) ?? raw; }
        catch { return raw; }
    }

    private static string? GetString(JsonElement e, string name) => e.TryGetProperty(name, out var x) && x.ValueKind == JsonValueKind.String ? x.GetString() : null;
    private static double? GetDouble(JsonElement e, string name)
    {
        if (!e.TryGetProperty(name, out var x)) return null;
        if (x.ValueKind == JsonValueKind.Number && x.TryGetDouble(out var d)) return d;
        if (x.ValueKind == JsonValueKind.String && double.TryParse(x.GetString(), System.Globalization.CultureInfo.InvariantCulture, out d)) return d;
        return null;
    }

    private Task OnUiAsync(Func<Task> work)
    {
        if (!_uiOwner.InvokeRequired) return work();
        var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        _uiOwner.BeginInvoke(new Action(async () => { try { await work(); tcs.TrySetResult(true); } catch (Exception ex) { tcs.TrySetException(ex); } }));
        return tcs.Task;
    }

    private Task<T> OnUiAsync<T>(Func<Task<T>> work)
    {
        if (!_uiOwner.InvokeRequired) return work();
        var tcs = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
        _uiOwner.BeginInvoke(new Action(async () => { try { tcs.TrySetResult(await work()); } catch (Exception ex) { tcs.TrySetException(ex); } }));
        return tcs.Task;
    }

    public async ValueTask DisposeAsync()
    {
        await OnUiAsync(() =>
        {
            foreach (var w in _all) w.Dispose();
            _host?.Close();
            _host?.Dispose();
            return Task.CompletedTask;
        });
        _slots.Dispose();
    }
}
