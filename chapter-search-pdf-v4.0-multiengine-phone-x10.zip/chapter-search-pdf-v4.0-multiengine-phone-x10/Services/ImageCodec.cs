using SkiaSharp;

namespace ChapterSearchPdfV3.Services;

public static class ImageCodec
{
    public sealed record JpegPage(byte[] Bytes, int Width, int Height);

    public static JpegPage ToJpeg(byte[] raw, int quality = 91)
    {
        using var codec = SKCodec.Create(new SKMemoryStream(raw)) ?? throw new InvalidDataException("Image non décodable");
        var info = codec.Info;
        if (info.Width <= 0 || info.Height <= 0) throw new InvalidDataException("Dimensions image invalides");

        // JPEG déjà valide : zéro recompression, gain CPU important.
        if (raw.Length >= 3 && raw[0] == 0xFF && raw[1] == 0xD8 && raw[2] == 0xFF)
            return new JpegPage(raw, info.Width, info.Height);

        using var bitmap = SKBitmap.Decode(raw) ?? throw new InvalidDataException("Image non décodable");
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Jpeg, quality) ?? throw new InvalidDataException("Conversion JPEG impossible");
        return new JpegPage(data.ToArray(), bitmap.Width, bitmap.Height);
    }
}
