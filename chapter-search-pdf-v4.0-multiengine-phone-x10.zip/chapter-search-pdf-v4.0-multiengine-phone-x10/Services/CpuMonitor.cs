using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ChapterSearchPdfV3.Services;

public sealed class CpuMonitor
{
    private readonly Process _process = Process.GetCurrentProcess();
    private TimeSpan _lastProcessCpu;
    private DateTime _lastWall = DateTime.UtcNow;
    private ulong _lastIdle, _lastKernel, _lastUser;

    public CpuMonitor()
    {
        _lastProcessCpu = _process.TotalProcessorTime;
        ReadSystem(out _lastIdle, out _lastKernel, out _lastUser);
    }

    public (double AppCpu, double SystemCpu, double RamMb) Sample()
    {
        _process.Refresh();
        var now = DateTime.UtcNow;
        var procCpu = _process.TotalProcessorTime;
        var wall = Math.Max(0.001, (now - _lastWall).TotalSeconds);
        var app = Math.Clamp((procCpu - _lastProcessCpu).TotalSeconds / wall / Math.Max(1, Environment.ProcessorCount) * 100d, 0, 100);
        _lastProcessCpu = procCpu;
        _lastWall = now;

        var system = 0d;
        if (ReadSystem(out var idle, out var kernel, out var user))
        {
            var idleDelta = idle - _lastIdle;
            var kernelDelta = kernel - _lastKernel;
            var userDelta = user - _lastUser;
            var total = kernelDelta + userDelta;
            if (total > 0) system = Math.Clamp((total - idleDelta) * 100d / total, 0, 100);
            _lastIdle = idle; _lastKernel = kernel; _lastUser = user;
        }
        return (app, system, _process.WorkingSet64 / 1024d / 1024d);
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct FILETIME { public uint Low; public uint High; public ulong Value => ((ulong)High << 32) | Low; }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetSystemTimes(out FILETIME idle, out FILETIME kernel, out FILETIME user);

    private static bool ReadSystem(out ulong idle, out ulong kernel, out ulong user)
    {
        if (GetSystemTimes(out var i, out var k, out var u)) { idle = i.Value; kernel = k.Value; user = u.Value; return true; }
        idle = kernel = user = 0; return false;
    }
}
