using System.Globalization;
using System.Text;

namespace ChapterSearchPdfV3.Services;

public sealed class StreamingPdfWriter : IDisposable
{
    private readonly FileStream _stream;
    private readonly Dictionary<int, long> _offsets = [];
    private readonly List<int> _pages = [];
    private int _nextObject = 3;
    private bool _completed;

    public StreamingPdfWriter(string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        _stream = new FileStream(path, FileMode.Create, FileAccess.ReadWrite, FileShare.None, 1024 * 64, FileOptions.SequentialScan);
        WriteAscii("%PDF-1.4\n%âãÏÓ\n");
    }

    public void AddJpeg(ReadOnlySpan<byte> jpeg, int width, int height)
    {
        if (_completed) throw new InvalidOperationException("PDF terminé");
        if (width <= 0 || height <= 0 || jpeg.Length < 4) throw new InvalidDataException("Image invalide");

        var imageObj = _nextObject++;
        var contentObj = _nextObject++;
        var pageObj = _nextObject++;

        BeginObject(imageObj);
        WriteAscii($"<< /Type /XObject /Subtype /Image /Width {width} /Height {height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {jpeg.Length} >>\nstream\n");
        _stream.Write(jpeg);
        WriteAscii("\nendstream\nendobj\n");

        var w = width.ToString(CultureInfo.InvariantCulture);
        var h = height.ToString(CultureInfo.InvariantCulture);
        var content = Encoding.ASCII.GetBytes($"q\n{w} 0 0 {h} 0 0 cm\n/Im0 Do\nQ\n");
        BeginObject(contentObj);
        WriteAscii($"<< /Length {content.Length} >>\nstream\n");
        _stream.Write(content);
        WriteAscii("endstream\nendobj\n");

        BeginObject(pageObj);
        WriteAscii($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w} {h}] /Resources << /XObject << /Im0 {imageObj} 0 R >> >> /Contents {contentObj} 0 R >>\nendobj\n");
        _pages.Add(pageObj);
    }

    public void Complete()
    {
        if (_completed) return;
        if (_pages.Count == 0) throw new InvalidDataException("Aucune page PDF valide");

        BeginObject(2);
        WriteAscii($"<< /Type /Pages /Kids [{string.Join(" ", _pages.Select(p => $"{p} 0 R"))}] /Count {_pages.Count} >>\nendobj\n");
        BeginObject(1);
        WriteAscii("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        var xref = _stream.Position;
        var max = _nextObject - 1;
        WriteAscii($"xref\n0 {max + 1}\n");
        WriteAscii("0000000000 65535 f \n");
        for (var i = 1; i <= max; i++)
        {
            var pos = _offsets.TryGetValue(i, out var p) ? p : 0;
            WriteAscii(pos.ToString("0000000000", CultureInfo.InvariantCulture) + " 00000 n \n");
        }
        WriteAscii($"trailer\n<< /Size {max + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n");
        _stream.Flush(true);
        _completed = true;
    }

    private void BeginObject(int n)
    {
        _offsets[n] = _stream.Position;
        WriteAscii($"{n} 0 obj\n");
    }

    private void WriteAscii(string text)
    {
        var bytes = Encoding.Latin1.GetBytes(text);
        _stream.Write(bytes, 0, bytes.Length);
    }

    public void Dispose() => _stream.Dispose();
}
