using ChapterSearchPdfV3.Models;
using ChapterSearchPdfV3.Services;

namespace ChapterSearchPdfV3;

public sealed class SearchForm : Form
{
    private readonly MultiSiteSearchService _service;
    private readonly TextBox _query = new() { Dock = DockStyle.Top, Height = 34 };
    private readonly ListView _results = new() { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true };
    private readonly Label _status = new() { Dock = DockStyle.Bottom, Height = 25, ForeColor = Color.Silver };
    private List<SearchResult> _items = [];
    public string? SelectedUrl { get; private set; }

    public SearchForm(MultiSiteSearchService service)
    {
        _service = service; Text = "Recherche multi-site"; Width = 900; Height = 650; StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(12, 18, 32); ForeColor = Color.White;
        _query.BackColor = Color.FromArgb(17, 27, 48); _query.ForeColor = Color.White; _query.BorderStyle = BorderStyle.FixedSingle;
        _results.BackColor = Color.FromArgb(17, 27, 48); _results.ForeColor = Color.White; _results.Columns.Add("Source", 130); _results.Columns.Add("Titre", 280); _results.Columns.Add("URL", 420);
        var top = new Panel { Dock = DockStyle.Top, Height = 74, Padding = new Padding(10) };
        var search = new Button { Text = "Rechercher", Dock = DockStyle.Right, Width = 120, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(55, 96, 240), ForeColor = Color.White };
        top.Controls.Add(search); top.Controls.Add(_query);
        search.Click += async (_, _) => await DoSearchAsync(); _query.KeyDown += async (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await DoSearchAsync(); } };
        _results.DoubleClick += (_, _) => Accept();
        var open = new Button { Text = "Ouvrir", Dock = DockStyle.Bottom, Height = 38, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(24, 147, 91), ForeColor = Color.White };
        open.Click += (_, _) => Accept();
        Controls.Add(_results); Controls.Add(_status); Controls.Add(open); Controls.Add(top);
    }

    private async Task DoSearchAsync()
    {
        if (_query.Text.Trim().Length < 2) return;
        _status.Text = "Recherche parallèle…"; _results.Items.Clear();
        try
        {
            _items = await _service.SearchAsync(_query.Text);
            foreach (var x in _items) _results.Items.Add(new ListViewItem([x.Source, x.Title, x.Url]));
            _status.Text = $"{_items.Count} résultat(s) • jusqu'à 8 sources interrogées en parallèle";
        }
        catch (Exception ex) { _status.Text = ex.Message; }
    }

    private void Accept()
    {
        if (_results.SelectedIndices.Count == 0) return;
        SelectedUrl = _items[_results.SelectedIndices[0]].Url; DialogResult = DialogResult.OK; Close();
    }
}
