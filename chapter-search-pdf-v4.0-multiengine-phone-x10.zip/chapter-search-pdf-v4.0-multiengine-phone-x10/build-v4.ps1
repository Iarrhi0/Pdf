$ErrorActionPreference = 'Stop'
$proj = Join-Path $PSScriptRoot 'ChapterSearchPdfV3.csproj'
dotnet restore $proj
dotnet build $proj -c Release --no-restore
dotnet publish $proj -c Release -r win-x64 --self-contained false -o (Join-Path $PSScriptRoot 'publish-light')
