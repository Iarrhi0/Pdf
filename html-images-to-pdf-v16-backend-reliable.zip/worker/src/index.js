const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Range',
  'Access-Control-Expose-Headers': 'Content-Type, Content-Length, Content-Range, Accept-Ranges, ETag, Last-Modified',
};

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function isBlockedHost(host){
  const h=String(host||'').toLowerCase();
  if(h==='localhost'||h.endsWith('.localhost')||h==='0.0.0.0'||h==='::1')return true;
  if(/^127\./.test(h)||/^10\./.test(h)||/^192\.168\./.test(h)||/^169\.254\./.test(h))return true;
  const m=h.match(/^172\.(\d+)\./); if(m&&Number(m[1])>=16&&Number(m[1])<=31)return true;
  return false;
}
function cleanTarget(raw){
  let u; try{u=new URL(raw)}catch{throw new Error('URL cible invalide')}
  if(!['http:','https:'].includes(u.protocol))throw new Error('Protocole non autorisé');
  if(isBlockedHost(u.hostname))throw new Error('Hôte local/privé interdit');
  return u;
}
async function fetchRetry(target, referer, request){
  const incomingRange=request.headers.get('Range');
  let last;
  for(let attempt=0;attempt<5;attempt++){
    const headers=new Headers({
      'Accept': request.headers.get('Accept') || 'text/html,application/xhtml+xml,application/pdf,image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      'Accept-Language':'fr-FR,fr;q=0.9,en;q=0.7',
      'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36',
      'Cache-Control':'no-cache'
    });
    if(referer)headers.set('Referer',referer);
    if(incomingRange)headers.set('Range',incomingRange);
    try{
      const r=await fetch(target.toString(),{method:request.method==='HEAD'?'HEAD':'GET',headers,redirect:'follow'});
      last=r;
      if(r.status!==429 && r.status<500)return r;
      const ra=Number(r.headers.get('retry-after'));
      const wait=Number.isFinite(ra)&&ra>0?Math.min(ra*1000,15000):Math.min(700*Math.pow(2,attempt)+Math.floor(Math.random()*350),10000);
      await sleep(wait);
    }catch(e){
      if(attempt===4)throw e;
      await sleep(Math.min(700*Math.pow(2,attempt),8000));
    }
  }
  return last;
}
async function handler(request){
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:corsHeaders});
  if(!['GET','HEAD'].includes(request.method))return new Response('Méthode non autorisée',{status:405,headers:corsHeaders});
  const here=new URL(request.url); const raw=here.searchParams.get('url');
  if(!raw)return new Response('Paramètre url manquant',{status:400,headers:corsHeaders});
  let target; try{target=cleanTarget(raw)}catch(e){return new Response(e.message,{status:400,headers:corsHeaders})}
  let referer=here.searchParams.get('referer')||target.origin+'/';
  try{referer=cleanTarget(referer).toString()}catch{referer=target.origin+'/'}
  try{
    const upstream=await fetchRetry(target,referer,request);
    if(!upstream)return new Response('Échec du site distant',{status:502,headers:corsHeaders});
    const h=new Headers(corsHeaders);
    for(const k of ['content-type','content-length','content-range','accept-ranges','etag','last-modified','cache-control']){
      const v=upstream.headers.get(k); if(v)h.set(k,v);
    }
    h.set('X-V16-Upstream-Status',String(upstream.status));
    if(upstream.status===429)h.set('Retry-After',upstream.headers.get('retry-after')||'5');
    return new Response(request.method==='HEAD'?null:upstream.body,{status:upstream.status,statusText:upstream.statusText,headers:h});
  }catch(e){return new Response('Backend V16 : '+(e.message||e),{status:502,headers:corsHeaders})}
}
export default { async fetch(request){ return handler(request); } };
