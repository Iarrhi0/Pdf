# V16 — HTML/Images vers PDF + téléchargement de séries fiable

## Ce que corrige la V16

- Le mode Site ne dépend plus d'un proxy public qui renvoie facilement HTTP 429.
- Les requêtes externes peuvent passer par un backend Cloudflare Worker/Pages Function avec CORS autorisé et réessais automatiques sur 429/5xx.
- Ortega Scans a un profil dédié : si la série annonce 96 chapitres, la V16 construit 1 à 96 avec `/chapter/<numero>` même si la page n'affiche que le premier lot.
- Les chapitres et les images utilisent 2 traitements simultanés par défaut pour éviter de saturer le téléphone ou le site cible.
- Les modes locaux HTML/ZIP restent utilisables comme avant.

## Installation la plus simple et la plus fiable

### Option A — Cloudflare Pages (recommandée)

1. Mets tout le contenu de ce ZIP dans un dépôt GitHub.
2. Dans Cloudflare > Workers & Pages > Create > Pages > Connect to Git.
3. Choisis le dépôt.
4. Aucun framework n'est nécessaire. Le dossier `functions/api/fetch.js` devient automatiquement le backend `/api/fetch`.
5. Ouvre ensuite l'adresse `*.pages.dev` créée par Cloudflare. La V16 détecte automatiquement son backend.

### Option B — garder GitHub Pages + Worker Cloudflare

1. Déploie le Worker fourni (`worker/src/index.js` + `wrangler.toml`) dans Cloudflare Workers.
2. Copie l'URL `https://...workers.dev`.
3. Dans l'app V16, onglet Site chapitres > Accès réseau fiable, colle l'URL puis appuie sur `Enregistrer le backend`.
4. Ce réglage est mémorisé dans le navigateur.

## Utilisation

1. Onglet `Site chapitres`.
2. Colle l'URL de la série.
3. Appuie directement sur `Télécharger automatiquement toute la série`.
4. L'analyse est automatique si elle n'a pas déjà été faite.
5. Chaque PDF est téléchargé dès qu'il est terminé et un ZIP final peut aussi être créé.

## Limite volontaire

Le backend V16 ne contourne pas les paywalls, CAPTCHA ni accès Premium. Une connexion Google faite dans le navigateur appartient au domaine du site et ne peut pas être transférée automatiquement à un Worker externe. Les pages publiques sont le cas pris en charge de manière fiable.
