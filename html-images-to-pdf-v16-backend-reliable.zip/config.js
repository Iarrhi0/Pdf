// Facultatif sur GitHub Pages : colle ici l'URL de ton Worker Cloudflare après son déploiement.
// Exemple : window.APP_CONFIG = { backendUrl: 'https://pdf-v16-relay.ton-compte.workers.dev' };
window.APP_CONFIG = { backendUrl: '' };
