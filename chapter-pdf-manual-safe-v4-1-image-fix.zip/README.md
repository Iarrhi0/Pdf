# Chapter PDF Manual Safe V4.1 — Correctif images

Correctif ciblé du premier problème signalé.

## Corrigé
- ne prend plus automatiquement `img.src` quand il s'agit d'un placeholder ;
- priorité aux vraies sources lazy-load : `data-src`, `data-original`, `data-lazy-src`, `data-url`, `data-image`, etc. ;
- lecture de `srcset` et `picture/source` ;
- lecture des images dans `noscript` ;
- recherche d'URLs d'images supplémentaires dans le HTML/JSON/JavaScript brut du chapitre ;
- déduplication des URL ;
- contrôle SHA-256 du contenu réellement téléchargé ;
- une même image renvoyée plusieurs fois par le serveur n'est plus ajoutée plusieurs fois au PDF ;
- le compteur affiche maintenant les URL détectées, images uniques, doublons et échecs.

Cette V4.1 ne traite volontairement que le problème d'images répétées / sous-détection.
Le renommage intelligent et le mode upload dossier seront traités séparément ensuite.

## Sortie
Téléchargements/PDF_CONVERTIS/

Compatible avec `unzip-and-build-apk.yml`.
