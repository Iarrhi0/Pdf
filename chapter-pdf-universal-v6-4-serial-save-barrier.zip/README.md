# V6.4 — Serial Save Barrier

Correction du blocage où seuls les fichiers impairs apparaissaient
(`021`, `023`) tandis que `022`, `024` restaient absents.

## Ce qui reste parallèle
Les deux chapitres de la paire continuent :
- détection des images ;
- téléchargement des images ;
- découpage ;
- construction PDF ;
en parallèle.

## Ce qui devient séquentiel
La phase finale JS -> Android -> MediaStore est volontairement sérialisée :

1. le premier PDF prêt entre dans la file d'écriture ;
2. Android confirme `finishDirect()` ;
3. le deuxième PDF est alors écrit ;
4. Android confirme `finishDirect()` ;
5. seulement ensuite la paire suivante démarre.

Chaque PDF possède toujours son propre nom et sa propre entrée MediaStore.
Il n'y a donc ni fusion, ni partage de fichier temporaire.

L'interface distingue maintenant :
- `PDF prêt · attente écriture ...`
- `écriture Android terminée ...`
- `PAIRE ... TERMINÉE · fichier A ET fichier B confirmés sur Android`
