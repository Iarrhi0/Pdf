# Chapter Search PDF PC v1

Version Windows desktop issue de la logique Chapter Search PDF v4 Android.

## Ce qui est porté sur PC

- Interface desktop intégrée avec navigateur Chromium.
- Catalogue `sources.json`, activation/désactivation et injection de nouvelles sources.
- Méta recherche sur les sources actives, jusqu'à 20 recherches en parallèle.
- Ouverture d'un résultat dans le navigateur intégré.
- Détection stricte du lecteur de chapitre.
- Analyse d'une page série et extraction des liens de chapitres numérotés.
- Téléchargement d'un chapitre en PDF.
- Téléchargement groupé avec jusqu'à 10 workers simultanés.
- Pause et arrêt du lot.
- États visibles : LOAD, ANALYSE, DOWNLOAD, PDF, SAVED, ERROR.
- Sortie : `Téléchargements\Chapter Search PDF\`.
- Un chapitre = un PDF, nommé `Série - Chapitre X.pdf`.

## Générer le .exe avec GitHub

1. Crée un dépôt GitHub.
2. Envoie tout le contenu de ce ZIP dans le dépôt.
3. Ouvre **Actions** > **Build Windows EXE**.
4. Clique **Run workflow**.
5. À la fin, télécharge l'artefact **Chapter-Search-PDF-Windows**.
6. Il contient l'installateur Windows et la version portable `.exe`.

Le workflow utilise `windows-latest`, Node.js 20, Electron et electron-builder.

## Lancer localement en développement

```bash
npm install
npm start
```

## Construire localement sous Windows

```bash
npm install
npm run build:win
```

## Limites à connaître

- Certains sites peuvent bloquer les recherches automatisées, exiger un CAPTCHA, un compte ou modifier leur HTML.
- La méta recherche utilise DuckDuckGo HTML comme index pour retrouver les pages d'un domaine. Une source bloquée ou non indexée peut donc retourner zéro résultat même si le titre existe sur le site.
- Le détecteur de chapitres est générique. Les sites avec lecteurs chiffrés, canvas, DRM ou API privées peuvent nécessiter un adaptateur spécifique.
- Utilise uniquement des contenus que tu as le droit de télécharger.
