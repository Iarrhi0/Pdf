# MangaHub PDF 4.2 — fonctionnement intégré

- Démarrage directement sur **Explorer/Rechercher** au lieu d'une bibliothèque vide.
- Recherche globale Kahon alimentée par des **sources compilées dans l'APK** : SushiScan.fr, SushiScan.net, OrtegaScans, Mangas-Origines, ToonFR, HentaiZone.
- Aucun dépôt ou APK d'extension requis pour ces sources.
- Les catalogues populaires de chaque source servent à la découverte/suggestion de séries.
- Sur une série : téléchargement d'un chapitre particulier ou sélection multiple ; **Tout sélectionner + Télécharger** lance toute la série.
- Scheduler MangaHub/Kahon : jusqu'à 10 chapitres actifs, remplissage immédiat des slots libérés.
- Sortie : **un PDF par chapitre**.
- Téléchargements persistants et cache des pages.
- Écran Téléchargements : pause/reprise et arrêt/annulation de la file disponibles via les contrôles Kahon.
- AUTO ENGINE conservé en secours lorsque la liste de pages fournie par le parseur direct échoue.
