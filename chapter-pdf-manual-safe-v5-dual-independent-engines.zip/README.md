# V5.0 — Dual Independent Multi-Engine

Correction majeure du traitement parallèle.

## Principe

Deux chapitres maximum sont traités en parallèle.

Chaque chapitre possède maintenant son propre contexte totalement indépendant :
- son URL ;
- son numéro de chapitre ;
- son modèle d'URL Ortega ;
- sa liste d'images ;
- ses moteurs ;
- ses hashes de doublons ;
- ses pages PDF ;
- ses contrôleurs réseau ;
- ses compteurs.

Aucune image du chapitre A ne peut être réutilisée par le chapitre B.

## Multi-Engine dans CHAQUE chapitre

Pour chaque chapitre :

- Moteur 1 : images 1 à 5
- Moteur 2 : images 6 à 10
- Moteur 3 : images 11 à 15
- Moteur 4 : images 16 à 20
- etc.

Le panneau affiche réellement :
`File A · chap 10 · Moteur 2 · images 6-10`
et en même temps par exemple :
`File B · chap 11 · Moteur 3 · images 11-15`

Un seul téléchargement image actif par file :
2 requêtes image maximum au total.

## Enchaînement

File A :
1 -> 3 -> 5 -> 7 -> ...

File B :
2 -> 4 -> 6 -> 8 -> ...

Chaque file passe à son chapitre suivant dès qu'elle termine,
sans attendre l'autre.

## Séries de plus de 100 chapitres

Il n'y a pas de limite artificielle à 10 ou 12 chapitres.
La file continue tant que la page du chapitre suivant existe.

FIN n'est déclaré que si la page chapitre elle-même répond réellement
404/410.

403/429 = BLOQUÉ, jamais FIN.

## Mémoire

À la fin de chaque chapitre, son contexte est libéré avant de passer au suivant,
afin d'éviter que les images ou pages PDF d'un chapitre soient réutilisées
dans les chapitres suivants.
