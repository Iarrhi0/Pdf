#!/usr/bin/env python3
from pathlib import Path
import shutil, sys, re

if len(sys.argv) != 3:
    raise SystemExit("usage: patch_mangahub.py <kahon-root> <overlay-root>")
root = Path(sys.argv[1]).resolve()
overlay = Path(sys.argv[2]).resolve()

def read(rel): return (root / rel).read_text(encoding='utf-8')
def write(rel, text):
    p = root / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text, encoding='utf-8')
def require_replace(text, old, new, label):
    if old not in text:
        raise RuntimeError(f"Patch marker missing: {label}")
    return text.replace(old, new, 1)

# 1) Branding + independent install package.
p = 'app/build.gradle.kts'
s = read(p)
s = require_replace(s, 'applicationId = "com.amanoteam.kahon"', 'applicationId = "com.mangahub.pdf"', 'applicationId')
s = require_replace(s, 'versionCode = 23', 'versionCode = 400', 'versionCode')
s = require_replace(s, 'versionName = "0.20.2"', 'versionName = "4.0.0-kahon-extensions"', 'versionName')
s = s.replace('buildConfigField("boolean", "UPDATER_ENABLED", "${Config.enableUpdater}")', 'buildConfigField("boolean", "UPDATER_ENABLED", "false")')
write(p, s)

p = 'app/src/main/AndroidManifest.xml'
s = read(p)
s = require_replace(s, 'android:label="@string/app_name"', 'android:label="MangaHub PDF"', 'app label')
write(p, s)

# 2) Kahon runtime: allow all extension content classes; user still chooses what to install.
p = 'app/src/main/java/eu/kanade/tachiyomi/extension/util/ExtensionLoader.kt'
s = read(p)
s = require_replace(s, 'private val loadNsfwSource by lazy {\n        preferences.showNsfwSource.get()\n    }', 'private val loadNsfwSource by lazy { true }', 'NSFW extension visibility')
write(p, s)

# 3) Kahon's downloader default: 10 source jobs in parallel.
p = 'domain/src/main/java/tachiyomi/domain/download/service/DownloadPreferences.kt'
s = read(p)
s = require_replace(s, 'preferenceStore.getInt("download_parallel_source_limit", 5)', 'preferenceStore.getInt("download_parallel_source_limit", 10)', 'parallel source default')
write(p, s)

# 4) Accept modern stores and legacy index.min.json-only stores.
p = 'data/src/main/java/mihon/data/extension/repository/ExtensionStoreRepositoryImpl.kt'
s = read(p)
old = '''    override suspend fun insert(indexUrl: String): Result<Unit> {\n        return service.fetch(indexUrl).mapCatching { upsert(it) }\n    }'''
new = '''    override suspend fun insert(indexUrl: String): Result<Unit> {\n        val fetched = service.fetch(indexUrl)\n        if (fetched.isSuccess) return fetched.mapCatching { upsert(it) }\n\n        // MangaHub compatibility: some useful community stores still publish only\n        // index.min.json. Kahon 0.20+ normally expects repo.json. Register those\n        // as legacy stores so the existing legacy parser can consume their index.\n        if (indexUrl.endsWith("/index.min.json")) {\n            return runCatching {\n                val baseUrl = indexUrl.removeSuffix("/index.min.json")\n                val host = runCatching { java.net.URI(indexUrl).host }.getOrNull() ?: "Community"\n                database.extension_storeQueries.upsert(\n                    indexUrl = "$baseUrl/repo.json",\n                    name = host,\n                    badgeLabel = host,\n                    signingKey = "NO_SIGNING_KEY",\n                    contactWebsite = baseUrl,\n                    contactDiscord = null,\n                    isLegacy = true,\n                    extensionListUrl = null,\n                )\n            }\n        }\n        return fetched.mapCatching { upsert(it) }\n    }'''
s = require_replace(s, old, new, 'legacy extension store fallback')
write(p, s)

# 5) Preconfigure common extension stores on first run.
p = 'app/src/main/java/eu/kanade/tachiyomi/App.kt'
s = read(p)
anchor_import = 'import mihon.core.migration.migrations.migrations\n'
s = require_replace(s, anchor_import, anchor_import + 'import mihon.domain.extension.repository.ExtensionStoreRepository\n', 'ExtensionStoreRepository import')
old_call = '''        scope.launch(Dispatchers.IO) {\n            ensureSavedSearchTable()\n        }'''
new_call = '''        scope.launch(Dispatchers.IO) {\n            ensureSavedSearchTable()\n            ensureMangaHubExtensionStores()\n        }'''
s = require_replace(s, old_call, new_call, 'startup store init')
marker = '    // Self-heal databases created by dev builds whose user_version was bumped\n'
func = '''    private suspend fun ensureMangaHubExtensionStores() {\n        val prefs = getSharedPreferences("mangahub_pdf", MODE_PRIVATE)\n        if (prefs.getBoolean("extension_stores_v2", false)) return\n\n        val repository = Injekt.get<ExtensionStoreRepository>()\n        val stores = listOf(\n            "https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.min.json",\n            "https://raw.githubusercontent.com/Poulpiix/Extension-Tachimanga-FR/refs/heads/main/index.min.json",\n            "https://raw.githubusercontent.com/marbou92/MHRepo/main/repo.json",\n        )\n        var success = false\n        stores.forEach { url ->\n            repository.insert(url).onSuccess { success = true }\n        }\n        if (success) prefs.edit().putBoolean("extension_stores_v2", true).apply()\n    }\n\n'''
if marker not in s: raise RuntimeError('Patch marker missing: App helper insertion')
s = s.replace(marker, func + marker, 1)
write(p, s)

# 6) Copy MangaHub exporter + AUTO ENGINE overlay.
src_dir = overlay / 'app/src/main/java/eu/kanade/tachiyomi/data/download'
dst_dir = root / 'app/src/main/java/eu/kanade/tachiyomi/data/download'
for name in ['MangaHubPdfExporter.kt', 'MangaHubAutoEngine.kt']:
    shutil.copy2(src_dir / name, dst_dir / name)

# 7) Wire extension-first AUTO ENGINE and mandatory PDF creation into Kahon downloader.
p = 'app/src/main/java/eu/kanade/tachiyomi/data/download/Downloader.kt'
s = read(p)
old_pages = '''                val pages = download.source.getPageList(download.chapter.toSChapter())\n\n                if (pages.isEmpty()) {\n                    throw Exception(context.stringResource(MR.strings.page_list_empty_error))\n                }'''
new_pages = '''                val sourceChapter = download.chapter.toSChapter()\n                val pages = runCatching { download.source.getPageList(sourceChapter) }\n                    .getOrElse { primaryError ->\n                        logcat(LogPriority.WARN, primaryError) { "Extension page engine failed; trying MangaHub AUTO ENGINE" }\n                        MangaHubAutoEngine.extractGeneric(download.source, sourceChapter)\n                    }\n                    .ifEmpty { MangaHubAutoEngine.extractGeneric(download.source, sourceChapter) }\n\n                if (pages.isEmpty()) {\n                    throw Exception(context.stringResource(MR.strings.page_list_empty_error))\n                }'''
s = require_replace(s, old_pages, new_pages, 'AUTO ENGINE page list')

old_pdf_point = '''            createComicInfoFile(\n                tmpDir,\n                download.manga,\n                download.chapter,\n                download.source,\n            )'''
new_pdf_point = '''            // MangaHub invariant: a chapter is only considered successful after its PDF exists.\n            MangaHubPdfExporter.exportChapter(\n                context = context,\n                chapterDir = tmpDir,\n                mangaTitle = download.manga.title,\n                chapterName = download.chapter.name,\n            ).getOrElse { throw IllegalStateException("PDF export failed", it) }\n\n            createComicInfoFile(\n                tmpDir,\n                download.manga,\n                download.chapter,\n                download.source,\n            )'''
s = require_replace(s, old_pdf_point, new_pdf_point, 'PDF export hook')
write(p, s)

# 8) Add attribution/notes into cloned project.
(root / 'MANGAHUB_PATCHED.txt').write_text('''MangaHub PDF V4 — Kahon Extensions Edition\n\nKahon upstream pinned: 3f7cda90cac82c781751c593478cd6dca2e3e1d5\nMangaHub additions: extension stores bootstrap, legacy repo fallback, 10-source downloads, AUTO ENGINE fallback, one-chapter-one-PDF exporter.\n''', encoding='utf-8')
print('MangaHub patches applied successfully')
