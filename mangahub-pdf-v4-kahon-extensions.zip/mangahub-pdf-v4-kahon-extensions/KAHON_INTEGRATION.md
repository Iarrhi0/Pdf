# Architecture

Extension Store -> Extension APK -> Source Kahon -> Manga -> Chapitres -> Pages
                                                       |
                                                       +-> MangaHub AUTO ENGINE fallback
                                                       |
                                                       +-> Downloader Kahon (resume/cache)
                                                       |
                                                       +-> MangaHub PDF exporter

Le système d'extensions est celui de Kahon/Mihon, pas une liste de sites codée dans MangaHub.
