# MangaHub PDF V4 — Kahon Extensions Edition

Cette version n'est plus basée sur la petite WebView de MangaHub V3.
Le workflow GitHub récupère une version épinglée de Kahon, applique les patches MangaHub, puis construit l'APK.

## Ce que V4 apporte

- Runtime d'extensions Kahon/Mihon réel (extensions APK, sources, magasins, mises à jour).
- Compatibilité Kahon actuelle avec extensions tachiyomix 1.4 et 1.6.
- Magasins préconfigurés au premier lancement : Keiyoushi, Poulpiix FR, MHExtensions.
- Les magasins supplémentaires restent ajoutables depuis l'écran Extensions de Kahon.
- Toutes les langues/extensions restent accessibles via le système Kahon.
- Sources NSFW autorisées par le runtime MangaHub (elles ne sont pas installées automatiquement).
- 10 sources/chapitres peuvent être téléchargés en parallèle.
- 1 chapitre = 1 PDF exporté dans Download/MangaHub PDF/<Série>/.
- Sauvegarde PDF via MediaStore avec IS_PENDING sur Android 10+.
- Le téléchargement Kahon original est conservé pour la reprise/cache/lecture ; le PDF est un export obligatoire du chapitre.
- AUTO ENGINE : l'extracteur de l'extension est prioritaire; si sa liste de pages échoue ou est vide, MangaHub essaie un extracteur HTML générique multi-attributs avant d'abandonner.

## Build

1. Décompresser ce ZIP dans un dépôt GitHub vide.
2. Commit/push.
3. Ouvrir Actions > Build MangaHub PDF Kahon Edition > Run workflow.
4. Télécharger l'artifact `MangaHub-PDF-V4-APK`.

Le workflow utilise JDK 25 comme Kahon upstream et clone un commit Kahon épinglé pour éviter qu'une modification future casse le patch.

## Important

Les extensions ne sont pas copiées dans l'APK principal : comme Kahon, MangaHub les découvre depuis des magasins et les installe comme extensions. C'est ce qui permet d'avoir le catalogue complet et de recevoir les mises à jour sans reconstruire MangaHub.

Kahon est sous licence Apache-2.0. Les fichiers upstream restent sous leur licence et leurs copyrights respectifs.
