package eu.kanade.tachiyomi.data.download

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.hippo.unifile.UniFile
import java.io.File
import java.io.FileOutputStream

/** MangaHub invariant: one downloaded chapter produces one PDF. */
object MangaHubPdfExporter {
    fun exportChapter(
        context: Context,
        chapterDir: UniFile,
        mangaTitle: String,
        chapterName: String,
    ): Result<Unit> = runCatching {
        val images = chapterDir.listFiles().orEmpty()
            .filter { f ->
                val n = f.name?.lowercase().orEmpty()
                f.isFile && !n.endsWith(".tmp") &&
                    (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
                        n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".avif"))
            }
            .sortedBy { it.name.orEmpty() }

        require(images.isNotEmpty()) { "Aucune image de chapitre à exporter" }

        val safeManga = sanitize(mangaTitle)
        val safeChapter = sanitize(chapterName)
        val displayName = "$safeManga - $safeChapter.pdf"
        val pdf = PdfDocument()

        try {
            images.forEachIndexed { idx, file ->
                val bitmap = file.openInputStream().use { BitmapFactory.decodeStream(it) }
                    ?: error("Image illisible: ${file.name}")
                try {
                    val width = bitmap.width.coerceAtLeast(1)
                    val height = bitmap.height.coerceAtLeast(1)
                    val pageInfo = PdfDocument.PageInfo.Builder(width, height, idx + 1).create()
                    val page = pdf.startPage(pageInfo)
                    page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdf.finishPage(page)
                } finally {
                    bitmap.recycle()
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/MangaHub PDF/$safeManga")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Impossible de créer le PDF MediaStore")
                try {
                    resolver.openOutputStream(uri, "w")!!.use { pdf.writeTo(it) }
                    val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                } catch (t: Throwable) {
                    resolver.delete(uri, null, null)
                    throw t
                }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "MangaHub PDF/$safeManga",
                )
                check(dir.exists() || dir.mkdirs()) { "Impossible de créer ${dir.absolutePath}" }
                val part = File(dir, "$displayName.part")
                val target = File(dir, displayName)
                FileOutputStream(part).use { pdf.writeTo(it) }
                if (target.exists()) target.delete()
                check(part.renameTo(target)) { "Impossible de finaliser le PDF" }
            }
        } finally {
            pdf.close()
        }
    }

    private fun sanitize(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|]"), "_")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(120)
        .ifBlank { "Chapitre" }
}
