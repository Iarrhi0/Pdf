package eu.kanade.tachiyomi.data.download

import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.online.HttpSource
import okhttp3.Request
import org.jsoup.Jsoup
import java.net.URI
import java.util.LinkedHashSet

/**
 * Fallback MangaHub. The extension remains engine #1 because it knows the source.
 * This engine is used only when the extension cannot return usable pages.
 */
object MangaHubAutoEngine {
    fun extractGeneric(source: HttpSource, chapter: SChapter): List<Page> {
        val chapterUrl = absolute(source.baseUrl, chapter.url)
        val response = source.client.newCall(
            Request.Builder().url(chapterUrl).headers(source.headers).build(),
        ).execute()
        response.use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            val html = it.body.string()
            val doc = Jsoup.parse(html, chapterUrl)
            val urls = LinkedHashSet<String>()

            val attrs = listOf("src", "data-src", "data-original", "data-lazy-src", "data-url", "data-image")
            doc.select("img").forEach { el ->
                attrs.forEach { attr -> addCandidate(urls, el.attr(attr), chapterUrl) }
                addSrcset(urls, el.attr("srcset"), chapterUrl)
            }
            doc.select("source").forEach { el ->
                addCandidate(urls, el.attr("src"), chapterUrl)
                addSrcset(urls, el.attr("srcset"), chapterUrl)
            }
            doc.select("noscript").forEach { ns ->
                val inner = Jsoup.parse(ns.html(), chapterUrl)
                inner.select("img").forEach { el ->
                    attrs.forEach { attr -> addCandidate(urls, el.attr(attr), chapterUrl) }
                }
            }

            // URLs embedded in JSON/JS.
            Regex("https?://[^\\\"'\\s<>]+", RegexOption.IGNORE_CASE)
                .findAll(html)
                .forEach { addCandidate(urls, it.value.replace("\\/", "/"), chapterUrl) }

            return urls
                .filter(::looksLikeReaderImage)
                .mapIndexed { index, url -> Page(index, imageUrl = url) }
        }
    }

    private fun addSrcset(out: MutableSet<String>, value: String, base: String) {
        value.split(',').forEach { part -> addCandidate(out, part.trim().substringBefore(' '), base) }
    }

    private fun addCandidate(out: MutableSet<String>, raw: String?, base: String) {
        if (raw.isNullOrBlank() || raw.startsWith("data:")) return
        runCatching { absolute(base, raw.trim()) }.getOrNull()?.let(out::add)
    }

    private fun absolute(base: String, candidate: String): String = URI(base).resolve(candidate).toString()

    private fun looksLikeReaderImage(url: String): Boolean {
        val u = url.lowercase()
        if (!(u.contains(".jpg") || u.contains(".jpeg") || u.contains(".png") || u.contains(".webp") || u.contains(".avif"))) return false
        val bad = listOf("logo", "avatar", "icon", "emoji", "banner", "adsense", "/ads/", "advert", "publicite", "promo", "sponsor", "sprite", "placeholder", "loading", "spacer", "favicon", "recommend", "related", "thumbnail", "thumb")
        return bad.none { u.contains(it) }
    }
}
