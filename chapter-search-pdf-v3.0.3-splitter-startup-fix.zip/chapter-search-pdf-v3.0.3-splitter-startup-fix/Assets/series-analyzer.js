(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function canon(h){try{var u=new URL(h,location.href);u.hash='';['utm_source','utm_medium','utm_campaign','ref'].forEach(function(k){u.searchParams.delete(k)});if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/+$/,'/');return u.href}catch(e){return ''}}
  function cleanSeries(s){return norm(s).replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()}
  function number(t,u){var s=(t||'')+' '+(u||'');var m=s.match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(m)return parseFloat(m[1]);m=s.match(/(?:^|[-_\/])(\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?parseFloat(m[1]):null}
  function listContainer(a){return !!(a&&a.closest&&a.closest('.chapters,.chapter-list,.listing-chapters_wrap,.wp-manga-chapter,.eplister,.episodelist,.list-chapter,.version-chap,.c-tabs-item__content,.page-listing-item,.chapter-listing,.episodes,.episode-list,.chapters-list,.manga-chapters,.chapter-list-wrap'))}
  function parasite(a){return !!(a&&a.closest&&a.closest('header,footer,nav,.menu,.related,.recommend,.recommendation,.similar,.sidebar,.widget,.breadcrumb,.breadcrumbs,.popular,.latest,.recent'))}
  var origin=location.origin,path=location.pathname,parts=path.split('/').filter(Boolean);
  var heads=['porncomic','manga','comic','webtoon','title','series','manga-series','manhwa','manhua','comics','catalogue'];
  var family='';
  if(parts.length>=2&&heads.indexOf(parts[0].toLowerCase())>=0)family='/'+parts[0]+'/'+parts[1]+'/';
  var h1=norm((document.querySelector('h1')||{}).textContent),series=cleanSeries(h1)||cleanSeries(document.title)||'Série';
  var bodyText=norm((document.body||{}).innerText||'');
  var declaredLast=null, dm=bodyText.match(/(?:dernier|last)\s*(?:chapitre|chapter|tome|volume)?\s*[:#-]?\s*(\d+(?:\.\d+)?)/i);if(dm)declaredLast=parseFloat(dm[1]);
  var map={};
  document.querySelectorAll('a[href]').forEach(function(a){
    var u=canon(a.getAttribute('href')),t=norm(a.innerText||a.textContent);if(!u)return;
    var x;try{x=new URL(u);if(x.origin!==origin)return}catch(e){return}
    var familyOk=!!family&&x.pathname.indexOf(family)===0;
    var familyRest=familyOk?x.pathname.slice(family.length):'';
    var familyDirect=familyOk&&/^\d+(?:\.\d+)?(?:[-_\/]|$)/.test(familyRest);
    var listOk=listContainer(a);
    if(!familyOk&&!listOk)return;
    if(parasite(a)&&!familyOk)return;
    var n=number(t,u);if(n===null||isNaN(n))return;
    if(declaredLast!==null&&n>declaredLast+0.001)return;
    var sig=/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*\d/i.test(t+' '+u);
    if(!sig&&!listOk&&!familyDirect)return;
    var key=String(n),cand={number:n,title:(/(tome|volume)/i.test(t+' '+u)?'Tome ':'Chapitre ')+n,url:u,series:series,source:familyOk?'same-series-path':'chapter-list'};
    var old=map[key];if(!old||familyOk&&old.source!=='same-series-path')map[key]=cand;
  });
  var out=Object.keys(map).map(function(k){return map[k]}).sort(function(a,b){return a.number-b.number});
  if(family)out=out.filter(function(c){try{return new URL(c.url).pathname.indexOf(family)===0}catch(e){return false}});
  var next=null;
  document.querySelectorAll('a[href]').forEach(function(a){if(next)return;var txt=norm(a.innerText||a.textContent),rel=(a.getAttribute('rel')||'');if(/(^|\s)next(\s|$)/i.test(rel)||/^(suivant|next|chapitre suivant|next chapter|tome suivant)$/i.test(txt)){var u=canon(a.getAttribute('href'));if(u)next=u;}});
  return JSON.stringify({series:series,family:family,declaredLast:declaredLast,chapters:out.slice(0,2000),next:next,current:canon(location.href)});
})();
