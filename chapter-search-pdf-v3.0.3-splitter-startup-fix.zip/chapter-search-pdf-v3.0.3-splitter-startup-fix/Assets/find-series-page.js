(function(){
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function clean(s){return norm(s).replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').trim()}
  var p=location.pathname.split('/').filter(Boolean),heads=['porncomic','manga','comic','webtoon','title','series','manga-series','manhwa','manhua','comics','catalogue'];
  if(p.length>=2&&heads.indexOf(p[0].toLowerCase())>=0){return JSON.stringify({series:clean((document.querySelector('h1')||{}).textContent)||clean(document.title),url:location.origin+'/'+p[0]+'/'+p[1]+'/'});}
  return JSON.stringify({series:clean((document.querySelector('h1')||{}).textContent)||clean(document.title),url:location.href});
})();
