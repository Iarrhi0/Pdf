# Build Fix 3.0.1

Corrections de compilation uniquement, sans changement fonctionnel :

1. `RendererPool.cs`: `Environment.GetFolderPath(...)` est qualifié en `System.Environment.GetFolderPath(...)` pour éviter la collision avec la propriété `RendererPool.Environment`.
2. `MainForm.cs`: les déclarations `var a = ..., b = ...` ont été séparées en déclarations individuelles (C# interdit plusieurs déclarateurs avec `var`).
3. Version du projet passée à 3.0.1 afin que le ZIP corrigé soit clairement identifiable.
