namespace ChapterSearchPdfV3.Models;

public enum JobState
{
    Queued,
    Render,
    Engine5,
    Download,
    Pdf,
    Paused,
    Saved,
    Error,
    Stopped,
    Removed
}

public sealed class ChapterCandidate
{
    public double Number { get; set; }
    public string Title { get; set; } = "Chapitre";
    public string Url { get; set; } = "";
    public string Series { get; set; } = "Série";
    public string Source { get; set; } = "";
}

public sealed class ExtractPayload
{
    public bool Ok { get; set; }
    public string Series { get; set; } = "Série";
    public string Chapter { get; set; } = "Chapitre";
    public double? Number { get; set; }
    public List<string> Images { get; set; } = [];
    public string Engine { get; set; } = "APK40";
    public string Reader { get; set; } = "";
    public string FinalUrl { get; set; } = "";
    public string CookieHeader { get; set; } = "";
    public string UserAgent { get; set; } = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36";
}

public sealed class DownloadJob
{
    public int Id { get; set; }
    public string Series { get; set; } = "Série";
    public string Title { get; set; } = "Chapitre";
    public double? Number { get; set; }
    public string Url { get; set; } = "";
    public JobState State { get; set; } = JobState.Queued;
    public string Phase { get; set; } = "QUEUED";
    public string Error { get; set; } = "";
    public int Page { get; set; }
    public int Pages { get; set; }
    public string Target { get; set; } = "";
    public double SpeedMbps { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.Now;
    public CancellationTokenSource Cancellation { get; set; } = new();
    public AsyncPauseGate PauseGate { get; } = new();
    public bool RemoveWhenDone { get; set; }
    public int Generation { get; set; }
}

public sealed class SearchSource
{
    public string Name { get; set; } = "";
    public string Domain { get; set; } = "";
    public string Lang { get; set; } = "";
    public string Type { get; set; } = "";
    public bool Enabled { get; set; } = true;
}

public sealed class SearchResult
{
    public string Source { get; set; } = "";
    public string Title { get; set; } = "";
    public string Url { get; set; } = "";
    public double Score { get; set; }
    public string Method { get; set; } = "";
}

public sealed class AsyncPauseGate
{
    private volatile TaskCompletionSource<bool>? _waiter;
    public bool IsPaused => _waiter is not null;

    public void Pause()
    {
        Interlocked.CompareExchange(ref _waiter, new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously), null);
    }

    public void Resume()
    {
        var waiter = Interlocked.Exchange(ref _waiter, null);
        waiter?.TrySetResult(true);
    }

    public async Task WaitAsync(CancellationToken token)
    {
        var waiter = _waiter;
        if (waiter is null) return;
        await waiter.Task.WaitAsync(token);
    }
}
