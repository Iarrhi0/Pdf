using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using ChapterSearchPdfV3.Models;

namespace ChapterSearchPdfV3.Services;

public sealed class DownloadManager : IDisposable
{
    private readonly RendererPool _renderers;
    private readonly object _gate = new();
    private readonly List<DownloadJob> _jobs = [];
    private readonly ConcurrentDictionary<int, Task> _active = new();
    private readonly SemaphoreSlim _convert = new(2, 2);
    private readonly HttpClient _http;
    private readonly CancellationTokenSource _lifetime = new();
    private readonly Task _scheduler;
    private int _nextId = 1;
    private const int MaxActive = 10;
    private readonly string _queuePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChapterSearchPdfV3", "download-queue.json");
    private long _lastPersistTicks;

    public event Action? Changed;

    public DownloadManager(RendererPool renderers)
    {
        _renderers = renderers;
        var handler = new SocketsHttpHandler
        {
            AutomaticDecompression = DecompressionMethods.All,
            MaxConnectionsPerServer = 20,
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            ConnectTimeout = TimeSpan.FromSeconds(8),
            UseCookies = false,
            AllowAutoRedirect = true
        };
        _http = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
        RestoreQueue();
        _scheduler = Task.Run(SchedulerLoopAsync);
    }

    public IReadOnlyList<DownloadJob> Snapshot()
    {
        lock (_gate) return _jobs.Where(j => j.State != JobState.Removed).OrderBy(j => j.AddedAt).ToList();
    }

    public void Add(IEnumerable<ChapterCandidate> chapters, bool startImmediately = true)
    {
        lock (_gate)
        {
            foreach (var c in chapters)
            {
                if (!Uri.TryCreate(c.Url, UriKind.Absolute, out var u) || (u.Scheme != "http" && u.Scheme != "https")) continue;
                if (_jobs.Any(j => j.State != JobState.Removed && SameIdentity(j, c))) continue;
                _jobs.Add(new DownloadJob
                {
                    Id = _nextId++,
                    Series = Sanitize(c.Series),
                    Title = string.IsNullOrWhiteSpace(c.Title) ? $"Chapitre {c.Number}" : c.Title,
                    Number = c.Number,
                    Url = u.AbsoluteUri,
                    State = startImmediately ? JobState.Queued : JobState.Paused,
                    Phase = startImmediately ? "QUEUED" : "PAUSED"
                });
            }
        }
        Notify();
    }

    public void Pause(int id)
    {
        var j = Find(id); if (j is null) return;
        j.PauseGate.Pause();
        if (j.State == JobState.Queued) j.State = JobState.Paused;
        j.Phase = "PAUSED";
        Notify();
    }

    public void Resume(int id)
    {
        var j = Find(id); if (j is null) return;
        j.PauseGate.Resume();
        if (j.State == JobState.Paused) { j.State = JobState.Queued; j.Phase = "QUEUED"; }
        else if (j.State == JobState.Download) j.Phase = $"DOWNLOAD {j.Page}/{Math.Max(1, j.Pages)}";
        Notify();
    }

    public void Stop(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        j.Cancellation.Cancel();
        j.PauseGate.Resume();
        j.State = JobState.Stopped;
        j.Phase = "STOPPED";
        Notify();
    }

    public void Remove(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        j.Cancellation.Cancel();
        j.PauseGate.Resume();
        j.State = JobState.Removed;
        j.Phase = "REMOVED";
        Notify();
    }

    public void Retry(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        try { j.Cancellation.Cancel(); } catch { }
        j.Cancellation.Dispose();
        j.Cancellation = new CancellationTokenSource();
        j.PauseGate.Resume();
        j.Error = "";
        j.Page = 0;
        j.Pages = 0;
        j.SpeedMbps = 0;
        j.Target = "";
        j.State = JobState.Queued;
        j.Phase = "RELOAD";
        Notify();
    }

    public void PauseAll() { foreach (var j in Snapshot().Where(x => x.State is JobState.Queued or JobState.Render or JobState.Engine5 or JobState.Download or JobState.Pdf)) Pause(j.Id); }
    public void ResumeAll() { foreach (var j in Snapshot().Where(x => x.State == JobState.Paused)) Resume(j.Id); }
    public void RetryErrors() { foreach (var j in Snapshot().Where(x => x.State == JobState.Error)) Retry(j.Id); }
    public void ClearFinished() { foreach (var j in Snapshot().Where(x => x.State is JobState.Saved or JobState.Stopped or JobState.Error)) Remove(j.Id); }

    private async Task SchedulerLoopAsync()
    {
        while (!_lifetime.IsCancellationRequested)
        {
            try
            {
                var capacity = MaxActive - _active.Count;
                if (capacity > 0)
                {
                    List<DownloadJob> next;
                    lock (_gate)
                    {
                        next = _jobs.Where(j => j.State == JobState.Queued && !_active.ContainsKey(j.Id)).Take(capacity).ToList();
                        foreach (var j in next) { j.State = JobState.Render; j.Phase = "LOAD"; }
                    }
                    foreach (var job in next)
                    {
                        var generation = job.Generation;
                        var task = Task.Run(() => RunJobAsync(job, generation));
                        _active[job.Id] = task;
                        _ = task.ContinueWith(_ => { _active.TryRemove(job.Id, out _); Notify(); }, TaskScheduler.Default);
                    }
                    if (next.Count > 0) Notify();
                }
                await Task.Delay(120, _lifetime.Token);
            }
            catch (OperationCanceledException) { break; }
            catch { await Task.Delay(400); }
        }
    }

    private async Task RunJobAsync(DownloadJob job, int generation)
    {
        var token = job.Cancellation.Token;
        string? temp = null;
        try
        {
            await job.PauseGate.WaitAsync(token);
            Set(job, generation, JobState.Render, "RENDER");
            var payload = await _renderers.RenderChapterAsync(job.Url, token);
            EnsureGeneration(job, generation);

            payload.Series = string.IsNullOrWhiteSpace(job.Series) ? payload.Series : job.Series;
            payload.Chapter = string.IsNullOrWhiteSpace(job.Title) ? payload.Chapter : job.Title;
            job.Pages = payload.Images.Count;
            Set(job, generation, JobState.Engine5, $"{payload.Engine} • {payload.Images.Count} pages");

            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "Chapter Search PDF", Sanitize(payload.Series));
            Directory.CreateDirectory(dir);
            var target = Path.Combine(dir, BuildPdfName(payload.Series, payload.Chapter));
            temp = target + ".part";
            job.Target = target;
            if (File.Exists(target)) { Set(job, generation, JobState.Saved, "SAVED"); return; }
            if (File.Exists(temp)) File.Delete(temp);

            Set(job, generation, JobState.Download, "DOWNLOAD");
            var currentPayload = payload;
            var recovered = false;
            using (var pdf = new StreamingPdfWriter(temp))
            {
                for (var i = 0; i < currentPayload.Images.Count; i++)
                {
                    token.ThrowIfCancellationRequested();
                    EnsureGeneration(job, generation);
                    await job.PauseGate.WaitAsync(token);
                    if (job.State == JobState.Paused) Set(job, generation, JobState.Download, "DOWNLOAD");

                    byte[]? bytes = null;
                    var sw = Stopwatch.StartNew();
                    try
                    {
                        bytes = await FetchWithRetryAsync(currentPayload.Images[i], currentPayload, token);
                    }
                    catch when (!recovered)
                    {
                        // Comme le téléphone : rerendre le chapitre et renouveler URLs/cookies avant d'abandonner.
                        recovered = true;
                        Set(job, generation, JobState.Render, "RECOVERY • ENGINE5");
                        currentPayload = await _renderers.RenderChapterAsync(job.Url, token);
                        currentPayload.Series = payload.Series;
                        currentPayload.Chapter = payload.Chapter;
                        if (i >= currentPayload.Images.Count) throw new InvalidOperationException($"Page {i + 1} introuvable après récupération");
                        Set(job, generation, JobState.Download, "DOWNLOAD");
                        bytes = await FetchWithRetryAsync(currentPayload.Images[i], currentPayload, token);
                    }

                    await _convert.WaitAsync(token);
                    ImageCodec.JpegPage page;
                    try { page = ImageCodec.ToJpeg(bytes!); }
                    finally { _convert.Release(); }
                    pdf.AddJpeg(page.Bytes, page.Width, page.Height);
                    sw.Stop();

                    job.Page = i + 1;
                    job.Pages = currentPayload.Images.Count;
                    var mb = bytes!.LongLength / 1024d / 1024d;
                    job.SpeedMbps = sw.Elapsed.TotalSeconds > 0 ? mb / sw.Elapsed.TotalSeconds : 0;
                    job.Phase = $"DOWNLOAD {job.Page}/{job.Pages}";
                    NotifyThrottled();
                }
                Set(job, generation, JobState.Pdf, "PDF");
                pdf.Complete();
            }

            File.Move(temp, target, true);
            temp = null;
            Set(job, generation, JobState.Saved, "SAVED");
        }
        catch (OperationCanceledException)
        {
            if (job.Generation == generation && job.State != JobState.Removed) Set(job, generation, JobState.Stopped, "STOPPED");
        }
        catch (Exception ex)
        {
            if (job.Generation == generation && job.State != JobState.Removed)
            {
                job.Error = ex.Message;
                Set(job, generation, JobState.Error, "ERROR");
            }
        }
        finally
        {
            if (temp is not null) { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
    }

    private async Task<byte[]> FetchWithRetryAsync(string url, ExtractPayload payload, CancellationToken token)
    {
        Exception? last = null;
        for (var attempt = 1; attempt <= 3; attempt++)
        {
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.TryAddWithoutValidation("User-Agent", payload.UserAgent);
                req.Headers.TryAddWithoutValidation("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
                req.Headers.TryAddWithoutValidation("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8");
                req.Headers.TryAddWithoutValidation("Referer", payload.FinalUrl);
                if (!string.IsNullOrWhiteSpace(payload.CookieHeader)) req.Headers.TryAddWithoutValidation("Cookie", payload.CookieHeader);
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
                timeout.CancelAfter(TimeSpan.FromSeconds(18));
                using var res = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
                if (!res.IsSuccessStatusCode) throw new HttpRequestException($"HTTP {(int)res.StatusCode}");
                var media = res.Content.Headers.ContentType?.MediaType ?? "";
                if (media.Contains("html", StringComparison.OrdinalIgnoreCase) || media.Contains("text/", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Réponse non-image");
                var bytes = await res.Content.ReadAsByteArrayAsync(timeout.Token);
                if (bytes.Length < 128) throw new InvalidDataException("Image trop petite");
                return bytes;
            }
            catch (Exception ex) when (attempt < 3 && ex is not OperationCanceledException)
            {
                last = ex;
                await Task.Delay(180 * attempt, token);
            }
        }
        throw last ?? new IOException("Téléchargement image impossible");
    }

    private void Set(DownloadJob job, int generation, JobState state, string phase)
    {
        EnsureGeneration(job, generation);
        job.State = state;
        job.Phase = phase;
        Notify();
    }

    private static void EnsureGeneration(DownloadJob job, int generation)
    {
        if (job.Generation != generation) throw new OperationCanceledException();
    }

    private DownloadJob? Find(int id) { lock (_gate) return _jobs.FirstOrDefault(x => x.Id == id); }
    private static bool SameIdentity(DownloadJob j, ChapterCandidate c) => string.Equals(j.Series, c.Series, StringComparison.OrdinalIgnoreCase) && Math.Abs((j.Number ?? -1) - c.Number) < 0.0001;
    private static string Sanitize(string s) => string.Join(" ", (s ?? "Série").Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries)).Trim() is { Length: > 0 } x ? x : "Série";
    private static string BuildPdfName(string series, string chapter)
    {
        var s = Sanitize(series); var c = Sanitize(chapter);
        return c.StartsWith(s, StringComparison.OrdinalIgnoreCase) ? c + ".pdf" : $"{s} - {c}.pdf";
    }

    private long _lastNotifyTicks;
    private void NotifyThrottled()
    {
        var now = Environment.TickCount64;
        if (now - Interlocked.Read(ref _lastNotifyTicks) < 250) return;
        Interlocked.Exchange(ref _lastNotifyTicks, now);
        Notify();
    }
    private void Notify()
    {
        PersistThrottled();
        Changed?.Invoke();
    }

    private void PersistThrottled()
    {
        var now = Environment.TickCount64;
        if (now - Interlocked.Read(ref _lastPersistTicks) < 700) return;
        Interlocked.Exchange(ref _lastPersistTicks, now);
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_queuePath)!);
            List<object> dto;
            lock (_gate)
            {
                dto = _jobs.Where(j => j.State != JobState.Removed).Select(j => (object)new
                {
                    j.Id, j.Series, j.Title, j.Number, j.Url,
                    State = j.State.ToString(), j.Phase, j.Error, j.Page, j.Pages, j.Target, j.AddedAt
                }).ToList();
            }
            File.WriteAllText(_queuePath, JsonSerializer.Serialize(new { nextId = _nextId, jobs = dto }, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void RestoreQueue()
    {
        try
        {
            if (!File.Exists(_queuePath)) return;
            using var doc = JsonDocument.Parse(File.ReadAllText(_queuePath));
            if (doc.RootElement.TryGetProperty("nextId", out var ni) && ni.TryGetInt32(out var next)) _nextId = Math.Max(1, next);
            if (!doc.RootElement.TryGetProperty("jobs", out var jobs) || jobs.ValueKind != JsonValueKind.Array) return;
            foreach (var x in jobs.EnumerateArray())
            {
                var stateText = x.TryGetProperty("State", out var st) ? st.GetString() : "Queued";
                Enum.TryParse<JobState>(stateText, true, out var state);
                var target = x.TryGetProperty("Target", out var tg) ? tg.GetString() ?? "" : "";
                if (state is JobState.Render or JobState.Engine5 or JobState.Download or JobState.Pdf) state = JobState.Queued;
                if (state == JobState.Saved && !string.IsNullOrWhiteSpace(target) && !File.Exists(target)) state = JobState.Queued;
                var j = new DownloadJob
                {
                    Id = x.TryGetProperty("Id", out var id) && id.TryGetInt32(out var iv) ? iv : _nextId++,
                    Series = x.TryGetProperty("Series", out var se) ? se.GetString() ?? "Série" : "Série",
                    Title = x.TryGetProperty("Title", out var ti) ? ti.GetString() ?? "Chapitre" : "Chapitre",
                    Number = x.TryGetProperty("Number", out var nu) && nu.ValueKind == JsonValueKind.Number && nu.TryGetDouble(out var nv) ? nv : null,
                    Url = x.TryGetProperty("Url", out var ur) ? ur.GetString() ?? "" : "",
                    State = state,
                    Phase = state == JobState.Queued ? "QUEUED" : state.ToString().ToUpperInvariant(),
                    Error = x.TryGetProperty("Error", out var er) ? er.GetString() ?? "" : "",
                    Page = x.TryGetProperty("Page", out var pg) && pg.TryGetInt32(out var pgv) ? pgv : 0,
                    Pages = x.TryGetProperty("Pages", out var pgs) && pgs.TryGetInt32(out var pgsv) ? pgsv : 0,
                    Target = target,
                    AddedAt = x.TryGetProperty("AddedAt", out var ad) && ad.TryGetDateTime(out var dt) ? dt : DateTime.Now
                };
                if (Uri.TryCreate(j.Url, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) _jobs.Add(j);
                _nextId = Math.Max(_nextId, j.Id + 1);
            }
        }
        catch { }
    }

    public void Dispose()
    {
        PersistThrottled();
        _lifetime.Cancel();
        foreach (var j in Snapshot()) { try { j.Cancellation.Cancel(); } catch { } }
        try { _scheduler.Wait(1000); } catch { }
        _http.Dispose();
        _convert.Dispose();
        _lifetime.Dispose();
    }
}
