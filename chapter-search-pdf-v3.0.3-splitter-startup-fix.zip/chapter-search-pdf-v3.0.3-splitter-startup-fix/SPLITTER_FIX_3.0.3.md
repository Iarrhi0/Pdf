# Correctif 3.0.3

Cause : `MainForm.BuildUi()` imposait `split.SplitterDistance = 1030` alors que le `SplitContainer` n'avait pas encore reçu sa largeur finale. Selon le DPI, la résolution et le layout initial, WinForms levait `ArgumentOutOfRangeException`.

Correction :
1. suppression du `SplitterDistance` fixe pendant `BuildUi()` ;
2. mémorisation du `SplitContainer` dans `_mainSplit` ;
3. calcul différé dans `Shown` ;
4. formule bornée : `Math.Clamp(desired, Panel1MinSize, Width - Panel2MinSize - SplitterWidth)` ;
5. recalcul sur `Resize`.
