# V3.0.2 Startup Fix

- Fenêtre WinForms affichée avant l'initialisation WebView2.
- Détection explicite du runtime WebView2.
- Journal de démarrage : `%LOCALAPPDATA%\ChapterSearchPdfV3\Logs\startup.log`.
- Gestion globale des exceptions de démarrage.
- Pool de renderers créé après le navigateur visible, avec fallback automatique de 3 à 1 renderer.
- Build STANDALONE publié en dossier self-contained, pas en single-file, pour fiabiliser WebView2Loader.dll et les DLL natives SkiaSharp.
