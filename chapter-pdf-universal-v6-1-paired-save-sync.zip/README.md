# V6.1 — Paired Save Sync

Correction du mode 2 chapitres simultanés.

## Sauvegarde séparée
Les deux chapitres continuent d'être analysés et convertis en parallèle, mais
la phase finale d'écriture Android est mise en file. AndroidFiles n'utilise
plus le même flux pour deux PDF au même instant.

Chaque chapitre obtient un nom déterministe séparé, par exemple :
- `Set_It_010.pdf`
- `Set_It_011.pdf`

## Synchronisation par paire
Le comportement devient :
- A = chapitre 10
- B = chapitre 11
- les deux travaillent en même temps
- si A finit avant B, A attend
- lorsque A ET B sont terminés et enregistrés, lancement simultané de :
  - A = chapitre 12
  - B = chapitre 13
- puis 14 + 15, etc.

Aucune file ne part seule sur le chapitre suivant.
