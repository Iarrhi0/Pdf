# V5.2 — Ortega Pattern Fix

Correction du chapitre 10 : Ortega utilise actuellement des URLs comme
`image/1_1.jpg`, `image/1_2.jpg`, etc., alors que le Multi-Engine cherchait
un modèle `image/1.jpg`, `image/2.jpg`.

V5.2 reconnaît les deux formats et inspecte aussi directement le HTML / payload
Next.js du chapitre.

Chaque chapitre conserve ses moteurs :
- Moteur 1 : 1–5
- Moteur 2 : 6–10
- Moteur 3 : 11–15
- etc.
