# Chapter Search PDF PC v1.9 — Image Recovery

Cette version corrige les erreurs observées dans la file multi-séries quand un tome était extrait avec seulement quelques faux candidats, puis échouait avec `HTTP 404` ou `Input buffer contains unsupported image format`.

## Corrections principales

- extraction rapide sans images en premier passage
- fallback profond limité à 1 chapitre à la fois si l’extraction est faible
- balayage automatique de la page pour déclencher les lecteurs lazy/IntersectionObserver
- pour un Tome/Volume, une extraction de moins de 12 images est considérée comme suspecte et relancée
- E5 filtre davantage les logos, placeholders, images de chargement et assets génériques
- priorité aux `data-src` / `data-lazy-src` avant les placeholders `src`
- validation du contenu téléchargé par signature réelle avant Sharp
- rejet des pages HTML/anti-bot déguisées en images
- seconde tentative sans query-string en cas d’URL image cassée
- fallback Chromium `nativeImage` quand Sharp ne sait pas décoder un format que Chromium accepte
- déduplication de la file par série + numéro de tome/chapitre, pas seulement par URL
- migration de la file persistante pour supprimer les doublons déjà enregistrés au prochain lancement

## Performance

La limite globale reste contrôlée afin de ne pas revenir au blocage de v1.7. Le fallback profond avec images activées est limité à un seul chapitre à la fois.

## Test conseillé

1. Compiler la v1.9.
2. Ouvrir City Hunter Ultime.
3. Cliquer `Réessayer erreurs` pour les tomes qui avaient échoué.
4. Vérifier qu’un tome n’est plus analysé comme seulement 5 pages.
5. Vérifier qu’un même Tome 25 n’apparaît plus deux fois après redémarrage.
