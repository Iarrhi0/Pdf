# V5 — Quality Guard

## Bugs corrigés par rapport à V4.1

1. `SAVED 100%` ne signifie plus simplement que tous les candidats ont été traités.
2. Le nombre de pages PDF est séparé du nombre de candidats analysés.
3. Un chapitre avec trop de pages ignorées est rejeté et relancé avec l'autre moteur.
4. Les URL de thème, miniatures, avatars, bannières, placeholders et assets décoratifs sont filtrées avant téléchargement.
5. Les images identiques sont détectées par contenu SHA-256, même si leurs URLs diffèrent.
6. Un PDF anormalement léger est rejeté avant remplacement du fichier final.
7. L'ancien PDF n'est remplacé qu'après validation complète du nouveau PDF.
8. Les tâches terminées d'anciennes sessions ne polluent plus la file active.
9. Les doublons de tâche sont détectés par URL normalisée ou identité série + numéro.
10. Recovery qualité : premier moteur → contrôle → moteur alternatif + rendu profond → contrôle final.

## Règle importante

V5 préfère afficher une erreur de qualité plutôt que produire volontairement un PDF faux ou incomplet.
