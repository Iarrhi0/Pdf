# Chapter Search PDF V5.0 — QUALITY GUARD • PHONE x10

Version native Windows .NET 8 + WebView2, sans Electron/Chromium embarqué.

## Objectif V5

V5 corrige le bug observé en V4.1 où un chapitre pouvait être marqué `SAVED 100%` alors que le PDF contenait surtout des miniatures, placeholders ou seulement une fraction des vraies pages.

### Pipeline

`WebView2 → lazy-load progressif → APK40 → ENGINE5-JAVA → validation réelle des images → QUALITY GUARD → PDF → SAVED`

- 10 chapitres actifs simultanément.
- 3 renderers WebView2 partagés.
- 1 flux image par chapitre, comme le moteur téléphone.
- Analyse série multi-moteur S1→S5.
- Sélecteurs SushiScan/Madara conservés.
- ENGINE5-JAVA reste le fallback du lecteur.

## QUALITY GUARD V5

Avant `SAVED`, V5 contrôle maintenant :

- dimensions et surface réelles des images ;
- rejet des miniatures, bannières et placeholders ;
- déduplication SHA-256 du contenu ;
- ratio `vraies pages / candidats` ;
- cohérence de taille médiane des pages ;
- poids médian des images ;
- poids final du PDF par page.

Exemple : `16 vraies pages / 51 candidats` n'est plus considéré comme 100%. La première extraction est rejetée, le moteur alterne APK40/JAVA5 et relance un rendu profond. Si la qualité reste incohérente, le chapitre passe en ERROR au lieu de sauvegarder un faux PDF.

## PDF existants

V5 ne fait pas automatiquement confiance aux PDF créés par V4/V4.1. Un fichier n'est considéré comme déjà validé que s'il possède le marqueur caché V5 généré après un téléchargement contrôlé. Cela permet à V5 de remplacer progressivement les anciens PDF suspects.

## File

Les tâches `SAVED` restent visibles pendant la session, mais ne sont plus restaurées comme file active au prochain lancement. Cela évite les listes de 100+ anciens téléchargements mélangées à la série courante.

La progression affiche désormais le résultat réel :

`38/51 traités • 35 OK • 3 IGN`

puis :

`SAVED • 48/51 pages • Q92`

## Build

Le ZIP contient `.github/workflows/build-windows.yml`.

Artifacts GitHub Actions :

- `Chapter-Search-PDF-V5-LIGHT-x64`
- `Chapter-Search-PDF-V5-STANDALONE-x64`

Repère visuel : `PC v5.0 • QUALITY GUARD • MULTI S1-S5 • PHONE x10`.
