(function(){
  function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function chapNo(s){var m=(s||'').match(/(?:chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=(s||'').match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?m[1]:''}
  function bad(u){u=(u||'').toLowerCase();return !u||u.indexOf('data:')===0||u.indexOf('blob:')===0||/(logo|avatar|icon|sprite|emoji|advert|banner|tracking|pixel|favicon|header|footer|cover|thumbnail|thumb|placeholder|loading|lazyload|spacer|transparent|blank\.(?:gif|png|webp)|wp-content\/themes|cropped-|discord|rating|no-image|default-image)/.test(u)}
  var lazyAttrs=['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc','data-echo','data-lazy'];
  function firstSrcset(s){if(!s)return '';var parts=s.split(',').map(function(x){var p=x.trim().split(/\s+/);var score=parseFloat((p[1]||'1').replace(/[^0-9.]/g,''))||1;return {u:p[0],score:score}}).filter(function(x){return x.u});parts.sort(function(a,b){return b.score-a.score});return parts.length?parts[0].u:''}
  function preferred(i){
    for(var k=0;k<lazyAttrs.length;k++){var v=i.getAttribute&&i.getAttribute(lazyAttrs[k]);if(v&&!bad(v))return v}
    var ds=i.getAttribute&&i.getAttribute('data-srcset');var x=firstSrcset(ds);if(x&&!bad(x))return x;
    var pic=i.closest&&i.closest('picture');if(pic){var src=pic.querySelector('source[data-srcset],source[srcset]');if(src){x=firstSrcset(src.getAttribute('data-srcset')||src.getAttribute('srcset'));if(x&&!bad(x))return x}}
    x=firstSrcset((i.getAttribute&&i.getAttribute('srcset'))||'');if(x&&!bad(x))return x;
    return (i.currentSrc||i.src||'');
  }
  function hasLazy(i){for(var k=0;k<lazyAttrs.length;k++)if(i.getAttribute&&i.getAttribute(lazyAttrs[k]))return true;return !!(i.getAttribute&&i.getAttribute('data-srcset'))}
  function imgLike(i){var u=preferred(i);if(bad(u))return false;var w=i.naturalWidth||parseInt(i.getAttribute('width')||'0')||0,h=i.naturalHeight||parseInt(i.getAttribute('height')||'0')||0;if(!hasLazy(i)&&w&&h&&(w<220||h<220))return false;return true}
  var sels=['.reading-content','.page-break','#readerarea','.reader-area','.readerarea','.ts_reader','.chapter-content','.chapter-images','.container-chapter-reader','.reading-detail','.viewer','.viewer_img','.episode-body','.webtoon-reader','.chapterbody','.chapter-body','.manga-reader','.comic-reader','main'];
  var best=null,bestCount=0,bestSel='';
  // Madara/SushiScan: the actual scan pages live in reading-content/page-break. Prefer them explicitly.
  if(/(^|\.)sushiscan\./i.test(location.hostname)){
    var sushi=document.querySelector('.reading-content');
    if(sushi){var sc=0;sushi.querySelectorAll('.page-break img,img').forEach(function(i){if(imgLike(i))sc++});if(sc>=2){best=sushi;bestCount=sc;bestSel='sushiscan:.reading-content'}}
  }
  if(!best){sels.forEach(function(s){document.querySelectorAll(s).forEach(function(el){var c=0;el.querySelectorAll('img').forEach(function(i){if(imgLike(i))c++});if(c>bestCount){best=el;bestCount=c;bestSel=s}})})}
  var title=norm(document.title),url=location.href,n=chapNo(title)||chapNo(url),chapterSignal=!!n||/(chapter|chapitre|episode|reader|lecture|scan)/i.test(url+' '+title);
  if(!best||bestCount<2){if(!chapterSignal)return JSON.stringify({ok:false,reason:'Page non reconnue comme chapitre',images:[]});best=document.body;bestSel='body-fallback'}
  var out=[],seen={};function add(raw){var u=abs(raw);if(!bad(u)&&!seen[u]){seen[u]=1;out.push(u)}}
  best.querySelectorAll('img').forEach(function(i){if(!imgLike(i))return;add(preferred(i))});
  // V5: si une famille URL représente clairement le bloc du lecteur, écarter les inserts thème/pub.
  if(out.length>=6){try{var fam={};function family(u){var x=new URL(u);var p=x.pathname.split('/');p.pop();return x.host+p.join('/')}out.forEach(function(u){var f=family(u);fam[f]=(fam[f]||0)+1});var fk=Object.keys(fam).sort(function(a,b){return fam[b]-fam[a]})[0];if(fk&&fam[fk]>=4&&fam[fk]/out.length>=0.70)out=out.filter(function(u){return family(u)===fk})}catch(e){}}
  // Only use direct sources/styles if the reader img list was insufficient.
  if(out.length<2){best.querySelectorAll('source').forEach(function(s){add(firstSrcset(s.getAttribute('data-srcset')||s.getAttribute('srcset')||''))});best.querySelectorAll('[style]').forEach(function(el){var st=el.getAttribute('style')||'',m=st.match(/url\(['"]?([^'")]+)['"]?\)/ig)||[];m.forEach(function(x){add(x.replace(/^url\(['"]?/i,'').replace(/['"]?\)$/,''))})})}
  if(out.length<2&&chapterSignal){document.querySelectorAll('script').forEach(function(sc){var t=sc.textContent||'',re=/(https?:\/\/[^\s'"<>]+?\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?[^\s'"<>]*)?)/ig,m,k=0;while((m=re.exec(t))&&k<500){var u=m[1].replace(/\\u002F/g,'/');if(/(chapter|chapitre|manga|comic|webtoon|uploads|images)/i.test(u))add(u);k++}})}
  var h1=norm((document.querySelector('h1')||{}).textContent),rawSeries=h1||title;rawSeries=rawSeries.replace(/(?:[-|–—:]\s*)?(?:chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim();if(!rawSeries)rawSeries='Série';
  var label=n?('Chapitre '+n):norm(title).replace(rawSeries,'').replace(/^[-|–—: ]+|[-|–—: ]+$/g,'');if(!label)label='Chapitre';
  var strict=bestSel!=='body-fallback',ok=out.length>=2&&(strict||chapterSignal);
  return JSON.stringify({ok:ok,reason:ok?'':('Seulement '+out.length+' page(s) valide(s) détectée(s)'),series:rawSeries,chapter:label,number:n,reader:bestSel,strictReader:strict,count:out.length,images:out,engine:'APK40'});
})();
