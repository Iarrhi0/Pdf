(function(){try{
  function bad(u){u=(u||'').toLowerCase();return !u||/(placeholder|loading|lazyload|spacer|transparent|blank\.(?:gif|png|webp)|favicon|logo|avatar|icon|sprite|emoji)/.test(u)}
  function firstSrcset(s){if(!s)return '';var a=s.split(',').map(function(x){var p=x.trim().split(/\s+/);return {u:p[0],n:parseFloat((p[1]||'1').replace(/[^0-9.]/g,''))||1}}).filter(function(x){return x.u});a.sort(function(x,y){return y.n-x.n});return a.length?a[0].u:''}
  document.querySelectorAll('img').forEach(function(i){
    var cand='';
    ['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc','data-echo','data-lazy'].some(function(a){var v=i.getAttribute(a);if(v&&!bad(v)){cand=v;return true}return false});
    if(!cand)cand=firstSrcset(i.getAttribute('data-srcset')||'');
    var cur=i.getAttribute('src')||'';
    if(cand&&(!cur||bad(cur)))try{i.setAttribute('src',cand)}catch(e){}
    if(i.getAttribute('data-srcset')&&!i.getAttribute('srcset'))try{i.setAttribute('srcset',i.getAttribute('data-srcset'))}catch(e){}
    i.loading='eager';
    try{i.removeAttribute('loading')}catch(e){}
  });
  window.scrollTo(0,Math.max(document.body.scrollHeight,document.documentElement.scrollHeight));
  return 'ok';
}catch(e){return 'err';}})();
