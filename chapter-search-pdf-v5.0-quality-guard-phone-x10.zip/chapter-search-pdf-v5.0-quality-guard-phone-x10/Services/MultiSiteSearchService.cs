using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using ChapterSearchPdfV5.Models;

namespace ChapterSearchPdfV5.Services;

public sealed class MultiSiteSearchService : IDisposable
{
    private readonly HttpClient _http;
    private readonly List<SearchSource> _sources;
    private readonly SemaphoreSlim _parallel = new(8, 8);

    public IReadOnlyList<SearchSource> Sources => _sources;

    public MultiSiteSearchService()
    {
        var handler = new SocketsHttpHandler
        {
            AutomaticDecompression = DecompressionMethods.All,
            MaxConnectionsPerServer = 8,
            PooledConnectionLifetime = TimeSpan.FromMinutes(5),
            ConnectTimeout = TimeSpan.FromSeconds(5),
            UseCookies = false
        };
        _http = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(7) };
        _http.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", RendererPool.AndroidUserAgent);
        _http.DefaultRequestHeaders.TryAddWithoutValidation("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8");
        var path = Path.Combine(AppContext.BaseDirectory, "Assets", "sources.json");
        _sources = JsonSerializer.Deserialize<List<SearchSource>>(File.ReadAllText(path), new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? [];
    }

    public async Task<List<SearchResult>> SearchAsync(string query, IEnumerable<SearchSource>? selected = null, CancellationToken token = default)
    {
        query = query.Trim();
        if (query.Length < 2) return [];
        var sources = (selected ?? _sources.Where(s => s.Enabled)).ToList();
        var tasks = sources.Select(async source =>
        {
            await _parallel.WaitAsync(token);
            try { return await SearchSourceAsync(source, query, token); }
            catch { return new List<SearchResult>(); }
            finally { _parallel.Release(); }
        });
        var all = (await Task.WhenAll(tasks)).SelectMany(x => x)
            .GroupBy(x => Canon(x.Url), StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(x => x.Score).First())
            .OrderByDescending(x => x.Score).ThenBy(x => x.Source).Take(80).ToList();
        return all;
    }

    private async Task<List<SearchResult>> SearchSourceAsync(SearchSource source, string query, CancellationToken token)
    {
        if (source.Domain.Equals("mangadex.org", StringComparison.OrdinalIgnoreCase)) return await SearchMangaDex(source, query, token);
        if (source.Domain.Equals("comick.io", StringComparison.OrdinalIgnoreCase)) return await SearchComick(source, query, token);

        var results = new List<SearchResult>();
        foreach (var url in SearchUrls(source, query).Take(2))
        {
            try
            {
                var html = await _http.GetStringAsync(url, token);
                results.AddRange(ParseAnchors(source, query, html, url));
                if (results.Count >= 5) break;
            }
            catch { }
        }
        return results.OrderByDescending(x => x.Score).Take(5).ToList();
    }

    private async Task<List<SearchResult>> SearchMangaDex(SearchSource s, string q, CancellationToken token)
    {
        var raw = await _http.GetStringAsync($"https://api.mangadex.org/manga?title={Uri.EscapeDataString(q)}&limit=5", token);
        using var doc = JsonDocument.Parse(raw); var list = new List<SearchResult>();
        if (!doc.RootElement.TryGetProperty("data", out var data)) return list;
        foreach (var item in data.EnumerateArray())
        {
            var id = item.GetProperty("id").GetString();
            var titleObj = item.GetProperty("attributes").GetProperty("title");
            string? title = null;
            if (titleObj.TryGetProperty("fr", out var fr)) title = fr.GetString();
            else if (titleObj.TryGetProperty("en", out var en)) title = en.GetString();
            else { foreach (var prop in titleObj.EnumerateObject()) { title = prop.Value.GetString(); break; } }
            if (id is null || title is null) continue;
            var url = $"https://mangadex.org/title/{id}";
            list.Add(new SearchResult { Source = s.Name, Title = title, Url = url, Score = Score(q, title, url) + 40, Method = "API" });
        }
        return list;
    }

    private async Task<List<SearchResult>> SearchComick(SearchSource s, string q, CancellationToken token)
    {
        var raw = await _http.GetStringAsync($"https://api.comick.fun/v1.0/search/?q={Uri.EscapeDataString(q)}&limit=5&page=1&t=false", token);
        using var doc = JsonDocument.Parse(raw); var root = doc.RootElement; var list = new List<SearchResult>();
        if (root.ValueKind != JsonValueKind.Array) return list;
        foreach (var x in root.EnumerateArray())
        {
            var title = x.TryGetProperty("title", out var t) ? t.GetString() : null;
            var slug = x.TryGetProperty("slug", out var sl) ? sl.GetString() : x.TryGetProperty("hid", out var h) ? h.GetString() : null;
            if (title is null || slug is null) continue;
            var url = $"https://comick.io/comic/{slug}";
            list.Add(new SearchResult { Source = s.Name, Title = title, Url = url, Score = Score(q, title, url) + 35, Method = "API" });
        }
        return list;
    }

    private static IEnumerable<string> SearchUrls(SearchSource s, string q)
    {
        var e = Uri.EscapeDataString(q); var slug = Slug(q); var b = $"https://{s.Domain}";
        return s.Domain switch
        {
            "sushiscan.fr" => [$"{b}/?s={e}", $"{b}/catalogue/list-mode/"],
            "mangabuddy.com" => [$"{b}/search?q={e}", $"{b}/{slug}"],
            "mangapill.com" => [$"{b}/search?q={e}", $"{b}/manga/{slug}"],
            "mangafire.to" => [$"{b}/filter?keyword={e}", $"{b}/manga/{slug}"],
            "toonily.com" => [$"{b}/?s={e}", $"{b}/webtoon/{slug}"],
            "readallcomics.com" => [$"{b}/?s={e}"],
            _ => [$"{b}/?s={e}", $"{b}/search?q={e}"]
        };
    }

    private static List<SearchResult> ParseAnchors(SearchSource s, string q, string html, string baseUrl)
    {
        var outList = new List<SearchResult>();
        foreach (Match m in Regex.Matches(html, "<a\\b[^>]*?href\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*>([\\s\\S]*?)</a>", RegexOptions.IgnoreCase))
        {
            if (!Uri.TryCreate(new Uri(baseUrl), WebUtility.HtmlDecode(m.Groups[1].Value), out var u)) continue;
            if (!StripWww(u.Host).EndsWith(StripWww(s.Domain), StringComparison.OrdinalIgnoreCase)) continue;
            var title = Regex.Replace(WebUtility.HtmlDecode(m.Groups[2].Value), "<[^>]+>", " ");
            title = Regex.Replace(title, "\\s+", " ").Trim();
            var score = Score(q, title, u.AbsoluteUri);
            if (score < 36) continue;
            outList.Add(new SearchResult { Source = s.Name, Title = title.Length > 0 ? title : q, Url = u.AbsoluteUri, Score = score, Method = "Interne" });
        }
        return outList.GroupBy(x => Canon(x.Url)).Select(g => g.OrderByDescending(x => x.Score).First()).OrderByDescending(x => x.Score).Take(5).ToList();
    }

    private static double Score(string q, string title, string url)
    {
        var nq = Norm(q); var nt = Norm(title); var nu = Norm(url); var tokens = nq.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Length == 0) return 0;
        double score = 0; var hits = 0;
        foreach (var tok in tokens) { if (nt.Contains(tok)) { score += 18; hits++; } else if (nu.Contains(tok)) { score += 8; hits++; } }
        if (nt == nq) score += 90; else if (nt.StartsWith(nq)) score += 65; else if (nt.Contains(nq)) score += 50;
        if (hits == tokens.Length) score += 30;
        if (hits < Math.Ceiling(tokens.Length * .6)) return 0;
        return score;
    }

    private static string StripWww(string s) => s.StartsWith("www.", StringComparison.OrdinalIgnoreCase) ? s[4..] : s;
    private static string Norm(string s) => Regex.Replace(s.ToLowerInvariant(), "[^a-z0-9]+", " ").Trim();
    private static string Slug(string s) => Regex.Replace(Norm(s), "\\s+", "-");
    private static string Canon(string s) { try { var u = new UriBuilder(s) { Fragment = "" }; return u.Uri.AbsoluteUri.TrimEnd('/'); } catch { return s; } }

    public void Dispose() { _http.Dispose(); _parallel.Dispose(); }
}
