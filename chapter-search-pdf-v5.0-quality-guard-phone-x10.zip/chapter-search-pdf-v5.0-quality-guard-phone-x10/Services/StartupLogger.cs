using System.Text;

namespace ChapterSearchPdfV5.Services;

public static class StartupLogger
{
    private static readonly object Gate = new();
    public static string LogDirectory { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChapterSearchPdfV5", "Logs");
    public static string LogFile { get; } = Path.Combine(LogDirectory, "startup.log");

    public static void Initialize()
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            File.AppendAllText(LogFile, $"\r\n===== START {DateTime.Now:yyyy-MM-dd HH:mm:ss} =====\r\n", Encoding.UTF8);
            Log("BOOT", $"BaseDir={AppContext.BaseDirectory}");
            Log("BOOT", $"OS={Environment.OSVersion}; 64bit={Environment.Is64BitOperatingSystem}/{Environment.Is64BitProcess}; .NET={Environment.Version}");
        }
        catch { }
    }

    public static void Log(string area, string message)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(LogDirectory);
                File.AppendAllText(LogFile, $"[{DateTime.Now:HH:mm:ss.fff}] {area}: {message}\r\n", Encoding.UTF8);
            }
        }
        catch { }
    }

    public static void Log(string area, Exception ex) => Log(area, ex.ToString());

    public static void Fatal(string area, Exception ex)
    {
        Log(area, ex);
        try
        {
            MessageBox.Show($"Chapter Search PDF V5 n'a pas pu démarrer correctement.\n\n{ex.Message}\n\nJournal :\n{LogFile}",
                "Chapter Search PDF V5 — erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch { }
    }
}
