using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ChapterSearchPdfV5.Models;

namespace ChapterSearchPdfV5.Services;

public sealed class DownloadManager : IDisposable
{
    private sealed record PageMetric(int Width, int Height, int RawBytes, int JpegBytes);
    private sealed record QualityAssessment(bool Acceptable, double Score, string Reason);
    private sealed record PassResult(
        int Valid, int Skipped, int Total, int Duplicates, int QualityRejected,
        bool Acceptable, double QualityScore, string QualityReason, string Engine);

    private readonly RendererPool _renderers;
    private readonly object _gate = new();
    private readonly List<DownloadJob> _jobs = [];
    private readonly ConcurrentDictionary<int, Task> _active = new();
    private readonly SemaphoreSlim _convert = new(2, 2);
    private readonly HttpClient _http;
    private readonly CancellationTokenSource _lifetime = new();
    private readonly Task _scheduler;
    private int _nextId = 1;
    private const int MaxActive = 10;
    private readonly string _queuePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChapterSearchPdfV5", "download-queue.json");
    private long _lastPersistTicks;

    public event Action? Changed;

    public DownloadManager(RendererPool renderers)
    {
        _renderers = renderers;
        var handler = new SocketsHttpHandler
        {
            AutomaticDecompression = DecompressionMethods.All,
            MaxConnectionsPerServer = 20,
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2),
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
            ConnectTimeout = TimeSpan.FromSeconds(18),
            UseCookies = false,
            AllowAutoRedirect = true
        };
        _http = new HttpClient(handler) { Timeout = Timeout.InfiniteTimeSpan };
        RestoreQueue();
        _scheduler = Task.Run(SchedulerLoopAsync);
    }

    public IReadOnlyList<DownloadJob> Snapshot()
    {
        lock (_gate) return _jobs.Where(j => j.State != JobState.Removed).OrderBy(j => j.AddedAt).ToList();
    }

    public void Add(IEnumerable<ChapterCandidate> chapters, bool startImmediately = true)
    {
        lock (_gate)
        {
            foreach (var c in chapters)
            {
                if (!Uri.TryCreate(c.Url, UriKind.Absolute, out var u) || (u.Scheme != "http" && u.Scheme != "https")) continue;
                if (_jobs.Any(j => j.State != JobState.Removed && SameIdentity(j, c))) continue;
                _jobs.Add(new DownloadJob
                {
                    Id = _nextId++,
                    Series = Sanitize(c.Series),
                    Title = string.IsNullOrWhiteSpace(c.Title) ? $"Chapitre {c.Number}" : c.Title,
                    Number = c.Number,
                    Url = u.AbsoluteUri,
                    State = startImmediately ? JobState.Queued : JobState.Paused,
                    Phase = startImmediately ? "QUEUED" : "PAUSED"
                });
            }
        }
        Notify();
    }

    public void Pause(int id)
    {
        var j = Find(id); if (j is null) return;
        j.PauseGate.Pause();
        if (j.State == JobState.Queued) j.State = JobState.Paused;
        j.Phase = "PAUSED";
        Notify();
    }

    public void Resume(int id)
    {
        var j = Find(id); if (j is null) return;
        j.PauseGate.Resume();
        if (j.State == JobState.Paused) { j.State = JobState.Queued; j.Phase = "QUEUED"; }
        else if (j.State == JobState.Download) j.Phase = $"DOWN {j.Page}/{Math.Max(1, j.Pages)} • {j.ValidPages} OK • {j.SkippedPages} IGN";
        Notify();
    }

    public void Stop(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        j.Cancellation.Cancel();
        j.PauseGate.Resume();
        j.State = JobState.Stopped;
        j.Phase = "STOPPED";
        Notify();
    }

    public void Remove(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        j.Cancellation.Cancel();
        j.PauseGate.Resume();
        j.State = JobState.Removed;
        j.Phase = "REMOVED";
        Notify();
    }

    public void Retry(int id)
    {
        var j = Find(id); if (j is null) return;
        j.Generation++;
        try { j.Cancellation.Cancel(); } catch { }
        j.Cancellation.Dispose();
        j.Cancellation = new CancellationTokenSource();
        j.PauseGate.Resume();
        j.Error = "";
        j.Page = 0;
        j.Pages = 0;
        j.ValidPages = 0;
        j.SkippedPages = 0;
        j.DuplicatePages = 0;
        j.RejectedQualityPages = 0;
        j.QualityScore = 0;
        j.QualityNote = "";
        j.SpeedMbps = 0;
        j.Target = "";
        j.State = JobState.Queued;
        j.Phase = "RELOAD";
        Notify();
    }

    public void PauseAll() { foreach (var j in Snapshot().Where(x => x.State is JobState.Queued or JobState.Render or JobState.Engine5 or JobState.Download or JobState.Pdf)) Pause(j.Id); }
    public void ResumeAll() { foreach (var j in Snapshot().Where(x => x.State == JobState.Paused)) Resume(j.Id); }
    public void RetryErrors() { foreach (var j in Snapshot().Where(x => x.State == JobState.Error)) Retry(j.Id); }
    public void ClearFinished() { foreach (var j in Snapshot().Where(x => x.State is JobState.Saved or JobState.Stopped or JobState.Error)) Remove(j.Id); }

    private async Task SchedulerLoopAsync()
    {
        while (!_lifetime.IsCancellationRequested)
        {
            try
            {
                var capacity = MaxActive - _active.Count;
                if (capacity > 0)
                {
                    List<DownloadJob> next;
                    lock (_gate)
                    {
                        next = _jobs.Where(j => j.State == JobState.Queued && !_active.ContainsKey(j.Id)).Take(capacity).ToList();
                        foreach (var j in next) { j.State = JobState.Render; j.Phase = "LOAD"; }
                    }
                    foreach (var job in next)
                    {
                        var generation = job.Generation;
                        var task = Task.Run(() => RunJobAsync(job, generation));
                        _active[job.Id] = task;
                        _ = task.ContinueWith(_ => { _active.TryRemove(job.Id, out _); Notify(); }, TaskScheduler.Default);
                    }
                    if (next.Count > 0) Notify();
                }
                await Task.Delay(120, _lifetime.Token);
            }
            catch (OperationCanceledException) { break; }
            catch { await Task.Delay(400); }
        }
    }

    private async Task RunJobAsync(DownloadJob job, int generation)
    {
        var token = job.Cancellation.Token;
        string? temp = null;
        try
        {
            await job.PauseGate.WaitAsync(token);
            Set(job, generation, JobState.Render, "RENDER • APK40 + JAVA5");
            var payload = await _renderers.RenderChapterAsync(job.Url, token, preferAlternate: false);
            EnsureGeneration(job, generation);

            payload.Series = string.IsNullOrWhiteSpace(job.Series) ? payload.Series : job.Series;
            payload.Chapter = string.IsNullOrWhiteSpace(job.Title) ? payload.Chapter : job.Title;
            ResetProgress(job, payload.Images.Count);
            Set(job, generation, JobState.Engine5, $"{payload.Engine} • {payload.Reader} • {payload.Images.Count} candidats");

            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "Chapter Search PDF", Sanitize(payload.Series));
            Directory.CreateDirectory(dir);
            var target = Path.Combine(dir, BuildPdfName(payload.Series, payload.Chapter));
            temp = target + ".part";
            job.Target = target;

            // V5 ne fait confiance qu'aux PDF déjà validés par V5. Les anciens PDF V4 suspects
            // seront retéléchargés puis remplacés seulement si le nouveau contrôle qualité réussit.
            if (File.Exists(target) && IsV5Validated(target))
            {
                job.ValidPages = payload.Images.Count;
                job.Pages = payload.Images.Count;
                job.QualityScore = 100;
                job.QualityNote = "PDF déjà validé V5";
                Set(job, generation, JobState.Saved, $"SAVED • V5 VALIDÉ • {job.ValidPages} pages");
                return;
            }
            if (File.Exists(temp)) File.Delete(temp);

            var result = await DownloadPassAsync(job, generation, payload, temp, token);

            // V5 : on récupère aussi un chapitre qui a beaucoup de pages décodables mais incohérentes.
            // L'ancien V4 sauvegardait 16/51 pages et affichait 100%; V5 refuse ce cas.
            if (!result.Acceptable)
            {
                try { if (File.Exists(temp)) File.Delete(temp); } catch { }
                Set(job, generation, JobState.Render, $"RECOVERY QUALITÉ • {Short(result.QualityReason, 64)}");
                var refreshed = await _renderers.RenderChapterAsync(job.Url, token, preferAlternate: true);
                refreshed.Series = payload.Series;
                refreshed.Chapter = payload.Chapter;
                ResetProgress(job, refreshed.Images.Count);
                result = await DownloadPassAsync(job, generation, refreshed, temp, token);
            }

            if (!result.Acceptable)
                throw new InvalidDataException($"Qualité rejetée : {result.Valid}/{result.Total} vraie(s) page(s), Q{result.QualityScore:0} • {result.QualityReason}");

            File.Move(temp, target, true);
            temp = null;
            MarkV5Validated(target, result);

            job.Error = result.Skipped > 0 ? $"{result.Skipped} candidat(s) ignoré(s)" : "";
            job.QualityScore = result.QualityScore;
            job.QualityNote = result.QualityReason;
            Set(job, generation, JobState.Saved, $"SAVED • {result.Valid}/{result.Total} pages • Q{result.QualityScore:0}");
        }
        catch (OperationCanceledException)
        {
            if (job.Generation == generation && job.State != JobState.Removed) Set(job, generation, JobState.Stopped, "STOPPED");
        }
        catch (Exception ex)
        {
            if (job.Generation == generation && job.State != JobState.Removed)
            {
                job.Error = ex.Message;
                Set(job, generation, JobState.Error, "ERROR");
            }
        }
        finally
        {
            if (temp is not null) { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
    }

    private async Task<PassResult> DownloadPassAsync(
        DownloadJob job, int generation, ExtractPayload payload, string temp, CancellationToken token)
    {
        var valid = 0;
        var skipped = 0;
        var duplicates = 0;
        var qualityRejected = 0;
        var total = payload.Images.Count;
        var seenContent = new HashSet<string>(StringComparer.Ordinal);
        var metrics = new List<PageMetric>(Math.Min(total, 256));
        job.Pages = total;
        Set(job, generation, JobState.Download, $"DOWNLOAD • {payload.Engine}");

        using var pdf = new StreamingPdfWriter(temp);
        for (var i = 0; i < total; i++)
        {
            token.ThrowIfCancellationRequested();
            EnsureGeneration(job, generation);
            await job.PauseGate.WaitAsync(token);
            if (job.State == JobState.Paused) Set(job, generation, JobState.Download, $"DOWNLOAD • {payload.Engine}");

            var url = payload.Images[i];
            var sw = Stopwatch.StartNew();
            byte[]? bytes = null;
            try
            {
                if (LooksDecorativeUrl(url))
                {
                    qualityRejected++;
                    throw new InvalidDataException("URL décorative / miniature");
                }

                bytes = await FetchPhoneStyleAsync(url, payload, token);
                await _convert.WaitAsync(token);
                try
                {
                    var page = ImageCodec.ToJpeg(bytes);
                    if (!ImageCodec.LooksLikeReaderPage(page, bytes.Length, out var pageReason))
                    {
                        qualityRejected++;
                        throw new InvalidDataException(pageReason);
                    }

                    // Hash du JPEG final : détecte aussi les mêmes placeholders servis via plusieurs URLs.
                    var hash = Convert.ToHexString(SHA256.HashData(page.Bytes));
                    if (!seenContent.Add(hash))
                    {
                        duplicates++;
                        throw new InvalidDataException("Image dupliquée");
                    }

                    pdf.AddJpeg(page.Bytes, page.Width, page.Height);
                    metrics.Add(new PageMetric(page.Width, page.Height, bytes.Length, page.Bytes.Length));
                    valid++;
                }
                finally { _convert.Release(); }

                sw.Stop();
                var mb = bytes.LongLength / 1024d / 1024d;
                job.SpeedMbps = sw.Elapsed.TotalSeconds > 0 ? mb / sw.Elapsed.TotalSeconds : 0;
            }
            catch (OperationCanceledException) { throw; }
            catch
            {
                skipped++;
            }

            job.Page = i + 1;               // candidats traités
            job.ValidPages = valid;         // vraies pages PDF
            job.SkippedPages = skipped;
            job.DuplicatePages = duplicates;
            job.RejectedQualityPages = qualityRejected;
            job.Phase = $"DOWN {job.Page}/{total} • {valid} OK • {skipped} IGN";
            NotifyThrottled();
        }

        var assessment = AssessChapterQuality(payload, total, valid, skipped, duplicates, qualityRejected, metrics);
        job.QualityScore = assessment.Score;
        job.QualityNote = assessment.Reason;

        if (assessment.Acceptable && valid >= 2)
        {
            Set(job, generation, JobState.Pdf, $"PDF • {valid}/{total} • Q{assessment.Score:0}");
            pdf.Complete();

            // Dernier garde-fou : un PDF de dizaines de pages ne doit pas peser quelques centaines de Ko.
            var fileBytes = new FileInfo(temp).Length;
            var perPage = fileBytes / (double)Math.Max(1, valid);
            if (valid >= 8 && perPage < 12_000)
            {
                assessment = new QualityAssessment(false, Math.Min(assessment.Score, 35), $"PDF trop léger ({perPage / 1024d:0.0} Ko/page)");
                job.QualityScore = assessment.Score;
                job.QualityNote = assessment.Reason;
            }
        }

        return new PassResult(valid, skipped, total, duplicates, qualityRejected,
            assessment.Acceptable, assessment.Score, assessment.Reason, payload.Engine);
    }

    private static QualityAssessment AssessChapterQuality(
        ExtractPayload payload, int total, int valid, int skipped, int duplicates, int qualityRejected, List<PageMetric> metrics)
    {
        if (total < 2) return new QualityAssessment(false, 0, "moins de 2 candidats");
        if (valid < 2) return new QualityAssessment(false, 0, $"seulement {valid} vraie(s) page(s)");

        var ratio = valid / (double)Math.Max(1, total);
        var strictReader = !string.IsNullOrWhiteSpace(payload.Reader) &&
                           !payload.Reader.Contains("body-fallback", StringComparison.OrdinalIgnoreCase) &&
                           !payload.Reader.Contains("numeric-order", StringComparison.OrdinalIgnoreCase);

        var minRatio = total >= 20 ? (strictReader ? 0.50 : 0.42)
                     : total >= 8 ? (strictReader ? 0.48 : 0.40)
                     : 0.40;
        var minPages = total >= 30 ? Math.Max(8, (int)Math.Ceiling(total * 0.30))
                     : total >= 10 ? Math.Max(4, (int)Math.Ceiling(total * 0.30))
                     : 2;

        var areas = metrics.Select(m => (double)m.Width * m.Height).OrderBy(x => x).ToArray();
        var longs = metrics.Select(m => (double)Math.Max(m.Width, m.Height)).OrderBy(x => x).ToArray();
        var sizes = metrics.Select(m => (double)m.JpegBytes).OrderBy(x => x).ToArray();
        var medianArea = Median(areas);
        var medianLong = Median(longs);
        var medianBytes = Median(sizes);

        var dimensionOk = metrics.Count < 3 || (medianArea >= 280_000 && medianLong >= 580);
        var densityOk = metrics.Count < 3 || medianBytes >= 12_000;
        var ratioOk = ratio >= minRatio && valid >= minPages;

        var score = 0d;
        score += Math.Min(60, ratio * 70);
        score += dimensionOk ? 20 : 0;
        score += densityOk ? 15 : 0;
        score += duplicates <= Math.Max(1, total / 12) ? 5 : 0;
        score = Math.Clamp(score, 0, 100);

        if (!ratioOk)
            return new QualityAssessment(false, score, $"ratio insuffisant {valid}/{total} ({ratio:P0}) • moteur {payload.Engine}/{payload.Reader}");
        if (!dimensionOk)
            return new QualityAssessment(false, score, $"pages trop petites (médiane {Math.Sqrt(Math.Max(0, medianArea)):0}px équiv.)");
        if (!densityOk)
            return new QualityAssessment(false, score, $"pages anormalement légères (médiane {medianBytes / 1024d:0.0} Ko)");
        if (valid >= 8 && score < 62)
            return new QualityAssessment(false, score, $"cohérence faible Q{score:0}");

        var note = $"Q{score:0} • {valid}/{total} vraies • {skipped} IGN";
        if (duplicates > 0) note += $" • {duplicates} DUP";
        if (qualityRejected > 0) note += $" • {qualityRejected} MINI";
        return new QualityAssessment(true, score, note);
    }

    private async Task<byte[]> FetchPhoneStyleAsync(string url, ExtractPayload payload, CancellationToken token)
    {
        // Politique téléphone : une requête normale, seul HTTP 416 est rejoué.
        for (var pass = 0; pass < 2; pass++)
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.TryAddWithoutValidation("User-Agent", payload.UserAgent);
            req.Headers.TryAddWithoutValidation("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
            req.Headers.TryAddWithoutValidation("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8");
            req.Headers.TryAddWithoutValidation("Referer", payload.FinalUrl);
            if (!string.IsNullOrWhiteSpace(payload.CookieHeader)) req.Headers.TryAddWithoutValidation("Cookie", payload.CookieHeader);

            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
            timeout.CancelAfter(TimeSpan.FromSeconds(30));
            using var res = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
            if ((int)res.StatusCode == 416 && pass == 0) continue;
            if (!res.IsSuccessStatusCode) throw new HttpRequestException($"HTTP {(int)res.StatusCode}");

            var media = res.Content.Headers.ContentType?.MediaType ?? "";
            if (media.Contains("html", StringComparison.OrdinalIgnoreCase) || media.StartsWith("text/", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Réponse non-image");
            if (res.Content.Headers.ContentLength is long len && len > 40L * 1024 * 1024)
                throw new InvalidDataException("Image trop volumineuse");

            await using var input = await res.Content.ReadAsStreamAsync(timeout.Token);
            using var output = new MemoryStream();
            var buffer = new byte[32 * 1024];
            long total = 0;
            while (true)
            {
                var n = await input.ReadAsync(buffer.AsMemory(0, buffer.Length), timeout.Token);
                if (n <= 0) break;
                total += n;
                if (total > 40L * 1024 * 1024) throw new InvalidDataException("Image trop volumineuse");
                output.Write(buffer, 0, n);
            }
            var bytes = output.ToArray();
            if (bytes.Length < 512) throw new InvalidDataException("Image trop petite");
            return bytes;
        }
        throw new HttpRequestException("HTTP 416");
    }

    private static bool LooksDecorativeUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var u)) return true;
        var p = (u.AbsolutePath + "?" + u.Query).ToLowerInvariant();
        return p.Contains("/wp-content/themes/") || p.Contains("/avatars/") || p.Contains("/avatar/") ||
               p.Contains("favicon") || p.Contains("placeholder") || p.Contains("lazy-placeholder") ||
               p.Contains("loading.") || p.Contains("loader.") || p.Contains("no-image") || p.Contains("default-image") ||
               p.Contains("thumbnail") || p.Contains("/thumb/") || p.Contains("-thumb.") || p.Contains("cropped-") ||
               p.Contains("/emoji/") || p.Contains("/icons/") || p.Contains("/icon/") || p.Contains("sprite") ||
               p.Contains("/ads/") || p.Contains("/advert") || p.Contains("banner") || p.Contains("discord");
    }

    private static double Median(double[] values)
    {
        if (values.Length == 0) return 0;
        var mid = values.Length / 2;
        return values.Length % 2 == 1 ? values[mid] : (values[mid - 1] + values[mid]) / 2d;
    }

    private static void ResetProgress(DownloadJob job, int pages)
    {
        job.Pages = pages;
        job.Page = 0;
        job.ValidPages = 0;
        job.SkippedPages = 0;
        job.DuplicatePages = 0;
        job.RejectedQualityPages = 0;
        job.QualityScore = 0;
        job.QualityNote = "";
    }

    private static string ValidationMarker(string target) => target + ".v5.ok";

    private static bool IsV5Validated(string target)
    {
        try
        {
            var marker = ValidationMarker(target);
            if (!File.Exists(target) || !File.Exists(marker)) return false;
            var info = new FileInfo(target);
            if (info.Length <= 100_000) return false;
            var lines = File.ReadAllLines(marker);
            var sizeLine = lines.FirstOrDefault(x => x.StartsWith("size=", StringComparison.OrdinalIgnoreCase));
            return sizeLine is not null && long.TryParse(sizeLine[5..], out var recorded) && recorded == info.Length;
        }
        catch { return false; }
    }

    private static void MarkV5Validated(string target, PassResult result)
    {
        try
        {
            var marker = ValidationMarker(target);
            var size = new FileInfo(target).Length;
            File.WriteAllText(marker,
                $"Chapter Search PDF V5 QUALITY-GUARD\n{DateTime.Now:O}\nsize={size}\n{result.Valid}/{result.Total}\nQ={result.QualityScore:0.0}\n{result.QualityReason}", Encoding.UTF8);
            try { File.SetAttributes(marker, File.GetAttributes(marker) | FileAttributes.Hidden); } catch { }
        }
        catch { }
    }

    private void Set(DownloadJob job, int generation, JobState state, string phase)
    {
        EnsureGeneration(job, generation);
        job.State = state;
        job.Phase = phase;
        Notify();
    }

    private static void EnsureGeneration(DownloadJob job, int generation)
    {
        if (job.Generation != generation) throw new OperationCanceledException();
    }

    private DownloadJob? Find(int id) { lock (_gate) return _jobs.FirstOrDefault(x => x.Id == id); }

    private static bool SameIdentity(DownloadJob j, ChapterCandidate c)
    {
        if (NormalizeUrl(j.Url) == NormalizeUrl(c.Url)) return true;
        return NormalizeIdentity(j.Series) == NormalizeIdentity(c.Series) && Math.Abs((j.Number ?? -1) - c.Number) < 0.0001;
    }

    private static string NormalizeUrl(string value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var u)) return value.Trim().ToLowerInvariant();
        return (u.Scheme + "://" + u.Host + u.AbsolutePath.TrimEnd('/')).ToLowerInvariant();
    }

    private static string NormalizeIdentity(string value)
    {
        var chars = (value ?? "").ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray();
        return new string(chars);
    }

    private static string Sanitize(string s) => string.Join(" ", (s ?? "Série").Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries)).Trim() is { Length: > 0 } x ? x : "Série";
    private static string BuildPdfName(string series, string chapter)
    {
        var s = Sanitize(series); var c = Sanitize(chapter);
        return c.StartsWith(s, StringComparison.OrdinalIgnoreCase) ? c + ".pdf" : $"{s} - {c}.pdf";
    }

    private static string Short(string text, int max) => string.IsNullOrWhiteSpace(text) || text.Length <= max ? text : text[..max] + "…";

    private long _lastNotifyTicks;
    private void NotifyThrottled()
    {
        var now = Environment.TickCount64;
        if (now - Interlocked.Read(ref _lastNotifyTicks) < 250) return;
        Interlocked.Exchange(ref _lastNotifyTicks, now);
        Notify();
    }

    private void Notify()
    {
        PersistThrottled();
        Changed?.Invoke();
    }

    private void PersistThrottled()
    {
        var now = Environment.TickCount64;
        if (now - Interlocked.Read(ref _lastPersistTicks) < 700) return;
        Interlocked.Exchange(ref _lastPersistTicks, now);
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_queuePath)!);
            List<object> dto;
            lock (_gate)
            {
                // Les SAVED sont un historique de session, pas une file active persistante.
                // V5 ne recharge donc plus 100+ anciennes tâches terminées au prochain démarrage.
                dto = _jobs.Where(j => j.State != JobState.Removed && j.State != JobState.Saved).Select(j => (object)new
                {
                    j.Id, j.Series, j.Title, j.Number, j.Url,
                    State = j.State.ToString(), j.Phase, j.Error, j.Page, j.Pages, j.ValidPages, j.SkippedPages,
                    j.DuplicatePages, j.RejectedQualityPages, j.QualityScore, j.QualityNote, j.Target, j.AddedAt
                }).ToList();
            }
            File.WriteAllText(_queuePath, JsonSerializer.Serialize(new { nextId = _nextId, jobs = dto }, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void RestoreQueue()
    {
        try
        {
            if (!File.Exists(_queuePath)) return;
            using var doc = JsonDocument.Parse(File.ReadAllText(_queuePath));
            if (doc.RootElement.TryGetProperty("nextId", out var ni) && ni.TryGetInt32(out var next)) _nextId = Math.Max(1, next);
            if (!doc.RootElement.TryGetProperty("jobs", out var jobs) || jobs.ValueKind != JsonValueKind.Array) return;
            foreach (var x in jobs.EnumerateArray())
            {
                var stateText = x.TryGetProperty("State", out var st) ? st.GetString() : "Queued";
                Enum.TryParse<JobState>(stateText, true, out var state);
                if (state is JobState.Render or JobState.Engine5 or JobState.Download or JobState.Pdf) state = JobState.Queued;
                if (state == JobState.Saved) continue;
                var j = new DownloadJob
                {
                    Id = x.TryGetProperty("Id", out var id) && id.TryGetInt32(out var iv) ? iv : _nextId++,
                    Series = x.TryGetProperty("Series", out var se) ? se.GetString() ?? "Série" : "Série",
                    Title = x.TryGetProperty("Title", out var ti) ? ti.GetString() ?? "Chapitre" : "Chapitre",
                    Number = x.TryGetProperty("Number", out var nu) && nu.ValueKind == JsonValueKind.Number && nu.TryGetDouble(out var nv) ? nv : null,
                    Url = x.TryGetProperty("Url", out var ur) ? ur.GetString() ?? "" : "",
                    State = state,
                    Phase = state == JobState.Queued ? "QUEUED" : state.ToString().ToUpperInvariant(),
                    Error = x.TryGetProperty("Error", out var er) ? er.GetString() ?? "" : "",
                    Page = x.TryGetProperty("Page", out var pg) && pg.TryGetInt32(out var pgv) ? pgv : 0,
                    Pages = x.TryGetProperty("Pages", out var pgs) && pgs.TryGetInt32(out var pgsv) ? pgsv : 0,
                    ValidPages = x.TryGetProperty("ValidPages", out var vp) && vp.TryGetInt32(out var vpv) ? vpv : 0,
                    SkippedPages = x.TryGetProperty("SkippedPages", out var sp) && sp.TryGetInt32(out var spv) ? spv : 0,
                    DuplicatePages = x.TryGetProperty("DuplicatePages", out var dp) && dp.TryGetInt32(out var dpv) ? dpv : 0,
                    RejectedQualityPages = x.TryGetProperty("RejectedQualityPages", out var qp) && qp.TryGetInt32(out var qpv) ? qpv : 0,
                    QualityScore = x.TryGetProperty("QualityScore", out var qs) && qs.TryGetDouble(out var qsv) ? qsv : 0,
                    QualityNote = x.TryGetProperty("QualityNote", out var qn) ? qn.GetString() ?? "" : "",
                    Target = x.TryGetProperty("Target", out var tg) ? tg.GetString() ?? "" : "",
                    AddedAt = x.TryGetProperty("AddedAt", out var ad) && ad.TryGetDateTime(out var dt) ? dt : DateTime.Now
                };
                if (Uri.TryCreate(j.Url, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) _jobs.Add(j);
                _nextId = Math.Max(_nextId, j.Id + 1);
            }
        }
        catch { }
    }

    public void Dispose()
    {
        PersistThrottled();
        _lifetime.Cancel();
        foreach (var j in Snapshot()) { try { j.Cancellation.Cancel(); } catch { } }
        try { _scheduler.Wait(1000); } catch { }
        _http.Dispose();
        _convert.Dispose();
        _lifetime.Dispose();
    }
}
