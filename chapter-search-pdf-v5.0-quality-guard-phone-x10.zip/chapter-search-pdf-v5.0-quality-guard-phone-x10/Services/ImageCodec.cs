using SkiaSharp;

namespace ChapterSearchPdfV5.Services;

public static class ImageCodec
{
    public sealed record JpegPage(byte[] Bytes, int Width, int Height);

    public static JpegPage ToJpeg(byte[] raw, int quality = 91)
    {
        using var codec = SKCodec.Create(new SKMemoryStream(raw)) ?? throw new InvalidDataException("Image non décodable");
        var info = codec.Info;
        if (info.Width <= 0 || info.Height <= 0) throw new InvalidDataException("Dimensions image invalides");

        // JPEG déjà valide : aucune recompression. C'est le chemin le plus rapide et le plus léger CPU.
        if (raw.Length >= 3 && raw[0] == 0xFF && raw[1] == 0xD8 && raw[2] == 0xFF)
            return new JpegPage(raw, info.Width, info.Height);

        using var bitmap = SKBitmap.Decode(raw) ?? throw new InvalidDataException("Image non décodable");
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Jpeg, quality) ?? throw new InvalidDataException("Conversion JPEG impossible");
        return new JpegPage(data.ToArray(), bitmap.Width, bitmap.Height);
    }

    public static bool LooksLikeReaderPage(JpegPage page, int rawBytes, out string reason)
    {
        reason = "";
        var w = page.Width;
        var h = page.Height;
        var area = (long)w * h;
        var ratio = w / (double)Math.Max(1, h);
        var squareish = ratio >= 0.70 && ratio <= 1.42;

        // Rejette les icônes, avatars, vignettes et placeholders avant qu'ils entrent dans le PDF.
        if (w < 300 || h < 300) { reason = "dimensions trop petites"; return false; }
        if (area < 220_000) { reason = "surface trop petite"; return false; }
        if (rawBytes < 8_000) { reason = "fichier trop léger"; return false; }

        // Les faux visuels de thèmes sont très souvent carrés et légers. Les pages de scans carrées
        // existent, mais elles sont généralement bien plus grandes ou plus lourdes.
        if (squareish && w <= 900 && h <= 900 && rawBytes < 140_000)
        {
            reason = "image carrée légère / placeholder";
            return false;
        }

        // Bannières horizontales de thème/pub.
        if (ratio > 3.4 && h < 900)
        {
            reason = "bannière horizontale";
            return false;
        }

        return true;
    }
}
