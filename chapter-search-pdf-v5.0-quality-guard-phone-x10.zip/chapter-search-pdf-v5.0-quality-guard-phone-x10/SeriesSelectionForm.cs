using ChapterSearchPdfV5.Models;

namespace ChapterSearchPdfV5;

public sealed class SeriesSelectionForm : Form
{
    private readonly CheckedListBox _list = new() { Dock = DockStyle.Fill, CheckOnClick = true };
    private readonly List<ChapterCandidate> _chapters;
    public List<ChapterCandidate> SelectedChapters { get; private set; } = [];

    public SeriesSelectionForm(List<ChapterCandidate> chapters, string title = "Chapitres détectés")
    {
        _chapters = chapters;
        Text = title;
        Width = 700; Height = 650; StartPosition = FormStartPosition.CenterParent;
        BackColor = Color.FromArgb(12, 18, 32); ForeColor = Color.White;
        foreach (var c in chapters) _list.Items.Add($"{c.Title}    {c.Url}", true);
        _list.BackColor = Color.FromArgb(17, 27, 48); _list.ForeColor = Color.White; _list.BorderStyle = BorderStyle.FixedSingle;

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 52, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(8) };
        var add = Button("Ajouter + démarrer"); var none = Button("Aucun"); var all = Button("Tout");
        add.Click += (_, _) => { SelectedChapters = Enumerable.Range(0, _list.Items.Count).Where(i => _list.GetItemChecked(i)).Select(i => _chapters[i]).ToList(); DialogResult = DialogResult.OK; Close(); };
        all.Click += (_, _) => { for (var i = 0; i < _list.Items.Count; i++) _list.SetItemChecked(i, true); };
        none.Click += (_, _) => { for (var i = 0; i < _list.Items.Count; i++) _list.SetItemChecked(i, false); };
        buttons.Controls.AddRange([add, none, all]);
        Controls.Add(_list); Controls.Add(buttons);
    }

    private static Button Button(string text) => new() { Text = text, AutoSize = true, Height = 32, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(55, 96, 240), ForeColor = Color.White };
}
