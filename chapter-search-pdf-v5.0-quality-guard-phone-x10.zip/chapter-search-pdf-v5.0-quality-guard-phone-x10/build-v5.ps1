$ErrorActionPreference = 'Stop'
$proj = Join-Path $PSScriptRoot 'ChapterSearchPdfV5.csproj'
$out = Join-Path $PSScriptRoot 'publish\standalone'
dotnet restore $proj
dotnet publish $proj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -p:PublishTrimmed=false -p:DebugType=None -p:DebugSymbols=false -o $out
Write-Host "Build V5: $out\ChapterSearchPdfV5.exe"
