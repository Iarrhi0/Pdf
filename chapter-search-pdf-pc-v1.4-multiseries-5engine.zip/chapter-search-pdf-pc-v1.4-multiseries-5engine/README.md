# Chapter Search PDF PC v1.4

Version PC navigateur avec file persistante multi séries et extraction multi moteur.

## Multi moteur E1 → E5

- E1 : lecteur DOM connu / conteneur principal
- E2 : analyse géométrique des images rendues
- E3 : extraction depuis scripts / JSON embarqués
- E4 : ressources réellement chargées par le navigateur via Performance API
- E5 : fusion hybride, déduplication, scoring multi moteur et validation réseau réelle avant PDF

## Vitesse et concurrence

- 20 sources simultanées pour la méta recherche
- jusqu’à 10 chapitres simultanés
- jusqu’à 5 chapitres actifs par série pour éviter qu’une seule série monopolise la file
- 4 pages téléchargées simultanément par chapitre
- plafond global de 24 requêtes image simultanées
- extraction navigateur invisible limitée à 5 workers pour maîtriser RAM/CPU
- répartition round-robin entre séries

## File multi séries

1. Ouvre une série dans le navigateur.
2. Clique sur Analyser la série.
3. Sélectionne les chapitres.
4. Clique sur Ajouter à la file.
5. Navigue vers une deuxième ou troisième série et recommence.
6. Ouvre File séries puis Démarrer.

La file est enregistrée dans les données de l'application. Les tâches RUNNING redeviennent QUEUED après redémarrage.

## Sortie

`Téléchargements/Chapter Search PDF/<Nom de la série>/`

Chaque chapitre est écrit d'abord en `.part`, puis renommé en `.pdf` uniquement après assemblage complet.

Utilise uniquement des contenus que tu as le droit de télécharger.
