package com.example.chapterpdf;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private CheckBox autoNextCheck;
    private CheckBox skipExistingCheck;
    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;
    private WebView browser;
    private WebView converter;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> visited = new HashSet<>();

    private boolean running = false;
    private boolean autoMode = false;
    private boolean stopAfterCurrent = false;
    private boolean waitingCaptcha = false;
    private boolean analysisScheduled = false;
    private boolean conversionActive = false;
    private int sequence = 0;

    private PageData currentData;
    private PdfName currentName;
    private File currentTempPdf;
    private FileOutputStream currentTempOut;
    private long currentExpectedBytes = 0L;
    private long currentReceivedBytes = 0L;

    private static class PageData {
        String url = "";
        String series = "Serie";
        String chapter = "";
        boolean captcha = false;
        JSONArray images = new JSONArray();
        String next = "";
        String end = "unknown";
    }

    private static class PdfName {
        final String series;
        final String chapter;
        final String fileName;

        PdfName(String series, String chapter, String fileName) {
            this.series = series;
            this.chapter = chapter;
            this.fileName = fileName;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStoragePermissionIfNeeded();
        buildUi();
        configureWebViews();
    }

    @Override
    protected void onDestroy() {
        closeTransferQuietly();
        if (browser != null) browser.destroy();
        if (converter != null) converter.destroy();
        super.onDestroy();
    }

    private void requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    1001
            );
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 14, 18, 12);

        TextView title = new TextView(this);
        title.setText("Chapitre → PDF → Suivant");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);

        urlInput = new EditText(this);
        urlInput.setHint("Colle le lien du chapitre");
        urlInput.setSingleLine(true);
        urlInput.setTextSize(16);

        Button oneButton = new Button(this);
        oneButton.setText("TÉLÉCHARGER CE CHAPITRE EN PDF");

        Button allButton = new Button(this);
        allButton.setText("DÉMARRER TOUTE LA SUITE");

        autoNextCheck = new CheckBox(this);
        autoNextCheck.setText("Continuer automatiquement");
        autoNextCheck.setChecked(true);

        skipExistingCheck = new CheckBox(this);
        skipExistingCheck.setText("Ignorer les PDF déjà terminés");
        skipExistingCheck.setChecked(true);

        Button stopButton = new Button(this);
        stopButton.setText("ARRÊTER APRÈS CE CHAPITRE");

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);

        percentText = new TextView(this);
        percentText.setText("0 %");
        percentText.setTextSize(18);

        statusText = new TextView(this);
        statusText.setText("Prêt.");
        statusText.setTextSize(15);
        statusText.setPadding(0, 8, 0, 8);

        browser = new WebView(this);
        converter = new WebView(this);

        root.addView(title);
        root.addView(urlInput);
        root.addView(oneButton);
        root.addView(allButton);
        root.addView(autoNextCheck);
        root.addView(skipExistingCheck);
        root.addView(stopButton);
        root.addView(progressBar,
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 18));
        root.addView(percentText);
        root.addView(statusText);

        LinearLayout.LayoutParams browserParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
        browserParams.weight = 1f;
        root.addView(browser, browserParams);

        // Le moteur HTML reste dans la vue mais minuscule/invisible à l'usage.
        converter.setAlpha(0.01f);
        root.addView(converter,
                new LinearLayout.LayoutParams(1, 1));

        setContentView(root);

        oneButton.setOnClickListener(v -> start(false));
        allButton.setOnClickListener(v -> start(true));

        stopButton.setOnClickListener(v -> {
            stopAfterCurrent = true;
            setStatus("Arrêt demandé. Le chapitre en cours sera terminé.");
        });
    }

    private void configureWebViews() {
        configureWebView(browser);
        configureWebView(converter);

        browser.addJavascriptInterface(new BrowserBridge(), "ChapterBridge");
        converter.addJavascriptInterface(new ConverterBridge(), "AndroidPdf");

        browser.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                analysisScheduled = false;
                if (running && !conversionActive) {
                    updateProgress(3, "Chargement de la page…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!running || conversionActive || analysisScheduled) {
                    return;
                }

                analysisScheduled = true;
                updateProgress(8, "Page chargée. Analyse du chapitre…");

                // Pas de scroll. Petit délai seulement pour laisser le DOM/lazy-loader initial se stabiliser.
                handler.postDelayed(() -> {
                    analysisScheduled = false;
                    if (running && !conversionActive) {
                        inspectDomWithoutScrolling();
                    }
                }, 700);
            }
        });
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(view, true);

        view.setWebChromeClient(new WebChromeClient());
    }

    private void start(boolean all) {
        String url = urlInput.getText().toString().trim();

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            setStatus("Colle une URL de chapitre valide.");
            return;
        }

        if (!running) {
            visited.clear();
            sequence = 0;
        }

        running = true;
        autoMode = all;
        stopAfterCurrent = false;
        waitingCaptcha = false;
        conversionActive = false;
        analysisScheduled = false;

        loadChapter(url);
    }

    private void loadChapter(String url) {
        if (!running) return;

        if (visited.contains(url)) {
            running = false;
            setStatus("Boucle détectée : ce chapitre a déjà été visité.");
            return;
        }

        visited.add(url);
        sequence++;
        updateProgress(2, "Ouverture du chapitre " + sequence + "…");
        browser.loadUrl(url);
    }

    private void inspectDomWithoutScrolling() {
        String js = """
            (function(){
              function abs(u){
                try{return new URL(u,location.href).href}catch(e){return ''}
              }

              function captcha(){
                const t=(document.body?.innerText||'').toLowerCase();
                return /captcha|verify you are human|checking your browser|just a moment|vérif(ier|ication).*(humain|robot)/i.test(t)
                  || !!document.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],[class*="captcha"],[id*="captcha"],[class*="turnstile"]');
              }

              function collectImages(){
                const out=[],seen=new Set();

                document.querySelectorAll('img').forEach((img,index)=>{
                  const candidates=[
                    img.getAttribute('src'),
                    img.currentSrc,
                    img.getAttribute('data-src'),
                    img.getAttribute('data-lazy-src'),
                    img.getAttribute('data-original'),
                    img.getAttribute('data-url'),
                    img.getAttribute('data-cfsrc'),
                    img.getAttribute('data-lazy'),
                    img.getAttribute('data-image')
                  ].filter(Boolean);

                  if(img.srcset){
                    img.srcset.split(',').forEach(part=>{
                      const u=(part.trim().split(/\\s+/)[0]||'');
                      if(u)candidates.push(u);
                    });
                  }

                  let u='';
                  for(const c of candidates){
                    const a=abs(c);
                    if(a && !a.startsWith('data:')){
                      u=a;
                      break;
                    }
                  }

                  if(!u || seen.has(u))return;

                  const w=img.naturalWidth||parseInt(img.getAttribute('width')||'0',10)||img.width||0;
                  const h=img.naturalHeight||parseInt(img.getAttribute('height')||'0',10)||img.height||0;
                  const meta=((img.alt||'')+' '+(img.className||'')+' '+(img.id||'')+' '+u).toLowerCase();

                  let score=0;
                  if(h>=500)score+=3;
                  if(w>=300)score+=2;
                  if(h>0 && w>0 && h/w>0.7)score+=2;
                  if(/page|chapter|scan|reader|manga|manhwa|webtoon|wp-manga-chapter-img|reading-content/.test(meta))score+=5;
                  if(/logo|avatar|icon|emoji|banner|discord|flag|ads?|pub|button|social/.test(meta))score-=6;

                  // Lazy images non chargées : on ne les rejette pas seulement parce que naturalWidth=0.
                  if(score>=1 || /data-src|data-lazy|chapter|reader|manga|manhwa|webtoon/.test(meta)){
                    seen.add(u);
                    out.push(u);
                  }
                });

                // Si le filtre intelligent a trouvé trop peu d'éléments, reprendre les grandes/lazy images.
                if(out.length<2){
                  document.querySelectorAll('img').forEach(img=>{
                    const raw=img.getAttribute('data-src')
                      || img.getAttribute('data-lazy-src')
                      || img.getAttribute('data-original')
                      || img.getAttribute('src')
                      || img.currentSrc
                      || '';
                    const u=abs(raw);
                    if(u && !u.startsWith('data:') && !seen.has(u)){
                      seen.add(u);
                      out.push(u);
                    }
                  });
                }

                return out;
              }

              function nextUrl(){
                const links=[...document.querySelectorAll('a[href]')].map(a=>{
                  const text=((a.innerText||'')+' '+(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'')+' '+(a.rel||'')+' '+(a.className||'')).toLowerCase();
                  const href=abs(a.getAttribute('href'));
                  let score=0;
                  if(/\\b(chapitre suivant|next chapter|chapter next|suivant|next)\\b/.test(text))score+=14;
                  if(/\\b(précédent|precedent|previous|prev)\\b/.test(text))score-=30;
                  if(/\\bnext\\b/.test((a.rel||'').toLowerCase()))score+=18;
                  if(/chapter|chapitre|episode|\\/ch[\\/_-]?\\d/i.test(href))score+=4;
                  return {href:href,score:score};
                }).filter(x=>x.href && x.href!==location.href && x.score>0);

                links.sort((a,b)=>b.score-a.score);
                return links[0]?.href||'';
              }

              function chapter(){
                const src=((document.querySelector('h1')?.innerText||'')+' '+document.title+' '+location.pathname);
                const m=src.match(/(?:chapter|chapitre|chap|ch|episode|ep)[\\s\\/_#.-]*(\\d+(?:[.,]\\d+)?)/i)
                  || location.pathname.match(/\\/chapter\\/(\\d+(?:[.,]\\d+)?)/i);
                return m?m[1].replace(',','.'):'';
              }

              function series(){
                const parts=location.pathname.split('/').filter(Boolean);
                const ci=parts.findIndex(x=>/^chapter$/i.test(x));
                let name=ci>0?parts[ci-1]:'';

                if(!name){
                  const crumb=[...document.querySelectorAll('a')].find(a=>/\\/serie\\//i.test(a.getAttribute('href')||''));
                  if(crumb)name=(crumb.textContent||'').trim();
                }

                if(!name){
                  name=(document.title||'Serie')
                    .replace(/chapter|chapitre\\s*\\d+.*/i,'')
                    .trim();
                }

                return name.replace(/[-_]+/g,' ').replace(/\\s+/g,' ').trim()||'Serie';
              }

              function endState(){
                const t=(document.body?.innerText||'').toLowerCase();
                if(/coming soon|to be continued|à suivre|a suivre|suite.*bient[oô]t|prochain chapitre.*bient[oô]t|en attente de la suite/i.test(t))return 'waiting';
                if(/fin de (la )?(série|serie|manga|manhwa|webtoon)|the end|completed|terminé|termine/i.test(t))return 'finished';
                return 'unknown';
              }

              ChapterBridge.onPageData(JSON.stringify({
                url:location.href,
                series:series(),
                chapter:chapter(),
                captcha:captcha(),
                images:collectImages(),
                next:nextUrl(),
                end:endState()
              }));
            })();
        """;

        browser.evaluateJavascript(js, null);
    }

    private class BrowserBridge {
        @JavascriptInterface
        public void onPageData(String raw) {
            runOnUiThread(() -> {
                try {
                    JSONObject j = new JSONObject(raw);
                    PageData d = new PageData();

                    d.url = j.optString("url", "");
                    d.series = j.optString("series", "Serie");
                    d.chapter = j.optString("chapter", "");
                    d.captcha = j.optBoolean("captcha", false);
                    d.images = j.optJSONArray("images");
                    if (d.images == null) d.images = new JSONArray();
                    d.next = j.optString("next", "");
                    d.end = j.optString("end", "unknown");

                    handlePage(d);
                } catch (Exception e) {
                    running = false;
                    setStatus("Erreur d’analyse : " + e.getMessage());
                }
            });
        }
    }

    private void handlePage(PageData data) {
        if (!running) return;

        currentData = data;

        if (data.captcha) {
            waitingCaptcha = true;
            updateProgress(8, "Vérification humaine nécessaire. Fais le CAPTCHA dans la page.");
            handler.postDelayed(() -> {
                if (running && waitingCaptcha && !conversionActive) {
                    inspectDomWithoutScrolling();
                }
            }, 1800);
            return;
        }

        waitingCaptcha = false;
        currentName = makePdfName(data);

        if (skipExistingCheck.isChecked() && pdfExists(currentName.series, currentName.fileName)) {
            updateProgress(100, "Déjà terminé : " + currentName.fileName);
            continueOrFinish(data);
            return;
        }

        if (data.images.length() == 0) {
            running = false;
            setStatus("Aucune image de chapitre détectée dans le HTML.");
            return;
        }

        updateProgress(
                12,
                data.images.length() + " image(s) détectée(s). Chargement réel des images…"
        );

        startHtmlEngine(data);
    }

    private void startHtmlEngine(PageData data) {
        conversionActive = true;
        closeTransferQuietly();

        JSONObject config = new JSONObject();
        try {
            config.put("images", data.images);
            config.put("baseUrl", data.url);
            config.put("mobileFit", true);
            config.put("normalizeWidth", true);
        } catch (Exception e) {
            running = false;
            conversionActive = false;
            setStatus("Erreur de préparation : " + e.getMessage());
            return;
        }

        String converterHtml = buildConverterHtml(config.toString());

        // Base URL du chapitre = cookies/référent similaires à la session du lecteur.
        converter.loadDataWithBaseURL(
                data.url,
                converterHtml,
                "text/html",
                "UTF-8",
                null
        );
    }

    private String buildConverterHtml(String configJson) {
        String escapedConfig = configJson.replace("</script>", "<\\/script>");

        // Le moteur ci-dessous reprend les fonctions clés de la web app V21 :
        // averageImageWidth, imageToJpegSegments, canvasToJpeg et buildPdf.
        return """
            <!doctype html>
            <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1">
            </head>
            <body>
            <script>
            const CFG = %s;

            function report(stage, percent, detail){
              AndroidPdf.progress(stage, Math.max(0,Math.min(100,Math.round(percent))), detail||'');
            }

            function imageFromUrl(src){
              return new Promise((resolve,reject)=>{
                const im=new Image();
                let finished=false;

                // D'abord sans crossOrigin pour profiter du contexte/cookies WebView.
                const timer=setTimeout(()=>{
                  if(finished)return;
                  finished=true;
                  im.src='';
                  reject(new Error('Délai dépassé : '+src));
                },30000);

                im.onload=()=>{
                  if(finished)return;
                  finished=true;
                  clearTimeout(timer);
                  resolve(im);
                };

                im.onerror=()=>{
                  if(finished)return;
                  finished=true;
                  clearTimeout(timer);
                  reject(new Error('Image inaccessible : '+src));
                };

                im.src=src;
              });
            }

            function canvasToJpeg(canvas){
              const dataUrl=canvas.toDataURL('image/jpeg',0.95);
              const bin=atob(dataUrl.split(',')[1]);
              const bytes=new Uint8Array(bin.length);
              for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
              return {bytes,width:canvas.width,height:canvas.height};
            }

            function averageImageWidth(images){
              const widths=images
                .map(im=>im?.naturalWidth||im?.width||0)
                .filter(w=>w>0);

              if(!widths.length)return null;

              return Math.max(
                1,
                Math.min(
                  4096,
                  Math.round(widths.reduce((a,b)=>a+b,0)/widths.length)
                )
              );
            }

            function imageToJpegSegments(im,mobileFit=true,targetWidth=null){
              const srcW=im.naturalWidth||im.width;
              const srcH=im.naturalHeight||im.height;

              if(!srcW||!srcH)throw new Error('Dimensions image invalides');

              const outW=Math.max(1,Math.round(targetWidth||srcW));
              const scale=outW/srcW;

              // Identique au mode mobile de la web app : tranches 9:16 basées sur la largeur source.
              const maxSliceH=mobileFit
                ? Math.max(1,Math.round(srcW*16/9))
                : srcH;

              const out=[];

              for(let y=0;y<srcH;y+=maxSliceH){
                const sliceH=Math.min(maxSliceH,srcH-y);
                const outH=Math.max(1,Math.round(sliceH*scale));

                const canvas=document.createElement('canvas');
                canvas.width=outW;
                canvas.height=outH;

                const ctx=canvas.getContext('2d');
                ctx.fillStyle='#fff';
                ctx.fillRect(0,0,outW,outH);

                ctx.drawImage(
                  im,
                  0,y,srcW,sliceH,
                  0,0,outW,outH
                );

                out.push(canvasToJpeg(canvas));
              }

              return out;
            }

            function ascii(s){
              return new TextEncoder().encode(s);
            }

            function concat(arrs){
              let n=arrs.reduce((s,a)=>s+a.length,0);
              const o=new Uint8Array(n);
              let p=0;
              for(const a of arrs){
                o.set(a,p);
                p+=a.length;
              }
              return o;
            }

            function buildPdf(images){
              const PX_TO_PT=72/96;
              const objs=[];
              const pageRefs=[];

              for(let i=0;i<images.length;i++){
                pageRefs.push(`${3+i*3} 0 R`);
              }

              const firstPage=images.length?'3 0 R':'2 0 R';

              objs[1]=ascii(
                `<< /Type /Catalog /Pages 2 0 R /PageLayout /OneColumn /ViewerPreferences << /FitWindow true /CenterWindow false >> /OpenAction [${firstPage} /FitH 0] >>`
              );

              objs[2]=ascii(
                `<< /Type /Pages /Kids [${pageRefs.join(' ')}] /Count ${images.length} >>`
              );

              for(let i=0;i<images.length;i++){
                const img=images[i];
                const page=3+i*3;
                const content=page+1;
                const image=page+2;

                let pageW=Math.max(1,img.width*PX_TO_PT);
                let pageH=Math.max(1,img.height*PX_TO_PT);

                const MAX_PT=14400;

                if(pageW>MAX_PT||pageH>MAX_PT){
                  const scale=Math.min(MAX_PT/pageW,MAX_PT/pageH);
                  pageW*=scale;
                  pageH*=scale;
                }

                const w=pageW.toFixed(2);
                const h=pageH.toFixed(2);

                const stream=`q\\n${w} 0 0 ${h} 0 0 cm\\n/Im0 Do\\nQ\\n`;

                objs[page]=ascii(
                  `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /CropBox [0 0 ${w} ${h}] /Resources << /XObject << /Im0 ${image} 0 R >> >> /Contents ${content} 0 R >>`
                );

                objs[content]=concat([
                  ascii(`<< /Length ${ascii(stream).length} >>\\nstream\\n`),
                  ascii(stream),
                  ascii('endstream')
                ]);

                objs[image]=concat([
                  ascii(
                    `<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.bytes.length} >>\\nstream\\n`
                  ),
                  img.bytes,
                  ascii('\\nendstream')
                ]);
              }

              const head=ascii('%PDF-1.4\\n%\\xE2\\xE3\\xCF\\xD3\\n');
              const parts=[head];
              const offsets=[0];
              let pos=head.length;

              for(let i=1;i<objs.length;i++){
                offsets[i]=pos;

                const block=concat([
                  ascii(`${i} 0 obj\\n`),
                  objs[i],
                  ascii('\\nendobj\\n')
                ]);

                parts.push(block);
                pos+=block.length;
              }

              const xrefPos=pos;

              let xref=`xref\\n0 ${objs.length}\\n0000000000 65535 f \\n`;

              for(let i=1;i<objs.length;i++){
                xref+=String(offsets[i]).padStart(10,'0')+' 00000 n \\n';
              }

              xref+=`trailer\\n<< /Size ${objs.length} /Root 1 0 R >>\\nstartxref\\n${xrefPos}\\n%%EOF`;

              parts.push(ascii(xref));
              return concat(parts);
            }

            function sendPdf(bytes){
              const CHUNK=192*1024;
              AndroidPdf.startPdf(bytes.length);

              let sent=0;

              for(let offset=0;offset<bytes.length;offset+=CHUNK){
                const part=bytes.subarray(offset,Math.min(bytes.length,offset+CHUNK));
                let binary='';

                // Sous-blocs pour éviter "Maximum call stack" / concat trop lourde.
                const SMALL=8192;
                for(let i=0;i<part.length;i+=SMALL){
                  binary+=String.fromCharCode.apply(
                    null,
                    part.subarray(i,Math.min(part.length,i+SMALL))
                  );
                }

                AndroidPdf.pdfChunk(btoa(binary));
                sent+=part.length;

                const transferPct=95+(sent/bytes.length)*5;
                report('Transfert PDF',transferPct,`${sent}/${bytes.length} octets`);
              }

              AndroidPdf.finishPdf();
            }

            async function run(){
              try{
                const srcs=[...new Set((CFG.images||[]).filter(Boolean))];

                if(!srcs.length){
                  throw new Error('Aucune image détectée');
                }

                report('Analyse HTML',12,`${srcs.length} image(s) détectée(s)`);

                const raw=[];
                const failures=[];

                for(let i=0;i<srcs.length;i++){
                  const pct=12+((i)/srcs.length)*58;
                  report(
                    'Chargement images',
                    pct,
                    `Image ${i+1}/${srcs.length}`
                  );

                  try{
                    const im=await imageFromUrl(srcs[i]);
                    raw.push(im);
                  }catch(e){
                    failures.push(e.message||String(e));
                  }

                  const donePct=12+((i+1)/srcs.length)*58;
                  report(
                    'Chargement images',
                    donePct,
                    `${i+1}/${srcs.length} traité(es)`
                  );
                }

                if(!raw.length){
                  throw new Error(
                    'Aucune image n’a pu être chargée'+
                    (failures.length?'\\n'+failures.join('\\n'):'')
                  );
                }

                const avg=CFG.normalizeWidth
                  ? averageImageWidth(raw)
                  : null;

                report(
                  'Largeur moyenne',
                  72,
                  avg?`Largeur moyenne : ${avg}px`:'Largeur originale'
                );

                const segments=[];

                for(let i=0;i<raw.length;i++){
                  const made=imageToJpegSegments(
                    raw[i],
                    CFG.mobileFit!==false,
                    avg
                  );

                  segments.push(...made);

                  const pct=72+((i+1)/raw.length)*18;
                  report(
                    'Découpage mobile',
                    pct,
                    `Image ${i+1}/${raw.length} · ${segments.length} page(s) PDF`
                  );
                }

                report(
                  'Construction PDF',
                  92,
                  `${segments.length} page(s)`
                );

                const pdfBytes=buildPdf(segments);

                report(
                  'PDF prêt',
                  95,
                  `${pdfBytes.length} octets`
                );

                sendPdf(pdfBytes);

              }catch(e){
                AndroidPdf.error(e && e.message ? e.message : String(e));
              }
            }

            run();
            </script>
            </body>
            </html>
        """.formatted(escapedConfig);
    }

    private class ConverterBridge {
        @JavascriptInterface
        public void progress(String stage, int percent, String detail) {
            runOnUiThread(() -> updateProgress(percent, stage + (detail.isEmpty() ? "" : "\n" + detail)));
        }

        @JavascriptInterface
        public void startPdf(long totalBytes) {
            runOnUiThread(() -> {
                try {
                    closeTransferQuietly();
                    currentExpectedBytes = totalBytes;
                    currentReceivedBytes = 0L;
                    currentTempPdf = new File(getCacheDir(), "html_engine_" + System.currentTimeMillis() + ".pdf");
                    currentTempOut = new FileOutputStream(currentTempPdf);
                    updateProgress(95, "PDF construit. Transfert vers Android…");
                } catch (Exception e) {
                    transferFailed("Impossible de créer le fichier temporaire : " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void pdfChunk(String base64) {
            try {
                byte[] bytes;
                if (Build.VERSION.SDK_INT >= 26) {
                    bytes = Base64.getDecoder().decode(base64);
                } else {
                    bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                }

                synchronized (MainActivity.this) {
                    if (currentTempOut == null) {
                        throw new IllegalStateException("Transfert PDF non initialisé");
                    }
                    currentTempOut.write(bytes);
                    currentReceivedBytes += bytes.length;
                }

                int pct = currentExpectedBytes > 0
                        ? 95 + (int)Math.min(5, (currentReceivedBytes * 5L) / currentExpectedBytes)
                        : 97;

                runOnUiThread(() -> updateProgress(pct, "Enregistrement du PDF…"));
            } catch (Exception e) {
                transferFailed("Erreur de transfert PDF : " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void finishPdf() {
            runOnUiThread(() -> {
                try {
                    synchronized (MainActivity.this) {
                        if (currentTempOut != null) {
                            currentTempOut.flush();
                            currentTempOut.close();
                            currentTempOut = null;
                        }
                    }

                    if (currentTempPdf == null || !currentTempPdf.exists() || currentTempPdf.length() < 1000L) {
                        throw new IllegalStateException("PDF temporaire vide ou incomplet");
                    }

                    if (currentExpectedBytes > 0 && currentTempPdf.length() != currentExpectedBytes) {
                        throw new IllegalStateException(
                                "PDF incomplet : " + currentTempPdf.length() + "/" + currentExpectedBytes + " octets"
                        );
                    }

                    boolean saved = savePdf(currentTempPdf, currentName.series, currentName.fileName);

                    currentTempPdf.delete();
                    currentTempPdf = null;
                    conversionActive = false;

                    if (!saved) {
                        running = false;
                        setStatus("PDF créé mais impossible à enregistrer.");
                        return;
                    }

                    updateProgress(
                            100,
                            "✓ PDF enregistré\n" + currentName.fileName
                                    + "\nTéléchargements/PDF_CONVERTIS/" + currentName.series + "/"
                    );

                    continueOrFinish(currentData);

                } catch (Exception e) {
                    transferFailed("Finalisation PDF : " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void error(String message) {
            runOnUiThread(() -> {
                conversionActive = false;
                running = false;
                closeTransferQuietly();
                setStatus("Erreur du convertisseur HTML :\n" + message);
            });
        }
    }

    private void transferFailed(String message) {
        runOnUiThread(() -> {
            conversionActive = false;
            running = false;
            closeTransferQuietly();
            setStatus(message);
        });
    }

    private synchronized void closeTransferQuietly() {
        try {
            if (currentTempOut != null) {
                currentTempOut.close();
            }
        } catch (Exception ignored) {
        }
        currentTempOut = null;
        currentExpectedBytes = 0L;
        currentReceivedBytes = 0L;
    }

    private PdfName makePdfName(PageData data) {
        String series = normalizeSeries(data.series);
        String chapter = data.chapter == null ? "" : data.chapter.trim().replace(',', '.');

        if (chapter.isEmpty()) chapter = extractChapter(data.url);
        if (chapter.isEmpty()) chapter = String.valueOf(sequence);

        String padded;
        if (chapter.contains(".")) {
            String[] p = chapter.split("\\.", 2);
            padded = leftPad(p[0], 3) + "." + p[1];
        } else {
            padded = leftPad(chapter, 3);
        }

        String fileName = series.replace(" ", "_") + "_Chapitre_" + padded + ".pdf";
        return new PdfName(series, chapter, fileName);
    }

    private boolean pdfExists(String series, String fileName) {
        if (Build.VERSION.SDK_INT >= 29) {
            String relative = "Download/PDF_CONVERTIS/" + series + "/";
            String[] projection = new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.SIZE};
            String selection = MediaStore.Downloads.DISPLAY_NAME + "=? AND "
                    + MediaStore.Downloads.RELATIVE_PATH + "=?";
            String[] args = new String[]{fileName, relative};

            try (android.database.Cursor c = getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    args,
                    null
            )) {
                return c != null && c.moveToFirst() && c.getLong(1) > 10000L;
            }
        }

        File f = legacyFile(series, fileName);
        return f.exists() && f.length() > 10000L;
    }

    private boolean savePdf(File source, String series, String fileName) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH,
                    "Download/PDF_CONVERTIS/" + series + "/");
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri == null) return false;

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 FileInputStream in = new FileInputStream(source)) {

                if (out == null) throw new IllegalStateException("Sortie MediaStore indisponible");

                byte[] buffer = new byte[65536];
                int len;

                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;

            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                setStatus("Erreur d’enregistrement : " + e.getMessage());
                return false;
            }
        }

        File output = legacyFile(series, fileName);
        File parent = output.getParentFile();
        if (parent != null) parent.mkdirs();

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output)) {

            byte[] buffer = new byte[65536];
            int len;

            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }

            return true;

        } catch (Exception e) {
            setStatus("Erreur d’enregistrement : " + e.getMessage());
            return false;
        }
    }

    private File legacyFile(String series, String fileName) {
        File downloads = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
        );

        return new File(
                downloads,
                "PDF_CONVERTIS/" + series + "/" + fileName
        );
    }

    private void continueOrFinish(PageData data) {
        if (data == null) {
            running = false;
            return;
        }

        if (stopAfterCurrent) {
            running = false;
            setStatus(statusText.getText() + "\nArrêt demandé après ce chapitre.");
            return;
        }

        boolean continueAuto = autoMode && autoNextCheck.isChecked();

        if (continueAuto && data.next != null && !data.next.isEmpty()) {
            handler.postDelayed(() -> loadChapter(data.next), 700);
            return;
        }

        running = false;

        if (data.next != null && !data.next.isEmpty() && !continueAuto) {
            setStatus(statusText.getText() + "\nChapitre suivant détecté : " + data.next);
        } else if ("finished".equals(data.end)) {
            setStatus(statusText.getText() + "\nFin de série détectée.");
        } else if ("waiting".equals(data.end)) {
            setStatus(statusText.getText() + "\nEn attente de la suite.");
        } else {
            setStatus(statusText.getText() + "\nAucun chapitre suivant disponible.");
        }
    }

    private void updateProgress(int percent, String message) {
        int p = Math.max(0, Math.min(100, percent));
        progressBar.setProgress(p);
        percentText.setText(p + " %");
        statusText.setText(message);
    }

    private static String normalizeSeries(String raw) {
        String clean = raw == null ? "" : raw
                .replaceAll("[\\\\/:*?\"<>|]+", " ")
                .replaceAll("\\s+", " ")
                .trim();

        if (clean.isEmpty()) return "Serie";

        StringBuilder b = new StringBuilder();

        for (String word : clean.split(" ")) {
            if (word.isEmpty()) continue;

            String lower = word.toLowerCase(Locale.getDefault());
            String nice = Character.toUpperCase(lower.charAt(0)) + lower.substring(1);

            if (b.length() > 0) b.append(' ');
            b.append(nice);
        }

        return b.length() == 0 ? "Serie" : b.toString();
    }

    private static String extractChapter(String url) {
        if (url == null) return "";

        Matcher m = Pattern.compile(
                "(?:chapter|chapitre|chap|ch|episode|ep)[/_-]?(\\d+(?:[.,]\\d+)?)",
                Pattern.CASE_INSENSITIVE
        ).matcher(url);

        return m.find() ? m.group(1).replace(',', '.') : "";
    }

    private static String leftPad(String value, int width) {
        StringBuilder b = new StringBuilder();
        while (b.length() + value.length() < width) b.append('0');
        b.append(value);
        return b.toString();
    }

    private void setStatus(String text) {
        statusText.setText(text);
    }
}
