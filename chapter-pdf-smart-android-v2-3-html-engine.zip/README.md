# Chapter PDF Smart Android V2.3 — moteur HTML V21

Cette version change complètement le chargement du chapitre.

## Plus de scroll automatique
L'application n'effectue plus de scroll rapide pour forcer les images à apparaître.

Elle lit directement le DOM de la page et détecte :
- `src`
- `currentSrc`
- `data-src`
- `data-lazy-src`
- `data-original`
- `data-url`
- `srcset`
- autres attributs lazy courants

Cela permet de récupérer les URL des pages même si elles ne sont pas encore affichées à l'écran.

## Progression réelle
La barre avance selon le travail réellement effectué :
- chargement page / analyse HTML ;
- nombre d'images réellement chargées ;
- calcul de la largeur moyenne ;
- découpage des images longues ;
- construction du PDF ;
- transfert du PDF vers Android ;
- enregistrement dans Téléchargements.

La vitesse dépend donc réellement du réseau, du site et du téléphone.

## Moteur de conversion
Le moteur JavaScript reprend le comportement de la web app V21 :
- largeur moyenne de toutes les images ;
- redimensionnement uniforme sans déformation ;
- découpage mobile 9:16 ;
- JPEG qualité 0.95 ;
- une image/segment = une page PDF sans marge ;
- page PDF exactement au ratio du segment ;
- ouverture FitH / OneColumn.

Fonctions reprises :
- `averageImageWidth`
- `imageToJpegSegments`
- `canvasToJpeg`
- `buildPdf`

## Sortie
`Téléchargements/PDF_CONVERTIS/Nom Serie/`

Exemple :
`Set_It_Chapitre_001.pdf`

## Automatisation
- chapitre courant ;
- toute la suite ;
- ignorer les PDF déjà terminés ;
- CAPTCHA manuel ;
- chapitre suivant ;
- fin de série ;
- attente de suite ;
- arrêt après chapitre courant.

## Workflow
Compatible avec `unzip-and-build-apk.yml`.
