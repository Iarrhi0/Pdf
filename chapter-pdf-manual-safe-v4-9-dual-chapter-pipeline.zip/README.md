# V4.9 Dual Chapter Pipeline

File A : 1 -> 3 -> 5 -> 7...
File B : 2 -> 4 -> 6 -> 8...

Chaque file avance dès que son chapitre est fini, sans attendre l'autre.
Quand une file ne trouve plus de chapitre : FIN.
Quand les deux sont terminées : FIN DE LA SÉRIE.

Le moteur V4.8 Multi-Engine est conservé à l'intérieur de chaque chapitre.
Maximum : deux chapitres en parallèle.
