# HTML Images vers PDF V13

V13 ajoute trois améliorations principales :

1. Uniformisation intelligente des images : dans chaque PDF, la largeur moyenne des images source est calculée puis toutes les images sont redimensionnées à cette largeur en conservant leur ratio. Le mode mobile continue à découper les images très longues sans marge.
2. Classement intelligent et nettoyage : les doublons strictement identiques sont supprimés par empreinte SHA-256. Les répétitions ayant le même chapitre et le même titre sont regroupées et la version la plus volumineuse est conservée. Les fichiers sont triés naturellement, rangés dans des dossiers et le nom source passe en premier dans le nom du PDF. Un rapport DOUBLONS_SUPPRIMES.txt est créé.
3. Nouveau mode PDF dans pages : l’application analyse une page Web et, avec une profondeur réglable, ses pages liées du même domaine pour trouver les liens PDF. Les PDF sont téléchargés en parallèle, triés, dédupliqués par contenu et rangés par site/dossier quand l’accès au dossier de sortie est disponible.

La V13 conserve aussi les conversions parallèles, le mode ZIP/dossier Android, les fichiers MHT/MHTML, le mode multi-sites par chapitres, la connexion réalisée directement sur le site, le téléchargement immédiat des PDF terminés et le ZIP final de secours.

Limites : une application GitHub Pages ne peut pas contourner CORS, Cloudflare, CAPTCHA, paywall ou les restrictions de connexion d’un site. Le proxy public de secours ne doit être utilisé que pour des ressources que tu es autorisé à récupérer.
