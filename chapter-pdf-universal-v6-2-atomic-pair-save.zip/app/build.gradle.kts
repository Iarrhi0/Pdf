plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.chapterpdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.chapterpdf"
        minSdk = 24
        targetSdk = 35
        versionCode = 27
        versionName = "6.2"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
