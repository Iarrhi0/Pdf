# V6.2 — Atomic Pair Save

Cette version corrige réellement la course d'enregistrement observée avec
les chapitres 17/18.

## Cause exacte de V6.1
- le verrou `queuedDownload()` n'était pas appliqué au bon convertisseur ;
- `AndroidFiles.finish()` lançait la finalisation sur le thread UI puis
  retournait immédiatement au JavaScript ;
- le moteur pouvait donc croire le PDF terminé, lancer la suite, et réutiliser
  le même transfert temporaire alors que le précédent n'était pas fini.

Conséquences possibles :
- deux chapitres fusionnés ;
- nom du chapitre le plus rapide appliqué au mauvais contenu ;
- paire suivante lancée trop tôt.

## V6.2
- ajout de `AndroidFiles.finishSync()` ;
- l'appel JavaScript ne revient qu'après écriture complète dans Downloads ;
- le convertisseur parallèle utilise réellement `queuedDownload()` ;
- un seul PDF peut entrer dans la section critique d'écriture Android ;
- chaque contexte garde son propre nom (`..._017.pdf`, `..._018.pdf`) ;
- si 18 finit sa conversion avant 17, il peut attendre dans la file de sauvegarde ;
- 19/20 ne démarrent qu'après confirmation de sauvegarde complète de 17 ET 18 ;
- la barre de série affiche explicitement les deux noms enregistrés avant
  d'annoncer la paire suivante.

Le traitement/décodage des deux chapitres reste parallèle ; seule l'écriture
finale Android est sérialisée pour éviter toute collision.
