# Correspondance ancienne app Android → PC

| MangaHub Android | Chapter Search PDF PC v2.0 |
|---|---|
| Android WebView réel | BrowserWindow Chromium cachée, session Electron partagée |
| `onPageFinished` + délai | `loadURL` + rendu lazy + délai de stabilisation |
| `document.documentElement.outerHTML` | DOM rendu + outerHTML exploité dans E3 |
| CookieManager | `session.defaultSession.cookies` |
| User-Agent WebView | `webContents.getUserAgent()` |
| Referer final après redirection | `webContents.getURL()` |
| Engines 1–4 | DOM lecteur, lazy/srcset, HTML/JSON, liens/CSS/performance |
| Engine 5 HTTP validation | Range probe natif puis validation Chromium de secours |
| Web session registry | `legacy5Sessions` par URL image |
| V4.6 two-pass recovery | 2 rerendus profonds avec exact/adjacent page recovery |
| 403/429 = error/retry | 403/429 jamais interprétés comme fin de chapitre |
