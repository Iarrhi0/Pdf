const LEGACY_RENDER_PREP = String.raw`(async function(){
  const nap=ms=>new Promise(r=>setTimeout(r,ms));
  const attrs=['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc','data-echo','data-lazy'];
  function hydrate(){
    document.querySelectorAll('img').forEach(function(img){
      for(const a of attrs){
        const v=img.getAttribute(a);
        if(v && (!img.getAttribute('src') || /placeholder|loading|lazy|blank|spacer|transparent/i.test(img.getAttribute('src')||''))){
          img.setAttribute('src',v); break;
        }
      }
      const srcset=img.getAttribute('data-srcset');
      if(srcset && !img.getAttribute('srcset')) img.setAttribute('srcset',srcset);
      img.loading='eager';
    });
  }
  hydrate();
  const start=Math.max(document.documentElement.scrollHeight||0,document.body?.scrollHeight||0,1);
  const steps=18;
  let last=start,stable=0;
  for(let i=0;i<steps;i++){
    hydrate();
    const h=Math.max(document.documentElement.scrollHeight||0,document.body?.scrollHeight||0,1);
    window.scrollTo(0,Math.max(0,Math.round((h-window.innerHeight)*(i/(steps-1)))));
    window.dispatchEvent(new Event('scroll'));
    await nap(90);
    if(Math.abs(h-last)<10) stable++; else stable=0;
    last=h;
    if(i>10 && stable>=4) break;
  }
  hydrate();
  window.scrollTo(0,0);
  await nap(180);
  return {height:last,images:document.querySelectorAll('img').length};
})();`;

// Faithful browser-side counterpart of MangaHub V4.5 engines 1-4.
// Engine 5 itself runs in the Electron main process and performs real HTTP validation.
const LEGACY_EXTRACT_CANDIDATES = String.raw`(function(){
  function norm(s){return (s||'').replace(/\s+/g,' ').trim()}
  function abs(raw){
    var v=(raw||'').trim();
    if(!v||/^data:|^blob:/i.test(v))return '';
    v=v.replace(/\\\//g,'/').replace(/&amp;/g,'&').replace(/^["'\s]+|["'\s]+$/g,'');
    try{return new URL(v,location.href).href}catch(e){return ''}
  }
  function bad(u){
    var s=(u||'').toLowerCase();
    return !u || ['logo','avatar','favicon','emoji','banner','adsense','/ads/','advert','sprite','placeholder','loading','spacer','thumbnail','thumb','gravatar','analytics','pixel.gif','tracking','wp-content/plugins','wp-content/themes'].some(function(x){return s.indexOf(x)>=0});
  }
  function looks(u){var s=(u||'').toLowerCase().split('#')[0];return /\.(?:jpe?g|png|webp|avif|gif|bmp|tiff?)(?:\?.*)?$/.test(s)||['/image/','/images/','/uploads/','/manga/','/chapter/','/chapitre/','scan','cdn','media'].some(function(x){return s.indexOf(x)>=0})}
  function chapterNo(s){
    var m=(s||'').match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);
    if(!m)m=(s||'').match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);
    return m?parseFloat(m[1]):null;
  }
  var html=document.documentElement?document.documentElement.outerHTML:'';
  var map={},seq=0,stats={E1:0,E2:0,E3:0,E4:0};
  function add(raw,engine,pos,source){
    var u=abs(raw);if(!u||bad(u))return;
    var z=map[u];
    if(!z){z=map[u]={url:u,engine:engine,engines:[engine],position:pos==null?999999:pos,sources:[source||engine]};}
    else{
      if(z.engines.indexOf(engine)<0)z.engines.push(engine);
      if(source&&z.sources.indexOf(source)<0)z.sources.push(source);
      if(pos!=null&&pos<z.position){z.position=pos;z.engine=engine;}
    }
  }
  function attrPosition(raw,fallback){var p=html.indexOf(raw);return p>=0?p:fallback}
  function addElementImages(elements,engine,base){
    var attrs=['src','data-src','data-original','data-lazy-src','data-url','data-image','data-cfsrc','data-echo','data-lazy'];
    Array.prototype.forEach.call(elements,function(el){
      attrs.forEach(function(a){if(el.hasAttribute&&el.hasAttribute(a)){var raw=el.getAttribute(a)||'';add(raw,engine,attrPosition(raw,base+(seq++)),a)}});
      ['srcset','data-srcset'].forEach(function(a){if(el.hasAttribute&&el.hasAttribute(a)){(el.getAttribute(a)||'').split(',').forEach(function(part){var raw=part.trim().split(/\s+/)[0];if(raw)add(raw,engine,attrPosition(raw,base+(seq++)),a)})}});
    });
  }

  // Engine 1: reader DOM containers, same principle as MangaHub V4.5.
  var readerSelectors=['.reading-content','.chapter-content','.chapter-reader','.reader-content','.manga-reading-content','.wp-manga-chapter-img','.entry-content','[class*=reader]','[id*=reader]','[class*=chapter] main','main article','article','#readerarea','.reader-area','.readerarea','.ts_reader','.chapter-images','.container-chapter-reader','.reading-detail','.viewer','.viewer_img','.episode-body','.webtoon-reader','.chapterbody','.chapter-body','.manga-reader','.comic-reader'];
  readerSelectors.forEach(function(sel){
    try{document.querySelectorAll(sel).forEach(function(root){addElementImages(root.querySelectorAll('img,source,picture source'),1,0)})}catch(e){}
  });
  stats.E1=Object.values(map).filter(function(x){return x.engines.indexOf(1)>=0}).length;

  // Engine 2: lazy/srcset declarations across the rendered document.
  addElementImages(document.querySelectorAll('img,source,picture source'),2,100000);
  stats.E2=Object.values(map).filter(function(x){return x.engines.indexOf(2)>=0}).length;

  // Engine 3: rendered outerHTML/JSON/script payloads.
  var patterns=[
    /["'](?:src|image|imageUrl|image_url|url|file|path)["']\s*:\s*["']([^"']+)["']/gi,
    /(https?:\\?\/\\?\/[^"'<>\s]+?\.(?:jpe?g|png|webp|avif|gif|bmp|tiff?)(?:\?[^"'<>\s]*)?)/gi,
    /["']([^"']+?\.(?:jpe?g|png|webp|avif|gif|bmp|tiff?)(?:\?[^"']*)?)["']/gi
  ];
  patterns.forEach(function(re){var m,k=0;while((m=re.exec(html))&&k<2500){add((m[1]||'').replace(/\\u002F/g,'/').replace(/\\\//g,'/'),3,m.index,'raw');k++}});
  stats.E3=Object.values(map).filter(function(x){return x.engines.indexOf(3)>=0}).length;

  // Engine 4: direct links/CSS plus resources really loaded by Chromium.
  document.querySelectorAll('a[href]').forEach(function(a){var raw=a.getAttribute('href')||'';if(looks(raw))add(raw,4,attrPosition(raw,200000+(seq++)),'link')});
  var css=/url\(\s*["']?([^"')]+)["']?\s*\)/gi,m;while((m=css.exec(html)))add(m[1],4,m.index,'css');
  try{
    var perf=performance.getEntriesByType('resource')||[];
    perf.forEach(function(e,i){var u=e.name||'';if(!bad(u)&&(looks(u)||e.initiatorType==='img'))add(u,4,250000+Math.round((e.startTime||0)*10)+i,'performance:'+e.initiatorType)});
  }catch(e){}
  stats.E4=Object.values(map).filter(function(x){return x.engines.indexOf(4)>=0}).length;

  var ordered=Object.values(map).sort(function(a,b){if(a.position!==b.position)return a.position-b.position;return a.engine-b.engine});
  var title=norm(document.title),h1=norm((document.querySelector('h1')||{}).textContent),url=location.href,n=chapterNo(title+' '+url+' '+h1);
  var rawSeries=h1||title||'Série';
  rawSeries=rawSeries.replace(/(?:[-|–—:]\s*)?(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|cap[ií]tulo|scan)\s*[-:# ]*\d+(?:\.\d+)?.*$/i,'').replace(/\s*[-|–—:]\s*(lecture|read|scan).*$/i,'').trim()||'Série';
  var isVolume=/(tome|volume|vol\.?)/i.test(title+' '+url+' '+h1);
  var label=n?((isVolume?'Tome ':'Chapitre ')+n):(title.replace(rawSeries,'').replace(/^[-|–—: ]+|[-|–—: ]+$/g,'')||'Chapitre');
  var chapterSignal=!!n||/(chapter|chapitre|episode|reader|lecture|scan|tome|volume)/i.test(url+' '+title+' '+h1);
  return JSON.stringify({ok:ordered.length>0&&chapterSignal,series:rawSeries,chapter:label,number:n,isVolume:isVolume,chapterSignal:chapterSignal,finalUrl:location.href,candidates:ordered.slice(0,2500),engineStats:stats,htmlLength:html.length});
})();`;

module.exports = { LEGACY_RENDER_PREP, LEGACY_EXTRACT_CANDIDATES };
