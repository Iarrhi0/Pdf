# JAVA5 port fidèle

Cette version corrige la confusion des versions PC précédentes.

Source originale récupérée :
`mangahub-pdf-v2-multiengine-batch/app/src/main/java/com/mangahub/pdf/MainActivity.java`

Le pipeline original `extractReaderImages()` est porté tel quel dans `assets/java-engine5.js` :

1. E1 : `<img src>`
2. E2 : lazy attributes, `srcset`, `noscript`
3. E3 : HTML brut, JSON et configs JavaScript
4. E4 : liens image et CSS `url(...)`
5. E5 JAVA : détection du bloc `/api/chapters/.../image/N.ext`, isolation de ce bloc et tri numérique. Sinon tri numérique des pages puis ordre DOM.

Le rendu Chromium est utilisé uniquement pour obtenir le DOM réellement construit par JavaScript/lazy-load. Le rôle E5 n'est plus attribué à la validation réseau.

Après JAVA5, le téléchargement garde les cookies, le Referer et le User-Agent de la session et valide réellement les fichiers au moment du téléchargement.
