package com.chaptersafe.searchpdf;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class ReaderRegistry {
    public static final class Profile {
        public final String family;
        public final List<String> domains;
        public final List<String> markers;
        Profile(String family, String[] domains, String[] markers) {
            this.family = family;
            this.domains = Arrays.asList(domains);
            this.markers = Arrays.asList(markers);
        }
    }

    private static final List<Profile> PROFILES = new ArrayList<>();

    static {
        add("SushiScan / Madara FR", new String[]{"sushiscan.fr","sushiscan.net"}, new String[]{"reading-content","wp-manga-chapter"});
        add("OrtegaScans", new String[]{"ortegascans.com","ortegascans.fr"}, new String[]{"chapter-reader","reader"});
        add("Mangas-Origines", new String[]{"mangas-origines.fr"}, new String[]{"reading-content","wp-manga"});
        add("ToonFR", new String[]{"toonfr.com","toonfr.net"}, new String[]{"chapter","reader"});
        add("Japscan", new String[]{"japscan.lol","japscan.ws"}, new String[]{"lecture","reader"});
        add("Lelmanga", new String[]{"lelmanga.com"}, new String[]{"reading-content","chapter"});
        add("Scan-Manga", new String[]{"scan-manga.com"}, new String[]{"reader","chapter"});
        add("Manga-Scantrad", new String[]{"manga-scantrad.io","scantrad.net"}, new String[]{"reader","chapter"});
        add("MangaDex", new String[]{"mangadex.org"}, new String[]{"reader","chapter"});
        add("ComicK", new String[]{"comick.io","comick.fun"}, new String[]{"reader","chapter"});
        add("Bato / XBato", new String[]{"bato.to","xbato.com","batotoo.com"}, new String[]{"reader","episode"});
        add("MangaSee / MangaLife", new String[]{"mangasee123.com","manga4life.com"}, new String[]{"readerArea","Chapter"});
        add("MangaKakalot / MangaNato", new String[]{"mangakakalot.com","manganato.com","chapmanganato.to"}, new String[]{"container-chapter-reader","chapter"});
        add("MangaReader", new String[]{"mangareader.to"}, new String[]{"reading-detail","chapter"});
        add("MangaPark", new String[]{"mangapark.net","mangapark.io"}, new String[]{"reader","chapter"});
        add("MangaBuddy", new String[]{"mangabuddy.com"}, new String[]{"chapter-images","chapter"});
        add("MangaGo", new String[]{"mangago.me"}, new String[]{"viewer","chapter"});
        add("MangaHere", new String[]{"mangahere.cc"}, new String[]{"reader","chapter"});
        add("MangaFreak", new String[]{"mangafreak.me"}, new String[]{"manga_series","chapter"});
        add("MangaClash", new String[]{"mangaclash.com"}, new String[]{"reading-content","chapter"});
        add("MangaNelo", new String[]{"manganelo.com"}, new String[]{"container-chapter-reader","chapter"});
        add("Toonily", new String[]{"toonily.com","toonily.net"}, new String[]{"reading-content","wp-manga"});
        add("KunManga", new String[]{"kunmanga.com"}, new String[]{"reading-content","wp-manga"});
        add("HariManga", new String[]{"harimanga.com"}, new String[]{"reading-content","wp-manga"});
        add("CoffeeManga", new String[]{"coffeemanga.io","coffeemanga.com"}, new String[]{"reading-content","wp-manga"});
        add("ZinManga", new String[]{"zinmanga.com"}, new String[]{"reading-content","wp-manga"});
        add("ManhuaFast", new String[]{"manhuafast.com"}, new String[]{"reading-content","wp-manga"});
        add("ManhuaPlus", new String[]{"manhuaplus.com"}, new String[]{"reading-content","wp-manga"});
        add("Asura Scans", new String[]{"asuracomic.net","asuratoon.com","asurascans.com"}, new String[]{"reader","chapter"});
        add("Reaper Scans", new String[]{"reaperscans.com"}, new String[]{"reader","chapter"});
        add("Flame Comics", new String[]{"flamecomics.com","flamescans.org"}, new String[]{"reader","chapter"});
        add("Hive Scans", new String[]{"hivescans.com"}, new String[]{"reader","chapter"});
        add("Cosmic Scans", new String[]{"cosmicscans.com"}, new String[]{"reader","chapter"});
        add("Night Scans", new String[]{"nightscans.org"}, new String[]{"reader","chapter"});
        add("Rizz Comics", new String[]{"rizzfables.com","rizzcomic.com"}, new String[]{"reader","chapter"});
        add("Omega Scans", new String[]{"omegascans.org"}, new String[]{"reader","chapter"});
        add("Reset Scans", new String[]{"reset-scans.co"}, new String[]{"reader","chapter"});
        add("Lua Scans", new String[]{"luascans.com"}, new String[]{"reader","chapter"});
        add("ManhwaClan", new String[]{"manhwaclan.com"}, new String[]{"reading-content","chapter"});
        add("MangaBTT", new String[]{"mangabtt.com"}, new String[]{"chapter","viewer"});
        add("TuMangaOnline / LectorManga", new String[]{"lectormanga.com","visortmo.com","tmofans.com"}, new String[]{"viewer","chapter"});
        add("Webtoon / Naver", new String[]{"webtoons.com","comic.naver.com"}, new String[]{"viewer_img","episode"});
        add("Tapas", new String[]{"tapas.io"}, new String[]{"episode","viewer"});
        add("Tappytoon", new String[]{"tappytoon.com"}, new String[]{"episode","viewer"});
        add("Manta", new String[]{"manta.net"}, new String[]{"episode","viewer"});
        add("MANGA Plus", new String[]{"mangaplus.shueisha.co.jp"}, new String[]{"viewer","chapter"});
        add("Comikey", new String[]{"comikey.com"}, new String[]{"viewer","chapter"});
        add("FoolSlide", new String[]{}, new String[]{"foolslide","page-container","chapter-page"});
        add("Genkan", new String[]{}, new String[]{"genkan","reader-container"});
        add("Madara / WP Manga", new String[]{}, new String[]{"wp-manga","reading-content","page-break"});
        add("MangaStream / MangaThemesia", new String[]{}, new String[]{"readerarea","ts_reader","chapterbody"});
        add("Generic vertical webtoon", new String[]{}, new String[]{"chapter-images","episode-body","webtoon-reader"});
    }

    private static void add(String family, String[] domains, String[] markers) {
        PROFILES.add(new Profile(family, domains, markers));
    }

    public static String detect(String url, String html) {
        String host = "";
        try { host = new URI(url).getHost(); } catch (Exception ignored) {}
        if (host == null) host = "";
        host = host.toLowerCase(Locale.ROOT);
        String doc = html == null ? "" : html.toLowerCase(Locale.ROOT);
        for (Profile p : PROFILES) {
            for (String d : p.domains) {
                if (!d.isEmpty() && (host.equals(d) || host.endsWith("." + d))) return p.family;
            }
        }
        for (Profile p : PROFILES) {
            int hits = 0;
            for (String m : p.markers) if (!m.isEmpty() && doc.contains(m.toLowerCase(Locale.ROOT))) hits++;
            if (hits >= Math.min(2, Math.max(1, p.markers.size()))) return p.family;
        }
        return "Lecteur générique / Auto Engine";
    }

    public static int knownProfileCount() { return PROFILES.size(); }

    private ReaderRegistry() {}
}
