package com.chaptersafe.searchpdf;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PdfDownloadManager {
    public interface Listener {
        void onStatus(String text);
        void onDone(String displayName, String outputLocation);
        void onError(String message);
    }

    public interface Control {
        boolean isPaused();
        boolean isStopped();
    }

    private static final int CONNECT_TIMEOUT = 18000;
    private static final int READ_TIMEOUT = 30000;
    private static final int MAX_DIMENSION = 5000;

    public static void downloadChapter(Context context, String chapterUrl, String seriesTitle, String chapterLabel,
                                       List<String> candidates, String userAgent, Control control, Listener listener) {
        new Thread(() -> {
            File tempDir = null;
            try {
                if (candidates == null || candidates.isEmpty()) throw new IOException("Aucune image détectée");
                String cookies = CookieManager.getInstance().getCookie(chapterUrl);
                tempDir = new File(context.getCacheDir(), "chapter_" + System.nanoTime());
                if (!tempDir.mkdirs()) throw new IOException("Cache chapitre impossible");
                List<File> valid = new ArrayList<>();
                int total = candidates.size();
                for (int i = 0; i < total; i++) {
                    waitIfPaused(control);
                    if (control != null && control.isStopped()) throw new IOException("Téléchargement arrêté");
                    String imageUrl = candidates.get(i);
                    listener.onStatus("DOWNLOAD • page " + (i + 1) + "/" + total + " • validation réelle");
                    try {
                        byte[] bytes = fetchImage(imageUrl, chapterUrl, userAgent, cookies);
                        if (!isDecodableImage(bytes)) continue;
                        File f = new File(tempDir, String.format(Locale.US, "%05d.img", valid.size() + 1));
                        try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                        valid.add(f);
                    } catch (HttpStatusException e) {
                        if (e.code == 403 || e.code == 429) listener.onStatus("BLOQUÉ " + e.code + " • candidat suivant");
                    } catch (Exception ignored) { }
                }
                if (valid.size() < 2) throw new IOException("Chapitre rejeté : moins de 2 vraies pages décodables");
                waitIfPaused(control);
                if (control != null && control.isStopped()) throw new IOException("Téléchargement arrêté");
                String name = buildPdfName(seriesTitle, chapterLabel) + ".pdf";
                listener.onStatus("PDF • assemblage " + valid.size() + " pages");
                String location = writePdf(context, name, valid, control, listener);
                listener.onDone(name, location);
            } catch (Exception e) {
                listener.onError(e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "Erreur inconnue" : e.getMessage()));
            } finally {
                deleteRecursively(tempDir);
            }
        }, "chapter-pdf-download").start();
    }

    private static void waitIfPaused(Control c) throws InterruptedException {
        while (c != null && c.isPaused() && !c.isStopped()) Thread.sleep(180);
    }

    private static byte[] fetchImage(String url, String referer, String userAgent, String cookies) throws Exception {
        HttpURLConnection c = open(url, referer, userAgent, cookies);
        int code = c.getResponseCode();
        if (code == 416) { c.disconnect(); c = open(url, referer, userAgent, cookies); code = c.getResponseCode(); }
        if (code < 200 || code >= 400) throw new HttpStatusException(code);
        String type = c.getContentType();
        if (type != null && type.toLowerCase(Locale.ROOT).contains("text/html")) throw new IOException("Réponse HTML à la place d'une image");
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32768]; int n, total = 0;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n); total += n;
                if (total > 40 * 1024 * 1024) throw new IOException("Image trop volumineuse");
            }
            return out.toByteArray();
        } finally { c.disconnect(); }
    }

    private static HttpURLConnection open(String url, String referer, String userAgent, String cookies) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true); c.setConnectTimeout(CONNECT_TIMEOUT); c.setReadTimeout(READ_TIMEOUT);
        c.setRequestProperty("User-Agent", userAgent == null ? "Mozilla/5.0" : userAgent);
        c.setRequestProperty("Referer", referer);
        c.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        if (cookies != null && !cookies.isEmpty()) c.setRequestProperty("Cookie", cookies);
        return c;
    }

    private static boolean isDecodableImage(byte[] b) {
        if (b == null || b.length < 512 || !hasImageMagic(b)) return false;
        BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(b, 0, b.length, o);
        return o.outWidth > 0 && o.outHeight > 0;
    }

    private static boolean hasImageMagic(byte[] b) {
        if (b.length < 12) return false;
        boolean jpg = (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8;
        boolean png = (b[0] & 0xFF) == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47;
        boolean gif = b[0] == 'G' && b[1] == 'I' && b[2] == 'F';
        boolean webp = b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P';
        boolean bmp = b[0] == 'B' && b[1] == 'M';
        return jpg || png || gif || webp || bmp;
    }

    private static Bitmap decodeForPdf(File f) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("Image non décodable");
        int sample = 1;
        while ((bounds.outWidth / sample) > MAX_DIMENSION || (bounds.outHeight / sample) > MAX_DIMENSION * 4) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options(); opts.inSampleSize = sample; opts.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
        if (bitmap == null) throw new IOException("Décodage bitmap impossible");
        return bitmap;
    }

    private static String writePdf(Context context, String displayName, List<File> pages, Control control, Listener listener) throws Exception {
        PdfDocument pdf = new PdfDocument();
        try {
            int pageNo = 1;
            for (File data : pages) {
                waitIfPaused(control); if (control != null && control.isStopped()) throw new IOException("Téléchargement arrêté");
                listener.onStatus("PDF • page " + pageNo + "/" + pages.size());
                Bitmap b = decodeForPdf(data); int w = Math.max(1, b.getWidth()), h = Math.max(1, b.getHeight());
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(w, h, pageNo).create();
                PdfDocument.Page p = pdf.startPage(info); Canvas canvas = p.getCanvas(); canvas.drawBitmap(b, 0, 0, null);
                pdf.finishPage(p); b.recycle(); pageNo++;
            }
            OutputTarget target = createOutput(context, displayName);
            try (OutputStream out = target.stream) { pdf.writeTo(out); }
            return target.location;
        } finally { pdf.close(); }
    }

    private static OutputTarget createOutput(Context context, String name) throws Exception {
        String rel = Environment.DIRECTORY_DOWNLOADS + "/Chapter Search PDF";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf"); values.put(MediaStore.Downloads.RELATIVE_PATH, rel);
            ContentResolver resolver = context.getContentResolver(); Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Impossible de créer le PDF dans Téléchargements");
            OutputStream out = resolver.openOutputStream(uri, "w"); if (out == null) throw new IOException("Impossible d'ouvrir la sortie PDF");
            return new OutputTarget(out, "Téléchargements/Chapter Search PDF/" + name);
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Chapter Search PDF");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Impossible de créer le dossier de sortie");
        File f = new File(dir, name); return new OutputTarget(new FileOutputStream(f), f.getAbsolutePath());
    }

    public static String buildPdfName(String series, String chapter) {
        String s = sanitize(series == null ? "Série" : series);
        String c = sanitize(chapter == null ? "Chapitre" : chapter);
        if (c.toLowerCase(Locale.ROOT).startsWith(s.toLowerCase(Locale.ROOT))) return c;
        return sanitize(s + " - " + c);
    }

    public static String sanitize(String s) {
        if (s == null || s.trim().isEmpty()) return "Chapitre";
        String x = s.replaceAll("[\\\\/:*?\"<>|]", " ").replaceAll("\\s+", " ").trim();
        if (x.length() > 140) x = x.substring(0, 140).trim();
        return x.isEmpty() ? "Chapitre" : x;
    }

    private static void deleteRecursively(File f) { if (f == null || !f.exists()) return; if (f.isDirectory()) { File[] a=f.listFiles(); if(a!=null) for(File x:a) deleteRecursively(x); } f.delete(); }
    private static final class OutputTarget { final OutputStream stream; final String location; OutputTarget(OutputStream s,String l){stream=s;location=l;} }
    private static final class HttpStatusException extends IOException { final int code; HttpStatusException(int code){super("HTTP "+code);this.code=code;} }
    private PdfDownloadManager() {}
}
