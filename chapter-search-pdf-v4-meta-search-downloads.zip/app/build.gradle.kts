plugins {
    id("com.android.application")
}

android {
    namespace = "com.chaptersafe.searchpdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.chaptersafe.searchpdf"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "4.0-meta-search-downloads"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
