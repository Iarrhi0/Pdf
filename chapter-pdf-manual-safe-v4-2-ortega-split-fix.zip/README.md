# Chapter PDF Manual Safe V4.2 — Ortega + découpage mobile

Correctif ciblé pour le problème observé sur Ortega Scans.

## Pourquoi le compteur semblait trop petit
Un chapitre Ortega n'est pas nécessairement composé de dizaines de fichiers image.
Le lecteur peut fournir quelques **très longues images verticales**, chacune contenant
de nombreuses cases/pans du chapitre.

## V4.2
- détecte précisément les vraies images Ortega :
  `/api/chapters/<serie>/<id>/image/<numero>.jpg`
- ignore les images parasites lorsque ces URL sont présentes ;
- trie les images par numéro ;
- active le découpage mobile du moteur PDF ;
- chaque longue image est découpée en plusieurs pages d'environ 9:16 ;
- aucune marge ;
- largeur cible 1080 px ;
- ratio conservé ;
- le statut distingue maintenant :
  - images sources ;
  - pages PDF réellement générées ;
  - doublons ;
  - échecs.

La V4.2 traite uniquement ce problème. Le renommage intelligent et le mode
dossier HTML seront réintroduits après validation de cette conversion.
