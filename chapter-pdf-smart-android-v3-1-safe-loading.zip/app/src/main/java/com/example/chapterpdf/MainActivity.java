package com.example.chapterpdf;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private FrameLayout rootFrame;
    private WebView home;
    private WebView chapter;
    private WebView converter;
    private Button resumeButton;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> visited = new HashSet<>();

    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 9090;

    private boolean chainRunning = false;
    private boolean chainAuto = true;
    private boolean chainSkip = true;
    private boolean stopAfterCurrent = false;
    private boolean conversionActive = false;
    private boolean waitingHuman = false;
    private boolean pageStabilityRunning = false;
    private boolean finalAnalysisRunning = false;
    private int pageLoadToken = 0;
    private int stableSamples = 0;
    private String lastStabilityFingerprint = "";
    private long stabilityStartedAt = 0L;
    private int chapterSequence = 0;

    private PageData currentPage;
    private PdfName currentPdfName;

    private File transferTemp;
    private FileOutputStream transferOut;
    private long transferExpected;
    private long transferReceived;
    private String transferName;
    private String transferMime;

    private static class PageData {
        String url = "";
        String series = "Serie";
        String chapter = "";
        boolean captcha = false;
        JSONArray images = new JSONArray();
        String next = "";
        String end = "unknown";
    }

    private static class PdfName {
        final String series;
        final String chapter;
        final String fileName;

        PdfName(String series, String chapter, String fileName) {
            this.series = series;
            this.chapter = chapter;
            this.fileName = fileName;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStorageIfNeeded();
        buildUi();
        configureWebViews();
        home.loadUrl("file:///android_asset/index.html");
    }

    private void requestStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    440
            );
        }
    }

    private void buildUi() {
        rootFrame = new FrameLayout(this);

        home = new WebView(this);
        chapter = new WebView(this);
        converter = new WebView(this);

        rootFrame.addView(home, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        chapter.setVisibility(View.GONE);
        rootFrame.addView(chapter, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        converter.setAlpha(0.01f);
        FrameLayout.LayoutParams converterLp = new FrameLayout.LayoutParams(2, 2);
        converterLp.gravity = Gravity.BOTTOM | Gravity.END;
        rootFrame.addView(converter, converterLp);

        resumeButton = new Button(this);
        resumeButton.setText("REPRENDRE APRÈS VÉRIFICATION");
        resumeButton.setVisibility(View.GONE);
        resumeButton.setOnClickListener(v -> {
            waitingHuman = false;
            chapter.setVisibility(View.VISIBLE);
            resumeButton.setVisibility(View.GONE);
            beginSafeStabilityWait(pageLoadToken);
        });

        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        btnLp.gravity = Gravity.BOTTOM;
        btnLp.setMargins(18, 18, 18, 24);
        rootFrame.addView(resumeButton, btnLp);

        setContentView(rootFrame);
    }

    private void configureWebViews() {
        configure(home);
        configure(chapter);
        configure(converter);

        home.addJavascriptInterface(new AndroidFilesBridge(), "AndroidFiles");
        home.addJavascriptInterface(new AndroidChainBridge(), "AndroidChain");
        converter.addJavascriptInterface(new ConverterBridge(), "AndroidPdf");
        chapter.addJavascriptInterface(new ChapterBridge(), "ChapterBridge");

        home.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackNew,
                    FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackNew;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQ);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        chapter.setWebViewClient(createChapterWebViewClient());
    }

    private WebViewClient createChapterWebViewClient() {
        return new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                pageLoadToken++;
                pageStabilityRunning = false;
                finalAnalysisRunning = false;
                stableSamples = 0;
                lastStabilityFingerprint = "";
                stabilityStartedAt = System.currentTimeMillis();
                
                if (chainRunning && !conversionActive) {
                    nativeProgress("Chargement page", 3, "La page est en cours de chargement…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!chainRunning || conversionActive || waitingHuman) {
                    return;
                }

                nativeProgress(
                        "Chargement sécurisé",
                        10,
                        "La page a répondu. Attente de stabilité du DOM…"
                );

                beginSafeStabilityWait(pageLoadToken);
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                boolean crashed = detail != null && detail.didCrash();

                runOnUiThread(() -> {
                    pageStabilityRunning = false;
                    finalAnalysisRunning = false;
                    conversionActive = false;
                    waitingHuman = false;

                    nativeFinished(
                            crashed
                                    ? "Le moteur WebView a planté pendant le chargement. L’application est restée ouverte et le navigateur du chapitre va être recréé."
                                    : "Android a arrêté le moteur WebView faute de ressources. L’application est restée ouverte."
                    );

                    recreateChapterWebView();
                });

                // Important: true = crash du renderer géré par l'application.
                return true;
            }
        };
    }


    private void recreateChapterWebView() {
        try {
            if (chapter != null) {
                try {
                    rootFrame.removeView(chapter);
                } catch (Exception ignored) {
                }

                try {
                    chapter.stopLoading();
                    chapter.removeJavascriptInterface("ChapterBridge");
                    chapter.destroy();
                } catch (Exception ignored) {
                }
            }

            chapter = new WebView(this);
            configure(chapter);
            chapter.addJavascriptInterface(new ChapterBridge(), "ChapterBridge");
            chapter.setWebViewClient(createChapterWebViewClient());
            chapter.setVisibility(View.GONE);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            );

            // Keep the chapter viewer under the floating resume button.
            rootFrame.addView(chapter, 1, lp);

        } catch (Exception e) {
            nativeFinished("Impossible de recréer la WebView : " + e.getMessage());
        }
    }

    private void configure(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(view, true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQ) {
            Uri[] results = null;

            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }

            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private class AndroidFilesBridge {
        @JavascriptInterface
        public void begin(String name, String mime, long size) {
            synchronized (MainActivity.this) {
                closeTransferQuietly();
                try {
                    transferName = sanitizeDownloadName(name);
                    transferMime = (mime == null || mime.isEmpty())
                            ? "application/octet-stream"
                            : mime;
                    transferExpected = size;
                    transferReceived = 0;
                    transferTemp = new File(
                            getCacheDir(),
                            "web_" + System.currentTimeMillis() + ".tmp"
                    );
                    transferOut = new FileOutputStream(transferTemp);
                } catch (Exception e) {
                    showHomeMessage("Erreur création fichier : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void chunk(String base64) {
            synchronized (MainActivity.this) {
                try {
                    if (transferOut == null) {
                        throw new IllegalStateException("Transfert non initialisé");
                    }
                    byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                    transferOut.write(bytes);
                    transferReceived += bytes.length;
                } catch (Exception e) {
                    showHomeMessage("Erreur transfert : " + e.getMessage());
                    closeTransferQuietly();
                }
            }
        }

        @JavascriptInterface
        public void progress(long sent, long total) {
            // Intentionally lightweight: the web UI already owns its detailed status.
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(() -> {
                try {
                    synchronized (MainActivity.this) {
                        if (transferOut != null) {
                            transferOut.flush();
                            transferOut.close();
                            transferOut = null;
                        }
                    }

                    if (transferTemp == null || !transferTemp.exists()) {
                        throw new IllegalStateException("Fichier temporaire absent");
                    }

                    if (transferExpected > 0 && transferTemp.length() != transferExpected) {
                        throw new IllegalStateException(
                                "Transfert incomplet : " + transferTemp.length() + "/" + transferExpected
                        );
                    }

                    boolean ok = saveGenericToDownloads(
                            transferTemp,
                            transferName,
                            transferMime
                    );

                    transferTemp.delete();
                    transferTemp = null;

                    if (!ok) {
                        throw new IllegalStateException("Enregistrement Android impossible");
                    }

                    showHomeMessage("✓ Enregistré dans Téléchargements/PDF_CONVERTIS/\n" + transferName);

                } catch (Exception e) {
                    showHomeMessage("Erreur finalisation : " + e.getMessage());
                } finally {
                    closeTransferQuietly();
                }
            });
        }

        @JavascriptInterface
        public void cancel(String message) {
            closeTransferQuietly();
            showHomeMessage("Téléchargement annulé : " + message);
        }
    }

    private class AndroidChainBridge {
        @JavascriptInterface
        public void start(String url, boolean auto, boolean skip) {
            runOnUiThread(() -> {
                if (url == null || (!url.startsWith("http://") && !url.startsWith("https://"))) {
                    nativeProgress("Erreur", 0, "URL invalide.");
                    return;
                }

                visited.clear();
                chapterSequence = 0;
                chainAuto = auto;
                chainSkip = skip;
                chainRunning = true;
                stopAfterCurrent = false;
                conversionActive = false;
                waitingHuman = false;
                resumeButton.setVisibility(View.GONE);
                chapter.setVisibility(View.GONE);

                loadChapter(url);
            });
        }

        @JavascriptInterface
        public void stop() {
            stopAfterCurrent = true;
        }

        @JavascriptInterface
        public void showChapter() {
            runOnUiThread(() -> {
                chapter.setVisibility(View.VISIBLE);
                resumeButton.setVisibility(View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void retry() {
            runOnUiThread(() -> {
                waitingHuman = false;
                pageStabilityRunning = false;
                finalAnalysisRunning = false;
                chapter.setVisibility(View.VISIBLE);
                chapter.reload();
            });
        }

        @JavascriptInterface
        public void resumeAfterHuman() {
            runOnUiThread(() -> {
                waitingHuman = false;
                chapter.setVisibility(View.VISIBLE);
                resumeButton.setVisibility(View.GONE);
                beginSafeStabilityWait(pageLoadToken);
            });
        }
    }

    private void loadChapter(String url) {
        if (!chainRunning) {
            return;
        }

        if (visited.contains(url)) {
            chainRunning = false;
            nativeFinished("Boucle détectée : chapitre déjà visité.");
            return;
        }

        visited.add(url);
        chapterSequence++;

        pageStabilityRunning = false;
        finalAnalysisRunning = false;
        stableSamples = 0;
        lastStabilityFingerprint = "";
        waitingHuman = false;

        nativeProgress("Ouverture chapitre", 2, "Connexion au chapitre…");
        chapter.loadUrl(url);
    }


    private void beginSafeStabilityWait(int token) {
        if (!chainRunning || conversionActive || waitingHuman) {
            return;
        }

        if (pageStabilityRunning && token == pageLoadToken) {
            return;
        }

        pageStabilityRunning = true;
        finalAnalysisRunning = false;
        stableSamples = 0;
        lastStabilityFingerprint = "";
        stabilityStartedAt = System.currentTimeMillis();

        scheduleStabilityProbe(token, 450);
    }

    private void scheduleStabilityProbe(int token, long delayMs) {
        handler.postDelayed(() -> runStabilityProbe(token), delayMs);
    }

    private void runStabilityProbe(int token) {
        if (!chainRunning ||
                conversionActive ||
                waitingHuman ||
                token != pageLoadToken ||
                chapter == null) {
            pageStabilityRunning = false;
            return;
        }

        final long elapsed = System.currentTimeMillis() - stabilityStartedAt;

        String probeJs = """
            (function(){
              try{
                const imgs=[...document.images];
                const loaded=imgs.filter(x=>x.complete&&x.naturalWidth>0).length;
                const total=imgs.length;
                const h=Math.max(
                  document.body?.scrollHeight||0,
                  document.documentElement?.scrollHeight||0
                );
                const nodes=document.body?document.body.getElementsByTagName('*').length:0;
                const title=(document.title||'').slice(0,120);
                return JSON.stringify({
                  ready:document.readyState||'loading',
                  total:total,
                  loaded:loaded,
                  height:h,
                  nodes:nodes,
                  title:title
                });
              }catch(e){
                return JSON.stringify({
                  ready:'error',
                  total:0,
                  loaded:0,
                  height:0,
                  nodes:0,
                  title:'',
                  error:String(e)
                });
              }
            })();
        """;

        try {
            chapter.evaluateJavascript(probeJs, rawValue -> {
                if (!chainRunning ||
                        conversionActive ||
                        waitingHuman ||
                        token != pageLoadToken) {
                    pageStabilityRunning = false;
                    return;
                }

                try {
                    String jsonText = decodeJavascriptString(rawValue);
                    JSONObject j = new JSONObject(jsonText);

                    String ready = j.optString("ready", "loading");
                    int total = j.optInt("total", 0);
                    int loaded = j.optInt("loaded", 0);
                    int height = j.optInt("height", 0);
                    int nodes = j.optInt("nodes", 0);
                    String title = j.optString("title", "");

                    String fingerprint =
                            ready + "|" + total + "|" + loaded + "|" + height + "|" + nodes;

                    if (fingerprint.equals(lastStabilityFingerprint)) {
                        stableSamples++;
                    } else {
                        stableSamples = 0;
                        lastStabilityFingerprint = fingerprint;
                    }

                    int loadPercent;
                    if (total > 0) {
                        loadPercent = Math.min(
                                70,
                                15 + Math.round((loaded * 55f) / Math.max(1, total))
                        );
                    } else {
                        loadPercent = "complete".equals(ready) ? 40 : 18;
                    }

                    String detail =
                            "DOM : " + ready
                                    + " · Images : " + loaded + "/" + total
                                    + " · Stabilité : " + Math.min(stableSamples, 3) + "/3";

                    nativeProgress("Chargement sécurisé", loadPercent, detail);

                    boolean documentReady =
                            "complete".equals(ready) || "interactive".equals(ready);

                    // We do not require every image to be loaded because lazy images may
                    // intentionally remain pending until conversion. We require the DOM
                    // counters to stop changing for three probes.
                    boolean stableEnough =
                            documentReady &&
                            stableSamples >= 3 &&
                            nodes > 0;

                    boolean timedOut = elapsed >= 30000L;

                    if (stableEnough || timedOut) {
                        pageStabilityRunning = false;

                        if (finalAnalysisRunning) {
                            return;
                        }

                        finalAnalysisRunning = true;

                        nativeProgress(
                                "Analyse du chapitre",
                                timedOut ? 70 : Math.max(55, loadPercent),
                                timedOut
                                        ? "Délai maximal atteint : analyse avec le DOM disponible."
                                        : "DOM stable. Analyse finale sans scroll."
                        );

                        handler.postDelayed(() -> {
                            if (chainRunning &&
                                    !conversionActive &&
                                    !waitingHuman &&
                                    token == pageLoadToken) {
                                inspectChapterWithoutScroll();
                            }
                        }, 250);

                    } else {
                        scheduleStabilityProbe(token, 1100);
                    }

                } catch (Exception e) {
                    if (elapsed >= 30000L) {
                        pageStabilityRunning = false;
                        if (!finalAnalysisRunning) {
                            finalAnalysisRunning = true;
                            inspectChapterWithoutScroll();
                        }
                    } else {
                        nativeProgress(
                                "Chargement sécurisé",
                                15,
                                "Le DOM n’est pas encore lisible. Nouvelle vérification…"
                        );
                        scheduleStabilityProbe(token, 1200);
                    }
                }
            });

        } catch (Throwable t) {
            pageStabilityRunning = false;
            finalAnalysisRunning = false;
            nativeFinished("Erreur WebView pendant la vérification : " + t.getMessage());
        }
    }

    private static String decodeJavascriptString(String rawValue) throws Exception {
        if (rawValue == null || "null".equals(rawValue)) {
            return "{}";
        }

        // evaluateJavascript returns a JSON-encoded JavaScript string.
        JSONArray wrapper = new JSONArray("[" + rawValue + "]");
        return wrapper.optString(0, "{}");
    }

    private void inspectChapterWithoutScroll() {
        if (!chainRunning || conversionActive || waitingHuman) {
            finalAnalysisRunning = false;
            return;
        }

        pageStabilityRunning = false;

        String js = """
            (function(){
              function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}

              function captcha(){
                const t=(document.body?.innerText||'').toLowerCase();
                return /captcha|verify you are human|checking your browser|just a moment|vérif(ier|ication).*(humain|robot)/i.test(t)
                  || !!document.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],[class*="captcha"],[id*="captcha"],[class*="turnstile"]');
              }

              function imgs(){
                const out=[],seen=new Set();

                document.querySelectorAll('img').forEach(img=>{
                  const cand=[
                    img.getAttribute('src'),
                    img.currentSrc,
                    img.getAttribute('data-src'),
                    img.getAttribute('data-lazy-src'),
                    img.getAttribute('data-original'),
                    img.getAttribute('data-url'),
                    img.getAttribute('data-cfsrc'),
                    img.getAttribute('data-lazy')
                  ].filter(Boolean);

                  if(img.srcset){
                    img.srcset.split(',').forEach(x=>{
                      const u=(x.trim().split(/\\s+/)[0]||'');
                      if(u)cand.push(u);
                    });
                  }

                  let u='';
                  for(const c of cand){
                    const a=abs(c);
                    if(a&&!a.startsWith('data:')){u=a;break}
                  }
                  if(!u||seen.has(u))return;

                  const w=img.naturalWidth||parseInt(img.getAttribute('width')||'0')||img.width||0;
                  const h=img.naturalHeight||parseInt(img.getAttribute('height')||'0')||img.height||0;
                  const meta=((img.alt||'')+' '+(img.className||'')+' '+(img.id||'')+' '+u).toLowerCase();

                  let score=0;
                  if(h>=500)score+=3;
                  if(w>=300)score+=2;
                  if(h>0&&w>0&&h/w>0.7)score+=2;
                  if(/page|chapter|scan|reader|manga|manhwa|webtoon|wp-manga-chapter-img|reading-content/.test(meta))score+=5;
                  if(/logo|avatar|icon|emoji|banner|discord|flag|ads?|pub|button|social/.test(meta))score-=6;

                  if(score>=1||/chapter|reader|manga|manhwa|webtoon/.test(meta)){
                    seen.add(u);
                    out.push(u);
                  }
                });

                if(out.length<2){
                  document.querySelectorAll('img').forEach(img=>{
                    const raw=img.getAttribute('data-src')
                      || img.getAttribute('data-lazy-src')
                      || img.getAttribute('data-original')
                      || img.getAttribute('src')
                      || img.currentSrc
                      || '';
                    const u=abs(raw);
                    if(u&&!u.startsWith('data:')&&!seen.has(u)){
                      seen.add(u);
                      out.push(u);
                    }
                  });
                }

                return out;
              }

              function nextUrl(){
                const links=[...document.querySelectorAll('a[href]')].map(a=>{
                  const text=((a.innerText||'')+' '+(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'')+' '+(a.rel||'')+' '+(a.className||'')).toLowerCase();
                  const href=abs(a.getAttribute('href'));
                  let score=0;
                  if(/\\b(chapitre suivant|next chapter|chapter next|suivant|next)\\b/.test(text))score+=14;
                  if(/\\b(précédent|precedent|previous|prev)\\b/.test(text))score-=30;
                  if(/\\bnext\\b/.test((a.rel||'').toLowerCase()))score+=18;
                  if(/chapter|chapitre|episode|\\/ch[\\/_-]?\\d/i.test(href))score+=4;
                  return {href:href,score:score};
                }).filter(x=>x.href&&x.href!==location.href&&x.score>0);

                links.sort((a,b)=>b.score-a.score);
                return links[0]?.href||'';
              }

              function chapterNo(){
                const src=((document.querySelector('h1')?.innerText||'')+' '+document.title+' '+location.pathname);
                const m=src.match(/(?:chapter|chapitre|chap|ch|episode|ep)[\\s\\/_#.-]*(\\d+(?:[.,]\\d+)?)/i)
                  || location.pathname.match(/\\/chapter\\/(\\d+(?:[.,]\\d+)?)/i);
                return m?m[1].replace(',','.'):'';
              }

              function seriesName(){
                const parts=location.pathname.split('/').filter(Boolean);
                const ci=parts.findIndex(x=>/^chapter$/i.test(x));
                let name=ci>0?parts[ci-1]:'';

                if(!name){
                  const crumb=[...document.querySelectorAll('a')].find(a=>/\\/serie\\//i.test(a.getAttribute('href')||''));
                  if(crumb)name=(crumb.textContent||'').trim();
                }

                if(!name){
                  name=(document.title||'Serie').replace(/chapter|chapitre\\s*\\d+.*/i,'').trim();
                }

                return name.replace(/[-_]+/g,' ').replace(/\\s+/g,' ').trim()||'Serie';
              }

              function endState(){
                const t=(document.body?.innerText||'').toLowerCase();
                if(/coming soon|to be continued|à suivre|a suivre|suite.*bient[oô]t|prochain chapitre.*bient[oô]t/i.test(t))return 'waiting';
                if(/fin de (la )?(série|serie|manga|manhwa|webtoon)|the end|completed|terminé|termine/i.test(t))return 'finished';
                return 'unknown';
              }

              ChapterBridge.onPageData(JSON.stringify({
                url:location.href,
                series:seriesName(),
                chapter:chapterNo(),
                captcha:captcha(),
                images:imgs(),
                next:nextUrl(),
                end:endState()
              }));
            })();
        """;

        chapter.evaluateJavascript(js, null);
    }

    private class ChapterBridge {
        @JavascriptInterface
        public void onPageData(String raw) {
            runOnUiThread(() -> {
                try {
                    JSONObject j = new JSONObject(raw);
                    PageData d = new PageData();
                    d.url = j.optString("url", "");
                    d.series = j.optString("series", "Serie");
                    d.chapter = j.optString("chapter", "");
                    d.captcha = j.optBoolean("captcha", false);
                    d.images = j.optJSONArray("images");
                    if (d.images == null) d.images = new JSONArray();
                    d.next = j.optString("next", "");
                    d.end = j.optString("end", "unknown");

                    finalAnalysisRunning = false;
                    handleChapterData(d);
                } catch (Exception e) {
                    finalAnalysisRunning = false;
                    chainRunning = false;
                    nativeProgress("Erreur analyse", 0, e.getMessage());
                }
            });
        }
    }

    private void handleChapterData(PageData data) {
        if (!chainRunning) {
            return;
        }

        currentPage = data;

        if (data.captcha) {
            finalAnalysisRunning = false;
            pageStabilityRunning = false;
            waitingHuman = true;
            chapter.setVisibility(View.VISIBLE);
            resumeButton.setVisibility(View.VISIBLE);
            nativeAccess(
                    "captcha",
                    "CAPTCHA détecté. Fais la vérification directement dans la page, puis touche REPRENDRE."
            );
            return;
        }

        waitingHuman = false;
        resumeButton.setVisibility(View.GONE);
        chapter.setVisibility(View.GONE);

        currentPdfName = makePdfName(data);

        if (chainSkip && pdfExists(currentPdfName.series, currentPdfName.fileName)) {
            nativeProgress("Reprise intelligente", 100, "Déjà terminé : " + currentPdfName.fileName);
            continueChain(data);
            return;
        }

        if (data.images.length() == 0) {
            chainRunning = false;
            nativeFinished("Aucune image de chapitre détectée dans le HTML.");
            return;
        }

        nativeProgress("Analyse HTML", 12, data.images.length() + " image(s) détectée(s)");
        startConverter(data);
    }

    private void startConverter(PageData data) {
        pageStabilityRunning = false;
        finalAnalysisRunning = false;
        conversionActive = true;
        closeTransferQuietly();

        JSONObject config = new JSONObject();
        try {
            config.put("images", data.images);
            config.put("baseUrl", data.url);
        } catch (Exception e) {
            conversionActive = false;
            chainRunning = false;
            nativeFinished("Erreur préparation : " + e.getMessage());
            return;
        }

        converter.loadDataWithBaseURL(
                data.url,
                buildConverterHtml(config.toString()),
                "text/html",
                "UTF-8",
                null
        );
    }

    private String buildConverterHtml(String configJson) {
        String cfg = configJson.replace("</script>", "<\\/script>");

        return """
            <!doctype html><html><head><meta charset="utf-8"></head><body><script>
            const CFG=%s;

            function report(stage,pct,detail){
              AndroidPdf.progress(stage,Math.max(0,Math.min(100,Math.round(pct))),detail||'');
            }

            function imageFromUrl(src){
              return new Promise((resolve,reject)=>{
                const im=new Image();
                let done=false;

                const timer=setTimeout(()=>{
                  if(done)return;
                  done=true;
                  im.src='';
                  reject(new Error('Délai dépassé'));
                },35000);

                im.onload=()=>{
                  if(done)return;
                  done=true;
                  clearTimeout(timer);
                  resolve(im);
                };

                im.onerror=()=>{
                  if(done)return;
                  done=true;
                  clearTimeout(timer);
                  reject(new Error('Image inaccessible'));
                };

                im.src=src;
              });
            }

            function canvasToJpeg(canvas){
              const data=canvas.toDataURL('image/jpeg',0.95);
              const bin=atob(data.split(',')[1]);
              const bytes=new Uint8Array(bin.length);
              for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
              return {bytes:bytes,width:canvas.width,height:canvas.height};
            }

            function averageImageWidth(images){
              const ws=images.map(x=>x.naturalWidth||x.width||0).filter(x=>x>0);
              if(!ws.length)return null;
              return Math.max(1,Math.min(4096,Math.round(ws.reduce((a,b)=>a+b,0)/ws.length)));
            }

            function imageToSegments(im,targetWidth){
              const sw=im.naturalWidth||im.width;
              const sh=im.naturalHeight||im.height;
              const ow=Math.max(1,Math.round(targetWidth||sw));
              const scale=ow/sw;
              const maxSliceH=Math.max(1,Math.round(sw*16/9));
              const out=[];

              for(let y=0;y<sh;y+=maxSliceH){
                const slice=Math.min(maxSliceH,sh-y);
                const oh=Math.max(1,Math.round(slice*scale));
                const c=document.createElement('canvas');
                c.width=ow;c.height=oh;
                const ctx=c.getContext('2d');
                ctx.fillStyle='#fff';
                ctx.fillRect(0,0,ow,oh);
                ctx.drawImage(im,0,y,sw,slice,0,0,ow,oh);
                out.push(canvasToJpeg(c));
              }

              return out;
            }

            function ascii(s){return new TextEncoder().encode(s)}

            function concat(arrs){
              let n=arrs.reduce((s,a)=>s+a.length,0);
              const o=new Uint8Array(n);
              let p=0;
              for(const a of arrs){o.set(a,p);p+=a.length}
              return o;
            }

            function buildPdf(images){
              const PX=72/96;
              const objs=[];
              const refs=[];

              for(let i=0;i<images.length;i++)refs.push(`${3+i*3} 0 R`);

              objs[1]=ascii(`<< /Type /Catalog /Pages 2 0 R /PageLayout /OneColumn /OpenAction [${images.length?'3 0 R':'2 0 R'} /FitH 0] >>`);
              objs[2]=ascii(`<< /Type /Pages /Kids [${refs.join(' ')}] /Count ${images.length} >>`);

              for(let i=0;i<images.length;i++){
                const im=images[i];
                const page=3+i*3,content=page+1,image=page+2;
                let pw=Math.max(1,im.width*PX),ph=Math.max(1,im.height*PX);
                const MAX=14400;

                if(pw>MAX||ph>MAX){
                  const s=Math.min(MAX/pw,MAX/ph);
                  pw*=s;ph*=s;
                }

                const w=pw.toFixed(2),h=ph.toFixed(2);
                const stream=`q\\n${w} 0 0 ${h} 0 0 cm\\n/Im0 Do\\nQ\\n`;

                objs[page]=ascii(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /Resources << /XObject << /Im0 ${image} 0 R >> >> /Contents ${content} 0 R >>`);
                objs[content]=concat([ascii(`<< /Length ${ascii(stream).length} >>\\nstream\\n`),ascii(stream),ascii('endstream')]);
                objs[image]=concat([ascii(`<< /Type /XObject /Subtype /Image /Width ${im.width} /Height ${im.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.bytes.length} >>\\nstream\\n`),im.bytes,ascii('\\nendstream')]);
              }

              const head=ascii('%PDF-1.4\\n%\\xE2\\xE3\\xCF\\xD3\\n');
              const parts=[head],offsets=[0];
              let pos=head.length;

              for(let i=1;i<objs.length;i++){
                offsets[i]=pos;
                const block=concat([ascii(`${i} 0 obj\\n`),objs[i],ascii('\\nendobj\\n')]);
                parts.push(block);
                pos+=block.length;
              }

              const xrefPos=pos;
              let xref=`xref\\n0 ${objs.length}\\n0000000000 65535 f \\n`;
              for(let i=1;i<objs.length;i++)xref+=String(offsets[i]).padStart(10,'0')+' 00000 n \\n';
              xref+=`trailer\\n<< /Size ${objs.length} /Root 1 0 R >>\\nstartxref\\n${xrefPos}\\n%%EOF`;
              parts.push(ascii(xref));

              return concat(parts);
            }

            function send(bytes){
              const CHUNK=192*1024;
              AndroidPdf.startPdf(bytes.length);

              for(let off=0;off<bytes.length;off+=CHUNK){
                const part=bytes.subarray(off,Math.min(bytes.length,off+CHUNK));
                let binary='';
                for(let i=0;i<part.length;i+=8192){
                  binary+=String.fromCharCode.apply(null,part.subarray(i,Math.min(part.length,i+8192)));
                }
                AndroidPdf.pdfChunk(btoa(binary));
                report('Transfert PDF',95+((off+part.length)/bytes.length)*5,`${Math.min(off+part.length,bytes.length)}/${bytes.length} octets`);
              }

              AndroidPdf.finishPdf();
            }

            (async()=>{
              try{
                const srcs=[...new Set((CFG.images||[]).filter(Boolean))];
                const loaded=[];

                for(let i=0;i<srcs.length;i++){
                  report('Chargement images',12+(i/srcs.length)*58,`Image ${i+1}/${srcs.length}`);
                  try{loaded.push(await imageFromUrl(srcs[i]))}catch(e){}
                  report('Chargement images',12+((i+1)/srcs.length)*58,`${i+1}/${srcs.length} traitée(s)`);
                }

                if(!loaded.length)throw new Error('Toutes les images ont échoué');

                const avg=averageImageWidth(loaded);
                report('Largeur moyenne',72,avg?`${avg}px`:'largeur originale');

                const pages=[];
                for(let i=0;i<loaded.length;i++){
                  pages.push(...imageToSegments(loaded[i],avg));
                  report('Découpage mobile',72+((i+1)/loaded.length)*18,`${pages.length} page(s)`);
                }

                report('Construction PDF',92,`${pages.length} page(s)`);
                const pdf=buildPdf(pages);
                report('PDF prêt',95,`${pdf.length} octets`);
                send(pdf);

              }catch(e){
                AndroidPdf.error(e&&e.message?e.message:String(e));
              }
            })();
            </script></body></html>
        """.formatted(cfg);
    }

    private class ConverterBridge {
        @JavascriptInterface
        public void progress(String stage, int pct, String detail) {
            nativeProgress(stage, pct, detail);
        }

        @JavascriptInterface
        public void startPdf(long total) {
            synchronized (MainActivity.this) {
                closeTransferQuietly();
                try {
                    transferExpected = total;
                    transferReceived = 0;
                    transferName = currentPdfName.fileName;
                    transferMime = "application/pdf";
                    transferTemp = new File(getCacheDir(), "chapter_" + System.currentTimeMillis() + ".pdf");
                    transferOut = new FileOutputStream(transferTemp);
                } catch (Exception e) {
                    conversionFailed("Création temporaire : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void pdfChunk(String b64) {
            synchronized (MainActivity.this) {
                try {
                    if (transferOut == null) throw new IllegalStateException("Transfert non initialisé");
                    byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                    transferOut.write(bytes);
                    transferReceived += bytes.length;
                } catch (Exception e) {
                    conversionFailed("Transfert PDF : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void finishPdf() {
            runOnUiThread(() -> {
                try {
                    synchronized (MainActivity.this) {
                        if (transferOut != null) {
                            transferOut.flush();
                            transferOut.close();
                            transferOut = null;
                        }
                    }

                    if (transferTemp == null || !transferTemp.exists() || transferTemp.length() < 1000) {
                        throw new IllegalStateException("PDF vide");
                    }

                    if (transferExpected > 0 && transferTemp.length() != transferExpected) {
                        throw new IllegalStateException("PDF incomplet");
                    }

                    boolean ok = saveChapterPdf(
                            transferTemp,
                            currentPdfName.series,
                            currentPdfName.fileName
                    );

                    transferTemp.delete();
                    transferTemp = null;
                    conversionActive = false;

                    if (!ok) {
                        throw new IllegalStateException("Enregistrement impossible");
                    }

                    nativeProgress(
                            "PDF enregistré",
                            100,
                            currentPdfName.fileName + "\nTéléchargements/PDF_CONVERTIS/" + currentPdfName.series + "/"
                    );

                    continueChain(currentPage);

                } catch (Exception e) {
                    conversionFailed("Finalisation : " + e.getMessage());
                } finally {
                    closeTransferQuietly();
                }
            });
        }

        @JavascriptInterface
        public void error(String message) {
            conversionFailed("Convertisseur HTML : " + message);
        }
    }

    private void conversionFailed(String message) {
        runOnUiThread(() -> {
            conversionActive = false;
            chainRunning = false;
            closeTransferQuietly();
            nativeFinished(message);
        });
    }

    private void continueChain(PageData data) {
        if (stopAfterCurrent) {
            chainRunning = false;
            nativeFinished("Arrêt demandé après ce chapitre.");
            return;
        }

        if (chainAuto && data.next != null && !data.next.isEmpty()) {
            handler.postDelayed(() -> loadChapter(data.next), 700);
            return;
        }

        chainRunning = false;

        if (data.next != null && !data.next.isEmpty() && !chainAuto) {
            nativeFinished("PDF terminé. Chapitre suivant détecté :\n" + data.next);
        } else if ("finished".equals(data.end)) {
            nativeFinished("Fin de série détectée.");
        } else if ("waiting".equals(data.end)) {
            nativeFinished("En attente de la suite.");
        } else {
            nativeFinished("Aucun chapitre suivant disponible.");
        }
    }

    private PdfName makePdfName(PageData data) {
        String series = normalizeSeries(data.series);
        String chapterNo = data.chapter == null ? "" : data.chapter.trim().replace(',', '.');

        if (chapterNo.isEmpty()) chapterNo = extractChapter(data.url);
        if (chapterNo.isEmpty()) chapterNo = String.valueOf(chapterSequence);

        String padded;
        if (chapterNo.contains(".")) {
            String[] p = chapterNo.split("\\.", 2);
            padded = leftPad(p[0], 3) + "." + p[1];
        } else {
            padded = leftPad(chapterNo, 3);
        }

        String fileName = series.replace(" ", "_") + "_Chapitre_" + padded + ".pdf";
        return new PdfName(series, chapterNo, fileName);
    }

    private boolean pdfExists(String series, String fileName) {
        if (Build.VERSION.SDK_INT >= 29) {
            String rel = "Download/PDF_CONVERTIS/" + series + "/";
            String[] proj = new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.SIZE};
            String sel = MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + "=?";

            try (android.database.Cursor c = getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    proj,
                    sel,
                    new String[]{fileName, rel},
                    null
            )) {
                return c != null && c.moveToFirst() && c.getLong(1) > 10000L;
            }
        }

        File f = legacyChapterFile(series, fileName);
        return f.exists() && f.length() > 10000L;
    }

    private boolean saveChapterPdf(File source, String series, String fileName) {
        String rel = "PDF_CONVERTIS/" + series + "/";
        return saveFile(source, fileName, "application/pdf", rel);
    }

    private boolean saveGenericToDownloads(File source, String name, String mime) {
        String rel = "PDF_CONVERTIS/WEB_APP/";
        return saveFile(source, name, mime, rel);
    }

    private boolean saveFile(File source, String name, String mime, String relativeSubdir) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/" + relativeSubdir);
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return false;

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 FileInputStream in = new FileInputStream(source)) {

                if (out == null) throw new IllegalStateException("Sortie indisponible");

                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;

            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                return false;
            }
        }

        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File output = new File(downloads, relativeSubdir + name);
        File parent = output.getParentFile();
        if (parent != null) parent.mkdirs();

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output)) {

            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private File legacyChapterFile(String series, String fileName) {
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        return new File(downloads, "PDF_CONVERTIS/" + series + "/" + fileName);
    }

    private void nativeProgress(String stage, int pct, String detail) {
        runOnUiThread(() -> {
            String js = "window.AndroidNativeProgress("
                    + JSONObject.quote(stage == null ? "" : stage) + ","
                    + Math.max(0, Math.min(100, pct)) + ","
                    + JSONObject.quote(detail == null ? "" : detail)
                    + ");";
            home.evaluateJavascript(js, null);
        });
    }

    private void nativeFinished(String message) {
        runOnUiThread(() -> {
            home.evaluateJavascript(
                    "window.AndroidNativeFinished(" + JSONObject.quote(message == null ? "" : message) + ");",
                    null
            );
        });
    }

    private void nativeAccess(String kind, String message) {
        runOnUiThread(() -> {
            home.evaluateJavascript(
                    "window.AndroidNativeAccess("
                            + JSONObject.quote(kind == null ? "" : kind) + ","
                            + JSONObject.quote(message == null ? "" : message)
                            + ");",
                    null
            );
        });
    }

    private void showHomeMessage(String message) {
        runOnUiThread(() -> {
            String safe = JSONObject.quote(message == null ? "" : message);
            home.evaluateJavascript(
                    "(function(){const s=document.querySelector('.panel.active .status');if(s)s.textContent=" + safe + ";})();",
                    null
            );
        });
    }

    private static String sanitizeDownloadName(String name) {
        String n = name == null ? "fichier.bin" : name;
        n = n.replaceAll("[\\\\/:*?\"<>|]+", "_").trim();
        return n.isEmpty() ? "fichier.bin" : n;
    }

    private static String normalizeSeries(String raw) {
        String clean = raw == null ? "" : raw
                .replaceAll("[\\\\/:*?\"<>|]+", " ")
                .replaceAll("\\s+", " ")
                .trim();

        if (clean.isEmpty()) return "Serie";

        StringBuilder b = new StringBuilder();
        for (String word : clean.split(" ")) {
            if (word.isEmpty()) continue;
            String lower = word.toLowerCase(Locale.getDefault());
            String nice = Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
            if (b.length() > 0) b.append(' ');
            b.append(nice);
        }

        return b.length() == 0 ? "Serie" : b.toString();
    }

    private static String extractChapter(String url) {
        if (url == null) return "";

        Matcher m = Pattern.compile(
                "(?:chapter|chapitre|chap|ch|episode|ep)[/_-]?(\\d+(?:[.,]\\d+)?)",
                Pattern.CASE_INSENSITIVE
        ).matcher(url);

        return m.find() ? m.group(1).replace(',', '.') : "";
    }

    private static String leftPad(String value, int width) {
        StringBuilder b = new StringBuilder();
        while (b.length() + value.length() < width) b.append('0');
        b.append(value);
        return b.toString();
    }

    private synchronized void closeTransferQuietly() {
        try {
            if (transferOut != null) transferOut.close();
        } catch (Exception ignored) {
        }

        transferOut = null;
        transferExpected = 0;
        transferReceived = 0;
    }

    @Override
    public void onBackPressed() {
        if (chapter.getVisibility() == View.VISIBLE) {
            chapter.setVisibility(View.GONE);
            resumeButton.setVisibility(View.GONE);
            return;
        }

        if (home.canGoBack()) {
            home.goBack();
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        pageLoadToken++;
        pageStabilityRunning = false;
        finalAnalysisRunning = false;
        handler.removeCallbacksAndMessages(null);
        closeTransferQuietly();
        if (home != null) home.destroy();
        if (chapter != null) chapter.destroy();
        if (converter != null) converter.destroy();
        super.onDestroy();
    }
}
