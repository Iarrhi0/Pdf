# Chapter PDF Smart Android V3.1 — Safe Loading

Cette version corrige spécifiquement le crash observé environ 1 seconde après l'ouverture d'un chapitre.

## Changement principal
`onPageFinished` ne lance plus immédiatement l'analyse complète.

Le nouveau pipeline :
1. ouverture de la page ;
2. sondage léger du DOM ;
3. suivi `document.readyState` ;
4. compteur d'images détectées / réellement chargées ;
5. suivi de la hauteur et du nombre de noeuds DOM ;
6. trois mesures stables consécutives ;
7. seulement ensuite, analyse complète du chapitre ;
8. timeout de 30 secondes : l'app continue avec le DOM disponible au lieu de rester bloquée.

Aucun scroll automatique n'est utilisé.

## Protection crash WebView
`onRenderProcessGone` est maintenant intercepté.
Si Chromium/WebView plante ou si Android tue le renderer par manque de mémoire :
- l'Activity reste ouverte ;
- la WebView du chapitre est détruite proprement ;
- une nouvelle WebView est recréée ;
- l'utilisateur voit un message au lieu d'une fermeture brutale.

## Les fonctions V3 restent présentes
Tous les modes et fonctions V22.2 + V2.3 sont conservés.

---

# Chapter PDF Smart Android V3 — All in One

Fusion de :
- `html-images-to-pdf-v22-2-access-states-fixed`
- moteur Android V2.3 sans scroll

## Les 5 modes du Web App V22.2 sont conservés
1. 1 fichier HTML / HTM / XHTML / MHT / MHTML
2. Dossier intelligent / multi-fichiers / ZIP
3. PDF déjà présents dans des pages
4. Site chapitres
5. Chapitre → Suivant

## Fonctions V22.2 conservées
- normalisation largeur moyenne
- découpage mobile 9:16
- classement intelligent
- tri naturel
- suppression doublons exacts
- dossier `DOUBLONS_A_VERIFIER`
- reprise intelligente SHA-256 dans le moteur Web
- réessai des échecs
- rapports CSV/TXT
- ZIP final
- détection HTML/MHTML mal renommés
- sous-dossiers
- téléchargement PDF existants
- états CAPTCHA / 403 / 429 / CORS-réseau

## Améliorations Android
- vrai sélecteur de fichiers Android
- pont natif pour enregistrer les Blob/PDF/ZIP dans Téléchargements
- sortie Web App : `Téléchargements/PDF_CONVERTIS/WEB_APP/`
- sortie Chapitre → Suivant : `Téléchargements/PDF_CONVERTIS/Nom Serie/`

## Chapitre → Suivant Android
Le mode web d'origine est remplacé par le moteur natif V2.3 :
- aucun scroll automatique
- analyse directe DOM + attributs lazy
- progression réelle selon le chargement
- cookies/session de la WebView
- CAPTCHA manuel visible
- reprise PDF déjà présent
- détection Suivant / Next
- anti-boucle
- fin de série / attente
- largeur moyenne
- découpage mobile
- génération PDF intégrée

## Build
ZIP compatible avec `unzip-and-build-apk.yml`.
