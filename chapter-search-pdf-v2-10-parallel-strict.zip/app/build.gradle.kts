plugins {
    id("com.android.application")
}

android {
    namespace = "com.chaptersafe.searchpdf"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.chaptersafe.searchpdf"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
