package com.chaptersafe.searchpdf;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int MAX_PARALLEL_CHAPTERS = 10;

    private final Handler main = new Handler(Looper.getMainLooper());
    private EditText searchBox;
    private WebView webView;
    private final WebView[] workers = new WebView[MAX_PARALLEL_CHAPTERS];
    private TextView status;
    private TextView downloadBoard;
    private Button batchPauseButton;
    private Button batchStopButton;

    private final ArrayDeque<ChapterJob> batchQueue = new ArrayDeque<>();
    private final Map<Integer, ChapterJob> activeJobs = new HashMap<>();
    private final Map<Integer, String> workerStates = new HashMap<>();
    private boolean batchRunning = false;
    private volatile boolean batchPaused = false;
    private volatile boolean batchStopped = false;
    private int batchDone = 0;
    private int batchFailed = 0;
    private int batchTotal = 0;
    private String lastDetectedReader = "Auto Engine";

    private final PdfDownloadManager.Control sharedControl = new PdfDownloadManager.Control() {
        @Override public boolean isPaused() { return batchPaused; }
        @Override public boolean isStopped() { return batchStopped; }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 44);
        }
        buildUi();
        configureWebView(webView, false);
        for (WebView w : workers) configureWebView(w, true);
        showHome();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 12, 16));

        TextView title = new TextView(this);
        title.setText("Chapter Search PDF • 10 moteurs simultanés");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setPadding(dp(14), dp(10), dp(14), dp(6));
        root.addView(title);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setPadding(dp(10), 0, dp(10), dp(6));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Rechercher une série ou coller un lien…");
        searchBox.setHintTextColor(Color.GRAY);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setBackgroundColor(Color.rgb(32, 34, 42));
        searchBox.setPadding(dp(12), 0, dp(12), 0);
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button go = button("Rechercher");
        go.setOnClickListener(v -> searchOrOpen(searchBox.getText().toString()));
        searchRow.addView(go, new LinearLayout.LayoutParams(dp(104), dp(46)));
        root.addView(searchRow);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), 0, dp(8), dp(5));
        Button back = button("←"); Button forward = button("→"); Button paste = button("Coller"); Button detect = button("Détecter");
        back.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        forward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });
        paste.setOnClickListener(v -> pasteAndOpen()); detect.setOnClickListener(v -> detectCurrentPage(true));
        addEqual(nav, back); addEqual(nav, forward); addEqual(nav, paste); addEqual(nav, detect);
        root.addView(nav);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(dp(8), 0, dp(8), dp(5));
        Button chapter = button("PDF chapitre"); Button series = button("Analyser série");
        chapter.setOnClickListener(v -> downloadCurrentChapter()); series.setOnClickListener(v -> detectSeriesChapters());
        addEqual(actions, chapter); addEqual(actions, series); root.addView(actions);

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        for (int i = 0; i < workers.length; i++) {
            workers[i] = new WebView(this);
            workers[i].setVisibility(View.GONE);
            root.addView(workers[i], new LinearLayout.LayoutParams(1, 1));
        }

        LinearLayout batchControls = new LinearLayout(this);
        batchControls.setOrientation(LinearLayout.HORIZONTAL); batchControls.setPadding(dp(8), dp(3), dp(8), dp(3));
        batchPauseButton = button("Pause"); batchStopButton = button("Arrêter");
        batchPauseButton.setOnClickListener(v -> toggleBatchPause()); batchStopButton.setOnClickListener(v -> stopBatch());
        addEqual(batchControls, batchPauseButton); addEqual(batchControls, batchStopButton); root.addView(batchControls);

        downloadBoard = new TextView(this);
        downloadBoard.setTextColor(Color.rgb(187, 196, 255));
        downloadBoard.setTextSize(11);
        downloadBoard.setPadding(dp(10), dp(5), dp(10), dp(5));
        downloadBoard.setMaxLines(12);
        downloadBoard.setText("Téléchargements : aucun\nSortie : Téléchargements/Chapter Search PDF/");
        root.addView(downloadBoard);

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY); status.setTextSize(12); status.setPadding(dp(12), dp(5), dp(12), dp(8)); status.setText("Prêt");
        root.addView(status);
        setContentView(root);
    }

    private void configureWebView(WebView w, boolean worker) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!worker) {
                    searchBox.setText(url); setStatus("Page chargée — " + url);
                    main.postDelayed(() -> detectCurrentPage(false), 600);
                }
            }
        });
    }

    private void showHome() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{background:#0b0c10;color:#fff;font-family:sans-serif;padding:22px}h1{color:#9c7cff}div{background:#181a22;padding:16px;border-radius:14px;margin:12px 0}.p{color:#b8b8c0}</style></head><body>" +
            "<h1>Chapter Search PDF V2</h1><div><b>Recherche externe</b><p class='p'>Cherche une série ou colle son lien.</p></div>" +
            "<div><b>Analyse stricte</b><p class='p'>L'app n'accepte plus toute image de la page : elle identifie le vrai conteneur lecteur et suit les pages du chapitre.</p></div>" +
            "<div><b>10 chapitres simultanés</b><p class='p'>Toute une série peut être traitée avec 10 workers indépendants.</p></div>" +
            "<div><b>Nommage</b><p class='p'>Série - Chapitre X.pdf dans Téléchargements/Chapter Search PDF/</p></div></body></html>";
        webView.loadDataWithBaseURL("https://chapter-search.local/", html, "text/html", "UTF-8", null);
    }

    private void searchOrOpen(String raw) {
        String q = raw == null ? "" : raw.trim(); if (q.isEmpty()) return;
        if (q.matches("(?i)^https?://.+")) webView.loadUrl(q);
        else if (q.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) webView.loadUrl("https://" + q);
        else {
            String query = URLEncoder.encode(q + " manga manhwa webtoon chapter", StandardCharsets.UTF_8);
            webView.loadUrl("https://www.google.com/search?q=" + query);
        }
    }

    private void pasteAndOpen() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return; ClipData clip = cm.getPrimaryClip(); if (clip == null || clip.getItemCount() == 0) return;
        String text = String.valueOf(clip.getItemAt(0).coerceToText(this)); searchBox.setText(text); searchOrOpen(text);
    }

    private void detectCurrentPage(boolean toast) {
        String url = webView.getUrl();
        webView.evaluateJavascript(EngineScripts.PAGE_HTML, raw -> {
            String html = decodeJsString(raw); lastDetectedReader = ReaderRegistry.detect(url == null ? "" : url, html);
            setStatus("Lecteur détecté : " + lastDetectedReader);
            if (toast) Toast.makeText(this, "Lecteur : " + lastDetectedReader, Toast.LENGTH_LONG).show();
        });
    }

    private void downloadCurrentChapter() {
        String url = webView.getUrl();
        if (url == null || url.startsWith("data:") || url.contains("chapter-search.local")) { toast("Ouvre d'abord un vrai chapitre."); return; }
        setStatus("ANALYSE • rendu complet du chapitre…");
        webView.evaluateJavascript(EngineScripts.FORCE_LAZY_LOAD, r -> main.postDelayed(() -> {
            webView.evaluateJavascript("window.scrollTo(0,0);'ok';", r2 -> {});
            main.postDelayed(() -> extractPayloadAndDownload(webView, url, null, null, -1), 1100);
        }, 1800));
    }

    private void extractPayloadAndDownload(WebView sourceView, String chapterUrl, String forcedSeries, String forcedChapter, int workerIndex) {
        sourceView.evaluateJavascript(EngineScripts.EXTRACT_CHAPTER_PAYLOAD, raw -> {
            try {
                JSONObject o = new JSONObject(decodeJsString(raw));
                if (!o.optBoolean("ok", false)) {
                    String why = o.optString("reason", "Page non reconnue comme chapitre");
                    if (workerIndex >= 0) finishWorker(workerIndex, false, why); else setStatus("REFUSÉ • " + why);
                    return;
                }
                JSONArray arr = o.optJSONArray("images"); List<String> urls = new ArrayList<>();
                if (arr != null) for (int i = 0; i < arr.length(); i++) { String u = arr.optString(i, ""); if (!u.isEmpty()) urls.add(u); }
                if (urls.size() < 2) { if (workerIndex >= 0) finishWorker(workerIndex, false, "moins de 2 pages"); else setStatus("REFUSÉ • chapitre incomplet"); return; }
                String series = cleanSeries(forcedSeries != null ? forcedSeries : o.optString("series", "Série"));
                String chapter = normalizeChapterLabel(forcedChapter != null ? forcedChapter : o.optString("chapter", "Chapitre"), o.optString("number", ""));
                String reader = o.optString("reader", "auto");
                String ua = sourceView.getSettings().getUserAgentString();
                if (workerIndex >= 0) updateWorker(workerIndex, "ANALYSE OK • " + urls.size() + " pages • " + reader);
                else setStatus("ANALYSE OK • " + series + " • " + chapter + " • " + urls.size() + " pages");

                PdfDownloadManager.Control ctl = workerIndex >= 0 ? sharedControl : new PdfDownloadManager.Control() {
                    @Override public boolean isPaused() { return false; }
                    @Override public boolean isStopped() { return false; }
                };
                PdfDownloadManager.downloadChapter(this, chapterUrl, series, chapter, urls, ua, ctl, new PdfDownloadManager.Listener() {
                    @Override public void onStatus(String text) { main.post(() -> { if (workerIndex >= 0) updateWorker(workerIndex, text); else setStatus(text); }); }
                    @Override public void onDone(String displayName, String outputLocation) { main.post(() -> {
                        if (workerIndex >= 0) finishWorker(workerIndex, true, "SAVED • " + displayName); else { setStatus("SAVED • " + outputLocation); toast("PDF enregistré : " + displayName); }
                    }); }
                    @Override public void onError(String message) { main.post(() -> { if (workerIndex >= 0) finishWorker(workerIndex, false, message); else setStatus("ERREUR • " + message); }); }
                });
            } catch (Exception e) {
                if (workerIndex >= 0) finishWorker(workerIndex, false, "Extraction : " + e.getMessage()); else setStatus("Extraction impossible : " + e.getMessage());
            }
        });
    }

    private void detectSeriesChapters() {
        setStatus("ANALYSE SÉRIE • recherche des chapitres numérotés…");
        webView.evaluateJavascript(EngineScripts.EXTRACT_CHAPTERS, raw -> {
            try {
                JSONArray arr = new JSONArray(decodeJsString(raw));
                if (arr.length() == 0) { setStatus("Aucun vrai lien de chapitre numéroté détecté."); return; }
                List<ChapterJob> jobs = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String url = o.optString("url", ""); double num = o.optDouble("number", -1);
                    if (url.isEmpty() || num < 0) continue;
                    String series = cleanSeries(o.optString("series", "Série"));
                    String label = formatChapterNumber(num);
                    jobs.add(new ChapterJob(series, label, url, num));
                }
                if (jobs.isEmpty()) { setStatus("Aucun chapitre fiable détecté."); return; }
                showChapterDialog(jobs);
            } catch (Exception e) { setStatus("Erreur détection série : " + e.getMessage()); }
        });
    }

    private void showChapterDialog(List<ChapterJob> jobs) {
        String[] labels = new String[Math.min(jobs.size(), 150) + 1];
        double first = jobs.get(0).number, last = jobs.get(jobs.size() - 1).number;
        labels[0] = "⬇ Télécharger la série • " + jobs.size() + " chapitres • " + first + " → " + last + " • 10 simultanés";
        for (int i = 1; i < labels.length; i++) labels[i] = jobs.get(i - 1).chapterLabel;
        new AlertDialog.Builder(this).setTitle(jobs.get(0).seriesTitle + " • chapitres fiables")
            .setItems(labels, (d, which) -> {
                if (which == 0) startBatch(jobs);
                else { ChapterJob j = jobs.get(which - 1); webView.loadUrl(j.url); setStatus("Chapitre ouvert : " + j.chapterLabel); }
            }).setNegativeButton("Fermer", null).show();
    }

    private synchronized ChapterJob pollJob() { return batchQueue.poll(); }

    private void startBatch(List<ChapterJob> jobs) {
        batchQueue.clear(); activeJobs.clear(); workerStates.clear();
        for (ChapterJob j : jobs) if (j.url != null && !j.url.isEmpty()) batchQueue.add(j);
        batchTotal = batchQueue.size(); batchDone = 0; batchFailed = 0; batchStopped = false; batchPaused = false; batchRunning = true;
        batchPauseButton.setText("Pause");
        setStatus("SÉRIE • " + batchTotal + " chapitres • jusqu'à 10 simultanés");
        for (int i = 0; i < workers.length; i++) scheduleWorker(i);
        renderDownloadBoard();
    }

    private void scheduleWorker(int index) {
        if (!batchRunning || batchStopped || batchPaused || activeJobs.containsKey(index)) return;
        ChapterJob job = pollJob();
        if (job == null) { checkBatchComplete(); return; }
        activeJobs.put(index, job); updateWorker(index, "LOAD • " + job.chapterLabel);
        WebView w = workers[index];
        w.setWebViewClient(new WebViewClient() {
            private boolean handled = false;
            @Override public void onPageFinished(WebView view, String url) {
                if (handled || batchStopped) return; handled = true;
                updateWorker(index, "RENDER • lecteur JavaScript");
                view.evaluateJavascript(EngineScripts.FORCE_LAZY_LOAD, r -> main.postDelayed(() -> {
                    if (batchStopped) { finishWorker(index, false, "arrêté"); return; }
                    view.evaluateJavascript("window.scrollTo(0,0);'ok';", r2 -> {});
                    main.postDelayed(() -> extractPayloadAndDownload(view, job.url, job.seriesTitle, job.chapterLabel, index), 1000);
                }, 1800));
            }
        });
        w.loadUrl(job.url);
    }

    private void finishWorker(int index, boolean success, String detail) {
        ChapterJob job = activeJobs.remove(index);
        if (job != null) { if (success) batchDone++; else batchFailed++; }
        workerStates.put(index, (success ? "✓ " : "✕ ") + detail);
        renderDownloadBoard();
        if (!batchStopped && !batchPaused) main.postDelayed(() -> scheduleWorker(index), 250);
        checkBatchComplete();
    }

    private void checkBatchComplete() {
        if (!batchRunning) return;
        if (batchQueue.isEmpty() && activeJobs.isEmpty()) {
            batchRunning = false;
            setStatus("TERMINÉ • " + batchDone + " enregistrés • " + batchFailed + " rejetés/échoués • " + batchTotal + " total");
            renderDownloadBoard();
        }
    }

    private void toggleBatchPause() {
        if (!batchRunning) { toast("Aucune série en téléchargement."); return; }
        batchPaused = !batchPaused; batchPauseButton.setText(batchPaused ? "Reprendre" : "Pause");
        setStatus(batchPaused ? "PAUSE • les 10 workers conservent leur progression" : "REPRISE • téléchargements en cours");
        if (!batchPaused) for (int i = 0; i < workers.length; i++) scheduleWorker(i);
        renderDownloadBoard();
    }

    private void stopBatch() {
        batchStopped = true; batchRunning = false; batchQueue.clear();
        for (WebView w : workers) w.stopLoading();
        setStatus("ARRÊTÉ • les PDF déjà enregistrés restent dans Téléchargements/Chapter Search PDF/"); renderDownloadBoard();
    }

    private void updateWorker(int index, String text) { workerStates.put(index, text); renderDownloadBoard(); }

    private void renderDownloadBoard() {
        StringBuilder b = new StringBuilder();
        b.append("Progression : ").append(batchDone).append(" OK • ").append(batchFailed).append(" échec • ").append(batchQueue.size()).append(" en attente\n");
        for (int i = 0; i < MAX_PARALLEL_CHAPTERS; i++) {
            ChapterJob j = activeJobs.get(i); String st = workerStates.get(i);
            if (j != null) b.append("#").append(i + 1).append(" • ").append(j.seriesTitle).append(" • ").append(j.chapterLabel).append(" • ").append(st == null ? "Analyse" : st).append("\n");
            else if (st != null && (st.startsWith("✓") || st.startsWith("✕"))) b.append("#").append(i + 1).append(" • ").append(st).append("\n");
        }
        b.append("Sortie : Téléchargements/Chapter Search PDF/");
        downloadBoard.setText(b.toString());
    }

    private String cleanSeries(String s) {
        String x = PdfDownloadManager.sanitize(s == null ? "Série" : s);
        x = x.replaceAll("(?i)\\s*[-|–—:]?\\s*(lecture en ligne|read online|scan vf|manga scan|webtoon).*?$", "").trim();
        return x.isEmpty() ? "Série" : x;
    }

    private String normalizeChapterLabel(String label, String number) {
        if (number != null && !number.trim().isEmpty()) {
            try { return formatChapterNumber(Double.parseDouble(number)); } catch (Exception ignored) { }
        }
        String l = PdfDownloadManager.sanitize(label);
        if (!l.toLowerCase(Locale.ROOT).contains("chap")) l = "Chapitre " + l;
        return l;
    }

    private String formatChapterNumber(double n) {
        if (Math.floor(n) == n) return String.format(Locale.US, "Chapitre %03d", (int) n);
        return "Chapitre " + String.format(Locale.US, "%.2f", n).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private String decodeJsString(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try { JSONArray a = new JSONArray("[" + raw + "]"); return a.getString(0); }
        catch (Exception e) { return raw.replace("\\\"", "\"").replace("\\n", "\n"); }
    }

    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(43, 40, 58)); b.setPadding(dp(4), 0, dp(4), 0); return b;
    }

    private void addEqual(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1); p.setMargins(dp(2), 0, dp(2), 0); row.addView(v, p);
    }

    private void setStatus(String text) { status.setText(text); }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); for (WebView w : workers) if (w != null) w.destroy(); super.onDestroy(); }

    private static final class ChapterJob {
        final String seriesTitle; final String chapterLabel; final String url; final double number;
        ChapterJob(String seriesTitle, String chapterLabel, String url, double number) { this.seriesTitle=seriesTitle; this.chapterLabel=chapterLabel; this.url=url; this.number=number; }
    }
}
