# Chapter Search PDF V2

- Recherche Web / liens externes
- Détection stricte du vrai lecteur de chapitre
- Analyse des chapitres numérotés de la série et tri du premier au dernier
- Jusqu’à 10 chapitres traités simultanément
- Un chapitre = un PDF
- Nommage : `Titre de la série - Chapitre 001.pdf`
- Suivi en direct des 10 workers : LOAD / RENDER / ANALYSE / DOWNLOAD / PDF / SAVED
- Dossier : `Téléchargements/Chapter Search PDF/`
- Validation binaire + décodage réel des images avant PDF
- 403/429 restent des blocages, jamais une fin de série
