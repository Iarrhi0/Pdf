# HTML Images vers PDF V9

Version mobile universelle.

Fonctions principales :
- HTML / HTM / XHTML / MHT / MHTML et détection de pages mal nommées.
- Import dossier, multi-fichiers ou ZIP.
- Conversion parallèle.
- Téléchargement de chaque PDF dès qu'il est terminé.
- Dossier PDF_CONVERTIS lorsque l'API navigateur le permet.
- Mode Adapter à tous les téléphones activé par défaut.
- Les images très longues sont découpées en segments proches du ratio 9:16, sans marges.
- Le PDF demande au lecteur un affichage ajusté à la largeur via OpenAction /FitH.
- Aucun étirement : le ratio original reste conservé.

Limite : un PDF ne peut pas imposer à 100 % le comportement d'affichage d'une application tierce. Le découpage mobile évite néanmoins les pages extrêmement longues qui deviennent minuscules dans les lecteurs utilisant Ajuster la page.
