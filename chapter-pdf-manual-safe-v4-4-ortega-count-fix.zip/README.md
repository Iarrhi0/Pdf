# Chapter PDF Manual Safe V4.4 — Ortega Count Fix

## Correctif principal
La V4.3 pouvait continuer à tester `image/18`, `image/19`, etc. après la dernière
page réelle d'un chapitre. Ortega peut répondre HTTP 403 sur ces URL inexistantes,
ce qui déclenchait à tort l'écran de vérification manuelle.

La V4.4 :
- extrait d'abord le nombre total annoncé par le lecteur, par exemple `10 / 17` ;
- si le total est 17, télécharge exactement `image/1` à `image/17` ;
- ne teste jamais `image/18` ;
- ne déclenche donc plus de faux HTTP 403 de fin de chapitre ;
- vérifie que les 17/17 sources ont réellement été récupérées ;
- refuse de produire silencieusement un PDF incomplet ;
- conserve le nom intelligent, par exemple `Set_It_Chapitre_001.pdf`.

Fallback :
si aucun total n'est détectable, la découverte séquentielle reste active,
mais un HTTP 403 après plusieurs images déjà récupérées est traité comme fin
possible du chapitre plutôt que comme CAPTCHA.

Sortie :
Téléchargements/PDF_CONVERTIS/
