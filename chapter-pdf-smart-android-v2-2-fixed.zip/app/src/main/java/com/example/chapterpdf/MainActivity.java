package com.example.chapterpdf;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private CheckBox autoNextCheck;
    private CheckBox skipExistingCheck;
    private ProgressBar progressBar;
    private TextView statusText;
    private WebView browser;
    private WebView pdfWebView;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> visited = new HashSet<>();

    private boolean running = false;
    private boolean autoMode = false;
    private boolean stopAfterCurrent = false;
    private boolean waitingCaptcha = false;
    private int sequence = 0;

    private PageData currentData;
    private PdfName pendingPdfName;

    private static class PageData {
        String url = "";
        String series = "Serie";
        String chapter = "";
        boolean captcha = false;
        JSONArray images = new JSONArray();
        String next = "";
        String end = "unknown";
    }

    private static class PdfName {
        final String series;
        final String chapter;
        final String fileName;

        PdfName(String series, String chapter, String fileName) {
            this.series = series;
            this.chapter = chapter;
            this.fileName = fileName;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStoragePermissionIfNeeded();
        buildUi();
        configureWebViews();
    }

    private void requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    1001
            );
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 14, 18, 12);

        TextView title = new TextView(this);
        title.setText("Chapitre → PDF → Suivant");
        title.setTextSize(25);
        title.setTextColor(Color.WHITE);

        urlInput = new EditText(this);
        urlInput.setHint("Colle le lien du chapitre 1");
        urlInput.setSingleLine(true);
        urlInput.setTextSize(17);

        Button oneButton = new Button(this);
        oneButton.setText("TÉLÉCHARGER CE CHAPITRE EN PDF");

        Button allButton = new Button(this);
        allButton.setText("DÉMARRER TOUTE LA SUITE");

        autoNextCheck = new CheckBox(this);
        autoNextCheck.setText("Continuer automatiquement");
        autoNextCheck.setChecked(true);

        skipExistingCheck = new CheckBox(this);
        skipExistingCheck.setText("Ignorer les PDF déjà terminés");
        skipExistingCheck.setChecked(true);

        Button stopButton = new Button(this);
        stopButton.setText("ARRÊTER APRÈS CE CHAPITRE");

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);

        statusText = new TextView(this);
        statusText.setText("Prêt.");
        statusText.setTextSize(16);
        statusText.setPadding(0, 10, 0, 10);

        browser = new WebView(this);
        pdfWebView = new WebView(this);
        pdfWebView.setVisibility(View.INVISIBLE);

        root.addView(title);
        root.addView(urlInput);
        root.addView(oneButton);
        root.addView(allButton);
        root.addView(autoNextCheck);
        root.addView(skipExistingCheck);
        root.addView(stopButton);
        root.addView(progressBar,
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 20));
        root.addView(statusText);

        LinearLayout.LayoutParams browserParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
        browserParams.weight = 1f;
        root.addView(browser, browserParams);

        root.addView(pdfWebView,
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));

        setContentView(root);

        oneButton.setOnClickListener(v -> start(false));
        allButton.setOnClickListener(v -> start(true));
        stopButton.setOnClickListener(v -> {
            stopAfterCurrent = true;
            setStatus("Arrêt demandé. Le chapitre en cours sera terminé.");
        });
    }

    private void configureWebViews() {
        configureWebView(browser);
        configureWebView(pdfWebView);

        browser.addJavascriptInterface(new BrowserBridge(), "ChapterBridge");
        pdfWebView.addJavascriptInterface(new PdfBridge(), "PdfBridge");

        browser.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (!running) {
                    return;
                }
                handler.postDelayed(MainActivity.this::inspectChapter, 700);
            }
        });
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(view, true);

        view.setWebChromeClient(new WebChromeClient());
    }

    private void start(boolean all) {
        String url = urlInput.getText().toString().trim();

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            setStatus("Colle une URL de chapitre valide.");
            return;
        }

        if (!running) {
            visited.clear();
            sequence = 0;
        }

        running = true;
        autoMode = all;
        stopAfterCurrent = false;
        waitingCaptcha = false;
        loadChapter(url);
    }

    private void loadChapter(String url) {
        if (!running) {
            return;
        }

        if (visited.contains(url)) {
            running = false;
            setStatus("Boucle détectée : chapitre déjà visité.");
            return;
        }

        visited.add(url);
        sequence++;
        progressBar.setProgress(5);
        setStatus("Chargement du chapitre…\n" + url);
        browser.loadUrl(url);
    }

    private void inspectChapter() {
        String js = """
            (async function(){
              function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
              let last=-1,stable=0;
              for(let i=0;i<70;i++){
                const h=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0);
                window.scrollBy(0,Math.max(300,window.innerHeight*0.8));
                await sleep(120);
                const y=window.scrollY+window.innerHeight;
                if(y>=h-20 || h===last)stable++;else stable=0;
                last=h;
                if(stable>=4)break;
              }
              await sleep(300);

              function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}

              function captcha(){
                const t=(document.body?.innerText||'').toLowerCase();
                return /captcha|verify you are human|checking your browser|just a moment|vérif(ier|ication).*(humain|robot)/i.test(t)
                  || !!document.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],[class*="captcha"],[id*="captcha"],[class*="turnstile"]');
              }

              function images(){
                const out=[],seen=new Set();
                document.querySelectorAll('img').forEach(img=>{
                  let u=img.getAttribute('data-src')
                    || img.getAttribute('data-lazy-src')
                    || img.getAttribute('data-original')
                    || img.getAttribute('data-url')
                    || img.getAttribute('src')
                    || '';

                  if(!u && img.srcset){
                    u=(img.srcset.split(',')[0]||'').trim().split(/\s+/)[0]||'';
                  }

                  u=abs(u);
                  if(!u || u.startsWith('data:') || seen.has(u))return;

                  const w=img.naturalWidth||img.width||0;
                  const h=img.naturalHeight||img.height||0;
                  if(w<180 || h<180)return;

                  const meta=((img.alt||'')+' '+(img.className||'')+' '+(img.id||'')+' '+u).toLowerCase();
                  let score=0;
                  if(h/Math.max(1,w)>0.7)score+=2;
                  if(h>=500)score+=3;
                  if(/page|chapter|scan|reader|manga|manhwa|webtoon/.test(meta))score+=3;
                  if(/logo|avatar|icon|banner|discord|flag|ads?|pub/.test(meta))score-=4;

                  if(score>=2){
                    seen.add(u);
                    out.push(u);
                  }
                });
                return out;
              }

              function nextUrl(){
                const links=[...document.querySelectorAll('a[href]')].map(a=>{
                  const text=((a.innerText||'')+' '+(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'')+' '+(a.rel||'')+' '+(a.className||'')).toLowerCase();
                  const href=abs(a.getAttribute('href'));
                  let score=0;
                  if(/\\b(chapitre suivant|next chapter|chapter next|suivant|next)\\b/.test(text))score+=12;
                  if(/\\b(précédent|precedent|previous|prev)\\b/.test(text))score-=25;
                  if(/\\bnext\\b/.test((a.rel||'').toLowerCase()))score+=15;
                  if(/chapter|chapitre|episode|\\/ch[\\/_-]?\\d/i.test(href))score+=4;
                  return {href:href,score:score};
                }).filter(x=>x.href && x.href!==location.href && x.score>0);

                links.sort((a,b)=>b.score-a.score);
                return links[0]?.href||'';
              }

              function chapter(){
                const src=((document.querySelector('h1')?.innerText||'')+' '+document.title+' '+location.pathname);
                const m=src.match(/(?:chapter|chapitre|chap|ch|episode|ep)[\\s\\/_#.-]*(\\d+(?:[.,]\\d+)?)/i)
                  || location.pathname.match(/\\/chapter\\/(\\d+(?:[.,]\\d+)?)/i);
                return m?m[1].replace(',','.'):'';
              }

              function series(){
                const parts=location.pathname.split('/').filter(Boolean);
                const ci=parts.findIndex(x=>/^chapter$/i.test(x));
                let name=ci>0?parts[ci-1]:'';
                if(!name){
                  const crumb=[...document.querySelectorAll('a')].find(a=>/\\/serie\\//i.test(a.getAttribute('href')||''));
                  if(crumb)name=(crumb.textContent||'').trim();
                }
                if(!name)name=(document.title||'Serie').replace(/chapter|chapitre\\s*\\d+.*/i,'').trim();
                return name.replace(/[-_]+/g,' ').replace(/\\s+/g,' ').trim()||'Serie';
              }

              function endState(){
                const t=(document.body?.innerText||'').toLowerCase();
                if(/coming soon|to be continued|à suivre|a suivre|suite.*bient[oô]t|prochain chapitre.*bient[oô]t|en attente de la suite/i.test(t))return 'waiting';
                if(/fin de (la )?(série|serie|manga|manhwa|webtoon)|the end|completed|terminé|termine/i.test(t))return 'finished';
                return 'unknown';
              }

              window.scrollTo(0,0);

              ChapterBridge.onPageData(JSON.stringify({
                url:location.href,
                series:series(),
                chapter:chapter(),
                captcha:captcha(),
                images:images(),
                next:nextUrl(),
                end:endState()
              }));
            })();
        """;

        browser.evaluateJavascript(js, null);
    }

    private class BrowserBridge {
        @JavascriptInterface
        public void onPageData(String raw) {
            runOnUiThread(() -> {
                try {
                    JSONObject j = new JSONObject(raw);
                    PageData d = new PageData();

                    d.url = j.optString("url", "");
                    d.series = j.optString("series", "Serie");
                    d.chapter = j.optString("chapter", "");
                    d.captcha = j.optBoolean("captcha", false);
                    d.images = j.optJSONArray("images");
                    if (d.images == null) {
                        d.images = new JSONArray();
                    }
                    d.next = j.optString("next", "");
                    d.end = j.optString("end", "unknown");

                    handlePage(d);
                } catch (Exception e) {
                    running = false;
                    setStatus("Erreur d’analyse : " + e.getMessage());
                }
            });
        }
    }

    private void handlePage(PageData data) {
        if (!running) {
            return;
        }

        currentData = data;

        if (data.captcha) {
            waitingCaptcha = true;
            progressBar.setProgress(10);
            setStatus("Vérification humaine nécessaire.\nFais le CAPTCHA directement dans la page. L’app reprendra automatiquement.");
            handler.postDelayed(() -> {
                if (running && waitingCaptcha) {
                    inspectChapter();
                }
            }, 1800);
            return;
        }

        waitingCaptcha = false;
        PdfName name = makePdfName(data);
        pendingPdfName = name;

        if (skipExistingCheck.isChecked() && pdfExists(name.series, name.fileName)) {
            progressBar.setProgress(100);
            setStatus("Déjà terminé : " + name.fileName + "\nPassage à la suite…");
            continueOrFinish(data);
            return;
        }

        if (data.images.length() == 0) {
            running = false;
            setStatus("Aucune image de chapitre fiable détectée.");
            return;
        }

        progressBar.setProgress(30);
        setStatus(name.series + " · chapitre " + name.chapter + "\n"
                + data.images.length() + " image(s) détectée(s).\nPréparation du PDF…");

        preparePdfDocument(data);
    }

    private void preparePdfDocument(PageData data) {
        StringBuilder tags = new StringBuilder();

        for (int i = 0; i < data.images.length(); i++) {
            String u = data.images.optString(i, "");
            if (!u.isEmpty()) {
                tags.append("<img src=\"")
                        .append(htmlAttr(u))
                        .append("\" loading=\"eager\">");
            }
        }

        String html = """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width,initial-scale=1">
              <style>
                html,body{margin:0!important;padding:0!important;background:#fff!important}
                img{display:block!important;width:100%!important;height:auto!important;margin:0!important;padding:0!important;border:0!important}
              </style>
            </head>
            <body>
              %s
              <script>
                (function(){
                  const imgs=[...document.images];
                  let done=0,sent=false;

                  function finish(){
                    if(sent || done<imgs.length)return;
                    sent=true;
                    setTimeout(()=>{
                      const ready=imgs.filter(x=>x.complete&&x.naturalWidth>0&&x.naturalHeight>0).length;
                      const height=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0);
                      PdfBridge.ready(ready,imgs.length,height);
                    },500);
                  }

                  if(!imgs.length){
                    PdfBridge.ready(0,0,0);
                    return;
                  }

                  imgs.forEach(img=>{
                    if(img.complete){
                      done++;
                      finish();
                    }else{
                      img.addEventListener('load',()=>{done++;finish()},{once:true});
                      img.addEventListener('error',()=>{done++;finish()},{once:true});
                    }
                  });

                  setTimeout(()=>{
                    if(sent)return;
                    sent=true;
                    const ready=imgs.filter(x=>x.complete&&x.naturalWidth>0).length;
                    const height=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0);
                    PdfBridge.ready(ready,imgs.length,height);
                  },25000);
                })();
              </script>
            </body>
            </html>
        """.formatted(tags.toString());

        pdfWebView.loadDataWithBaseURL(
                data.url,
                html,
                "text/html",
                "UTF-8",
                null
        );
    }

    private class PdfBridge {
        @JavascriptInterface
        public void ready(int ready, int total, int contentHeight) {
            runOnUiThread(() -> {
                if (!running) {
                    return;
                }

                if (ready <= 0 || total <= 0 || contentHeight <= 0) {
                    running = false;
                    setStatus("Les images n’ont pas pu être préparées pour le PDF.");
                    return;
                }

                progressBar.setProgress(60);
                setStatus(pendingPdfName.series + " · chapitre "
                        + pendingPdfName.chapter + "\n"
                        + ready + "/" + total + " image(s) prêtes.\nCréation du PDF…");

                renderPdf(contentHeight);
            });
        }
    }

    private void renderPdf(int contentHeight) {
        final int pageWidth = 1080;
        final int pageHeight = 1920;

        pdfWebView.measure(
                View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );

        int measuredHeight = Math.max(contentHeight, pdfWebView.getMeasuredHeight());

        if (measuredHeight <= 0) {
            running = false;
            setStatus("Hauteur du PDF invalide.");
            return;
        }

        pdfWebView.layout(0, 0, pageWidth, measuredHeight);

        PdfDocument pdf = new PdfDocument();
        File temp = new File(getCacheDir(), "chapter_" + System.currentTimeMillis() + ".pdf");

        try {
            int top = 0;
            int pageNo = 1;

            while (top < measuredHeight) {
                int slice = Math.min(pageHeight, measuredHeight - top);

                PdfDocument.PageInfo info =
                        new PdfDocument.PageInfo.Builder(pageWidth, slice, pageNo).create();

                PdfDocument.Page page = pdf.startPage(info);
                page.getCanvas().save();
                page.getCanvas().translate(0f, -top);
                pdfWebView.draw(page.getCanvas());
                page.getCanvas().restore();
                pdf.finishPage(page);

                top += slice;
                pageNo++;

                int p = 60 + Math.round(((float) top / (float) measuredHeight) * 24f);
                progressBar.setProgress(Math.min(84, p));
            }

            try (FileOutputStream fos = new FileOutputStream(temp)) {
                pdf.writeTo(fos);
            }
        } catch (Exception e) {
            running = false;
            setStatus("Erreur création PDF : " + e.getMessage());
            pdf.close();
            return;
        }

        pdf.close();

        boolean saved = savePdf(temp, pendingPdfName.series, pendingPdfName.fileName);
        temp.delete();

        if (!saved) {
            running = false;
            setStatus("PDF créé mais enregistrement impossible.");
            return;
        }

        progressBar.setProgress(100);
        setStatus("✓ PDF enregistré\n" + pendingPdfName.fileName
                + "\nDossier : Téléchargements/PDF_CONVERTIS/"
                + pendingPdfName.series + "/");

        continueOrFinish(currentData);
    }

    private PdfName makePdfName(PageData data) {
        String series = normalizeSeries(data.series);
        String chapter = data.chapter == null ? "" : data.chapter.trim().replace(',', '.');

        if (chapter.isEmpty()) {
            chapter = extractChapter(data.url);
        }
        if (chapter.isEmpty()) {
            chapter = String.valueOf(sequence);
        }

        String padded;
        if (chapter.contains(".")) {
            String[] p = chapter.split("\\.", 2);
            padded = leftPad(p[0], 3) + "." + p[1];
        } else {
            padded = leftPad(chapter, 3);
        }

        String fileName = series.replace(" ", "_") + "_Chapitre_" + padded + ".pdf";
        return new PdfName(series, chapter, fileName);
    }

    private boolean pdfExists(String series, String fileName) {
        if (Build.VERSION.SDK_INT >= 29) {
            String relative = "Download/PDF_CONVERTIS/" + series + "/";
            String[] projection = new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.SIZE};
            String selection = MediaStore.Downloads.DISPLAY_NAME + "=? AND "
                    + MediaStore.Downloads.RELATIVE_PATH + "=?";
            String[] args = new String[]{fileName, relative};

            try (android.database.Cursor c = getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    args,
                    null
            )) {
                return c != null && c.moveToFirst() && c.getLong(1) > 10000L;
            }
        }

        File f = legacyFile(series, fileName);
        return f.exists() && f.length() > 10000L;
    }

    private boolean savePdf(File source, String series, String fileName) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH,
                    "Download/PDF_CONVERTIS/" + series + "/");
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri == null) {
                return false;
            }

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 FileInputStream in = new FileInputStream(source)) {

                if (out == null) {
                    throw new IllegalStateException("Sortie indisponible");
                }

                byte[] buffer = new byte[65536];
                int len;
                while ((len = in.read(buffer)) != -1) {
                    out.write(buffer, 0, len);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;

            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                setStatus("Erreur enregistrement : " + e.getMessage());
                return false;
            }
        }

        File output = legacyFile(series, fileName);
        File parent = output.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output)) {

            byte[] buffer = new byte[65536];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
            return true;

        } catch (Exception e) {
            setStatus("Erreur enregistrement : " + e.getMessage());
            return false;
        }
    }

    private File legacyFile(String series, String fileName) {
        File downloads = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
        );
        return new File(
                downloads,
                "PDF_CONVERTIS/" + series + "/" + fileName
        );
    }

    private void continueOrFinish(PageData data) {
        if (data == null) {
            running = false;
            return;
        }

        if (stopAfterCurrent) {
            running = false;
            setStatus(statusText.getText() + "\nArrêt demandé après ce chapitre.");
            return;
        }

        boolean continueAuto = autoMode && autoNextCheck.isChecked();

        if (continueAuto && data.next != null && !data.next.isEmpty()) {
            handler.postDelayed(() -> loadChapter(data.next), 700);
            return;
        }

        running = false;

        if (data.next != null && !data.next.isEmpty() && !continueAuto) {
            setStatus(statusText.getText() + "\nChapitre suivant détecté : " + data.next);
        } else if ("finished".equals(data.end)) {
            setStatus(statusText.getText() + "\nFin de série détectée.");
        } else if ("waiting".equals(data.end)) {
            setStatus(statusText.getText() + "\nEn attente de la suite.");
        } else {
            setStatus(statusText.getText() + "\nAucun chapitre suivant disponible.");
        }
    }

    private static String normalizeSeries(String raw) {
        String clean = raw == null ? "" : raw
                .replaceAll("[\\\\/:*?\"<>|]+", " ")
                .replaceAll("\\s+", " ")
                .trim();

        if (clean.isEmpty()) {
            return "Serie";
        }

        StringBuilder b = new StringBuilder();
        for (String word : clean.split(" ")) {
            if (word.isEmpty()) {
                continue;
            }
            String lower = word.toLowerCase(Locale.getDefault());
            String nice = Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
            if (b.length() > 0) {
                b.append(' ');
            }
            b.append(nice);
        }

        return b.length() == 0 ? "Serie" : b.toString();
    }

    private static String extractChapter(String url) {
        if (url == null) {
            return "";
        }

        Matcher m = Pattern.compile(
                "(?:chapter|chapitre|chap|ch|episode|ep)[/_-]?(\\d+(?:[.,]\\d+)?)",
                Pattern.CASE_INSENSITIVE
        ).matcher(url);

        return m.find() ? m.group(1).replace(',', '.') : "";
    }

    private static String leftPad(String value, int width) {
        StringBuilder b = new StringBuilder();
        while (b.length() + value.length() < width) {
            b.append('0');
        }
        b.append(value);
        return b.toString();
    }

    private static String htmlAttr(String value) {
        return value
                .replace("&", "&amp;")
                .replace("\"", "&quot;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private void setStatus(String text) {
        statusText.setText(text);
    }
}
