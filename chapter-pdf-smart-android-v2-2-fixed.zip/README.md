# Chapter PDF Smart Android V2.2

Version reconstruite en Java pour supprimer les erreurs de compilation Kotlin.

Fonctions :
- Télécharger le chapitre courant en PDF.
- Télécharger automatiquement toute la suite.
- CAPTCHA manuel directement dans la WebView.
- Détection automatique de Suivant / Next.
- Ignorer les PDF déjà présents.
- Dossier automatique : Téléchargements/PDF_CONVERTIS/Nom Serie/
- Nom automatique : Nom_Serie_Chapitre_001.pdf
- Fin de série / attente de suite / aucun chapitre suivant.
- Génération PDF directe avec PdfDocument, sans PrintDocumentAdapter.

Compatible avec ton workflow `unzip-and-build-apk.yml`.
