# V3.0.4 No-Splitter Fix

Cause réelle : `Panel1MinSize`/`Panel2MinSize` étaient appliqués pendant la création du `SplitContainer`, avant que sa largeur finale DPI-scalée soit connue. WinForms pouvait donc lever l'exception avant que le correctif `Shown` de la V3.0.3 s'exécute.

Correction : suppression complète du `SplitContainer` principal et remplacement par un `TableLayoutPanel` à colonnes 70 % / 30 %.
