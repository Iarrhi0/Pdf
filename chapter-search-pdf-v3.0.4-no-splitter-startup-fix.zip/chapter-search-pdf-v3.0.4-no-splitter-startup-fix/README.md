# Chapter Search PDF V3.0.4 — No Splitter Startup Fix

Cette version conserve les fonctions de la V3.0.3 mais supprime complètement le `SplitContainer` de la fenêtre principale.

## Correctif démarrage

L'exception `Le SplitterDistance doit se situer entre Panel1MinSize et Width - Panel2MinSize` pouvait être déclenchée avant même l'événement `Shown`, au moment où WinForms appliquait `Panel1MinSize` et `Panel2MinSize` sur une largeur provisoire liée au DPI.

V3.0.4 utilise un `TableLayoutPanel` 70/30 : aucune propriété `SplitterDistance`, `Panel1MinSize` ou `Panel2MinSize` n'est utilisée.

## Fonctions conservées

- WebView2 natif Windows
- moteur APK40 / Engine 5
- PHONE x10
- 10 téléchargements simultanés
- recherche multi-site
- file multi-séries
- Pause / Reprendre / Relancer / Arrêter / Supprimer
- suivi CPU/RAM
- journal de démarrage

En-tête attendu : `PC v3.0.4 • WEBVIEW2 NO-SPLITTER • PHONE x10`.
