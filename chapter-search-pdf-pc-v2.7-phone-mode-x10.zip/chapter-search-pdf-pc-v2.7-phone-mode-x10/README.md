# Chapter Search PDF PC v2.7 — PHONE MODE x10

Version orientée vers le comportement de l’application Android 4.0.

## Ce qui change

- 10 chapitres actifs simultanément.
- 1 téléchargement d’image à la fois par chapitre, donc 10 flux réseau au maximum, comme le téléphone.
- 3 renderers Chromium de préparation seulement afin de remplir rapidement les 10 téléchargements sans ouvrir 10 navigateurs lourds.
- User-Agent Android pour le moteur caché APK40.
- téléchargement image simplifié : URL exacte + Referer + cookies + User-Agent, sans cascade de variantes lentes.
- PDF toujours streamé sur disque afin de limiter la RAM.
- détection de série stricte : sur les structures /manga/<serie>/..., /porncomic/<serie>/..., /comic/<serie>/..., etc., seuls les liens de la même famille URL sont acceptés.
- validation HTTP/HTTPS avant ajout à la file.
- clic sur une tâche : Pause/Reprendre, Relancer, Arrêter, Supprimer.
- panneau CPU/RAM/DOWN/RENDER en temps réel.

## Objectif

Éviter les faux chapitres d’autres séries et retrouver le modèle de l’application Android : beaucoup de chapitres en parallèle, mais un flux réseau simple et stable dans chaque chapitre.
