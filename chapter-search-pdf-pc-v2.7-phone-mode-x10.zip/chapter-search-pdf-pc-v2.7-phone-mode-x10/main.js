const { app, BrowserWindow, ipcMain, shell, session, nativeImage } = require('electron');
const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { PDFDocument } = require('pdf-lib');
const sharp = require('sharp');
const { FORCE_LAZY_LOAD, EXTRACT_CHAPTER_PAYLOAD, EXTRACT_CHAPTERS, FIND_SERIES_PAGE, EXTRACT_MULTI_ENGINE } = require('./assets/engine-scripts');
const { LEGACY_RENDER_PREP, LEGACY_EXTRACT_CANDIDATES } = require('./assets/legacy-engine5');
const { JAVA5_EXTRACT } = require('./assets/java-engine5');
const { APK_FORCE_LAZY_LOAD, APK_EXTRACT_CHAPTER_PAYLOAD } = require('./assets/apk-download-engine');

const SEARCH_CONCURRENCY = 8;
const CHAPTER_CONCURRENCY = 10; // mode téléphone : jusqu'à 10 chapitres réellement actifs
const EXTRACT_CONCURRENCY = 1;
const DEEP_EXTRACT_CONCURRENCY = 1;
const PDF_CONCURRENCY = 2;
const PAGE_CONCURRENCY_PER_CHAPTER = 1; // comme le téléphone : 1 page à la fois par chapitre
const GLOBAL_IMAGE_CONCURRENCY = 10; // 10 chapitres x 1 page chacun
const MAX_ACTIVE_PER_SERIES = 10;
const MAX_ACTIVE_PER_HOST = 10;
// Les 10 tâches restent disponibles, mais seules les phases lourdes sont limitées.
const APK40_RENDER_CONCURRENCY = 3; // 3 renderers seulement pour remplir rapidement les 10 downloads
const APK40_PIPELINE_CONCURRENCY = 10;
const PHONE_UA = 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36';
const EXTRACT_TIMEOUT_MS = 18000;
const IMAGE_TIMEOUT_MS = 12000;
const QUEUE_UI_INTERVAL_MS = 1200;
const LEGACY5_RENDER_TIMEOUT_MS = 26000;
const LEGACY5_VALIDATE_CONCURRENCY = 8;
const LEGACY5_SESSION_TTL_MS = 20 * 60 * 1000;
const LEGACY5_SESSION_MAX = 6000;

let mainWindow;
let apk40WorkerWindows=[];
let persistTimer=null;

// Electron normally creates several renderer processes. The app needs only the UI,
// the visible webview and one hidden APK40 renderer. Capping the pool reduces RAM.
app.commandLine.appendSwitch('renderer-process-limit','7');

class Semaphore {
  constructor(limit){ this.limit=limit; this.active=0; this.waiters=[]; }
  async acquire(){
    if(this.active < this.limit){ this.active++; return; }
    await new Promise(r=>this.waiters.push(r)); this.active++;
  }
  release(){ this.active=Math.max(0,this.active-1); const r=this.waiters.shift(); if(r)r(); }
  async use(fn){ await this.acquire(); try{return await fn();} finally{this.release();} }
}
sharp.concurrency(1);
sharp.cache({memory:8,files:4,items:12});
const extractSem = new Semaphore(EXTRACT_CONCURRENCY);
const deepExtractSem = new Semaphore(DEEP_EXTRACT_CONCURRENCY);
const pdfSem = new Semaphore(PDF_CONCURRENCY);
const imageSem = new Semaphore(GLOBAL_IMAGE_CONCURRENCY);
const convertSem = new Semaphore(1); // conversions lourdes sérialisées, réseau reste parallèle
const legacy5RenderSem = new Semaphore(2);
const legacy5RecoverySem = new Semaphore(1);
const legacy5ValidateSem = new Semaphore(LEGACY5_VALIDATE_CONCURRENCY);
const apk40RenderSem = new Semaphore(APK40_RENDER_CONCURRENCY);
const apk40PipelineSem = new Semaphore(APK40_PIPELINE_CONCURRENCY);

// v2.6: réutilise les connexions TCP/TLS au lieu de recréer une connexion par image.
// Le gain est surtout réseau ; cela ajoute très peu de CPU.
const httpKeepAliveAgent = new http.Agent({keepAlive:true,maxSockets:GLOBAL_IMAGE_CONCURRENCY,maxFreeSockets:8,keepAliveMsecs:15000});
const httpsKeepAliveAgent = new https.Agent({keepAlive:true,maxSockets:GLOBAL_IMAGE_CONCURRENCY,maxFreeSockets:8,keepAliveMsecs:15000});
const cookieHeaderCache = new Map();

const legacy5Sessions = new Map();

const queue = {
  jobs: [], running:false, paused:false, stopped:false,
  nextId:1, seriesCursor:0,
  activeBySeries:new Map(), activeByHost:new Map(), workers:new Map()
};

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function sanitize(s){
  let x=String(s||'Chapitre').replace(/[\\/:*?"<>|]/g,' ').replace(/\s+/g,' ').trim();
  if(x.length>140)x=x.slice(0,140).trim(); return x||'Chapitre';
}
function buildPdfName(series, chapter){
  const s=sanitize(series||'Série'), c=sanitize(chapter||'Chapitre');
  return c.toLowerCase().startsWith(s.toLowerCase())?`${c}.pdf`:`${sanitize(`${s} - ${c}`)}.pdf`;
}
function downloadRoot(){ return path.join(app.getPath('downloads'),'Chapter Search PDF'); }
function seriesDir(series){ return path.join(downloadRoot(),sanitize(series||'Série')); }
function ensureDir(dir=downloadRoot()){ fs.mkdirSync(dir,{recursive:true}); }
function userSourcesPath(){ return path.join(app.getPath('userData'),'sources.json'); }
function defaultSourcesPath(){ return path.join(__dirname,'assets','sources.json'); }
function queuePath(){ return path.join(app.getPath('userData'),'download-queue.json'); }
function loadSources(){ const p=userSourcesPath(); if(!fs.existsSync(p))fs.copyFileSync(defaultSourcesPath(),p); try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return JSON.parse(fs.readFileSync(defaultSourcesPath(),'utf8'));} }
function saveSources(s){ fs.writeFileSync(userSourcesPath(),JSON.stringify(s,null,2),'utf8'); return s; }
function decodeHtml(s=''){ return s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>'); }
function unwrapDdg(href){ try{const u=new URL(decodeHtml(href),'https://html.duckduckgo.com'); if(u.searchParams.has('uddg'))return decodeURIComponent(u.searchParams.get('uddg')); return u.href;}catch{return decodeHtml(href);} }
function hostOf(url){try{return new URL(url).hostname.replace(/^www\./,'');}catch{return 'unknown';}}
function seriesKey(job){ return sanitize(job.series||'Série').toLowerCase(); }

function numberFromJob(job){
  const direct=Number(job?.number);
  if(Number.isFinite(direct))return direct;
  const s=`${job?.title||''} ${job?.url||''}`;
  const m=s.match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);
  return m?Number(m[1]):null;
}
function queueIdentity(job){
  const n=numberFromJob(job);
  if(Number.isFinite(n))return `num:${seriesKey(job)}:${n}`;
  return `url:${normalizeQueueUrl(job?.url||'')}`;
}
function dedupeRestoredQueue(){
  const rank={SAVED:6,RUNNING:5,WAIT_PDF:5,QUEUED:4,ERROR:3,STOPPED:2};
  const map=new Map();
  for(const j of queue.jobs){
    const key=queueIdentity(j),prev=map.get(key);
    if(!prev||(rank[j.state]||0)>(rank[prev.state]||0))map.set(key,j);
  }
  queue.jobs=[...map.values()].sort((a,b)=>(a.addedAt||0)-(b.addedAt||0));
}

function persistQueue(){
  try{
    const data={nextId:queue.nextId,jobs:queue.jobs.map(j=>{const interrupted=j.state==='RUNNING'||j.state==='WAIT_PDF';return{...j,state:interrupted?'QUEUED':j.state,phase:interrupted?'QUEUED':(j.phase||j.state),error:interrupted?'Interrompu par fermeture':j.error};})};
    fs.writeFileSync(queuePath(),JSON.stringify(data,null,2),'utf8');
  }catch{}
}
function restoreQueue(){
  try{
    const raw=JSON.parse(fs.readFileSync(queuePath(),'utf8'));
    queue.nextId=Math.max(1,Number(raw.nextId)||1);
    queue.jobs=Array.isArray(raw.jobs)?raw.jobs.map(j=>{const interrupted=j.state==='RUNNING'||j.state==='WAIT_PDF';return{...j,state:interrupted?'QUEUED':j.state,phase:interrupted?'QUEUED':(j.phase||j.state)};}):[];dedupeRestoredQueue();
  }catch{ queue.jobs=[]; }
}
function queueSnapshot(){
  const counts={QUEUED:0,RUNNING:0,WAIT_PDF:0,SAVED:0,ERROR:0,STOPPED:0};
  const groups={};
  for(const j of queue.jobs){
    counts[j.state]=(counts[j.state]||0)+1;
    const key=seriesKey(j); if(!groups[key])groups[key]={series:j.series||'Série',total:0,queued:0,running:0,saved:0,error:0,stopped:0};
    const g=groups[key]; g.total++;
    if(j.state==='QUEUED')g.queued++; else if(j.state==='RUNNING'||j.state==='WAIT_PDF')g.running++; else if(j.state==='SAVED')g.saved++; else if(j.state==='ERROR')g.error++; else if(j.state==='STOPPED')g.stopped++;
  }
  return {running:queue.running,paused:queue.paused,stopped:queue.stopped,workerCount:(counts.RUNNING||0)+(counts.WAIT_PDF||0),poolCount:queue.workers.size,total:queue.jobs.length,counts,series:Object.values(groups),jobs:queue.jobs.map(j=>({id:j.id,url:j.url,title:j.title,series:j.series,number:j.number,state:j.state,phase:j.phase,error:j.error,target:j.target,slot:j.slot,pages:j.pages,page:j.page,engine:j.engine,engineStats:j.engineStats,paused:!!j.paused,stopRequested:!!j.stopRequested}))};
}
let queueEmitTimer=null,lastQueueEmit=0;
function schedulePersist(){clearTimeout(persistTimer);persistTimer=setTimeout(()=>{persistTimer=null;persistQueue();},700);}
function emitQueue(force=false){
  schedulePersist();
  const send=()=>{queueEmitTimer=null;lastQueueEmit=Date.now();if(mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('queue:update',queueSnapshot());};
  const wait=Math.max(0,QUEUE_UI_INTERVAL_MS-(Date.now()-lastQueueEmit));
  if(force||wait===0){if(queueEmitTimer){clearTimeout(queueEmitTimer);queueEmitTimer=null;}send();return;}
  if(!queueEmitTimer)queueEmitTimer=setTimeout(send,wait);
}

const SEARCH_TIMEOUT_MS = 6500;
const SEARCH_RESULTS_PER_SOURCE = 5;

function searchNorm(v=''){
  return decodeHtml(String(v||''))
    .replace(/<[^>]+>/g,' ')
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
}
function slugifySearch(v=''){
  return searchNorm(v).replace(/\s+/g,'-').replace(/-+/g,'-');
}
function canonicalSearchUrl(v){
  try{const u=new URL(v);u.hash='';['utm_source','utm_medium','utm_campaign','ref'].forEach(k=>u.searchParams.delete(k));if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/+$/,'/');return u.href;}catch{return String(v||'');}
}
function sourceHostMatches(source,url){
  try{const h=new URL(url).hostname.replace(/^www\./,'');const d=String(source.domain||'').replace(/^www\./,'');return h===d||h.endsWith('.'+d)||d.endsWith('.'+h);}catch{return false;}
}
function scoreSearchCandidate(query,title,url){
  const q=searchNorm(query),t=searchNorm(title),u=searchNorm(url),tokens=q.split(' ').filter(x=>x.length>1);
  if(!q||!tokens.length)return 0;
  let score=0,hit=0;
  for(const tok of tokens){if(t.includes(tok)){score+=18;hit++;}else if(u.includes(tok)){score+=9;hit++;}}
  if(t===q)score+=95;
  else if(t.startsWith(q))score+=72;
  else if(t.includes(q))score+=58;
  if(hit===tokens.length)score+=35;
  else if(hit<Math.ceil(tokens.length*.6))return 0;
  if(/\/(catalogue|manga|series|serie|title|comic|webtoon|book)\//i.test(url))score+=16;
  if(/(?:chapter|chapitre|tome|volume|vol-|episode|ep-)\D*\d/i.test(url+' '+title) && !/\d/.test(q))score-=24;
  if(/(?:tag|genre|author|login|register|privacy|contact|page\/\d+)/i.test(url))score-=18;
  return score;
}
function mergeSearchResults(target,incoming){
  const map=new Map(target.map(x=>[canonicalSearchUrl(x.url),x]));
  for(const x of incoming||[]){if(!x?.url)continue;const key=canonicalSearchUrl(x.url),prev=map.get(key);if(!prev||Number(x.score||0)>Number(prev.score||0))map.set(key,{...prev,...x,url:key});}
  return [...map.values()].sort((a,b)=>(b.score||0)-(a.score||0)).slice(0,SEARCH_RESULTS_PER_SOURCE);
}
function candidatesFromHtml(html,baseUrl,source,query,method){
  const out=[],rx=/<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;let m,n=0;
  while((m=rx.exec(html))&&n<7000){n++;let url;try{url=new URL(decodeHtml(m[1]),baseUrl).href;}catch{continue;}if(!sourceHostMatches(source,url))continue;
    const title=decodeHtml(m[2].replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
    const score=scoreSearchCandidate(query,title,url);if(score>=38)out.push({title:title||query,url,score,method});
  }
  return mergeSearchResults([],out);
}
async function fetchSearchText(url,timeoutMs=SEARCH_TIMEOUT_MS){
  const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    const res=await session.defaultSession.fetch(url,{signal:ctrl.signal,headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8','Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8','Cache-Control':'no-cache'}});
    if(!res.ok){const e=new Error(`HTTP ${res.status}`);e.statusCode=res.status;throw e;}return await res.text();
  }finally{clearTimeout(timer);}
}
async function searchMangaDex(source,query){
  if(source.domain!=='mangadex.org')return [];
  try{
    const url=`https://api.mangadex.org/manga?title=${encodeURIComponent(query)}&limit=${SEARCH_RESULTS_PER_SOURCE}`;
    const raw=await fetchSearchText(url),j=JSON.parse(raw),arr=Array.isArray(j.data)?j.data:[];
    return arr.map(x=>{const a=x.attributes||{},titles=a.title||{},title=titles.en||titles.fr||Object.values(titles)[0]||query;return{title,url:`https://mangadex.org/title/${x.id}`,score:scoreSearchCandidate(query,title,`https://mangadex.org/title/${x.id}`)+40,method:'API MangaDex'};}).filter(x=>x.score>=40).slice(0,SEARCH_RESULTS_PER_SOURCE);
  }catch{return [];}
}
async function searchComick(source,query){
  if(source.domain!=='comick.io')return [];
  try{
    const raw=await fetchSearchText(`https://api.comick.fun/v1.0/search/?q=${encodeURIComponent(query)}&limit=${SEARCH_RESULTS_PER_SOURCE}&page=1&t=false`),j=JSON.parse(raw),arr=Array.isArray(j)?j:(Array.isArray(j.results)?j.results:[]);
    return arr.map(x=>{const title=x.title||x.md_titles?.[0]?.title||x.name||query,slug=x.slug||x.hid;if(!slug)return null;const url=`https://comick.io/comic/${slug}`;return{title,url,score:scoreSearchCandidate(query,title,url)+38,method:'API Comick'};}).filter(Boolean).filter(x=>x.score>=40).slice(0,SEARCH_RESULTS_PER_SOURCE);
  }catch{return [];}
}
function customSearchUrls(source,query){
  const d=source.domain,q=encodeURIComponent(query),slug=slugifySearch(query),base=`https://${d}`;
  const special={
    'sushiscan.fr': [`${base}/catalogue/list-mode/`,`${base}/?s=${q}`],
    'mangabuddy.com': [`${base}/${slug}`,`${base}/search?q=${q}`],
    'mangapill.com': [`${base}/search?q=${q}`,`${base}/manga/${slug}`],
    'mangafire.to': [`${base}/filter?keyword=${q}`,`${base}/manga/${slug}`],
    'mangapark.net': [`${base}/search?word=${q}`,`${base}/title/${slug}`],
    'toonily.com': [`${base}/?s=${q}`,`${base}/webtoon/${slug}`],
    'webtoon.xyz': [`${base}/?s=${q}`,`${base}/read/${slug}`],
    'readallcomics.com': [`${base}/?s=${q}`],
    'readcomiconline.li': [`${base}/Search/Comic?keyword=${q}`]
  };
  if(special[d])return special[d];
  return [`${base}/?s=${q}`,`${base}/search?q=${q}`,`${base}/search?keyword=${q}`];
}
async function searchInternalSource(source,query){
  let out=[];const urls=customSearchUrls(source,query).slice(0,3);
  const settled=await Promise.allSettled(urls.map(async url=>{
    const html=await fetchSearchText(url);return candidatesFromHtml(html,url,source,query,url.includes('catalogue/list-mode')?'Catalogue':'Recherche interne');
  }));
  for(const r of settled)if(r.status==='fulfilled')out=mergeSearchResults(out,r.value);
  return out;
}
async function searchDuckDuckGoFallback(source,query){
  const q=`site:${source.domain} ${query}`,url=`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`;
  try{
    const html=await fetchSearchText(url,7000),rx=/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,out=[];let m;
    while((m=rx.exec(html))&&out.length<SEARCH_RESULTS_PER_SOURCE){const link=unwrapDdg(m[1]),title=decodeHtml(m[2].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());if(!sourceHostMatches(source,link))continue;const score=scoreSearchCandidate(query,title,link);if(score>=30)out.push({title,url:link,score,method:'Index web'});}
    return mergeSearchResults([],out);
  }catch{return [];}
}
async function searchOneSource(source,query){
  const started=Date.now();let out=[];const errors=[];
  try{
    const primary=await Promise.allSettled([searchMangaDex(source,query),searchComick(source,query),searchInternalSource(source,query)]);
    for(const r of primary){if(r.status==='fulfilled')out=mergeSearchResults(out,r.value);else errors.push(String(r.reason?.message||r.reason||''));}
    if(out.length<2)out=mergeSearchResults(out,await searchDuckDuckGoFallback(source,query));
    return{source,ok:true,results:out,elapsedMs:Date.now()-started,methods:[...new Set(out.map(x=>x.method).filter(Boolean))],errors};
  }catch(e){return{source,ok:false,error:String(e.message||e),results:out,elapsedMs:Date.now()-started,errors};}
}
async function pooled(items,concurrency,fn){ let index=0,out=new Array(items.length); async function worker(){while(true){const i=index++;if(i>=items.length)break;out[i]=await fn(items[i],i);}} await Promise.all(Array.from({length:Math.min(concurrency,items.length)},worker)); return out; }

const LAZY_SWEEP_SCRIPT = String.raw`(async function(){
  const nap=(ms)=>new Promise(r=>setTimeout(r,ms));
  const attrs=['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'];
  function hydrate(){
    document.querySelectorAll('img').forEach(function(i){
      for(const a of attrs){
        const v=i.getAttribute(a);
        if(v&&(!i.getAttribute('src')||/placeholder|loading|lazy|blank|spacer/i.test(i.getAttribute('src')||''))){i.setAttribute('src',v);break;}
      }
      i.loading='eager';
    });
  }
  let lastHeight=0,stable=0;
  for(let k=0;k<16;k++){
    hydrate();
    const h=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0,1);
    window.scrollTo(0,Math.round((h-1)*(k/15)));
    window.dispatchEvent(new Event('scroll'));
    await nap(75);
    if(Math.abs(h-lastHeight)<8)stable++;else stable=0;
    lastHeight=h;
    if(k>8&&stable>=4)break;
  }
  hydrate();window.scrollTo(0,0);await nap(80);
  return {count:document.querySelectorAll('img[src],img[data-src],img[data-lazy-src],img[data-original]').length,height:lastHeight};
})();`;

function extractionWeak(parsed){
  if(!parsed?.ok||!Array.isArray(parsed.images)||parsed.images.length<2)return true;
  const s=parsed.engineStats||{},count=parsed.images.length;
  if(/(?:tome|volume|vol\.?)/i.test(`${parsed.chapter||''} ${parsed.reader||''}`)&&count<12)return true;
  return !!parsed.lowConfidence || (count<8 && (s.E1||0)<2 && (s.strong||0)<2);
}
async function extractWindowPass(url,mode,ua,{allowImages=false,deep=false}={}){
  const win=new BrowserWindow({show:false,width:1000,height:760,webPreferences:{contextIsolation:true,nodeIntegration:false,backgroundThrottling:!allowImages,images:!!allowImages}});
  win.webContents.setAudioMuted(true);
  const timeoutMs=deep?EXTRACT_TIMEOUT_MS:Math.min(EXTRACT_TIMEOUT_MS,13000);
  let timer;
  const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`Analyse trop longue (>${Math.round(timeoutMs/1000)} s)`)),timeoutMs);});
  try{
    await Promise.race([win.loadURL(url,{userAgent:ua}),timeout]);
    await sleep(mode==='chapter'?(deep?500:220):160);
    if(mode==='chapter'){
      await win.webContents.executeJavaScript(FORCE_LAZY_LOAD,true).catch(()=>null);
      await win.webContents.executeJavaScript(LAZY_SWEEP_SCRIPT,true).catch(()=>null);
      if(deep)await sleep(350);
    }
    const script=mode==='seriesPage'?FIND_SERIES_PAGE:(mode==='series'?EXTRACT_CHAPTERS:EXTRACT_MULTI_ENGINE);
    const raw=await Promise.race([win.webContents.executeJavaScript(script,true),timeout]);
    const parsed=typeof raw==='string'?JSON.parse(raw):raw;
    if(parsed&&!Array.isArray(parsed)&&typeof parsed==='object'){parsed.__userAgent=win.webContents.getUserAgent()||ua;parsed.__deepPass=!!deep;}
    return parsed;
  }finally{
    clearTimeout(timer);
    try{win.webContents.stop();}catch{}
    if(!win.isDestroyed())win.destroy();
  }
}
async function loadAndExtract(url,mode='chapter'){
  return extractSem.use(async()=>{
    const ua=PHONE_UA;
    const first=await extractWindowPass(url,mode,ua,{allowImages:false,deep:false});
    if(mode!=='chapter'||!extractionWeak(first))return first;
    return deepExtractSem.use(async()=>{
      const second=await extractWindowPass(url,mode,ua,{allowImages:true,deep:true}).catch(()=>null);
      if(second?.ok&&Array.isArray(second.images)){
        const firstCount=Array.isArray(first?.images)?first.images.length:0;
        if(second.images.length>firstCount||!extractionWeak(second)){second.fallbackFrom=first?.engineStats||null;return second;}
      }
      return first;
    });
  });
}

function legacy5CleanupRegistry(){
  const now=Date.now();
  for(const [k,v] of legacy5Sessions){if(now-(v.savedAt||0)>LEGACY5_SESSION_TTL_MS)legacy5Sessions.delete(k);}
  if(legacy5Sessions.size>LEGACY5_SESSION_MAX){
    const entries=[...legacy5Sessions.entries()].sort((a,b)=>(a[1].savedAt||0)-(b[1].savedAt||0));
    for(let i=0;i<entries.length-LEGACY5_SESSION_MAX;i++)legacy5Sessions.delete(entries[i][0]);
  }
}
function legacy5RegisterSession(imageUrl,ctx){
  if(!imageUrl||!ctx)return;
  legacy5CleanupRegistry();
  legacy5Sessions.set(imageUrl,{referer:ctx.finalUrl||ctx.referer||'',userAgent:ctx.userAgent||'',cookies:ctx.cookies||'',savedAt:Date.now()});
}
function legacy5GetSession(imageUrl){
  const v=legacy5Sessions.get(imageUrl);if(!v)return null;
  if(Date.now()-(v.savedAt||0)>LEGACY5_SESSION_TTL_MS){legacy5Sessions.delete(imageUrl);return null;}
  return v;
}
async function legacy5CookieHeader(urls){
  const jar=new Map();
  for(const u of urls||[]){
    if(!u||!isHttpUrl(u))continue;
    try{for(const c of await session.defaultSession.cookies.get({url:u}))jar.set(c.name,c.value);}catch{}
  }
  return [...jar.entries()].map(([k,v])=>`${k}=${v}`).join('; ');
}
function legacy5ChallengeText(text=''){
  const lower=String(text||'').toLowerCase();
  return ['captcha','cf-chl-','turnstile','recaptcha','hcaptcha','verify you are human','checking your browser'].some(x=>lower.includes(x)) || (lower.includes('cloudflare')&&lower.includes('challenge'));
}
async function legacy5RenderChapter(url,{deep=false}={}){
  return legacy5RenderSem.use(async()=>{
    const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
    const win=new BrowserWindow({
      show:false,width:1180,height:860,paintWhenInitiallyHidden:true,
      webPreferences:{session:session.defaultSession,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,images:true,sandbox:true}
    });
    win.webContents.setAudioMuted(true);
    win.webContents.setUserAgent(ua);
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    let timer;
    const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`Moteur 5 rendu trop long (>${Math.round(LEGACY5_RENDER_TIMEOUT_MS/1000)} s)`)),LEGACY5_RENDER_TIMEOUT_MS);});
    try{
      await Promise.race([win.loadURL(url,{userAgent:ua}),timeout]);
      await sleep(450);
      const challenge=await win.webContents.executeJavaScript(`(function(){return (document.title+' '+(document.body?document.body.innerText.slice(0,5000):''));})()`,true).catch(()=> '');
      if(legacy5ChallengeText(challenge))throw new Error('CAPTCHA/Cloudflare verification required');
      await win.webContents.executeJavaScript(LEGACY_RENDER_PREP,true).catch(()=>null);
      if(deep){await sleep(500);await win.webContents.executeJavaScript(LEGACY_RENDER_PREP,true).catch(()=>null);}
      // V4.5 waited for JavaScript/lazy loaders after onPageFinished before capturing the DOM.
      await sleep(deep?1650:1100);
      const raw=await Promise.race([win.webContents.executeJavaScript(LEGACY_EXTRACT_CANDIDATES,true),timeout]);
      const parsed=typeof raw==='string'?JSON.parse(raw):raw;
      const finalUrl=win.webContents.getURL()||parsed?.finalUrl||url;
      const userAgent=win.webContents.getUserAgent()||ua;
      const cookies=await legacy5CookieHeader([finalUrl]);
      return {...(parsed||{}),finalUrl,userAgent,cookies,__deepPass:!!deep};
    }finally{
      clearTimeout(timer);
      try{win.webContents.stop();}catch{}
      if(!win.isDestroyed())win.destroy();
    }
  });
}
function legacy5ProbeRequest(url,headers,{range=true,redirects=0}={}){
  return new Promise((resolve,reject)=>{
    if(redirects>7)return reject(new Error('Trop de redirections'));
    let u;try{u=new URL(url);}catch{return reject(new Error('URL image invalide'));}
    if(!['http:','https:'].includes(u.protocol))return reject(new Error(`Schéma non pris en charge: ${u.protocol}`));
    const transport=u.protocol==='https:'?https:http;
    const h={...headers};if(range)h.Range='bytes=0-4095';
    let settled=false;
    const finish=(value,error)=>{if(settled)return;settled=true;if(error)reject(error);else resolve(value);};
    const req=transport.request(u,{method:'GET',headers:h,timeout:Math.min(IMAGE_TIMEOUT_MS,9000),rejectUnauthorized:true},res=>{
      const code=res.statusCode||0,type=String(res.headers['content-type']||'').toLowerCase();
      if(code>=300&&code<400&&res.headers.location){
        const next=new URL(res.headers.location,u).href;res.resume();
        legacy5ProbeRequest(next,headers,{range,redirects:redirects+1}).then(v=>finish(v),e=>finish(null,e));return;
      }
      if(code===403||code===429||code===416||code<200||code>=400){res.resume();finish({code,type,buffer:Buffer.alloc(0),finalUrl:u.href});return;}
      const chunks=[];let size=0;const MAX=64*1024;
      const done=()=>{const b=Buffer.concat(chunks);finish({code,type,buffer:b,finalUrl:u.href});try{res.destroy();}catch{}};
      res.on('data',c=>{if(settled)return;const remaining=MAX-size;if(remaining>0){chunks.push(c.length>remaining?c.subarray(0,remaining):c);size+=Math.min(c.length,remaining);}if(size>=MAX)done();});
      res.on('end',()=>{if(!settled)done();});res.on('error',e=>{if(!settled)finish(null,e);});
    });
    req.on('timeout',()=>req.destroy(new Error('Délai validation image dépassé')));
    req.on('error',e=>{if(!settled)finish(null,e);});req.end();
  });
}
async function legacy5ChromiumProbe(url,headers,{range=true}={}){
  const h={...headers};if(range)h.Range='bytes=0-4095';
  try{
    const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),Math.min(IMAGE_TIMEOUT_MS,9000));
    const res=await session.defaultSession.fetch(url,{headers:h,signal:ctrl.signal,redirect:'follow'});
    clearTimeout(timer);
    const code=res.status,type=String(res.headers.get('content-type')||'').toLowerCase();
    if(code===403||code===429||code===416||code<200||code>=400)return{code,type,buffer:Buffer.alloc(0),finalUrl:res.url||url};
    const reader=res.body?.getReader?.();
    if(!reader){const b=Buffer.from(await res.arrayBuffer());return{code,type,buffer:b.subarray(0,64*1024),finalUrl:res.url||url};}
    const chunks=[];let size=0;
    try{
      while(size<64*1024){const {done,value}=await reader.read();if(done)break;if(value){const b=Buffer.from(value),remaining=64*1024-size;chunks.push(b.length>remaining?b.subarray(0,remaining):b);size+=Math.min(b.length,remaining);}}
    }finally{try{await reader.cancel();}catch{}}
    return{code,type,buffer:Buffer.concat(chunks),finalUrl:res.url||url};
  }catch{return null;}
}

function legacy5FamilyKey(raw){
  try{
    const u=new URL(raw),parts=u.pathname.split('/').filter(Boolean);if(parts.length)parts.pop();
    return `${u.origin}/${parts.join('/').toLowerCase()}`;
  }catch{return 'unknown';}
}
function legacy5ChoosePageSet(validated){
  const sorted=[...validated].sort((a,b)=>(a.position??999999)-(b.position??999999));
  const e1=sorted.filter(x=>(x.engines||[]).includes(1));
  const multi=sorted.filter(x=>(x.engines||[]).length>=2);
  if(e1.length>=2)return{method:'reader-dom',pages:e1};
  if(multi.length>=2)return{method:'multi-engine',pages:multi};
  const groups=new Map();for(const x of sorted){const k=legacy5FamilyKey(x.url);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(x);}
  const family=[...groups.values()].sort((a,b)=>b.length-a.length)[0]||[];
  if(family.length>=2)return{method:'url-family',pages:family.sort((a,b)=>(a.position??999999)-(b.position??999999))};
  return{method:'all-validated',pages:sorted};
}
async function legacy5ValidateCandidate(candidate,rendered){
  return legacy5ValidateSem.use(async()=>{
    const targetCookies=await legacy5CookieHeader([candidate.url,rendered.finalUrl]);
    const headers={
      'User-Agent':rendered.userAgent,
      'Referer':rendered.finalUrl,
      'Accept':'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      'Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8',
      'Accept-Encoding':'identity',
      'Cache-Control':'no-cache'
    };
    if(targetCookies)headers.Cookie=targetCookies;
    let probe=await legacy5ProbeRequest(candidate.url,headers,{range:true}).catch(()=>null);
    if(probe?.code===416)probe=await legacy5ProbeRequest(candidate.url,headers,{range:false}).catch(()=>null);
    let check=probe&&probe.code>=200&&probe.code<300?inspectImageBuffer(probe.buffer,probe.type):null;
    // On PC, Chromium is the closest equivalent of Android WebView's live network session.
    // If the native probe is blocked or returns a dubious body, validate once more through that exact session.
    if(!probe||probe.code===403||probe.code===429||(probe.code>=200&&probe.code<300&&!check?.ok)){
      let chromium=await legacy5ChromiumProbe(candidate.url,headers,{range:true});
      if(chromium?.code===416)chromium=await legacy5ChromiumProbe(candidate.url,headers,{range:false});
      if(chromium)probe=chromium;
      check=probe&&probe.code>=200&&probe.code<300?inspectImageBuffer(probe.buffer,probe.type):null;
    }
    if(!probe)return{ok:false,candidate};
    if(probe.code===403||probe.code===429)return{ok:false,blocked:probe.code,candidate};
    if(probe.code<200||probe.code>=300)return{ok:false,status:probe.code,candidate};
    if(!check?.ok)return{ok:false,status:probe.code,reason:check?.reason||'signature image invalide',candidate};
    const ctx={finalUrl:rendered.finalUrl,userAgent:rendered.userAgent,cookies:targetCookies||rendered.cookies};
    legacy5RegisterSession(candidate.url,ctx);if(probe.finalUrl&&probe.finalUrl!==candidate.url)legacy5RegisterSession(probe.finalUrl,ctx);
    return{ok:true,...candidate,url:probe.finalUrl||candidate.url,kind:check.kind};
  });
}
function legacy5PayloadWeak(p){
  if(!p?.ok||!Array.isArray(p.images)||p.images.length<2)return true;
  if(p.engine==='JAVA5')return java5PayloadWeak(p);
  const c=p.confidence||{},count=p.images.length,e1=p.engineStats?.E1Validated||0,multi=p.engineStats?.multiValidated||0;
  if(p.isVolume&&count<8)return true;
  return !!p.lowConfidence || (count<6&&e1<2&&multi<2) || c.method==='all-validated'&&count<5;
}
async function legacy5ExtractOnce(url,{deep=false}={}){
  const rendered=await legacy5RenderChapter(url,{deep});
  if(!rendered?.chapterSignal)throw new Error('La page ouverte ne ressemble pas à un chapitre/tome');
  const candidates=Array.isArray(rendered.candidates)?rendered.candidates:[];
  if(!candidates.length)throw new Error('Aucune URL image réelle trouvée par les moteurs 1-4');

  // Fast path: validate the reader DOM / candidates seen by several engines first.
  const preferred=candidates.filter(c=>(c.engines||[]).includes(1)||(c.engines||[]).length>=2);
  const firstBatch=preferred.length>=2?preferred:candidates;
  const firstResults=(await pooled(firstBatch,LEGACY5_VALIDATE_CONCURRENCY,c=>legacy5ValidateCandidate(c,rendered))).filter(Boolean);
  let blockedStatus=firstResults.find(x=>x.blocked)?.blocked||null;
  let valid=firstResults.filter(x=>x.ok);
  let choice=legacy5ChoosePageSet(valid);

  const firstStrong=choice.pages.length>=2 && (choice.method==='reader-dom'||choice.method==='multi-engine');
  if(!firstStrong && firstBatch!==candidates){
    const tried=new Set(firstBatch.map(x=>x.url));
    const rest=candidates.filter(x=>!tried.has(x.url));
    const more=(await pooled(rest,LEGACY5_VALIDATE_CONCURRENCY,c=>legacy5ValidateCandidate(c,rendered))).filter(Boolean);
    blockedStatus=blockedStatus||more.find(x=>x.blocked)?.blocked||null;
    valid=valid.concat(more.filter(x=>x.ok));choice=legacy5ChoosePageSet(valid);
  }
  if(!choice.pages.length){if(blockedStatus)throw new Error(`HTTP ${blockedStatus} pendant la validation du moteur 5`);throw new Error('Moteur 5: aucune image réseau valide');}

  const distinct=[];const seen=new Set();for(const x of choice.pages){if(!seen.has(x.url)){seen.add(x.url);distinct.push(x);}}
  const e1v=valid.filter(x=>(x.engines||[]).includes(1)).length;
  const multiv=valid.filter(x=>(x.engines||[]).length>=2).length;
  const images=distinct.map(x=>x.url);
  const lowConfidence=(images.length<6&&e1v<2&&multiv<2)||choice.method==='all-validated';
  const engineStats={...(rendered.engineStats||{}),E5Validated:valid.length,E5Selected:images.length,E1Validated:e1v,multiValidated:multiv,method:choice.method,deep:!!deep,candidates:candidates.length};
  return{ok:images.length>=2,series:rendered.series||'Série',chapter:rendered.chapter||'Chapitre',number:rendered.number??null,isVolume:!!rendered.isVolume,images,engine:'E5-SESSION',engineStats,confidence:{method:choice.method},lowConfidence,__userAgent:rendered.userAgent,__finalUrl:rendered.finalUrl,__deepPass:!!deep};
}
async function java5RenderChapter(url,{deep=false}={}){
  return legacy5RenderSem.use(async()=>{
    const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
    const win=new BrowserWindow({show:false,width:1180,height:860,paintWhenInitiallyHidden:true,webPreferences:{session:session.defaultSession,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,images:true,sandbox:true}});
    win.webContents.setAudioMuted(true);win.webContents.setUserAgent(ua);win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    let timer;const timeoutMs=deep?22000:14500;
    const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`JAVA5 rendu trop long (>${Math.round(timeoutMs/1000)} s)`)),timeoutMs);});
    try{
      await Promise.race([win.loadURL(url,{userAgent:ua}),timeout]);
      await sleep(250);
      const challenge=await win.webContents.executeJavaScript(`(function(){return (document.title+' '+(document.body?document.body.innerText.slice(0,5000):''));})()`,true).catch(()=> '');
      if(legacy5ChallengeText(challenge))throw new Error('CAPTCHA/Cloudflare verification required');
      await win.webContents.executeJavaScript(LEGACY_RENDER_PREP,true).catch(()=>null);
      if(deep){await sleep(350);await win.webContents.executeJavaScript(LEGACY_RENDER_PREP,true).catch(()=>null);}
      await sleep(deep?900:450);
      const raw=await Promise.race([win.webContents.executeJavaScript(JAVA5_EXTRACT,true),timeout]);
      const parsed=typeof raw==='string'?JSON.parse(raw):raw;
      const finalUrl=win.webContents.getURL()||parsed?.finalUrl||url;
      const userAgent=win.webContents.getUserAgent()||ua;
      const cookies=await legacy5CookieHeader([finalUrl]);
      return {...(parsed||{}),finalUrl,userAgent,cookies,__deepPass:!!deep};
    }finally{clearTimeout(timer);try{win.webContents.stop();}catch{}if(!win.isDestroyed())win.destroy();}
  });
}
function java5PayloadWeak(p){
  if(!p?.ok||!Array.isArray(p.images)||p.images.length<2)return true;
  if(p.isVolume&&p.images.length<8)return true;
  if(!p.isVolume&&p.images.length<4)return true;
  return false;
}
async function java5ExtractOnce(url,{deep=false}={}){
  const rendered=await java5RenderChapter(url,{deep});
  if(!rendered?.chapterSignal)throw new Error('JAVA5: la page ne ressemble pas à un chapitre/tome');
  const candidates=Array.isArray(rendered.candidates)?rendered.candidates:[];
  if(!candidates.length)throw new Error('JAVA5: aucune image trouvée par les 5 moteurs Java');
  // Faithful behavior of MainActivity.java: E5 has ALREADY isolated/sorted the reader block.
  // Do not pre-download every candidate here. The page downloader performs the real request,
  // image-signature validation and retry with the same browser session. This keeps analysis fast.
  const images=[];const seen=new Set();
  for(const c of candidates){if(c?.url&&!seen.has(c.url)){seen.add(c.url);images.push(c.url);legacy5RegisterSession(c.url,{finalUrl:rendered.finalUrl,userAgent:rendered.userAgent,cookies:rendered.cookies});}}
  return {ok:images.length>=2,series:rendered.series||'Série',chapter:rendered.chapter||'Chapitre',number:rendered.number??null,isVolume:!!rendered.isVolume,images,engine:'JAVA5',engineStats:{...(rendered.engineStats||{}),method:rendered.engine5Mode||'java5',deep:!!deep,candidates:candidates.length},confidence:{method:rendered.engine5Mode||'java5'},lowConfidence:images.length<4,__userAgent:rendered.userAgent,__finalUrl:rendered.finalUrl,__deepPass:!!deep};
}
async function java5ExtractChapter(url){
  const first=await java5ExtractOnce(url,{deep:false});
  if(!java5PayloadWeak(first))return first;
  const second=await java5ExtractOnce(url,{deep:true}).catch(()=>null);
  if(second?.ok&&(!java5PayloadWeak(second)||second.images.length>first.images.length))return second;
  return first;
}
async function session5ExtractChapter(url){
  const first=await legacy5ExtractOnce(url,{deep:false});
  if(!legacy5PayloadWeak(first))return first;
  const second=await legacy5ExtractOnce(url,{deep:true}).catch(()=>null);
  if(second?.ok){
    if(!legacy5PayloadWeak(second)||second.images.length>first.images.length)return second;
  }
  return first;
}
async function legacy5ExtractChapter(url){
  // v2.1: ORIGINAL JAVA 5-engine extractor is the primary path.
  // V4.6 rendered/session validator remains only as a fallback when JAVA5 is weak.
  let javaResult=null,javaErr=null;
  try{javaResult=await java5ExtractChapter(url);if(javaResult&&!java5PayloadWeak(javaResult))return javaResult;}catch(e){javaErr=e;}
  let sessionResult=null,sessionErr=null;
  try{sessionResult=await session5ExtractChapter(url);if(sessionResult&&!legacy5PayloadWeak(sessionResult))return sessionResult;}catch(e){sessionErr=e;}
  if(javaResult&&sessionResult)return javaResult.images.length>=sessionResult.images.length?javaResult:sessionResult;
  if(javaResult)return javaResult;if(sessionResult)return sessionResult;
  throw javaErr||sessionErr||new Error('JAVA5 / E5: extraction impossible');
}

async function legacy5FetchImage(url,sourceUrl,fallbackUserAgent){
  return imageSem.use(async()=>{
    let lastErr;
    const reg=legacy5GetSession(url);
    const referer=reg?.referer||sourceUrl;
    const userAgent=reg?.userAgent||fallbackUserAgent||'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36';
    const cookies=reg?.cookies||await legacy5CookieHeader([url,referer]);
    const headers={'User-Agent':userAgent,'Referer':referer,'Accept':'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8','Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8','Accept-Encoding':'identity','Cache-Control':'no-cache'};
    if(cookies)headers.Cookie=cookies;
    for(let attempt=0;attempt<4;attempt++){
      if(attempt)await sleep([0,900,1900,3800][attempt]);
      try{return await nodeRequestBuffer(url,headers);}catch(e){lastErr=e;if(e.statusCode===404)break;}
      try{
        const res=await session.defaultSession.fetch(url,{headers});
        if(!res.ok){const e=new Error(`HTTP ${res.status}`);e.statusCode=res.status;throw e;}
        const type=String(res.headers.get('content-type')||'').toLowerCase(),buf=Buffer.from(await res.arrayBuffer()),check=inspectImageBuffer(buf,type);
        if(!check.ok)throw new Error(check.reason||'Contenu non-image');
        return{buffer:buf,contentType:type,kind:check.kind,finalUrl:url};
      }catch(e){lastErr=e;if(e.statusCode===404)break;}
    }
    throw lastErr||new Error('Image inaccessible avec la session du moteur 5');
  });
}
async function legacy5CreatePdf(payload,sourceUrl,onProgress=()=>{},control=null){
  return pdfSem.use(async()=>{
    const outDir=seriesDir(payload.series);ensureDir(outDir);const filename=buildPdfName(payload.series,payload.chapter),target=path.join(outDir,filename);
    const total=payload.images.length,converted=new Array(total),used=new Set(),failures=new Map();let cursor=0,done=0;
    const runInitial=async()=>{while(true){const i=cursor++;if(i>=total)break;while(control?.paused&&!control?.stopped)await sleep(180);if(control?.stopped)throw new Error('Téléchargement arrêté');try{const f=await legacy5FetchImage(payload.images[i],sourceUrl,payload.__userAgent);const c=await decodeToJpeg(f);converted[i]=c;used.add(payload.images[i]);failures.delete(i);}catch(e){failures.set(i,e);}done++;onProgress({state:'DOWNLOAD',current:done,total,valid:done-failures.size,skipped:failures.size});}};
    await Promise.all(Array.from({length:Math.min(PAGE_CONCURRENCY_PER_CHAPTER,total)},runInitial));

    // MangaHub V4.6 behavior: do not expose a page error yet. Re-render + all engines twice.
    for(let pass=1;pass<=2&&failures.size;pass++){
      if(control?.stopped)throw new Error('Téléchargement arrêté');
      onProgress({state:`RECOVERY${pass}`,current:total-failures.size,total,valid:total-failures.size,skipped:failures.size});
      await sleep(pass*900);
      const fresh=await legacy5RecoverySem.use(()=>legacy5ExtractOnce(sourceUrl,{deep:true})).catch(()=>null);
      if(!fresh?.images?.length)continue;
      const indexes=[...failures.keys()];
      await pooled(indexes,Math.min(2,indexes.length),async i=>{
        const idx=Math.max(0,Math.min(i,fresh.images.length-1));
        const alternatives=[fresh.images[idx],idx>0?fresh.images[idx-1]:null,idx<fresh.images.length-1?fresh.images[idx+1]:null].filter(Boolean);
        for(const alt of [...new Set(alternatives)]){
          if(used.has(alt))continue;
          try{const f=await legacy5FetchImage(alt,sourceUrl,fresh.__userAgent);const c=await decodeToJpeg(f);converted[i]=c;used.add(alt);failures.delete(i);break;}catch(e){failures.set(i,e);}
        }
        onProgress({state:`RECOVERY${pass}`,current:total-failures.size,total,valid:total-failures.size,skipped:failures.size});
      });
    }
    if(failures.size){
      const details=[...failures.entries()].slice(0,4).map(([i,e])=>`page ${i+1}: ${String(e?.message||e)}`).join(' | ');
      throw new Error(`Chapitre incomplet après moteur 5 + 2 récupérations : ${failures.size}/${total} page(s) en échec. ${details}`);
    }
    onProgress({state:'PDF',current:0,total,valid:total,skipped:0});
    const pdf=await PDFDocument.create();
    for(let i=0;i<converted.length;i++){
      const c=converted[i];if(!c)throw new Error(`Page ${i+1} manquante avant génération PDF`);
      const img=await pdf.embedJpg(c.data),w=c.info.width||img.width,h=c.info.height||img.height,page=pdf.addPage([w,h]);page.drawImage(img,{x:0,y:0,width:w,height:h});converted[i]=null;
      if(i===0||i===total-1||(i+1)%8===0)onProgress({state:'PDF',current:i+1,total,valid:total,skipped:0});
    }
    const tmp=target+'.part';fs.writeFileSync(tmp,await pdf.save());if(fs.existsSync(target))fs.unlinkSync(target);fs.renameSync(tmp,target);onProgress({state:'SAVED',current:total,total,valid:total,skipped:0,target});return target;
  });
}


function isHttpUrl(v){try{const u=new URL(v);return u.protocol==='http:'||u.protocol==='https:';}catch{return false;}}
function sameOrigin(a,b){try{return new URL(a).origin===new URL(b).origin;}catch{return false;}}
async function cookieHeaderFor(targetUrl,sourceUrl){
  let key='';
  try{key=`${new URL(targetUrl).origin}|${sourceUrl&&isHttpUrl(sourceUrl)?new URL(sourceUrl).origin:''}`;}catch{}
  const now=Date.now(),cached=key?cookieHeaderCache.get(key):null;
  if(cached&&now-cached.at<20000)return cached.value;
  const jar=new Map();
  const add=async u=>{if(!u||!isHttpUrl(u))return;try{for(const c of await session.defaultSession.cookies.get({url:u}))jar.set(c.name,c.value);}catch{}};
  await add(targetUrl); if(sourceUrl&&sameOrigin(targetUrl,sourceUrl))await add(sourceUrl);
  const value=[...jar.entries()].map(([k,v])=>`${k}=${v}`).join('; ');
  if(key){cookieHeaderCache.set(key,{at:now,value});if(cookieHeaderCache.size>64){const first=cookieHeaderCache.keys().next().value;cookieHeaderCache.delete(first);}}
  return value;
}
function inspectImageBuffer(buf,contentType=''){
  if(!Buffer.isBuffer(buf)||buf.length<24)return{ok:false,kind:'too-small',reason:'réponse trop courte'};
  const head=buf.subarray(0,512),txt=head.toString('utf8').replace(/^\uFEFF/,'').trimStart().toLowerCase();
  if(txt.startsWith('<!doctype html')||txt.startsWith('<html')||txt.includes('<head')||txt.includes('cloudflare')||txt.includes('access denied'))return{ok:false,kind:'html',reason:'HTML/anti-bot reçu à la place de l’image'};
  if(buf[0]===0xff&&buf[1]===0xd8&&buf[2]===0xff)return{ok:true,kind:'jpeg'};
  if(buf.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])))return{ok:true,kind:'png'};
  if(buf.subarray(0,6).toString('ascii')==='GIF87a'||buf.subarray(0,6).toString('ascii')==='GIF89a')return{ok:true,kind:'gif'};
  if(buf.subarray(0,4).toString('ascii')==='RIFF'&&buf.subarray(8,12).toString('ascii')==='WEBP')return{ok:true,kind:'webp'};
  if(buf.subarray(0,2).toString('ascii')==='BM')return{ok:true,kind:'bmp'};
  if((buf[0]===0x49&&buf[1]===0x49&&buf[2]===0x2a&&buf[3]===0x00)||(buf[0]===0x4d&&buf[1]===0x4d&&buf[2]===0x00&&buf[3]===0x2a))return{ok:true,kind:'tiff'};
  const brand=buf.subarray(4,12).toString('ascii').toLowerCase();
  if(brand.startsWith('ftyp')&&/(avif|avis|heic|heix|hevc|hevx|mif1|msf1)/.test(brand))return{ok:true,kind:'avif/heif'};
  if(txt.startsWith('<svg')||(txt.startsWith('<?xml')&&txt.includes('<svg')))return{ok:true,kind:'svg'};
  const ct=String(contentType||'').toLowerCase().split(';')[0].trim();
  const knownMime=new Set(['image/jpeg','image/jpg','image/png','image/gif','image/webp','image/avif','image/heif','image/heic','image/bmp','image/tiff','image/svg+xml']);
  if(knownMime.has(ct))return{ok:false,kind:ct.slice(6),reason:`signature ${ct} invalide ou réponse tronquée`};
  if(ct.startsWith('image/'))return{ok:false,kind:ct.slice(6),reason:`format image non pris en charge: ${ct}`};
  return{ok:false,kind:'unknown',reason:`contenu non-image (${ct||'type inconnu'})`};
}
function imageUrlVariants(raw){
  const out=[];const push=v=>{if(v&&!out.includes(v))out.push(v);};push(raw);
  try{const u=new URL(raw);if(u.search){const clean=new URL(u.href);clean.search='';push(clean.href);}}catch{}
  return out;
}
function nodeRequestBuffer(url,headers,redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>7)return reject(new Error('Trop de redirections'));let u;try{u=new URL(url);}catch{return reject(new Error('URL image invalide'));}
    if(!['http:','https:'].includes(u.protocol))return reject(new Error(`Schéma non pris en charge: ${u.protocol}`));const transport=u.protocol==='https:'?https:http;
    const req=transport.request(u,{method:'GET',headers,timeout:IMAGE_TIMEOUT_MS,rejectUnauthorized:true,agent:u.protocol==='https:'?httpsKeepAliveAgent:httpKeepAliveAgent},res=>{
      const code=res.statusCode||0;
      if(code>=300&&code<400&&res.headers.location){res.resume();const next=new URL(res.headers.location,u).href;nodeRequestBuffer(next,headers,redirects+1).then(resolve,reject);return;}
      if(code<200||code>=400){res.resume();const e=new Error(`HTTP ${code}`);e.statusCode=code;reject(e);return;}
      const type=String(res.headers['content-type']||'').toLowerCase();if(type.includes('text/html')){res.resume();reject(new Error('HTML au lieu d’une image'));return;}
      const chunks=[];let size=0;const MAX=55*1024*1024;
      res.on('data',c=>{size+=c.length;if(size>MAX){req.destroy(new Error('Image trop volumineuse'));return;}chunks.push(c);});
      res.on('end',()=>{const b=Buffer.concat(chunks),check=inspectImageBuffer(b,type);if(!check.ok)return reject(new Error(check.reason||'Image invalide'));resolve({buffer:b,contentType:type,kind:check.kind,finalUrl:u.href});});
      res.on('error',reject);
    });req.on('timeout',()=>req.destroy(new Error('Délai réseau dépassé')));req.on('error',reject);req.end();
  });
}
async function fetchImage(url,referer,userAgent){
  return imageSem.use(async()=>{
    if(!isHttpUrl(url))throw new Error('URL image non HTTP');
    const cookies=await cookieHeaderFor(url,referer);
    const headers={
      'User-Agent':userAgent||PHONE_UA,
      'Accept':'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      'Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8',
      'Accept-Encoding':'identity',
      'Connection':'keep-alive'
    };
    if(referer)headers.Referer=referer;
    if(cookies)headers.Cookie=cookies;
    try{return await nodeRequestBuffer(url,headers);}
    catch(e){
      // Comme le téléphone : pas de cascade de 6 variantes qui ralentit chaque page.
      // 416 peut être transitoire, une seule seconde tentative identique suffit.
      if(e?.statusCode===416)return nodeRequestBuffer(url,headers);
      // 403/429 : le candidat est ignoré, le chapitre continue avec les autres pages.
      if(e?.statusCode===403||e?.statusCode===429)throw e;
      // Un seul fallback Chromium garde la compatibilité avec les réponses particulières.
      try{
        const res=await session.defaultSession.fetch(url,{headers});
        if(!res.ok){const x=new Error(`HTTP ${res.status}`);x.statusCode=res.status;throw x;}
        const type=String(res.headers.get('content-type')||'').toLowerCase(),buf=Buffer.from(await res.arrayBuffer()),check=inspectImageBuffer(buf,type);
        if(!check.ok)throw new Error(check.reason||'Contenu non-image');
        return{buffer:buf,contentType:type,kind:check.kind,finalUrl:url};
      }catch(fallbackErr){throw fallbackErr||e;}
    }
  });
}
async function decodeToJpeg(fetched){
  const raw=Buffer.isBuffer(fetched)?fetched:fetched.buffer;
  try{
    const c=await sharp(raw,{failOn:'none'}).rotate().jpeg({quality:88,mozjpeg:true}).toBuffer({resolveWithObject:true});
    if(!c.info.width||!c.info.height)throw new Error('dimensions invalides');return c;
  }catch(sharpErr){
    try{
      const ni=nativeImage.createFromBuffer(raw);
      if(!ni.isEmpty()){const size=ni.getSize(),data=ni.toJPEG(88);if(size.width>0&&size.height>0&&data.length>512)return{data,info:{width:size.width,height:size.height,format:'jpeg',fallback:'chromium'}};}
    }catch{}
    throw new Error(`format image non décodable (${fetched?.kind||'inconnu'}) : ${String(sharpErr.message||sharpErr)}`);
  }
}

async function createPdfFromImages(payload,sourceUrl,onProgress=()=>{},userAgent=null,control=null){
  return pdfSem.use(async()=>{
    const outDir=seriesDir(payload.series);ensureDir(outDir);const filename=buildPdfName(payload.series,payload.chapter),target=path.join(outDir,filename),total=Array.isArray(payload.images)?payload.images.length:0;
    const converted=new Array(total),errors=[];let cursor=0,done=0,valid=0,skipped=0;
    const worker=async()=>{while(true){const i=cursor++;if(i>=total)break;while(control?.paused&&!control?.stopped)await sleep(180);if(control?.stopped)throw new Error('Téléchargement arrêté');try{const fetched=await fetchImage(payload.images[i],sourceUrl,userAgent||payload.__userAgent);const c=await decodeToJpeg(fetched);converted[i]=c;valid++;}catch(e){skipped++;errors.push(`page ${i+1}: ${String(e.message||e)}`);}done++;onProgress({state:'DOWNLOAD',current:done,total,valid,skipped});}};
    await Promise.all(Array.from({length:Math.min(PAGE_CONCURRENCY_PER_CHAPTER,total)},worker));
    if(control?.stopped)throw new Error('Téléchargement arrêté');if(valid<2)throw new Error(`Chapitre rejeté : ${valid}/${total} page(s) récupérée(s). ${errors.slice(0,3).join(' | ')}`.trim());
    onProgress({state:'PDF',current:0,total:valid,valid,skipped});const pdf=await PDFDocument.create();let pno=0;for(let i=0;i<converted.length;i++){const c=converted[i];if(!c)continue;const img=await pdf.embedJpg(c.data),w=c.info.width||img.width,h=c.info.height||img.height,page=pdf.addPage([w,h]);page.drawImage(img,{x:0,y:0,width:w,height:h});converted[i]=null;pno++;if(pno===1||pno===valid||pno%8===0)onProgress({state:'PDF',current:pno,total:valid,valid,skipped});}
    const tmp=target+'.part';fs.writeFileSync(tmp,await pdf.save());if(fs.existsSync(target))fs.unlinkSync(target);fs.renameSync(tmp,target);onProgress({state:'SAVED',current:valid,total:valid,valid,skipped,target});return target;
  });
}


// === Android APK 4.0 download engine port ====================================
// Mirrors MainActivity.java: each chapter gets its own Chromium renderer,
// FORCE_LAZY_LOAD is executed, then the strict reader container extractor runs.
const APK40_QUIET_PAGE = `(function(){
  try{
    document.querySelectorAll('video,audio').forEach(m=>{try{m.pause();m.muted=true;m.preload='none';}catch(e){}});
    if(!document.getElementById('__chapter_perf_css')){
      const st=document.createElement('style');st.id='__chapter_perf_css';
      st.textContent='*,*::before,*::after{animation-duration:0s!important;animation-iteration-count:1!important;transition-duration:0s!important;} video,audio{visibility:hidden!important;}';
      (document.head||document.documentElement).appendChild(st);
    }
  }catch(e){}
  return 'ok';
})()`;

function createApk40WorkerWindow(){
  const win=new BrowserWindow({
    show:false,width:820,height:620,paintWhenInitiallyHidden:false,
    webPreferences:{session:session.defaultSession,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,images:true,sandbox:true}
  });
  win.__apkBusy=false;
  win.webContents.setAudioMuted(true);
  win.webContents.setUserAgent(PHONE_UA);
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.on('closed',()=>{apk40WorkerWindows=apk40WorkerWindows.filter(x=>x!==win);});
  apk40WorkerWindows.push(win);
  return win;
}
function acquireApk40WorkerWindow(){
  apk40WorkerWindows=apk40WorkerWindows.filter(w=>w&&!w.isDestroyed());
  let win=apk40WorkerWindows.find(w=>!w.__apkBusy);
  if(!win && apk40WorkerWindows.length<APK40_RENDER_CONCURRENCY)win=createApk40WorkerWindow();
  if(!win)throw new Error('Aucun renderer APK40 disponible');
  win.__apkBusy=true;
  return win;
}

async function apk40ReleasePage(win){
  if(!win||win.isDestroyed())return;
  try{await win.webContents.executeJavaScript(`(function(){try{document.querySelectorAll('img,video,audio,source').forEach(e=>{try{e.removeAttribute('src');e.removeAttribute('srcset');}catch(x){}});document.documentElement.innerHTML='<head></head><body></body>';}catch(e){}return 'ok';})()`,true);}catch{}
  try{await win.loadURL('about:blank');}catch{}
  await sleep(40);
}

// APK 4.0 engine with ONE reusable Chromium renderer. The old v2.3 created a new
// BrowserWindow for every chapter; process creation/destruction was one of the CPU spikes.
async function apk40ExtractChapter(url){
  return apk40RenderSem.use(async()=>{
    const win=acquireApk40WorkerWindow();
    let timer=null;
    try{
      try{win.webContents.stop();}catch{}
      const loadPromise=new Promise((resolve,reject)=>{
        let done=false;
        const onFinish=()=>finish();
        const onFail=(_e,code,desc)=>{if(code!==-3)finish(new Error(`LOAD ${code}: ${desc}`));};
        const cleanup=()=>{win.webContents.removeListener('did-finish-load',onFinish);win.webContents.removeListener('did-fail-load',onFail);};
        const finish=(err)=>{if(done)return;done=true;clearTimeout(timer);cleanup();err?reject(err):resolve();};
        timer=setTimeout(()=>finish(new Error('LOAD: rendu du chapitre trop long (>60 s)')),60000);
        win.webContents.on('did-finish-load',onFinish);
        win.webContents.on('did-fail-load',onFail);
      });
      await win.loadURL(url);
      await loadPromise;
      await win.webContents.executeJavaScript(APK40_QUIET_PAGE,true).catch(()=>null);
      await win.webContents.executeJavaScript(APK_FORCE_LAZY_LOAD,true).catch(()=>null);
      await sleep(1500);
      await win.webContents.executeJavaScript("window.scrollTo(0,0);'ok';",true).catch(()=>null);
      await sleep(650);
      const raw=await win.webContents.executeJavaScript(APK_EXTRACT_CHAPTER_PAYLOAD,true);
      let parsed=raw;
      if(typeof parsed==='string'){
        try{parsed=JSON.parse(parsed);}catch{parsed={ok:false,reason:'JSON extraction invalide',images:[]};}
      }
      if(!parsed||!parsed.ok)throw new Error(parsed?.reason||'Page non reconnue comme chapitre');
      if(!Array.isArray(parsed.images)||parsed.images.length<2)throw new Error('Chapitre rejeté : moins de 2 pages détectées');
      const finalUrl=win.webContents.getURL()||url;
      const ua=win.webContents.getUserAgent();
      return {...parsed,engine:'APK40',engineStats:{reader:parsed.reader||'auto',count:parsed.images.length,mode:'Android 4.0 strict reader / renderer réutilisé'},__userAgent:ua,__finalUrl:finalUrl};
    }finally{
      if(timer)clearTimeout(timer);
      await apk40ReleasePage(win).catch(()=>null);
      if(win&&!win.isDestroyed())win.__apkBusy=false;
    }
  });
}

// Mirrors PdfDownloadManager.java: images are downloaded sequentially per chapter,
// with real cookies/referer/UA and only actually decodable images are kept.
// Optimisation PC: JPEG/PNG sont conservés tels quels. Sharp n'est utilisé que
// pour les formats que PDF-Lib ne sait pas embarquer directement (WebP/AVIF/etc.).
function jpegDimensions(buf){
  try{
    if(!Buffer.isBuffer(buf)||buf.length<4||buf[0]!==0xff||buf[1]!==0xd8)return null;
    let i=2;
    while(i+9<buf.length){
      if(buf[i]!==0xff){i++;continue;}
      while(i<buf.length&&buf[i]===0xff)i++;
      const marker=buf[i++];
      if(marker===0xd8||marker===0xd9)continue;
      if(i+1>=buf.length)break;
      const len=buf.readUInt16BE(i); if(len<2||i+len>buf.length)break;
      const sof=(marker>=0xc0&&marker<=0xc3)||(marker>=0xc5&&marker<=0xc7)||(marker>=0xc9&&marker<=0xcb)||(marker>=0xcd&&marker<=0xcf);
      if(sof&&len>=7){const h=buf.readUInt16BE(i+3),w=buf.readUInt16BE(i+5),components=buf[i+7]||3;if(w>0&&h>0)return{width:w,height:h,components};}
      i+=len;
    }
  }catch{}
  return null;
}

async function apk40PrepareJpegPage(fetched){
  const raw=Buffer.isBuffer(fetched)?fetched:fetched.buffer;
  const kind=String(fetched?.kind||'').toLowerCase();
  // JPEG can be embedded verbatim: metadata only, no pixel decode/recompression.
  if(kind==='jpeg'||kind==='jpg'){
    const d=jpegDimensions(raw);
    if(d?.width>0&&d?.height>0){
      return{data:raw,info:{width:d.width,height:d.height,colorSpace:d.components===1?'DeviceGray':'DeviceRGB'}};
    }
  }
  // Formats non JPEG: une seule conversion CPU lourde à la fois. Les autres
  // chapitres peuvent continuer leurs téléchargements réseau simultanément.
  return convertSem.use(async()=>{
    const c=await sharp(raw,{failOn:'none',sequentialRead:true,limitInputPixels:120000000})
      .rotate().flatten({background:'#ffffff'}).jpeg({quality:86,mozjpeg:false}).toBuffer({resolveWithObject:true});
    if(!c.info.width||!c.info.height)throw new Error('dimensions invalides');
    return{data:c.data,info:{width:c.info.width,height:c.info.height,colorSpace:'DeviceRGB'}};
  });
}

class JpegPdfStreamWriter{
  constructor(filePath){this.filePath=filePath;this.fh=null;this.offset=0;this.offsets=new Map();this.nextId=3;this.pages=[];this.closed=false;}
  async open(){this.fh=await fs.promises.open(this.filePath,'w');await this.write(Buffer.from('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n','binary'));}
  async write(data){if(typeof data==='string')data=Buffer.from(data,'binary');if(!data?.length)return;let pos=0;while(pos<data.length){const r=await this.fh.write(data,pos,data.length-pos,null);pos+=r.bytesWritten;this.offset+=r.bytesWritten;}}
  async objStart(id){this.offsets.set(id,this.offset);await this.write(`${id} 0 obj\n`);}
  async addPage(jpeg,width,height,colorSpace='DeviceRGB'){
    const imageId=this.nextId++,contentId=this.nextId++,pageId=this.nextId++;
    const w=Math.max(1,Math.round(width)),h=Math.max(1,Math.round(height));
    await this.objStart(imageId);
    await this.write(`<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /${colorSpace} /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);
    await this.write(jpeg);await this.write('\nendstream\nendobj\n');
    const content=`q\n${w} 0 0 ${h} 0 0 cm\n/Im0 Do\nQ\n`;
    await this.objStart(contentId);await this.write(`<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}endstream\nendobj\n`);
    await this.objStart(pageId);await this.write(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`);
    this.pages.push(pageId);
  }
  async finish(){
    await this.objStart(2);await this.write(`<< /Type /Pages /Count ${this.pages.length} /Kids [${this.pages.map(id=>`${id} 0 R`).join(' ')}] >>\nendobj\n`);
    await this.objStart(1);await this.write('<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
    const maxId=this.nextId-1,xref=this.offset;await this.write(`xref\n0 ${maxId+1}\n0000000000 65535 f \n`);
    for(let id=1;id<=maxId;id++){const off=this.offsets.get(id)||0;await this.write(`${String(off).padStart(10,'0')} 00000 n \n`);}
    await this.write(`trailer\n<< /Size ${maxId+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
    await this.fh.close();this.closed=true;
  }
  async abort(){try{if(this.fh&&!this.closed)await this.fh.close();}catch{}this.closed=true;try{await fs.promises.unlink(this.filePath);}catch{}}
}

// Low-RAM PDF path: download -> validate/convert -> write page -> release buffer.
// No array containing the whole chapter is kept in memory anymore.
async function apk40CreatePdf(payload,sourceUrl,onProgress=()=>{},control=null){
  return apk40PipelineSem.use(async()=>{
    const outDir=seriesDir(payload.series);ensureDir(outDir);
    const filename=buildPdfName(payload.series,payload.chapter),target=path.join(outDir,filename),tmp=target+'.part';
    const total=payload.images.length;let valid=0,skipped=0,done=0;
    try{await fs.promises.unlink(tmp);}catch{}
    const writer=new JpegPdfStreamWriter(tmp);await writer.open();
    const prepareOne=async(i)=>{
      while(control?.paused&&!control?.stopped)await sleep(180);
      if(control?.stopped)throw new Error('Téléchargement arrêté');
      try{
        // Une seule récupération : le buffer validé est directement réutilisé pour le PDF.
        const fetched=await fetchImage(payload.images[i],sourceUrl,payload.__userAgent);
        const page=await apk40PrepareJpegPage(fetched);
        return{i,page,error:null};
      }catch(e){return{i,page:null,error:e};}
    };
    try{
      // Fenêtre bornée de 3 pages : vrai parallélisme réseau, ordre PDF conservé,
      // sans charger le chapitre entier en RAM.
      for(let base=0;base<total;base+=PAGE_CONCURRENCY_PER_CHAPTER){
        const batch=[];
        for(let i=base;i<Math.min(total,base+PAGE_CONCURRENCY_PER_CHAPTER);i++)batch.push(prepareOne(i));
        const results=await Promise.all(batch);
        results.sort((a,b)=>a.i-b.i);
        for(const r of results){
          if(r.page){
            await writer.addPage(r.page.data,r.page.info.width,r.page.info.height,r.page.info.colorSpace);
            valid++;
            r.page.data=null;
          }else skipped++;
          done++;
          onProgress({state:'DOWNLOAD',current:done,total,valid,skipped,parallel:PAGE_CONCURRENCY_PER_CHAPTER});
        }
        // Rend la main entre les petites fenêtres, sans pause artificielle.
        await new Promise(r=>setImmediate(r));
      }
      if(valid<2)throw new Error('Chapitre rejeté : moins de 2 vraies pages décodables');
      onProgress({state:'PDF',current:valid,total:valid,valid,skipped});
      await writer.finish();
      try{await fs.promises.unlink(target);}catch{}
      await fs.promises.rename(tmp,target);
      onProgress({state:'SAVED',current:valid,total:valid,valid,skipped,target});
      return target;
    }catch(e){await writer.abort();throw e;}
  });
}
// ============================================================================

async function downloadChapterJob(job,slot){
  let lastProgressEmit=0;
  const send=(phase,extra={})=>{
    const terminal=['SAVED','ERROR','STOPPED'];
    const wait=phase==='WAIT_PDF';
    const state=terminal.includes(phase)?phase:(wait?'WAIT_PDF':'RUNNING');
    Object.assign(job,{state,phase,slot,...extra});
    const noisy=['DOWNLOAD','PDF'].includes(phase),now=Date.now();
    if(!noisy||now-lastProgressEmit>=QUEUE_UI_INTERVAL_MS){lastProgressEmit=now;emitQueue(!noisy);}
    if(!noisy&&mainWindow&&!mainWindow.isDestroyed())mainWindow.webContents.send('queue:progress',{id:job.id,slot,url:job.url,title:job.title,series:job.series,state,phase,...extra});
  };
  const expected=path.join(seriesDir(job.series),buildPdfName(job.series,job.title));
  if(job.series&&job.title&&fs.existsSync(expected)){send('SAVED',{target:expected,cached:true});return expected;}
  const control={get paused(){return !!queue.paused||!!job.paused;},get stopped(){return !!queue.stopped||!!job.stopRequested;}};
  while(control.paused&&!control.stopped)await sleep(180);
  if(control.stopped)throw new Error('Téléchargement arrêté');
  send('LOAD',{engine:'APK40'});
  const payload=await apk40ExtractChapter(job.url);
  while(control.paused&&!control.stopped)await sleep(180);
  if(control.stopped)throw new Error('Téléchargement arrêté');
  // Forced series/chapter labels behave like MainActivity startBatch().
  payload.series=job.series||payload.series||'Série';
  payload.chapter=job.title||payload.chapter||'Chapitre';
  job.series=payload.series;job.title=payload.chapter;job.engine='APK40';job.engineStats=payload.engineStats;job.pages=payload.images.length;
  send('ANALYSE',{pages:payload.images.length,engine:'APK40',engineStats:payload.engineStats});
  send('WAIT_PDF',{pages:payload.images.length,engine:'APK40'});
  const target=await apk40CreatePdf(payload,job.url,p=>send(p.state,{page:p.current,pages:p.total,valid:p.valid,skipped:p.skipped}),control);
  send('SAVED',{target});return target;
}

function inc(map,key,delta){const n=(map.get(key)||0)+delta;if(n<=0)map.delete(key);else map.set(key,n);}
function takeNextQueued(){
  const queued=queue.jobs.filter(j=>j.state==='QUEUED'&&!j.paused&&!j.stopRequested);if(!queued.length)return null;
  // Auto-réparation : aucune tâche RUNNING => les compteurs actifs doivent être vides.
  if(!queue.jobs.some(j=>j.state==='RUNNING'||j.state==='WAIT_PDF')){queue.activeBySeries.clear();queue.activeByHost.clear();}
  const series=[...new Set(queued.map(seriesKey))];if(!series.length)return null;
  for(let n=0;n<series.length;n++){
    const idx=(queue.seriesCursor+n)%series.length,key=series[idx];if((queue.activeBySeries.get(key)||0)>=MAX_ACTIVE_PER_SERIES)continue;
    const j=queued.find(x=>seriesKey(x)===key&&(queue.activeByHost.get(hostOf(x.url))||0)<MAX_ACTIVE_PER_HOST);if(!j)continue;
    queue.seriesCursor=(idx+1)%series.length;return j;
  }
  return null;
}
async function queueWorker(slot){
  while(!queue.stopped){
    while(queue.paused&&!queue.stopped)await sleep(180);if(queue.stopped)break;
    const job=takeNextQueued();
    if(!job){
      if(queue.jobs.some(j=>j.state==='RUNNING'||j.state==='WAIT_PDF')){await sleep(160);continue;}
      await sleep(420);
      if(queue.jobs.some(j=>j.state==='QUEUED'))continue;
      break;
    }
    const sk=seriesKey(job),hk=hostOf(job.url);job.state='RUNNING';job.phase='QUEUED';job.error='';job.slot=slot;inc(queue.activeBySeries,sk,1);inc(queue.activeByHost,hk,1);emitQueue(true);
    try{await downloadChapterJob(job,slot);}catch(e){job.state=(queue.stopped||job.stopRequested)?'STOPPED':'ERROR';job.phase=job.state;job.error=String(e.message||e);mainWindow?.webContents.send('queue:progress',{id:job.id,slot,url:job.url,title:job.title,series:job.series,state:job.state,phase:job.phase,error:job.error});}
    finally{inc(queue.activeBySeries,sk,-1);inc(queue.activeByHost,hk,-1);job.slot=null;if(job.retryAfterStop&&!job.removeWhenDone){job.retryAfterStop=false;job.stopRequested=false;job.paused=false;job.state='QUEUED';job.phase='QUEUED';job.error='';}if(job.removeWhenDone)queue.jobs=queue.jobs.filter(x=>x.id!==job.id);emitQueue(true);if(job.state==='QUEUED'&&!queue.paused&&!queue.stopped)setImmediate(spawnQueueWorkers);}
  }
}
function spawnQueueWorkers(){
  if(queue.stopped||queue.paused)return;
  if(!queue.jobs.some(j=>j.state==='QUEUED')){
    if(!queue.jobs.some(j=>j.state==='RUNNING'||j.state==='WAIT_PDF')&&queue.workers.size===0){queue.running=false;emitQueue();}
    return;
  }
  queue.running=true;
  for(let slot=1;slot<=CHAPTER_CONCURRENCY;slot++){
    if(queue.workers.has(slot))continue;
    const promise=queueWorker(slot).catch(()=>{}).finally(()=>{
      queue.workers.delete(slot);
      if(queue.jobs.some(j=>j.state==='QUEUED')&&!queue.stopped&&!queue.paused){setImmediate(spawnQueueWorkers);return;}
      if(!queue.jobs.some(j=>j.state==='RUNNING'||j.state==='WAIT_PDF')&&queue.workers.size===0){
        queue.running=false;emitQueue();mainWindow?.webContents.send('queue:complete',queueSnapshot());
      }
    });
    queue.workers.set(slot,promise);
  }
  emitQueue();
}
async function runQueue(){
  queue.stopped=false;queue.paused=false;
  if(!queue.jobs.some(j=>j.state==='QUEUED'||j.state==='RUNNING'||j.state==='WAIT_PDF')){queue.running=false;emitQueue();return queueSnapshot();}
  spawnQueueWorkers();
  return queueSnapshot();
}
function normalizeQueueUrl(raw){try{const u=new URL(String(raw||''));u.hash='';u.search='';u.pathname=u.pathname.replace(/\/{2,}/g,'/').replace(/\/(?:prev|next)\/?$/i,'');if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/$/,'');return u.origin+u.pathname.toLowerCase();}catch{return String(raw||'').trim().toLowerCase();}}
function addQueueJobs(jobs){
  const requested=Array.isArray(jobs)?jobs.length:0;
  const existing=new Set(queue.jobs.filter(j=>j.state!=='ERROR'&&j.state!=='STOPPED').map(queueIdentity));let added=0,skipped=0;
  for(const raw of jobs||[]){
    if(!raw?.url){skipped++;continue;}
    let validatedUrl='';try{const u=new URL(String(raw.url));if(!['http:','https:'].includes(u.protocol)||!u.hostname)throw new Error();u.hash='';validatedUrl=u.href;}catch{skipped++;continue;}
    const series=raw.series||'Série',candidate={...raw,url:validatedUrl,series},key=queueIdentity(candidate);
    if(!key||existing.has(key)){skipped++;continue;}
    queue.jobs.push({id:queue.nextId++,url:validatedUrl,title:raw.title||`Chapitre ${raw.number??''}`.trim(),series,number:raw.number??numberFromJob(raw),state:'QUEUED',phase:'QUEUED',error:'',target:'',engine:'',engineStats:null,paused:false,stopRequested:false,removeWhenDone:false,addedAt:Date.now()});
    existing.add(key);added++;
  }
  emitQueue();
  if(added>0&&queue.running&&!queue.paused&&!queue.stopped)setImmediate(spawnQueueWorkers);
  return{requested,added,skipped,snapshot:queueSnapshot()};
}

function createWindow(){mainWindow=new BrowserWindow({width:1440,height:900,minWidth:980,minHeight:650,title:'Chapter Search PDF',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,webviewTag:true,backgroundThrottling:true}});mainWindow.loadFile(path.join(__dirname,'index.html'));}

app.whenReady().then(()=>{restoreQueue();session.defaultSession.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{persistQueue();for(const w of apk40WorkerWindows){try{if(w&&!w.isDestroyed())w.destroy();}catch{}}apk40WorkerWindows=[];if(process.platform!=='darwin')app.quit();});

ipcMain.handle('engine:scripts',()=>({force:FORCE_LAZY_LOAD,chapter:EXTRACT_CHAPTER_PAYLOAD,multiChapter:EXTRACT_MULTI_ENGINE,series:EXTRACT_CHAPTERS,seriesPage:FIND_SERIES_PAGE}));
ipcMain.handle('sources:get',()=>loadSources());
ipcMain.handle('sources:save',(_e,s)=>saveSources(s));
ipcMain.handle('sources:inject',(_e,incoming)=>{const base=loadSources(),map=new Map(base.map(x=>[x.domain,x]));for(const x of incoming||[])if(x?.domain)map.set(x.domain,{enabled:true,lang:'?',type:'multi',...x});return saveSources([...map.values()]);});
ipcMain.handle('meta:search',async(_e,{query,sources})=>{let done=0;const active=(sources||loadSources()).filter(s=>s.enabled),results=await pooled(active,SEARCH_CONCURRENCY,async source=>{const r=await searchOneSource(source,query);done++;mainWindow?.webContents.send('meta:progress',{done,total:active.length,source:source.name,ok:r.ok,count:r.results.length});return r;});return results;});
ipcMain.handle('chapter:analyze',async(_e,url)=>apk40ExtractChapter(url));
ipcMain.handle('series:analyze',async(_e,url)=>loadAndExtract(url,'series'));
ipcMain.handle('series:page',async(_e,url)=>loadAndExtract(url,'seriesPage'));
ipcMain.handle('chapter:download',async(_e,{url,payload})=>{const p=(payload?.engine==='APK40')?payload:await apk40ExtractChapter(url);return apk40CreatePdf(p,url,()=>{},{paused:false,stopped:false});});
ipcMain.handle('pdf:exists',(_e,{series,chapter})=>fs.existsSync(path.join(seriesDir(series),buildPdfName(series,chapter))));
ipcMain.handle('downloads:open',()=>{ensureDir();return shell.openPath(downloadRoot());});
ipcMain.handle('external:open',(_e,url)=>shell.openExternal(url));

ipcMain.handle('perf:get',()=>{
  try{
    const metrics=app.getAppMetrics();
    const cpu=metrics.reduce((n,m)=>n+Number(m.cpu?.percentCPUUsage||0),0);
    const appRamKb=metrics.reduce((n,m)=>n+Number(m.memory?.workingSetSize||0),0);
    const mem=process.getSystemMemoryInfo();
    const usedKb=Math.max(0,Number(mem.total||0)-Number(mem.free||0));
    const activeDownloads=queue.jobs.filter(j=>j.state==='RUNNING'&&j.phase==='DOWNLOAD').length;
    const activeRenderers=apk40WorkerWindows.filter(w=>w&&!w.isDestroyed()&&w.__apkBusy).length;
    return{cpuApp:Math.round(cpu*10)/10,ramAppMb:Math.round(appRamKb/1024),ramSystemPct:mem.total?Math.round(usedKb/mem.total*100):0,activeDownloads,activeRenderers,queueActive:queue.jobs.filter(j=>j.state==='RUNNING'||j.state==='WAIT_PDF').length};
  }catch{return{cpuApp:0,ramAppMb:0,ramSystemPct:0,activeDownloads:0,activeRenderers:0,queueActive:0};}
});
ipcMain.handle('queue:get',()=>queueSnapshot());
ipcMain.handle('queue:add',(_e,jobs)=>addQueueJobs(jobs));
ipcMain.handle('queue:add-start',(_e,jobs)=>{const r=addQueueJobs(jobs);setImmediate(()=>runQueue());return r;});
ipcMain.handle('queue:start',()=>{setImmediate(()=>runQueue());return queueSnapshot();});
ipcMain.handle('queue:pause',(_e,v)=>{queue.paused=!!v;emitQueue();return queueSnapshot();});
ipcMain.handle('queue:stop',()=>{queue.stopped=true;queue.paused=false;for(const j of queue.jobs)if(j.state==='QUEUED')j.state='STOPPED';emitQueue();return queueSnapshot();});
ipcMain.handle('queue:retry-errors',()=>{for(const j of queue.jobs)if(j.state==='ERROR'||j.state==='STOPPED'){j.state='QUEUED';j.phase='QUEUED';j.error='';j.paused=false;j.stopRequested=false;j.removeWhenDone=false;j.retryAfterStop=false;}queue.stopped=false;emitQueue();return queueSnapshot();});
ipcMain.handle('queue:pause-job',(_e,id,v)=>{const j=queue.jobs.find(x=>x.id===Number(id));if(!j)return queueSnapshot();j.paused=!!v;if(j.paused&&j.state==='RUNNING')j.phase='PAUSED';if(!j.paused&&j.phase==='PAUSED')j.phase=j.state==='RUNNING'?'DOWNLOAD':'QUEUED';emitQueue(true);if(!j.paused&&!queue.paused&&!queue.stopped)setImmediate(spawnQueueWorkers);return queueSnapshot();});
ipcMain.handle('queue:retry-job',(_e,id)=>{const j=queue.jobs.find(x=>x.id===Number(id));if(!j)return queueSnapshot();if(j.state==='RUNNING'||j.state==='WAIT_PDF'){j.stopRequested=true;j.retryAfterStop=true;return queueSnapshot();}j.state='QUEUED';j.phase='QUEUED';j.error='';j.paused=false;j.stopRequested=false;j.removeWhenDone=false;queue.stopped=false;emitQueue(true);setImmediate(()=>runQueue());return queueSnapshot();});
ipcMain.handle('queue:stop-job',(_e,id)=>{const j=queue.jobs.find(x=>x.id===Number(id));if(!j)return queueSnapshot();j.stopRequested=true;j.paused=false;if(j.state==='QUEUED'){j.state='STOPPED';j.phase='STOPPED';j.error='Arrêté manuellement';}emitQueue(true);return queueSnapshot();});
ipcMain.handle('queue:remove-job',(_e,id)=>{const j=queue.jobs.find(x=>x.id===Number(id));if(!j)return queueSnapshot();if(j.state==='RUNNING'||j.state==='WAIT_PDF'){j.stopRequested=true;j.removeWhenDone=true;}else queue.jobs=queue.jobs.filter(x=>x.id!==j.id);emitQueue(true);return queueSnapshot();});
ipcMain.handle('queue:clear-done',()=>{queue.jobs=queue.jobs.filter(j=>j.state!=='SAVED');emitQueue();return queueSnapshot();});
ipcMain.handle('queue:remove-series',(_e,series)=>{const key=sanitize(series).toLowerCase();queue.jobs=queue.jobs.filter(j=>seriesKey(j)!==key||j.state==='RUNNING'||j.state==='WAIT_PDF');emitQueue();return queueSnapshot();});

// Compatibilité avec les anciennes interfaces.
ipcMain.handle('batch:start',(_e,jobs)=>{addQueueJobs(jobs);setImmediate(()=>runQueue());return queueSnapshot();});
ipcMain.handle('batch:pause',(_e,v)=>{queue.paused=!!v;emitQueue();return queueSnapshot();});
ipcMain.handle('batch:stop',()=>{queue.stopped=true;emitQueue();return queueSnapshot();});
