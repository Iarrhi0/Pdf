# Chapter Search PDF — V1

Nouvelle application indépendante inspirée du fonctionnement de Chapter PDF Manual Safe 6.7.

## Fonctionnement

1. Recherche Web intégrée depuis la barre supérieure (Google Web global).
2. Ouverture directe de n'importe quel lien externe dans WebView.
3. Détection automatique de familles de lecteurs connues + Auto Engine générique.
4. 5 moteurs de découverte d'images :
   - conteneurs de lecteur / DOM,
   - attributs lazy-loading,
   - srcset / picture / CSS,
   - scripts HTML / JSON,
   - ressources réellement chargées par le WebView.
5. Validation réelle de chaque image avant PDF : réponse HTTP, signature binaire, décodage dimensions.
6. Cookies + User-Agent + Referer provenant de la session WebView.
7. Un chapitre = un PDF dans `Téléchargements/Chapter Search PDF`.
8. Détection des liens de chapitres d'une fiche série et téléchargement en lot.
9. Pause / reprise / arrêt de la file série.

## Lecteurs

Le registre contient plus de 50 profils/familles ou sites connus : Madara/WP Manga, MangaStream/MangaThemesia, FoolSlide, Genkan, Webtoon/Naver, MangaDex, ComicK, Bato, MangaSee/MangaLife, MangaKakalot/MangaNato, MangaReader, MangaPark, MangaBuddy, MangaGo, Toonily, Asura, Reaper, Flame, SushiScan, OrtegaScans, Mangas-Origines, ToonFR, Japscan, Lelmanga, Scan-Manga, Manga-Scantrad, TMO/LectorManga, etc.

Le registre n'est pas une limite : si le domaine n'est pas connu, l'Auto Engine générique tente quand même l'extraction sur le DOM rendu.

## Restrictions

L'application ne contourne pas les paywalls, DRM ou CAPTCHA. Si un site demande une vérification, elle doit être réalisée manuellement dans le WebView puis le téléchargement peut être relancé.
