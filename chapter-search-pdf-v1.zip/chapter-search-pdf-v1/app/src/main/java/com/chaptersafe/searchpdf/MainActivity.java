package com.chaptersafe.searchpdf;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private EditText searchBox;
    private WebView webView;
    private WebView workerWebView;
    private TextView status;
    private Button batchPauseButton;
    private Button batchStopButton;
    private final ArrayDeque<ChapterJob> batchQueue = new ArrayDeque<>();
    private boolean batchRunning = false;
    private boolean batchPaused = false;
    private boolean batchStopped = false;
    private int batchDone = 0;
    private int batchTotal = 0;
    private String lastDetectedReader = "Auto Engine";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 44);
        }
        buildUi();
        configureWebView(webView, false);
        configureWebView(workerWebView, true);
        showHome();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11, 12, 16));

        TextView title = new TextView(this);
        title.setText("Chapter Search PDF");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setPadding(dp(14), dp(12), dp(14), dp(8));
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setPadding(dp(10), 0, dp(10), dp(6));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Rechercher une série ou coller un lien…");
        searchBox.setHintTextColor(Color.GRAY);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setBackgroundColor(Color.rgb(32, 34, 42));
        searchBox.setPadding(dp(12), 0, dp(12), 0);
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button go = button("Rechercher");
        go.setOnClickListener(v -> searchOrOpen(searchBox.getText().toString()));
        searchRow.addView(go, new LinearLayout.LayoutParams(dp(104), dp(46)));
        root.addView(searchRow);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), 0, dp(8), dp(5));
        Button back = button("←");
        Button forward = button("→");
        Button paste = button("Coller");
        Button detect = button("Détecter");
        back.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        forward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });
        paste.setOnClickListener(v -> pasteAndOpen());
        detect.setOnClickListener(v -> detectCurrentPage(true));
        addEqual(nav, back); addEqual(nav, forward); addEqual(nav, paste); addEqual(nav, detect);
        root.addView(nav);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(dp(8), 0, dp(8), dp(5));
        Button chapter = button("PDF chapitre");
        Button series = button("Chapitres / série");
        chapter.setOnClickListener(v -> downloadCurrentChapter());
        series.setOnClickListener(v -> detectSeriesChapters());
        addEqual(actions, chapter); addEqual(actions, series);
        root.addView(actions);

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        workerWebView = new WebView(this);
        workerWebView.setAlpha(0.01f);
        root.addView(workerWebView, new LinearLayout.LayoutParams(1, 1));

        LinearLayout batchControls = new LinearLayout(this);
        batchControls.setOrientation(LinearLayout.HORIZONTAL);
        batchControls.setPadding(dp(8), dp(4), dp(8), dp(4));
        batchPauseButton = button("Pause");
        batchStopButton = button("Arrêter");
        batchPauseButton.setOnClickListener(v -> toggleBatchPause());
        batchStopButton.setOnClickListener(v -> stopBatch());
        addEqual(batchControls, batchPauseButton); addEqual(batchControls, batchStopButton);
        root.addView(batchControls);

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(dp(12), dp(7), dp(12), dp(9));
        status.setText("Prêt");
        root.addView(status);

        setContentView(root);
    }

    private void configureWebView(WebView w, boolean worker) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(s.getUserAgentString());
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!worker) {
                    searchBox.setText(url);
                    setStatus("Page chargée — " + url);
                    main.postDelayed(() -> detectCurrentPage(false), 700);
                }
            }
        });
    }

    private void showHome() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{background:#0b0c10;color:#fff;font-family:sans-serif;padding:22px}h1{color:#9c7cff}div{background:#181a22;padding:16px;border-radius:14px;margin:12px 0}.p{color:#b8b8c0}</style></head><body>" +
            "<h1>Chapter Search PDF</h1><div><b>1. Recherche Web globale</b><p class='p'>Tape le nom d'un manga, manhwa, webtoon ou comics dans la barre.</p></div>" +
            "<div><b>2. Ouvre n'importe quel site</b><p class='p'>Google affiche les résultats externes. Tu peux aussi coller directement un lien.</p></div>" +
            "<div><b>3. Auto Engine</b><p class='p'>Détection de " + ReaderRegistry.knownProfileCount() + " familles/profils connus + lecteur générique : DOM, lazy/srcset, HTML/JSON, CSS/liens, ressources WebView.</p></div>" +
            "<div><b>4. PDF</b><p class='p'>Un chapitre = un PDF. Les fichiers invalides sont rejetés avant création du PDF.</p></div></body></html>";
        webView.loadDataWithBaseURL("https://chapter-search.local/", html, "text/html", "UTF-8", null);
    }

    private void searchOrOpen(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) return;
        if (q.matches("(?i)^https?://.+")) {
            webView.loadUrl(q);
        } else if (q.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) {
            webView.loadUrl("https://" + q);
        } else {
            String query = URLEncoder.encode(q + " manga manhwa webtoon chapter", StandardCharsets.UTF_8);
            webView.loadUrl("https://www.google.com/search?q=" + query);
        }
    }

    private void pasteAndOpen() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return;
        String text = String.valueOf(clip.getItemAt(0).coerceToText(this));
        searchBox.setText(text);
        searchOrOpen(text);
    }

    private void detectCurrentPage(boolean toast) {
        String url = webView.getUrl();
        webView.evaluateJavascript(EngineScripts.PAGE_HTML, raw -> {
            String html = decodeJsString(raw);
            lastDetectedReader = ReaderRegistry.detect(url == null ? "" : url, html);
            setStatus("Lecteur détecté : " + lastDetectedReader);
            if (toast) Toast.makeText(this, "Lecteur : " + lastDetectedReader, Toast.LENGTH_LONG).show();
        });
    }

    private void downloadCurrentChapter() {
        String url = webView.getUrl();
        if (url == null || url.startsWith("data:") || url.contains("chapter-search.local")) {
            toast("Ouvre d'abord un chapitre.");
            return;
        }
        setStatus("Préparation du lecteur rendu…");
        webView.evaluateJavascript(EngineScripts.FORCE_LAZY_LOAD, r -> {
            main.postDelayed(() -> {
                webView.evaluateJavascript("window.scrollTo(0,0);'ok';", r2 -> {});
                main.postDelayed(() -> extractImagesAndDownload(webView, url, guessTitle(webView), false), 1200);
            }, 1800);
        });
    }

    private void extractImagesAndDownload(WebView sourceView, String chapterUrl, String title, boolean batch) {
        sourceView.evaluateJavascript(EngineScripts.EXTRACT_IMAGES, raw -> {
            try {
                String json = decodeJsString(raw);
                JSONArray arr = new JSONArray(json);
                List<String> urls = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    String u = arr.optString(i, "");
                    if (!u.isEmpty()) urls.add(u);
                }
                if (urls.isEmpty()) {
                    if (batch) finishBatchItem(false, "0 image");
                    else setStatus("Aucune image détectée. Ouvre le lecteur dans WebView puis réessaie.");
                    return;
                }
                setStatus("5 moteurs : " + urls.size() + " candidats → validation réelle");
                String ua = sourceView.getSettings().getUserAgentString();
                PdfDownloadManager.downloadChapter(this, chapterUrl, title, urls, ua, new PdfDownloadManager.Listener() {
                    @Override public void onStatus(String text) { main.post(() -> setStatus((batch ? batchPrefix() : "") + text)); }
                    @Override public void onDone(String displayName) {
                        main.post(() -> {
                            toast("PDF enregistré : " + displayName);
                            if (batch) finishBatchItem(true, displayName); else setStatus("Terminé : " + displayName);
                        });
                    }
                    @Override public void onError(String message) {
                        main.post(() -> {
                            if (batch) finishBatchItem(false, message); else setStatus("Échec total moteurs : " + message);
                        });
                    }
                });
            } catch (Exception e) {
                if (batch) finishBatchItem(false, e.getMessage());
                else setStatus("Extraction impossible : " + e.getMessage());
            }
        });
    }

    private void detectSeriesChapters() {
        setStatus("Recherche des liens de chapitres sur la page…");
        webView.evaluateJavascript(EngineScripts.EXTRACT_CHAPTERS, raw -> {
            try {
                JSONArray arr = new JSONArray(decodeJsString(raw));
                if (arr.length() == 0) {
                    setStatus("Aucun lien de chapitre détecté sur cette page.");
                    return;
                }
                List<ChapterJob> jobs = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    jobs.add(new ChapterJob(o.optString("title", "Chapitre " + (i + 1)), o.optString("url", "")));
                }
                showChapterDialog(jobs);
            } catch (Exception e) {
                setStatus("Erreur détection série : " + e.getMessage());
            }
        });
    }

    private void showChapterDialog(List<ChapterJob> jobs) {
        String[] labels = new String[Math.min(jobs.size(), 120) + 1];
        labels[0] = "⬇ Télécharger TOUS les chapitres détectés (" + jobs.size() + ")";
        for (int i = 1; i < labels.length; i++) labels[i] = jobs.get(i - 1).title;
        new AlertDialog.Builder(this)
            .setTitle("Chapitres détectés")
            .setItems(labels, (d, which) -> {
                if (which == 0) startBatch(jobs);
                else {
                    ChapterJob j = jobs.get(which - 1);
                    webView.loadUrl(j.url);
                    setStatus("Chapitre ouvert : " + j.title + " — appuie PDF chapitre");
                }
            })
            .setNegativeButton("Fermer", null)
            .show();
    }

    private void startBatch(List<ChapterJob> jobs) {
        batchQueue.clear();
        for (ChapterJob j : jobs) if (j.url != null && !j.url.isEmpty()) batchQueue.add(j);
        batchTotal = batchQueue.size();
        batchDone = 0;
        batchStopped = false;
        batchPaused = false;
        batchRunning = true;
        batchPauseButton.setText("Pause");
        setStatus("Téléchargement série : " + batchTotal + " chapitres en file");
        processNextBatch();
    }

    private void processNextBatch() {
        if (!batchRunning || batchStopped || batchPaused) return;
        ChapterJob job = batchQueue.poll();
        if (job == null) {
            batchRunning = false;
            setStatus("Série terminée : " + batchDone + " / " + batchTotal + " chapitres traités");
            return;
        }
        currentBatchJob = job;
        setStatus(batchPrefix() + "Chargement rendu : " + job.title);
        workerWebView.setWebViewClient(new WebViewClient() {
            private boolean done = false;
            @Override public void onPageFinished(WebView view, String url) {
                if (done) return;
                done = true;
                view.evaluateJavascript(EngineScripts.FORCE_LAZY_LOAD, r -> main.postDelayed(() -> {
                    view.evaluateJavascript("window.scrollTo(0,0);'ok';", r2 -> {});
                    main.postDelayed(() -> extractImagesAndDownload(view, job.url, job.title, true), 1400);
                }, 2200));
            }
        });
        workerWebView.loadUrl(job.url);
    }

    private ChapterJob currentBatchJob;

    private void finishBatchItem(boolean success, String detail) {
        batchDone++;
        setStatus(batchPrefix() + (success ? "Enregistré" : "Ignoré après échec total") + " — " + detail);
        currentBatchJob = null;
        main.postDelayed(this::processNextBatch, 500);
    }

    private void toggleBatchPause() {
        if (!batchRunning) { toast("Aucune série en téléchargement."); return; }
        batchPaused = !batchPaused;
        batchPauseButton.setText(batchPaused ? "Reprendre" : "Pause");
        setStatus(batchPaused ? "Téléchargements en pause" : "Reprise des téléchargements");
        if (!batchPaused) processNextBatch();
    }

    private void stopBatch() {
        batchStopped = true;
        batchRunning = false;
        batchQueue.clear();
        workerWebView.stopLoading();
        setStatus("Téléchargement série arrêté. Les PDF déjà enregistrés restent conservés.");
    }

    private String batchPrefix() {
        return "[" + Math.min(batchDone + 1, Math.max(1, batchTotal)) + "/" + Math.max(1, batchTotal) + "] ";
    }

    private String guessTitle(WebView view) {
        String t = view.getTitle();
        if (t == null || t.trim().isEmpty()) t = "Chapitre";
        return PdfDownloadManager.sanitize(t.replace(" - Google Search", ""));
    }

    private String decodeJsString(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            JSONArray a = new JSONArray("[" + raw + "]");
            return a.getString(0);
        } catch (Exception e) {
            return raw.replace("\\\"", "\"").replace("\\n", "\n");
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(43, 40, 58));
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void addEqual(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1);
        p.setMargins(dp(2), 0, dp(2), 0);
        row.addView(v, p);
    }

    private void setStatus(String text) { status.setText(text); }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        if (workerWebView != null) workerWebView.destroy();
        super.onDestroy();
    }

    private static final class ChapterJob {
        final String title;
        final String url;
        ChapterJob(String title, String url) { this.title = title; this.url = url; }
    }
}
