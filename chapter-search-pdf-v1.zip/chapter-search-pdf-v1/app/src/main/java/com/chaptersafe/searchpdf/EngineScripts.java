package com.chaptersafe.searchpdf;

public final class EngineScripts {
    public static final String FORCE_LAZY_LOAD = "(function(){try{" +
        "document.querySelectorAll('img').forEach(function(i){" +
        "['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){var v=i.getAttribute(a);if(v&&!i.src)i.src=v;});" +
        "i.loading='eager';});window.scrollTo(0,document.body.scrollHeight);return 'ok';}catch(e){return 'err';}})();";

    public static final String EXTRACT_IMAGES = "(function(){" +
        "function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}" +
        "function bad(u){u=(u||'').toLowerCase();return !u||u.indexOf('data:')===0||/(logo|avatar|icon|sprite|emoji|advert|banner|tracking|pixel|favicon)/.test(u)}" +
        "var out=[],seen={};function add(u){u=abs(u);if(!bad(u)&&!seen[u]){seen[u]=1;out.push(u)}}" +
        "var sels=['.reading-content img','.page-break img','#readerarea img','.reader-area img','.readerarea img','.ts_reader img','.chapter-content img','.chapter-images img','.container-chapter-reader img','.reading-detail img','.viewer img','.viewer_img img','.episode-body img','.webtoon-reader img','.chapterbody img','main img'];" +
        "sels.forEach(function(s){document.querySelectorAll(s).forEach(function(i){add(i.currentSrc||i.src);['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc'].forEach(function(a){add(i.getAttribute(a))})})});" +
        "document.querySelectorAll('img').forEach(function(i){['data-src','data-lazy-src','data-original','data-url','data-image','data-cfsrc','src'].forEach(function(a){add(i.getAttribute(a))})});" +
        "document.querySelectorAll('source').forEach(function(s){var z=s.srcset||s.getAttribute('data-srcset')||'';z.split(',').forEach(function(x){add(x.trim().split(/\\s+/)[0])})});" +
        "document.querySelectorAll('[srcset]').forEach(function(s){(s.srcset||'').split(',').forEach(function(x){add(x.trim().split(/\\s+/)[0])})});" +
        "document.querySelectorAll('[style]').forEach(function(el){var st=el.getAttribute('style')||'';var m=st.match(/url\\(['\"]?([^'\")]+)['\"]?\\)/ig)||[];m.forEach(function(x){var q=x.replace(/^url\\(['\"]?/i,'').replace(/['\"]?\\)$/,'');add(q)})});" +
        "document.querySelectorAll('script').forEach(function(sc){var t=sc.textContent||'';var re=/(https?:\\/\\/[^\\s'\"<>]+?\\.(?:jpg|jpeg|png|webp|gif|avif)(?:\\?[^\\s'\"<>]*)?)/ig,m;var n=0;while((m=re.exec(t))&&n<1000){add(m[1].replace(/\\\\u002F/g,'/'));n++}});" +
        "try{performance.getEntriesByType('resource').forEach(function(r){var u=r.name||'';if(/\\.(jpg|jpeg|png|webp|gif|avif)(\\?|$)/i.test(u)||r.initiatorType==='img')add(u)})}catch(e){}" +
        "return JSON.stringify(out);})();";

    public static final String EXTRACT_CHAPTERS = "(function(){" +
        "function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}" +
        "var out=[],seen={};var re=/(chapitre|chapter|ch\\.?|episode|ep\\.?|cap[ií]tulo|scan)\\s*[-:# ]*\\d+(?:\\.\\d+)?/i;" +
        "document.querySelectorAll('a[href]').forEach(function(a){var t=(a.innerText||a.textContent||'').trim().replace(/\\s+/g,' '),h=abs(a.getAttribute('href'));if(!h)return;var hu=h.toLowerCase();if(re.test(t)||/(chapter|chapitre|episode|capitulo|\\/ch[-_]?\\d|\\/ep[-_]?\\d)/i.test(hu)){if(!seen[h]){seen[h]=1;out.push({title:t||h.split('/').filter(Boolean).pop(),url:h})}}});" +
        "return JSON.stringify(out.slice(0,1000));})();";

    public static final String PAGE_HTML = "(function(){return document.documentElement.outerHTML;})();";

    private EngineScripts() {}
}
