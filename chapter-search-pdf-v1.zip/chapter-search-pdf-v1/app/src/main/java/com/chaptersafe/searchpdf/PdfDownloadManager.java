package com.chaptersafe.searchpdf;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PdfDownloadManager {
    public interface Listener {
        void onStatus(String text);
        void onDone(String displayName);
        void onError(String message);
    }

    private static final int CONNECT_TIMEOUT = 18000;
    private static final int READ_TIMEOUT = 30000;
    private static final int MAX_DIMENSION = 5000;

    public static void downloadChapter(Context context, String chapterUrl, String title, List<String> candidates, String userAgent, Listener listener) {
        new Thread(() -> {
            try {
                if (candidates == null || candidates.isEmpty()) throw new IOException("Aucune image détectée");
                String cookies = CookieManager.getInstance().getCookie(chapterUrl);
                List<byte[]> valid = new ArrayList<>();
                int total = candidates.size();
                for (int i = 0; i < total; i++) {
                    String imageUrl = candidates.get(i);
                    listener.onStatus("Validation page " + (i + 1) + " / " + total);
                    try {
                        byte[] bytes = fetchImage(imageUrl, chapterUrl, userAgent, cookies);
                        if (isDecodableImage(bytes)) valid.add(bytes);
                    } catch (HttpStatusException e) {
                        if (e.code == 403 || e.code == 429) {
                            listener.onStatus("Page bloquée " + e.code + " → moteur suivant");
                        }
                    } catch (Exception ignored) {
                    }
                }
                if (valid.isEmpty()) throw new IOException("Aucune page image valide après les moteurs");
                listener.onStatus("Création PDF : " + valid.size() + " pages valides");
                String name = sanitize(title) + ".pdf";
                writePdf(context, name, valid, listener);
                listener.onDone(name);
            } catch (Exception e) {
                listener.onError(e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "Erreur inconnue" : e.getMessage()));
            }
        }, "chapter-pdf-download").start();
    }

    private static byte[] fetchImage(String url, String referer, String userAgent, String cookies) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(CONNECT_TIMEOUT);
        c.setReadTimeout(READ_TIMEOUT);
        c.setRequestProperty("User-Agent", userAgent == null ? "Mozilla/5.0" : userAgent);
        c.setRequestProperty("Referer", referer);
        c.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
        if (cookies != null && !cookies.isEmpty()) c.setRequestProperty("Cookie", cookies);
        int code = c.getResponseCode();
        if (code == 416) {
            c.disconnect();
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(CONNECT_TIMEOUT);
            c.setReadTimeout(READ_TIMEOUT);
            c.setRequestProperty("User-Agent", userAgent == null ? "Mozilla/5.0" : userAgent);
            c.setRequestProperty("Referer", referer);
            if (cookies != null && !cookies.isEmpty()) c.setRequestProperty("Cookie", cookies);
            code = c.getResponseCode();
        }
        if (code < 200 || code >= 400) throw new HttpStatusException(code);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32768];
            int n;
            int total = 0;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                total += n;
                if (total > 40 * 1024 * 1024) throw new IOException("Image trop volumineuse");
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static boolean isDecodableImage(byte[] b) {
        if (b == null || b.length < 512) return false;
        if (!hasImageMagic(b)) return false;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(b, 0, b.length, o);
        return o.outWidth > 0 && o.outHeight > 0;
    }

    private static boolean hasImageMagic(byte[] b) {
        if (b.length < 12) return false;
        boolean jpg = (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8;
        boolean png = (b[0] & 0xFF) == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47;
        boolean gif = b[0] == 'G' && b[1] == 'I' && b[2] == 'F';
        boolean webp = b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P';
        boolean bmp = b[0] == 'B' && b[1] == 'M';
        return jpg || png || gif || webp || bmp;
    }

    private static Bitmap decodeForPdf(byte[] bytes) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("Image non décodable");
        int sample = 1;
        while ((bounds.outWidth / sample) > MAX_DIMENSION || (bounds.outHeight / sample) > MAX_DIMENSION * 4) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
        if (bitmap == null) throw new IOException("Décodage bitmap impossible");
        return bitmap;
    }

    private static void writePdf(Context context, String displayName, List<byte[]> pages, Listener listener) throws Exception {
        PdfDocument pdf = new PdfDocument();
        try {
            int pageNo = 1;
            for (byte[] data : pages) {
                listener.onStatus("PDF " + pageNo + " / " + pages.size());
                Bitmap b = decodeForPdf(data);
                int w = Math.max(1, b.getWidth());
                int h = Math.max(1, b.getHeight());
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(w, h, pageNo).create();
                PdfDocument.Page p = pdf.startPage(info);
                Canvas canvas = p.getCanvas();
                canvas.drawBitmap(b, 0, 0, null);
                pdf.finishPage(p);
                b.recycle();
                pageNo++;
            }
            try (OutputStream out = createOutput(context, displayName)) {
                pdf.writeTo(out);
            }
        } finally {
            pdf.close();
        }
    }

    private static OutputStream createOutput(Context context, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Chapter Search PDF");
            ContentResolver resolver = context.getContentResolver();
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Impossible de créer le PDF dans Téléchargements");
            OutputStream out = resolver.openOutputStream(uri, "w");
            if (out == null) throw new IOException("Impossible d'ouvrir la sortie PDF");
            return out;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Chapter Search PDF");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Impossible de créer le dossier de sortie");
        return new FileOutputStream(new File(dir, name));
    }

    public static String sanitize(String s) {
        if (s == null || s.trim().isEmpty()) return "Chapitre";
        String x = s.replaceAll("[\\\\/:*?\"<>|]", " ").replaceAll("\\s+", " ").trim();
        if (x.length() > 120) x = x.substring(0, 120).trim();
        return x.isEmpty() ? "Chapitre" : x;
    }

    private static final class HttpStatusException extends IOException {
        final int code;
        HttpStatusException(int code) { super("HTTP " + code); this.code = code; }
    }

    private PdfDownloadManager() {}
}
