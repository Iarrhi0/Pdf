# V5.3 — Native HTTP Fallback

Correction du 403 Ortega vu au chapitre 10.

Le Multi-Engine reste inchangé dans son principe :
Moteur 1 = 1–5, Moteur 2 = 6–10, Moteur 3 = 11–15, etc.

Nouveau fonctionnement réseau :
1. l'image est tentée depuis le WebView ;
2. si Ortega répond 403/429 (ou si fetch échoue), l'app retente côté Android natif ;
3. le réseau Android envoie User-Agent, Referer et cookies ;
4. dès que le secours Android fonctionne, les images suivantes du chapitre utilisent directement ce chemin ;
5. un 403 WebView ne stoppe donc plus immédiatement le chapitre.

Le panneau indique `secours Android` puis `réseau Android` quand ce chemin est utilisé.
