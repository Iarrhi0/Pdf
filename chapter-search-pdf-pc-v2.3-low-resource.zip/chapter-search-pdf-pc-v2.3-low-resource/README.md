# Chapter Search PDF PC v2.3 — APK40 Low Resource

Cette version porte directement le moteur de téléchargement de l’APK Android Chapter Search PDF 4.0 :

- 10 chapitres simultanés
- 1 moteur Chromium/WebView indépendant par chapitre
- FORCE_LAZY_LOAD identique à l’APK
- extraction stricte du conteneur lecteur identique à EngineScripts.java
- téléchargement séquentiel des pages à l’intérieur de chaque chapitre
- cookies + Referer + User-Agent de la session réelle
- validation réelle du fichier image avant le PDF
- les faux candidats sont ignorés comme dans PdfDownloadManager.java
- pas de timeout JAVA5 à 15 secondes

La file multi-séries PC est conservée autour de ce moteur.
