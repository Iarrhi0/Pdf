# MangaHub PDF — Android V1

Application Android séparée de Chapter PDF Downloader.

## Identité Android
- App : MangaHub PDF
- Package : `com.mangahub.pdf`
- Version : 1.0.0
- Android minimum : 7.0 / API 24

Elle peut donc être installée en même temps que `com.example.chapterpdf`.

## Ce V1 contient
- Accueil
- Recherche multi-sources (prototype UI)
- Sources / extensions
- OrtegaScans
- Sushi-Scan
- AnimeSama
- Scan-Manga
- Webtoons.com
- Lelmanga
- Mangakawaii
- Manga-Scantrad
- Mangas-Origines.fr
- Comix
- Bibliothèque
- Téléchargements intelligents / simulation pool de 10 jobs
- écran Processus / architecture

## Important
Le V1 est le socle Android autonome + interface. Les connecteurs réels, le moteur natif de téléchargement persistant et la génération PDF native seront branchés sur ce projet, sans modifier Chapter PDF Downloader.

## Build GitHub
Le workflow `.github/workflows/build-apk.yml` génère `app-debug.apk` et l'ajoute aux Artifacts du workflow.


## Build correction
This corrected archive includes `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.properties`. The launcher downloads Gradle 8.9 automatically when needed.
