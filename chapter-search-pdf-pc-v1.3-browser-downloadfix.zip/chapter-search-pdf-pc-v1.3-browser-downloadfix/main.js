const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { PDFDocument } = require('pdf-lib');
const sharp = require('sharp');
const { FORCE_LAZY_LOAD, EXTRACT_CHAPTER_PAYLOAD, EXTRACT_CHAPTERS, FIND_SERIES_PAGE } = require('./assets/engine-scripts');

const SEARCH_CONCURRENCY = 20;
const DOWNLOAD_CONCURRENCY = 10;
let mainWindow;
let batchState = { stopped: false, paused: false };

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function sanitize(s){
  let x = String(s || 'Chapitre').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim();
  if (x.length > 140) x = x.slice(0, 140).trim();
  return x || 'Chapitre';
}
function buildPdfName(series, chapter){
  const s = sanitize(series || 'Série');
  const c = sanitize(chapter || 'Chapitre');
  return c.toLowerCase().startsWith(s.toLowerCase()) ? `${c}.pdf` : `${sanitize(`${s} - ${c}`)}.pdf`;
}
function downloadDir(){ return path.join(app.getPath('downloads'), 'Chapter Search PDF'); }
function ensureDir(){ fs.mkdirSync(downloadDir(), { recursive: true }); }
function userSourcesPath(){ return path.join(app.getPath('userData'), 'sources.json'); }
function defaultSourcesPath(){ return path.join(__dirname, 'assets', 'sources.json'); }
function loadSources(){
  const p = userSourcesPath();
  if (!fs.existsSync(p)) fs.copyFileSync(defaultSourcesPath(), p);
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return JSON.parse(fs.readFileSync(defaultSourcesPath(), 'utf8')); }
}
function saveSources(sources){ fs.writeFileSync(userSourcesPath(), JSON.stringify(sources, null, 2), 'utf8'); return sources; }
function decodeHtml(s=''){ return s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>'); }
function unwrapDdg(href){
  try {
    const u = new URL(decodeHtml(href), 'https://html.duckduckgo.com');
    if (u.searchParams.has('uddg')) return decodeURIComponent(u.searchParams.get('uddg'));
    return u.href;
  } catch { return decodeHtml(href); }
}
async function searchOneSource(source, query){
  const q = `site:${source.domain} ${query}`;
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10000);
  try {
    const res = await session.defaultSession.fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 ChapterSearchPDF/1.0', 'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8' }
    });
    if (!res.ok) return { source, ok:false, status:res.status, results:[] };
    const html = await res.text();
    const rx = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    const out=[]; let m;
    while ((m=rx.exec(html)) && out.length < 5) {
      const link = unwrapDdg(m[1]);
      const title = decodeHtml(m[2].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
      try {
        const host = new URL(link).hostname.replace(/^www\./,'');
        if (host === source.domain || host.endsWith('.'+source.domain) || source.domain.endsWith('.'+host)) out.push({title, url:link});
      } catch {}
    }
    return { source, ok:true, results:out };
  } catch (e) { return { source, ok:false, error:String(e.message||e), results:[] }; }
  finally { clearTimeout(timer); }
}
async function pooled(items, concurrency, fn){
  let index=0; const out=new Array(items.length);
  async function worker(){ while(true){ const i=index++; if(i>=items.length) break; out[i]=await fn(items[i], i); } }
  await Promise.all(Array.from({length:Math.min(concurrency,items.length)}, worker));
  return out;
}
async function loadAndExtract(url, mode='chapter'){
  const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36';
  const win = new BrowserWindow({
    show:false, width:1000, height:800,
    webPreferences:{ contextIsolation:true, nodeIntegration:false, backgroundThrottling:false, images:true }
  });
  try {
    await win.loadURL(url, { userAgent: ua });
    await sleep(1200);
    if(mode==='chapter'){
      await win.webContents.executeJavaScript(FORCE_LAZY_LOAD, true).catch(()=>null);
      await sleep(1800);
      await win.webContents.executeJavaScript("window.scrollTo(0,0);'ok';", true).catch(()=>null);
      await sleep(900);
    }
    const script = mode==='seriesPage' ? FIND_SERIES_PAGE : (mode==='series' ? EXTRACT_CHAPTERS : EXTRACT_CHAPTER_PAYLOAD);
    const raw = await win.webContents.executeJavaScript(script, true);
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if(parsed && !Array.isArray(parsed) && typeof parsed === 'object') parsed.__userAgent = win.webContents.getUserAgent() || ua;
    return parsed;
  } finally { if (!win.isDestroyed()) win.destroy(); }
}

function isHttpUrl(value){
  try { const u = new URL(value); return u.protocol === 'http:' || u.protocol === 'https:'; }
  catch { return false; }
}

function sameOrigin(a,b){
  try { return new URL(a).origin === new URL(b).origin; } catch { return false; }
}

async function cookieHeaderFor(targetUrl, sourceUrl){
  const jar = new Map();
  const add = async (u) => {
    if(!u || !isHttpUrl(u)) return;
    try {
      const list = await session.defaultSession.cookies.get({url:u});
      for(const c of list) jar.set(c.name, c.value);
    } catch {}
  };
  await add(targetUrl);
  if(sourceUrl && sameOrigin(targetUrl, sourceUrl)) await add(sourceUrl);
  return [...jar.entries()].map(([k,v])=>`${k}=${v}`).join('; ');
}

function nodeRequestBuffer(url, headers, redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects > 7) return reject(new Error('Trop de redirections'));
    let u;
    try { u = new URL(url); } catch { return reject(new Error('URL image invalide')); }
    if(!['http:','https:'].includes(u.protocol)) return reject(new Error(`Schéma image non pris en charge: ${u.protocol}`));
    const transport = u.protocol === 'https:' ? https : http;
    const req = transport.request(u, {
      method:'GET',
      headers,
      timeout:25000,
      rejectUnauthorized:true
    }, res=>{
      const code = res.statusCode || 0;
      if(code >= 300 && code < 400 && res.headers.location){
        res.resume();
        const next = new URL(res.headers.location, u).href;
        nodeRequestBuffer(next, headers, redirects+1).then(resolve,reject);
        return;
      }
      if(code < 200 || code >= 400){
        res.resume();
        const e = new Error(`HTTP ${code}`); e.statusCode = code; reject(e); return;
      }
      const type = String(res.headers['content-type'] || '').toLowerCase();
      if(type.includes('text/html')){
        res.resume(); reject(new Error('Réponse HTML à la place d’une image')); return;
      }
      const chunks=[]; let size=0; const MAX=50*1024*1024;
      res.on('data',chunk=>{
        size += chunk.length;
        if(size > MAX){ req.destroy(new Error('Image trop volumineuse')); return; }
        chunks.push(chunk);
      });
      res.on('end',()=>{
        const buf=Buffer.concat(chunks);
        if(buf.length < 512) return reject(new Error('Image trop petite/invalide'));
        resolve(buf);
      });
      res.on('error',reject);
    });
    req.on('timeout',()=>req.destroy(new Error('Délai réseau dépassé')));
    req.on('error',reject);
    req.end();
  });
}

async function fetchImage(url, referer, userAgent){
  if(!isHttpUrl(url)) throw new Error('URL image non HTTP');
  const cookies = await cookieHeaderFor(url, referer);
  const baseHeaders = {
    'User-Agent': userAgent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36',
    'Accept':'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    'Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8',
    'Accept-Encoding':'identity',
    'Cache-Control':'no-cache',
    'Pragma':'no-cache',
    'Sec-Fetch-Dest':'image',
    'Sec-Fetch-Mode':'no-cors',
    'Sec-Fetch-Site': sameOrigin(url, referer) ? 'same-origin' : 'cross-site'
  };
  if(cookies) baseHeaders.Cookie = cookies;

  const variants=[];
  if(referer) variants.push({...baseHeaders, Referer:referer});
  try { if(referer) variants.push({...baseHeaders, Referer:new URL(referer).origin+'/'}); } catch {}
  variants.push({...baseHeaders});

  let lastErr;
  for(const headers of variants){
    try { return await nodeRequestBuffer(url, headers); }
    catch(e){ lastErr=e; if(e.statusCode===404) break; }
  }

  // Last fallback: Electron network stack. Useful on systems that require its proxy configuration.
  try {
    const headers = {...baseHeaders};
    if(referer) headers.Referer = referer;
    const res = await session.defaultSession.fetch(url,{headers});
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if(buf.length < 512) throw new Error('Image trop petite/invalide');
    return buf;
  } catch(e) {
    throw lastErr || e;
  }
}

async function createPdfFromImages(payload, sourceUrl, onProgress=()=>{}, userAgent=null){
  ensureDir();
  const filename = buildPdfName(payload.series, payload.chapter);
  const target = path.join(downloadDir(), filename);
  const pdf = await PDFDocument.create();
  let valid=0, skipped=0;
  const errors=[];
  const total = Array.isArray(payload.images) ? payload.images.length : 0;

  for (let i=0;i<total;i++){
    while(batchState.paused && !batchState.stopped) await sleep(250);
    if(batchState.stopped) throw new Error('Téléchargement arrêté');
    onProgress({state:'DOWNLOAD', current:i+1, total, valid, skipped});
    try {
      const raw = await fetchImage(payload.images[i], sourceUrl, userAgent || payload.__userAgent);
      const converted = await sharp(raw).rotate().jpeg({quality:92, mozjpeg:true}).toBuffer({ resolveWithObject:true });
      if(!converted.info.width || !converted.info.height) throw new Error('Image non décodable');
      const img = await pdf.embedJpg(converted.data);
      const w = converted.info.width || img.width, h = converted.info.height || img.height;
      const page = pdf.addPage([w,h]);
      page.drawImage(img,{x:0,y:0,width:w,height:h});
      valid++;
    } catch(e) {
      skipped++;
      errors.push(`page ${i+1}: ${String(e.message||e)}`);
      onProgress({state:'SKIP', current:i+1, total, valid, skipped, error:String(e.message||e)});
    }
  }

  if(valid < 2){
    const hint = errors.slice(0,3).join(' | ');
    throw new Error(`Chapitre rejeté : ${valid}/${total} page(s) récupérée(s). ${hint}`.trim());
  }

  onProgress({state:'PDF', current:valid, total, valid, skipped});
  fs.writeFileSync(target, await pdf.save());
  onProgress({state:'SAVED', current:valid, total, valid, skipped, target});
  return target;
}

async function downloadChapterJob(job, slot, index, total){
  const send = (state, extra={}) => mainWindow?.webContents.send('batch:progress',{slot,index,total,url:job.url,title:job.title,state,...extra});
  send('LOAD');
  const payload = await loadAndExtract(job.url, 'chapter');
  if (!payload?.ok || !Array.isArray(payload.images) || payload.images.length < 2) throw new Error(payload?.reason || 'Chapitre non reconnu');
  send('ANALYSE',{pages:payload.images.length,series:payload.series,chapter:payload.chapter});
  const target = await createPdfFromImages(payload, job.url, p=>send(p.state,{page:p.current,pages:p.total,valid:p.valid,skipped:p.skipped,error:p.error}), payload.__userAgent);
  send('SAVED',{target}); return target;
}

function createWindow(){
  mainWindow = new BrowserWindow({
    width:1440, height:900, minWidth:980, minHeight:650,
    title:'Chapter Search PDF',
    webPreferences:{ preload:path.join(__dirname,'preload.js'), contextIsolation:true, nodeIntegration:false, webviewTag:true, backgroundThrottling:false }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(()=>{
  session.defaultSession.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));
  createWindow();
  app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});

ipcMain.handle('engine:scripts',()=>({ force:FORCE_LAZY_LOAD, chapter:EXTRACT_CHAPTER_PAYLOAD, series:EXTRACT_CHAPTERS, seriesPage:FIND_SERIES_PAGE }));
ipcMain.handle('sources:get',()=>loadSources());
ipcMain.handle('sources:save',(_e,s)=>saveSources(s));
ipcMain.handle('sources:inject',(_e,incoming)=>{
  const base=loadSources(); const map=new Map(base.map(x=>[x.domain,x]));
  for(const x of incoming||[]){ if(x?.domain) map.set(x.domain,{enabled:true,lang:'?',type:'multi',...x}); }
  return saveSources([...map.values()]);
});
ipcMain.handle('meta:search',async(_e,{query,sources})=>{
  let done=0;
  const active=(sources||loadSources()).filter(s=>s.enabled);
  const results=await pooled(active,SEARCH_CONCURRENCY,async(source)=>{
    const r=await searchOneSource(source,query); done++;
    mainWindow?.webContents.send('meta:progress',{done,total:active.length,source:source.name,ok:r.ok,count:r.results.length});
    return r;
  });
  return results;
});
ipcMain.handle('chapter:analyze',async(_e,url)=>loadAndExtract(url,'chapter'));
ipcMain.handle('series:analyze',async(_e,url)=>loadAndExtract(url,'series'));
ipcMain.handle('series:page',async(_e,url)=>loadAndExtract(url,'seriesPage'));
ipcMain.handle('chapter:download',async(_e,{url,payload,userAgent})=>createPdfFromImages(payload,url,()=>{},userAgent));
ipcMain.handle('pdf:exists',(_e,{series,chapter})=>fs.existsSync(path.join(downloadDir(),buildPdfName(series,chapter))));
ipcMain.handle('downloads:open',()=>{ensureDir(); return shell.openPath(downloadDir());});
ipcMain.handle('external:open',(_e,url)=>shell.openExternal(url));
ipcMain.handle('batch:pause',(_e,v)=>{batchState.paused=!!v; return batchState;});
ipcMain.handle('batch:stop',()=>{batchState.stopped=true; return batchState;});
ipcMain.handle('batch:start',async(_e,jobs)=>{
  batchState={stopped:false,paused:false};
  let next=0, done=0, failed=0; const total=jobs.length;
  const workers=Array.from({length:Math.min(DOWNLOAD_CONCURRENCY,total)},(_,slot)=> (async()=>{
    while(true){
      if(batchState.stopped) break;
      const i=next++; if(i>=total) break;
      try{ await downloadChapterJob(jobs[i],slot+1,i+1,total); done++; }
      catch(err){ failed++; mainWindow?.webContents.send('batch:progress',{slot:slot+1,index:i+1,total,url:jobs[i].url,title:jobs[i].title,state:'ERROR',error:String(err.message||err)}); }
    }
  })());
  await Promise.all(workers);
  const result={done,failed,total,stopped:batchState.stopped};
  mainWindow?.webContents.send('batch:complete',result);
  return result;
});
