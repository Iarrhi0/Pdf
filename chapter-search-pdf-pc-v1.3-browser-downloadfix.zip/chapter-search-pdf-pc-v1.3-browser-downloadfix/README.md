# Chapter Search PDF PC v1.3

Version Windows navigateur.

Corrections principales :
- téléchargement PDF n'utilise plus uniquement `session.fetch` de Chromium ; les images sont récupérées par le moteur réseau Node avec les cookies de la session, le Referer et le User-Agent du navigateur visible ;
- `ERR_BLOCKED_BY_CLIENT` n'arrête plus immédiatement le chapitre ; une image en erreur est ignorée et les autres pages continuent ;
- validation réelle des images via Sharp avant ajout au PDF ;
- meilleure remontée des erreurs de téléchargement ;
- analyse série intelligente : si la page de chapitre ne contient que Précédent/Suivant, l'application cherche la page mère de la série puis récupère la liste complète sans quitter le navigateur visible ;
- interface navigateur plein écran conservée ;
- PDF du chapitre, Analyser la série, Télécharger la suite et téléchargements multiples conservés.

Sortie : `Téléchargements/Chapter Search PDF/`.

Build Windows : `npm run build:win`.
