# V6.0 — Universal Real-URL Multi-Engine

Cette version abandonne la stratégie qui inventait des URLs d'images.

Elle fonctionne à partir des URLs réellement présentes dans chaque page de chapitre.

## 5 moteurs par chapitre

1. Lecteur DOM : zones de lecture principales.
2. Lazy/Srcset : src, data-src, data-original, srcset, picture/source, etc.
3. HTML/JSON : URLs d'images présentes dans le code/payload.
4. Liens/CSS : href d'images et background-image/url(...).
5. Validation réseau : télécharge uniquement les vraies candidates, bascule vers Android natif si le WebView est refusé, puis élimine logos/icônes/petites images.

Les résultats sont fusionnés et dédoublonnés avant création du PDF.

## Multi-sites

Le numéro de chapitre est reconnu dans plusieurs formats :
- /chapter/10
- /chapitre/10
- set-it-chapter-10
- set-it-chapitre-10
- paramètres ?chapter=10 / ?chapitre=10

Ainsi Ortega, SushiScan et les sites utilisant des structures proches peuvent utiliser le même moteur.

## Parallèle x2

Deux chapitres restent traités en parallèle, avec contexte, images, pages PDF et mémoire séparés.
Aucune URL n'est devinée par incrément d'image.
