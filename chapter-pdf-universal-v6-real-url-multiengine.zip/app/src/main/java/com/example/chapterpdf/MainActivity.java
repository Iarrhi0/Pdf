package com.example.chapterpdf;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 9090;

    private File transferTemp;
    private FileOutputStream transferOut;
    private long transferExpected;
    private String transferName;
    private String transferMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStorageIfNeeded();
        createWebView();
    }

    private void requestStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    440
            );
        }
    }

    private void createWebView() {
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= 26) {
            web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new AndroidFilesBridge(), "AndroidFiles");
        web.addJavascriptInterface(new AndroidBrowserBridge(), "AndroidBrowser");
        web.addJavascriptInterface(new AndroidHttpBridge(), "AndroidHttp");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQ);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                boolean crashed = detail != null && detail.didCrash();

                runOnUiThread(() -> {
                    try {
                        view.removeJavascriptInterface("AndroidFiles");
                        view.removeJavascriptInterface("AndroidBrowser");
                        view.removeJavascriptInterface("AndroidHttp");
                        view.destroy();
                    } catch (Exception ignored) {
                    }

                    createWebView();
                    web.loadUrl("file:///android_asset/index.html");

                    web.postDelayed(() -> {
                        String msg = crashed
                                ? "Le moteur WebView a redémarré après un crash. Aucun chapitre distant n’est rendu dans cette version."
                                : "Android a redémarré le moteur WebView pour libérer de la mémoire.";
                        web.evaluateJavascript(
                                "(function(){const e=document.querySelector('.panel.active .status');if(e)e.textContent="
                                        + JSONObject.quote(msg) + ";})();",
                                null
                        );
                    }, 800);
                });

                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBrowserBridge {
        @JavascriptInterface
        public void open(String url) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    showMessage("Impossible d’ouvrir le navigateur : " + e.getMessage());
                }
            });
        }
    }


    private class AndroidHttpBridge {
        @JavascriptInterface
        public String fetchImage(String urlString, String referer) {
            HttpURLConnection conn = null;
            InputStream in = null;

            try {
                URL url = new URL(urlString);
                conn = (HttpURLConnection) url.openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(20000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                conn.setRequestProperty("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8");
                conn.setRequestProperty("Cache-Control", "no-cache");

                String ua = web != null ? web.getSettings().getUserAgentString() : null;
                if (ua != null && !ua.isEmpty()) {
                    conn.setRequestProperty("User-Agent", ua);
                }

                if (referer != null && !referer.isEmpty()) {
                    conn.setRequestProperty("Referer", referer);
                }

                String cookie = CookieManager.getInstance().getCookie(urlString);
                if (cookie != null && !cookie.isEmpty()) {
                    conn.setRequestProperty("Cookie", cookie);
                }

                int status = conn.getResponseCode();
                String mime = conn.getContentType();

                if (status < 200 || status >= 300) {
                    JSONObject out = new JSONObject();
                    out.put("ok", false);
                    out.put("status", status);
                    out.put("mime", mime == null ? "" : mime);
                    return out.toString();
                }

                in = conn.getInputStream();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();

                byte[] buffer = new byte[64 * 1024];
                int n;
                long total = 0;
                final long maxBytes = 32L * 1024L * 1024L;

                while ((n = in.read(buffer)) != -1) {
                    total += n;
                    if (total > maxBytes) {
                        throw new IllegalStateException("Image trop volumineuse (>32 Mo)");
                    }
                    bytes.write(buffer, 0, n);
                }

                byte[] data = bytes.toByteArray();

                if (data.length < 256) {
                    JSONObject out = new JSONObject();
                    out.put("ok", false);
                    out.put("status", status);
                    out.put("mime", mime == null ? "" : mime);
                    return out.toString();
                }

                JSONObject out = new JSONObject();
                out.put("ok", true);
                out.put("status", status);
                out.put("mime", mime == null ? "image/jpeg" : mime);
                out.put("base64", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
                return out.toString();

            } catch (Exception e) {
                try {
                    JSONObject out = new JSONObject();
                    out.put("ok", false);
                    out.put("status", 0);
                    out.put("error", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                    return out.toString();
                } catch (Exception ignored) {
                    return "{\"ok\":false,\"status\":0}";
                }
            } finally {
                try { if (in != null) in.close(); } catch (Exception ignored) {}
                if (conn != null) conn.disconnect();
            }
        }
    }

    private class AndroidFilesBridge {
        @JavascriptInterface
        public void begin(String name, String mime, long size) {
            synchronized (MainActivity.this) {
                closeTransferQuietly();

                try {
                    transferName = sanitizeName(name);
                    transferMime = (mime == null || mime.isEmpty())
                            ? "application/octet-stream"
                            : mime;
                    transferExpected = size;
                    transferTemp = new File(
                            getCacheDir(),
                            "web_" + System.currentTimeMillis() + ".tmp"
                    );
                    transferOut = new FileOutputStream(transferTemp);

                } catch (Exception e) {
                    showMessage("Erreur création fichier : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void chunk(String base64) {
            synchronized (MainActivity.this) {
                try {
                    if (transferOut == null) {
                        throw new IllegalStateException("Transfert non initialisé");
                    }

                    byte[] bytes = android.util.Base64.decode(
                            base64,
                            android.util.Base64.DEFAULT
                    );

                    transferOut.write(bytes);

                } catch (Exception e) {
                    closeTransferQuietly();
                    showMessage("Erreur transfert : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void progress(long sent, long total) {
            // Le moteur Web garde son propre état d'avancement.
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(() -> {
                try {
                    synchronized (MainActivity.this) {
                        if (transferOut != null) {
                            transferOut.flush();
                            transferOut.close();
                            transferOut = null;
                        }
                    }

                    if (transferTemp == null || !transferTemp.exists()) {
                        throw new IllegalStateException("Fichier temporaire absent");
                    }

                    if (transferExpected > 0 && transferTemp.length() != transferExpected) {
                        throw new IllegalStateException(
                                "Transfert incomplet : "
                                        + transferTemp.length()
                                        + "/"
                                        + transferExpected
                        );
                    }

                    boolean ok = saveToDownloads(
                            transferTemp,
                            transferName,
                            transferMime
                    );

                    if (!ok) {
                        throw new IllegalStateException("Enregistrement Android impossible");
                    }

                    transferTemp.delete();
                    transferTemp = null;

                } catch (Exception e) {
                    showMessage("Erreur finalisation : " + e.getMessage());
                } finally {
                    closeTransferQuietly();
                }
            });
        }

        @JavascriptInterface
        public void cancel(String message) {
            closeTransferQuietly();
            showMessage("Téléchargement annulé : " + message);
        }
    }

    private boolean saveToDownloads(File source, String name, String mime) {
        String relativeSubdir = "PDF_CONVERTIS/";

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    "Download/" + relativeSubdir
            );
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri == null) return false;

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 FileInputStream in = new FileInputStream(source)) {

                if (out == null) {
                    throw new IllegalStateException("Sortie indisponible");
                }

                byte[] buf = new byte[65536];
                int n;

                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;

            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                return false;
            }
        }

        File downloads = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
        );
        File folder = new File(downloads, relativeSubdir);
        folder.mkdirs();

        File output = new File(folder, name);

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output)) {

            byte[] buf = new byte[65536];
            int n;

            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }

            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private void showMessage(String message) {
        runOnUiThread(() -> {
            if (web == null) return;

            web.evaluateJavascript(
                    "(function(){const e=document.querySelector('.panel.active .status');if(e)e.textContent="
                            + JSONObject.quote(message == null ? "" : message)
                            + ";})();",
                    null
            );
        });
    }

    private synchronized void closeTransferQuietly() {
        try {
            if (transferOut != null) transferOut.close();
        } catch (Exception ignored) {
        }

        transferOut = null;
        transferExpected = 0;
    }

    private static String sanitizeName(String name) {
        String n = name == null ? "fichier.bin" : name;
        n = n.replaceAll("[\\\\/:*?\"<>|]+", "_").trim();
        return n.isEmpty() ? "fichier.bin" : n;
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        if (requestCode == FILE_CHOOSER_REQ) {
            Uri[] results = null;

            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];

                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }

                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }

            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }

            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        closeTransferQuietly();

        if (web != null) {
            try {
                web.removeJavascriptInterface("AndroidFiles");
                web.removeJavascriptInterface("AndroidBrowser");
                web.destroy();
            } catch (Exception ignored) {
            }
        }

        super.onDestroy();
    }
}
