# Chapter PDF Smart Android V2

## Utilisation
1. Colle le lien exact d'un chapitre.
2. Utilise `TÉLÉCHARGER CE CHAPITRE EN PDF` pour un seul chapitre.
3. Utilise `DÉMARRER TOUTE LA SUITE` pour enchaîner automatiquement les chapitres.
4. Si une vérification humaine apparaît, fais-la directement dans la WebView.
5. Une fois le PDF terminé, l'app passe automatiquement au bouton `Suivant` si l'option est activée.
6. Si aucun chapitre suivant n'existe, l'app indique :
   - `Fin de série détectée`
   - `En attente de la suite`
   - ou `Aucun chapitre suivant disponible`

## Dossier et noms
Les PDF sont enregistrés automatiquement dans :

`Téléchargements/PDF_CONVERTIS/Nom de la série/`

Exemple :
- `Set_It_Chapitre_001.pdf`
- `Set_It_Chapitre_002.pdf`
- `Set_It_Chapitre_024.5.pdf`

## Reprise intelligente
Avant de convertir, l'app vérifie si le PDF existe déjà dans le dossier de la série.
Un PDF de plus de 10 Ko est considéré comme terminé et peut être ignoré automatiquement.
Un fichier vide ou manifestement incomplet est régénéré.

## Correction principale V2
L'app ne télécharge plus les images avec OkHttp après leur affichage.
Elle construit un document WebView dédié à partir des images du chapitre déjà autorisées dans la même session/cookies, puis utilise le moteur d'impression Android pour créer le PDF.

Cela évite le problème de la V1 :
`Toutes les images ont échoué`.

## GitHub
Le projet fonctionne avec le workflow externe `unzip-and-build-apk.yml` que tu as déjà :
- place ce ZIP à la racine du dépôt ;
- place ton workflow dans `.github/workflows/` ;
- le workflow décompresse le ZIP ;
- détecte `settings.gradle.kts` ;
- build `:app:assembleDebug`.


## V2.1 - Correctif build
La V2 utilisait directement `PrintDocumentAdapter.LayoutResultCallback` et
`WriteResultCallback`. Android ne permet pas d'instancier ces callbacks depuis
l'application, ce qui faisait échouer la compilation Kotlin.

La V2.1 supprime complètement cette méthode.

Le PDF est maintenant produit directement avec `android.graphics.pdf.PdfDocument`
en dessinant la WebView préparée sur des pages PDF successives. Il n'y a donc
plus de dépendance aux callbacks internes du système d'impression.
