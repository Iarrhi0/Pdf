package com.example.chapterpdf

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var currentButton: Button
    private lateinit var allButton: Button
    private lateinit var stopButton: Button
    private lateinit var autoNextCheck: CheckBox
    private lateinit var skipExistingCheck: CheckBox
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var browser: WebView
    private lateinit var printer: WebView

    @Volatile private var running = false
    @Volatile private var autoMode = false
    @Volatile private var stopAfterCurrent = false
    @Volatile private var waitingCaptcha = false
    private var currentPageUrl = ""
    private var currentChapterIndex = 0
    private val visited = linkedSetOf<String>()

    private data class PageData(
        val url: String,
        val title: String,
        val series: String,
        val chapter: String,
        val captcha: Boolean,
        val images: List<String>,
        val next: String,
        val end: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestLegacyStorageIfNeeded()
        buildUi()
        configureWebViews()
    }

    private fun requestLegacyStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                901
            )
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 12)
        }

        val title = TextView(this).apply {
            text = "Chapitre → PDF → Suivant"
            textSize = 25f
            setTextColor(Color.WHITE)
        }

        urlInput = EditText(this).apply {
            hint = "Colle le lien du chapitre 1"
            setSingleLine(true)
            textSize = 17f
        }

        currentButton = Button(this).apply {
            text = "TÉLÉCHARGER CE CHAPITRE EN PDF"
        }

        allButton = Button(this).apply {
            text = "DÉMARRER TOUTE LA SUITE"
        }

        stopButton = Button(this).apply {
            text = "ARRÊTER APRÈS CE CHAPITRE"
        }

        autoNextCheck = CheckBox(this).apply {
            text = "Continuer automatiquement"
            isChecked = true
        }

        skipExistingCheck = CheckBox(this).apply {
            text = "Ignorer les PDF déjà terminés"
            isChecked = true
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }

        statusText = TextView(this).apply {
            text = "Prêt."
            textSize = 16f
            setPadding(0, 10, 0, 10)
        }

        browser = WebView(this)
        printer = WebView(this).apply {
            visibility = View.INVISIBLE
            alpha = 0f
        }

        root.addView(title)
        root.addView(urlInput)
        root.addView(currentButton)
        root.addView(allButton)
        root.addView(autoNextCheck)
        root.addView(skipExistingCheck)
        root.addView(stopButton)
        root.addView(progressBar, LinearLayout.LayoutParams.MATCH_PARENT, 20)
        root.addView(statusText)

        root.addView(
            browser,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0
            ).apply { weight = 1f }
        )

        root.addView(
            printer,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                1
            )
        )

        setContentView(root)

        currentButton.setOnClickListener {
            begin(auto = false)
        }

        allButton.setOnClickListener {
            begin(auto = true)
        }

        stopButton.setOnClickListener {
            stopAfterCurrent = true
            setStatus("Arrêt demandé. Le chapitre en cours sera terminé proprement.")
        }
    }

    private fun begin(auto: Boolean) {
        val url = urlInput.text.toString().trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            setStatus("Colle une URL de chapitre valide.")
            return
        }

        if (!running) {
            visited.clear()
            currentChapterIndex = 0
        }

        running = true
        autoMode = auto
        stopAfterCurrent = false
        waitingCaptcha = false
        loadChapter(url)
    }

    private fun configureWebViews() {
        val cookieManager = CookieManager.getInstance().apply {
            setAcceptCookie(true)
        }

        fun configure(w: WebView) {
            w.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                loadsImagesAutomatically = true
                blockNetworkImage = false
            }
            cookieManager.setAcceptThirdPartyCookies(w, true)
            w.webChromeClient = WebChromeClient()
        }

        configure(browser)
        configure(printer)

        browser.addJavascriptInterface(PageBridge(), "ChapterBridge")

        browser.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (!running) return
                currentPageUrl = url
                lifecycleScope.launch {
                    delay(800)
                    inspectAfterAutoScroll()
                }
            }
        }
    }

    private fun loadChapter(url: String) {
        if (!running) return

        if (!visited.add(url)) {
            setStatus("Boucle détectée : ce chapitre a déjà été visité. Arrêt.")
            running = false
            return
        }

        currentChapterIndex += 1
        currentPageUrl = url
        progressBar.progress = 5
        setStatus("Chargement du chapitre…\n$url")
        browser.visibility = View.VISIBLE
        browser.loadUrl(url)
    }

    private fun inspectAfterAutoScroll() {
        val js = """
            (async function(){
              function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
              let last=-1, stable=0;
              for(let i=0;i<70;i++){
                const h=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0);
                window.scrollBy(0,Math.max(300,window.innerHeight*0.8));
                await sleep(130);
                const y=window.scrollY+window.innerHeight;
                if(y>=h-20 || h===last) stable++; else stable=0;
                last=h;
                if(stable>=4)break;
              }
              await sleep(350);

              function abs(u){try{return new URL(u,location.href).href}catch(e){return ''}}

              function detectCaptcha(){
                const t=(document.body?.innerText||'').toLowerCase();
                return /captcha|verify you are human|checking your browser|just a moment|vérif(ier|ication).*(humain|robot)/i.test(t)
                  || !!document.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],[class*="captcha"],[id*="captcha"],[class*="turnstile"]');
              }

              function chapterImages(){
                const seen=new Set(), out=[];
                const selectors=['img'];
                document.querySelectorAll(selectors.join(',')).forEach(img=>{
                  let u=img.getAttribute('data-src')
                    || img.getAttribute('data-lazy-src')
                    || img.getAttribute('data-original')
                    || img.getAttribute('data-url')
                    || img.getAttribute('src')
                    || '';
                  if(!u && img.srcset)u=(img.srcset.split(',')[0]||'').trim().split(/\s+/)[0]||'';
                  u=abs(u);
                  if(!u || u.startsWith('data:') || seen.has(u))return;

                  const w=img.naturalWidth||img.width||0;
                  const h=img.naturalHeight||img.height||0;
                  if(w<180 || h<180)return;

                  const ratio=h/Math.max(1,w);
                  const alt=(img.alt||'').toLowerCase();
                  const cls=((img.className||'')+' '+(img.id||'')).toLowerCase();

                  let score=0;
                  if(ratio>0.7)score+=2;
                  if(h>=500)score+=3;
                  if(/page|chapter|scan|reader|manga|manhwa|webtoon/.test(alt+' '+cls+' '+u))score+=3;
                  if(/logo|avatar|icon|banner|discord|flag|ads?|pub/.test(alt+' '+cls+' '+u))score-=4;

                  if(score>=2){seen.add(u);out.push(u)}
                });
                return out;
              }

              function nextUrl(){
                const links=[...document.querySelectorAll('a[href]')].map(a=>{
                  const txt=((a.innerText||'')+' '+(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'')+' '+(a.rel||'')+' '+(a.className||'')).toLowerCase();
                  const href=abs(a.getAttribute('href'));
                  let s=0;
                  if(/\b(chapitre suivant|next chapter|chapter next|suivant|next)\b/.test(txt))s+=12;
                  if(/\b(précédent|precedent|previous|prev)\b/.test(txt))s-=25;
                  if(/\bnext\b/.test((a.rel||'').toLowerCase()))s+=15;
                  if(/chapter|chapitre|episode|\/ch[\/_-]?\d/i.test(href))s+=4;
                  return {href,score:s};
                }).filter(x=>x.href && x.href!==location.href && x.score>0);
                links.sort((a,b)=>b.score-a.score);
                return links[0]?.href||'';
              }

              function endState(){
                const t=(document.body?.innerText||'').toLowerCase();
                if(/coming soon|to be continued|à suivre|a suivre|suite.*bient[oô]t|prochain chapitre.*bient[oô]t|en attente de la suite/i.test(t))return 'waiting';
                if(/fin de (la )?(série|serie|manga|manhwa|webtoon)|the end|completed|terminé|termine/i.test(t))return 'finished';
                return 'unknown';
              }

              function chapterNumber(){
                const src=(document.querySelector('h1')?.innerText||'')+' '+document.title+' '+location.pathname;
                const m=src.match(/(?:chapter|chapitre|chap|ch|episode|ep)[\s/_#.-]*(\d+(?:[.,]\d+)?)/i)
                  || location.pathname.match(/\/chapter\/(\d+(?:[.,]\d+)?)/i);
                return m?m[1].replace(',','.'):'';
              }

              function seriesName(){
                const path=location.pathname.split('/').filter(Boolean);
                const ci=path.findIndex(x=>/^chapter$/i.test(x));
                let slug='';
                if(ci>0)slug=path[ci-1];
                if(!slug){
                  const crumb=[...document.querySelectorAll('a')].find(a=>/\/serie\//i.test(a.getAttribute('href')||''));
                  if(crumb)slug=(crumb.textContent||'').trim();
                }
                if(!slug)slug=(document.title||'Serie').replace(/chapter|chapitre\s*\d+.*/i,'').trim();
                return slug.replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim()||'Serie';
              }

              window.scrollTo(0,0);
              ChapterBridge.onPageData(JSON.stringify({
                url:location.href,
                title:(document.querySelector('h1')?.innerText||document.title||'Chapitre').trim(),
                series:seriesName(),
                chapter:chapterNumber(),
                captcha:detectCaptcha(),
                images:chapterImages(),
                next:nextUrl(),
                end:endState()
              }));
            })();
        """.trimIndent()

        browser.evaluateJavascript(js, null)
    }

    inner class PageBridge {
        @JavascriptInterface
        fun onPageData(raw: String) {
            runOnUiThread {
                try {
                    val j = JSONObject(raw)
                    val arr = j.optJSONArray("images") ?: JSONArray()
                    val images = mutableListOf<String>()
                    for (i in 0 until arr.length()) {
                        val u = arr.optString(i)
                        if (u.isNotBlank()) images.add(u)
                    }

                    val data = PageData(
                        url = j.optString("url"),
                        title = j.optString("title", "Chapitre"),
                        series = normalizeSeriesName(j.optString("series", "Serie")),
                        chapter = j.optString("chapter"),
                        captcha = j.optBoolean("captcha"),
                        images = images,
                        next = j.optString("next"),
                        end = j.optString("end", "unknown")
                    )

                    handlePageData(data)
                } catch (e: Exception) {
                    running = false
                    setStatus("Erreur d’analyse : ${e.message}")
                }
            }
        }
    }

    private fun handlePageData(data: PageData) {
        if (!running) return

        if (data.captcha) {
            waitingCaptcha = true
            progressBar.progress = 10
            setStatus(
                "Vérification humaine nécessaire.\n" +
                    "Fais le CAPTCHA directement dans la page ci-dessous. " +
                    "L’app vérifiera automatiquement quand la page normale revient."
            )
            lifecycleScope.launch {
                while (running && waitingCaptcha) {
                    delay(1800)
                    inspectAfterAutoScroll()
                    delay(600)
                }
            }
            return
        }

        waitingCaptcha = false

        val chapter = data.chapter.ifBlank {
            extractChapterFromUrl(data.url).ifBlank { currentChapterIndex.toString() }
        }

        val displayName = buildPdfName(data.series, chapter)

        lifecycleScope.launch {
            if (skipExistingCheck.isChecked && pdfAlreadyExists(data.series, displayName)) {
                progressBar.progress = 100
                setStatus("Déjà terminé : $displayName\nPassage à la suite…")
                continueOrFinish(data)
                return@launch
            }

            if (data.images.isEmpty()) {
                running = false
                setStatus(
                    "Aucune image de chapitre fiable détectée.\n" +
                        "La page reste visible pour vérification."
                )
                return@launch
            }

            progressBar.progress = 30
            setStatus(
                "${data.series} · chapitre $chapter\n" +
                    "${data.images.size} image(s) détectée(s).\n" +
                    "Préparation du PDF…"
            )

            try {
                val tempPdf = renderImagesWithWebView(
                    data.images,
                    data.url,
                    data.series,
                    chapter
                )

                progressBar.progress = 85
                val savedUri = savePdfToDownloads(
                    tempPdf,
                    data.series,
                    displayName
                )

                tempPdf.delete()
                progressBar.progress = 100

                setStatus(
                    "✓ PDF enregistré\n" +
                        "$displayName\n" +
                        "Dossier : Téléchargements/PDF_CONVERTIS/${data.series}/"
                )

                if (savedUri == null) {
                    running = false
                    setStatus("Échec de l’enregistrement du PDF.")
                    return@launch
                }

                continueOrFinish(data)
            } catch (e: Exception) {
                running = false
                setStatus("Erreur pendant la création du PDF : ${e.message}")
            }
        }
    }

    private suspend fun continueOrFinish(data: PageData) {
        if (stopAfterCurrent) {
            running = false
            setStatus(statusText.text.toString() + "\nArrêt demandé après ce chapitre.")
            return
        }

        val shouldContinue = autoMode && autoNextCheck.isChecked

        if (shouldContinue && data.next.isNotBlank()) {
            delay(700)
            loadChapter(data.next)
            return
        }

        running = false
        when {
            data.next.isNotBlank() && !shouldContinue ->
                setStatus(statusText.text.toString() + "\nChapitre suivant détecté : ${data.next}")

            data.end == "finished" ->
                setStatus(statusText.text.toString() + "\nFin de série détectée.")

            data.end == "waiting" ->
                setStatus(statusText.text.toString() + "\nEn attente de la suite.")

            else ->
                setStatus(statusText.text.toString() + "\nAucun chapitre suivant disponible.")
        }
    }
        }
    }


    private suspend fun renderImagesWithWebView(
        images: List<String>,
        baseUrl: String,
        series: String,
        chapter: String
    ): File = suspendCancellableCoroutine { cont ->

        val safeBase = baseUrl
            .replace("&", "&amp;")
            .replace("\"", "&quot;")

        val imageTags = images.joinToString("\n") { u ->
            val safe = u
                .replace("&", "&amp;")
                .replace("\"", "&quot;")

            """<img src="$safe" loading="eager" referrerpolicy="unsafe-url">"""
        }

        val html = """
            <!doctype html>
            <html>
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <base href="$safeBase">
              <style>
                html,body{
                  margin:0!important;
                  padding:0!important;
                  background:#fff!important;
                  width:100%!important;
                }
                .pages{
                  margin:0;
                  padding:0;
                  width:100%;
                }
                img{
                  display:block;
                  width:100%;
                  height:auto;
                  margin:0!important;
                  padding:0!important;
                  border:0!important;
                }
              </style>
            </head>
            <body>
              <div class="pages">$imageTags</div>
            </body>
            </html>
        """.trimIndent()

        var completed = false

        fun fail(error: Throwable) {
            if (!completed && cont.isActive) {
                completed = true
                cont.resumeWithException(error)
            }
        }

        printer.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)

                lifecycleScope.launch {
                    try {
                        // Wait for eager images and layout to settle.
                        delay(1800)

                        printer.evaluateJavascript(
                            """
                            (function(){
                              const imgs=[...document.images];
                              return JSON.stringify({
                                total:imgs.length,
                                ready:imgs.filter(x=>x.complete&&x.naturalWidth>0&&x.naturalHeight>0).length,
                                height:Math.max(
                                  document.body?.scrollHeight||0,
                                  document.documentElement?.scrollHeight||0
                                )
                              });
                            })();
                            """.trimIndent()
                        ) { raw ->
                            try {
                                val decoded = raw
                                    ?.removeSurrounding("\"")
                                    ?.replace("\\\"", "\"")
                                    ?.replace("\\\\", "\\")
                                    ?: "{}"

                                val info = JSONObject(decoded)
                                val total = info.optInt("total", 0)
                                val ready = info.optInt("ready", 0)
                                val contentHeight = info.optInt("height", 0)

                                if (ready <= 0 || total <= 0 || contentHeight <= 0) {
                                    fail(
                                        IllegalStateException(
                                            "Les images n’ont pas pu être préparées dans la WebView PDF."
                                        )
                                    )
                                    return@evaluateJavascript
                                }

                                progressBar.progress = 60
                                setStatus(
                                    "$series · chapitre $chapter\n" +
                                        "$ready/$total image(s) prêtes.\nCréation du PDF…"
                                )

                                lifecycleScope.launch {
                                    try {
                                        val file = renderWebViewDirectToPdf(
                                            printer,
                                            contentHeight,
                                            series,
                                            chapter
                                        )

                                        if (!completed && cont.isActive) {
                                            completed = true
                                            cont.resume(file)
                                        }
                                    } catch (e: Exception) {
                                        fail(e)
                                    }
                                }
                            } catch (e: Exception) {
                                fail(e)
                            }
                        }
                    } catch (e: Exception) {
                        fail(e)
                    }
                }
            }
        }

        printer.loadDataWithBaseURL(
            baseUrl,
            html,
            "text/html",
            "UTF-8",
            null
        )
    }

    private suspend fun renderWebViewDirectToPdf(
        webView: WebView,
        contentHeightCss: Int,
        series: String,
        chapter: String
    ): File = withContext(kotlinx.coroutines.Dispatchers.Main) {

        val pageWidth = 1080
        val pageHeight = 1920

        // Convert CSS height to the measured pixel height used by this WebView.
        webView.measure(
            View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )

        val measuredHeight = maxOf(
            webView.measuredHeight,
            contentHeightCss
        )

        webView.layout(
            0,
            0,
            pageWidth,
            measuredHeight
        )

        val pdf = PdfDocument()
        val temp = File(
            cacheDir,
            "chapter_${System.currentTimeMillis()}.pdf"
        )

        var top = 0
        var pageNumber = 1

        try {
            while (top < measuredHeight) {
                val sliceHeight = minOf(
                    pageHeight,
                    measuredHeight - top
                ).coerceAtLeast(1)

                val pageInfo = PdfDocument.PageInfo.Builder(
                    pageWidth,
                    sliceHeight,
                    pageNumber
                ).create()

                val page = pdf.startPage(pageInfo)
                val canvas = page.canvas

                canvas.save()
                canvas.translate(0f, -top.toFloat())
                webView.draw(canvas)
                canvas.restore()

                pdf.finishPage(page)

                top += sliceHeight
                pageNumber += 1

                progressBar.progress = minOf(
                    84,
                    60 + ((top.toFloat() / measuredHeight.toFloat()) * 24f).toInt()
                )
            }

            withContext(kotlinx.coroutines.Dispatchers.IO) {
                FileOutputStream(temp).use { output ->
                    pdf.writeTo(output)
                }
            }
        } finally {
            pdf.close()
        }

        temp
    }

    private suspend fun pdfAlreadyExists(
        series: String,
        displayName: String
    ): Boolean {
        return if (Build.VERSION.SDK_INT >= 29) {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val relative = "Download/PDF_CONVERTIS/$series/"
            val projection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.SIZE
            )
            val selection =
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
            val args = arrayOf(displayName, relative)

            contentResolver.query(
                collection,
                projection,
                selection,
                args,
                null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val id = c.getLong(0)
                    val size = c.getLong(1)
                    if (size > 10_000L) {
                        true
                    } else {
                        contentResolver.delete(
                            Uri.withAppendedPath(collection, id.toString()),
                            null,
                            null
                        )
                        false
                    }
                } else false
            } ?: false
        } else {
            val f = legacyOutputFile(series, displayName)
            f.exists() && f.length() > 10_000L
        }
    }

    private suspend fun savePdfToDownloads(
        source: File,
        series: String,
        displayName: String
    ): Uri? {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    "Download/PDF_CONVERTIS/$series/"
                )
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
            ) ?: return null

            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(source).use { input ->
                        input.copyTo(out)
                    }
                } ?: throw IllegalStateException("Impossible d’ouvrir le fichier de sortie")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                uri
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        } else {
            val out = legacyOutputFile(series, displayName)
            out.parentFile?.mkdirs()
            FileInputStream(source).use { input ->
                FileOutputStream(out).use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(out)
        }
    }

    private fun legacyOutputFile(
        series: String,
        displayName: String
    ): File {
        val root = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS
        )
        return File(
            root,
            "PDF_CONVERTIS/$series/$displayName"
        )
    }

    private fun buildPdfName(series: String, chapter: String): String {
        val cleanSeries = normalizeSeriesName(series)
            .replace(' ', '_')

        val number = chapter.trim()
            .replace(',', '.')
            .ifBlank { currentChapterIndex.toString() }

        val padded = if (number.contains('.')) {
            val parts = number.split('.', limit = 2)
            parts[0].padStart(3, '0') + "." + parts[1]
        } else {
            number.padStart(3, '0')
        }

        return "${cleanSeries}_Chapitre_$padded.pdf"
    }

    private fun normalizeSeriesName(raw: String): String {
        val clean = raw
            .replace(Regex("""[\\/:*?"<>|]+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

        return clean
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                word.lowercase(Locale.getDefault())
                    .replaceFirstChar { it.titlecase(Locale.getDefault()) }
            }
            .ifBlank { "Serie" }
    }

    private fun extractChapterFromUrl(url: String): String {
        return Regex(
            """(?:chapter|chapitre|chap|ch|episode|ep)[/_-]?(\d+(?:[.,]\d+)?)""",
            RegexOption.IGNORE_CASE
        ).find(url)?.groupValues?.getOrNull(1)
            ?.replace(',', '.')
            .orEmpty()
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }
}
