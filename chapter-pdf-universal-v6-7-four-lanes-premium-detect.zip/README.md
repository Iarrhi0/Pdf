# V6.7 — 4 Files + Premium / Fin

## 4 téléchargements simultanés indépendants
À partir du chapitre 24 :
- File A : 24 -> 28 -> 32 -> ...
- File B : 25 -> 29 -> 33 -> ...
- File C : 26 -> 30 -> 34 -> ...
- File D : 27 -> 31 -> 35 -> ...

Chaque file enregistre son PDF immédiatement puis passe à +4 sans attendre
les trois autres.

## États de fin
Avant l'extraction des images, l'application analyse l'état de la page :

- `PREMIUM` : le chapitre existe mais le contenu est verrouillé/payant.
  La file concernée s'arrête, sans toucher aux autres.
- `FIN` : 404/410 ou vraie page "chapter not found".
- `BLOQUÉ` : 403, 429 ou CAPTCHA ; jamais traité comme une fin.
- `ERREUR` : état ambigu / problème réseau.
- `OK` : le Multi-Engine continue normalement.

Le mode manuel affiche aussi `PREMIUM` ou `FIN`.

## Important
La sauvegarde rapide native V6.6 est conservée.
Chaque PDF garde son propre transferId, son propre MediaStore et son propre nom.
