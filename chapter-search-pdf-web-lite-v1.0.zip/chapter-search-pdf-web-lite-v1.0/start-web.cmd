@echo off
cd /d "%~dp0"
where python >nul 2>&1 || (echo Python 3 est requis pour la version source.& pause & exit /b 1)
python -m pip install -r requirements.txt
python server.py
