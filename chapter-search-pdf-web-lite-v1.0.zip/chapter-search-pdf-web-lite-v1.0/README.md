# Chapter Search PDF Web Lite v1.0

Version web locale légère : pas d'Electron, pas de Chromium embarqué.

## Mode recommandé
Utilisez l'artefact **PORTABLE-WINDOWS** généré par GitHub Actions : extrayez le ZIP puis lancez `ChapterSearchPdfWebLite.exe`. Le navigateur s'ouvre automatiquement sur `http://127.0.0.1:5173`.

## Mode source
Python 3.11+ : `pip install -r requirements.txt` puis `python server.py`.

## Principes
- 2 chapitres simultanés par défaut, réglable 1–4.
- Analyse de série S1–S4 + consolidation multi-moteur légère.
- APK40 lecteur strict + JAVA5-LITE fallback HTML.
- Aucun rendu JavaScript/Chromium : un site qui ne livre ses pages qu'après exécution JS peut échouer dans Web Lite.
- Sessions HTTP persistantes, User-Agent mobile, Referer et cookies.
- Tolérance aux pages invalides, contrôle qualité avant SAVED.
- PDF créé progressivement sur disque.
- Tâches : pause, reprise, relance, arrêt, suppression.
- CPU/RAM/débit affichés dans l'interface.

## Sortie
`Téléchargements/Chapter Search PDF Web/<Série>/`
