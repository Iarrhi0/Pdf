import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import extract_images, analyze_series_html

def test_reader_prefers_data_src():
    h='''<html><div class="reading-content"><div class="page-break"><img src="https://x/logo-loading.png" data-src="https://cdn.x/page-001.jpg"></div><div class="page-break"><img src="https://x/logo-loading.png" data-src="https://cdn.x/page-002.jpg"></div></div></html>'''
    u,e=extract_images(h,'https://x/chapter-1/')
    assert u==['https://cdn.x/page-001.jpg','https://cdn.x/page-002.jpg']

def test_series_strict_container():
    h='''<h1>Beautiful Days</h1><div class="wp-manga-chapter"><a href="/beautiful-days-chapitre-1/">Chapitre 1</a></div><div class="wp-manga-chapter"><a href="/beautiful-days-chapitre-2/">Chapitre 2</a></div><a href="/other-chapter-99/">Chapitre 99</a>'''
    r=analyze_series_html(h,'https://sushiscan.fr/catalogue/beautiful-days/')
    assert [x['number'] for x in r['chapters']]==[1.0,2.0]
if __name__=='__main__':
    test_reader_prefers_data_src();test_series_strict_container();print('OK')
