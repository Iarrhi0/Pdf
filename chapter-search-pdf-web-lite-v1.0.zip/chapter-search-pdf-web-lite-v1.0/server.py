from __future__ import annotations
import hashlib, html as htmlmod, io, json, os, re, shutil, socket, subprocess, sys, threading, time, traceback, uuid, webbrowser
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, asdict
from http import HTTPStatus
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urljoin, urlparse, parse_qs, unquote

import psutil
import requests
from bs4 import BeautifulSoup
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

APP_NAME = "Chapter Search PDF Web Lite"
VERSION = "1.0.0"
HOST = "127.0.0.1"
DEFAULT_PORT = 5173
DEFAULT_CONCURRENCY = 2
MAX_CONCURRENCY = 4
PHONE_UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36"
BAD_IMAGE_TOKENS = ("logo", "avatar", "icon", "sprite", "emoji", "advert", "banner", "tracking", "pixel", "favicon", "header", "footer", "cover", "thumbnail", "thumb", "gravatar", "placeholder", "loading", "lazyload", "blank", "spacer", "transparent", "default-image")
CHAPTER_RE = re.compile(r"(?:chapter|chapitre|ch\.?|tome|volume|vol\.?)[\s_\-:#]*(\d+(?:\.\d+)?)", re.I)

if getattr(sys, 'frozen', False):
    BASE_DIR = Path(sys._MEIPASS)
    RUN_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent
    RUN_DIR = BASE_DIR
WEB_DIR = BASE_DIR / "web"
CONFIG_DIR = BASE_DIR / "config"


def default_download_root() -> Path:
    home = Path.home()
    downloads = home / "Downloads"
    if not downloads.exists(): downloads = home
    out = downloads / "Chapter Search PDF Web"
    out.mkdir(parents=True, exist_ok=True)
    return out

OUTPUT_ROOT = default_download_root()


def safe_name(s: str, fallback="Serie") -> str:
    s = re.sub(r"[<>:\\/*?\"|]", "_", (s or "").strip())
    s = re.sub(r"\s+", " ", s).strip(" .")
    return (s[:120] or fallback)


def norm_text(s: str) -> str:
    s = htmlmod.unescape(s or "").lower()
    s = re.sub(r"[^a-z0-9à-ÿ]+", " ", s, flags=re.I)
    return re.sub(r"\s+", " ", s).strip()


def chapter_number(text: str, url: str = ""):
    hay = f"{text} {unquote(url)}"
    m = CHAPTER_RE.search(hay)
    if m:
        try: return float(m.group(1))
        except: pass
    # fallback trailing number when explicit chapter page
    m = re.search(r"(?:^|[-_/])(\d+(?:\.\d+)?)(?:[-_/]|$)", urlparse(url).path)
    if m and re.search(r"chapter|chapitre|tome|volume|vol", hay, re.I):
        try: return float(m.group(1))
        except: pass
    return None


def is_http_url(u: str) -> bool:
    try: return urlparse(u).scheme in ("http", "https") and bool(urlparse(u).netloc)
    except: return False


def make_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": PHONE_UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.7",
        "Connection": "keep-alive",
    })
    return s


def fetch_html(url: str, session=None, timeout=25):
    s = session or make_session()
    r = s.get(url, timeout=timeout, allow_redirects=True)
    r.raise_for_status()
    if "text/html" not in (r.headers.get("content-type", "").lower()) and "<html" not in r.text[:500].lower():
        raise ValueError("La ressource n'est pas une page HTML")
    return r.text, r.url, s


def same_origin(a: str, b: str) -> bool:
    try: return urlparse(a).netloc.lower() == urlparse(b).netloc.lower()
    except: return False


def canonical_series_name(soup: BeautifulSoup, url: str) -> str:
    selectors = ["h1", ".post-title h1", ".c-breadcrumb li:nth-last-child(2)", ".breadcrumb li:nth-last-child(2)"]
    title = ""
    for sel in selectors:
        n = soup.select_one(sel)
        if n and n.get_text(" ", strip=True):
            title = n.get_text(" ", strip=True); break
    if not title:
        title = soup.title.get_text(" ", strip=True) if soup.title else Path(urlparse(url).path).stem
    title = re.sub(r"\s*[-–—:]?\s*(?:chapter|chapitre|tome|volume|vol\.?)\s*\d+(?:\.\d+)?\b.*$", "", title, flags=re.I).strip(" -–—:")
    return title or "Série"


def derive_slug_hint(url: str, series_name: str) -> str:
    p = urlparse(url).path.strip("/").lower()
    parts = p.split("/")
    if "catalogue" in parts:
        i=parts.index("catalogue")
        if i+1<len(parts): return parts[i+1]
    if "porncomic" in parts:
        i=parts.index("porncomic")
        if i+1<len(parts): return parts[i+1]
    slug = re.sub(r"[^a-z0-9]+", "-", norm_text(series_name)).strip("-")
    return slug


def candidate_series_pages(soup, base_url, series_name):
    out=[]
    # explicit links saying all chapters / catalogue / series
    keywords=("tous les chapitres", "all chapters", "tous les volumes", "catalogue", "série", "serie")
    for a in soup.select("a[href]"):
        txt=norm_text(a.get_text(" ", strip=True))
        href=urljoin(base_url,a.get("href",""))
        if not is_http_url(href) or not same_origin(href,base_url): continue
        if any(k in txt for k in keywords): out.append(href)
    # SushiScan canonical catalogue guess only as fallback
    host=urlparse(base_url).netloc.lower()
    if "sushiscan" in host:
        slug=re.sub(r"[^a-z0-9]+","-",norm_text(series_name)).strip("-")
        if slug: out.append(urljoin(base_url, f"/catalogue/{slug}/"))
    return list(dict.fromkeys(out))[:8]


def analyze_series_html(html: str, base_url: str, engine_prefix="S"):
    soup=BeautifulSoup(html,"html.parser")
    series_name=canonical_series_name(soup,base_url)
    slug_hint=derive_slug_hint(base_url,series_name)
    found={}
    engines=[]

    def add(a, engine, bonus=0):
        href=urljoin(base_url,a.get("href") or a.get("value") or "")
        txt=a.get_text(" ",strip=True) if hasattr(a,"get_text") else ""
        if not is_http_url(href) or not same_origin(href,base_url): return
        n=chapter_number(txt,href)
        if n is None: return
        path=urlparse(href).path.lower()
        score=bonus
        if slug_hint and slug_hint in path: score+=5
        if re.search(r"chapter|chapitre|tome|volume|vol", f"{txt} {path}", re.I): score+=3
        if any(x in path for x in ("/tag/","/category/","/author/","/artist/")): score-=5
        cur=found.get(n)
        item={"number":n,"title":txt or f"Chapitre {n:g}","url":href,"engine":engine,"score":score}
        if cur is None or item["score"]>cur["score"]: found[n]=item

    # S1 strict known chapter containers
    strict_selectors=[".wp-manga-chapter a[href]", ".chapter-list a[href]", ".chapters a[href]", ".listing-chapters_wrap a[href]", ".eph-num a[href]", ".row-content-chapter a[href]"]
    for sel in strict_selectors:
        nodes=soup.select(sel)
        if nodes:
            engines.append("S1")
            for a in nodes: add(a,"S1",10)
    # S2 select/options (common on reader pages)
    nodes=soup.select("select option[value]")
    good=0
    for o in nodes:
        if chapter_number(o.get_text(" ",strip=True),o.get("value","")) is not None:
            add(o,"S2",8); good+=1
    if good: engines.append("S2")
    # S3 anchors constrained by slug / chapter terms
    count_before=len(found)
    for a in soup.select("a[href]"):
        href=urljoin(base_url,a.get("href","")); txt=a.get_text(" ",strip=True)
        if slug_hint and slug_hint not in urlparse(href).path.lower() and slug_hint not in re.sub(r"[^a-z0-9]+","-",norm_text(txt)):
            continue
        add(a,"S3",3)
    if len(found)>count_before: engines.append("S3")
    # S4 scripts / JSON urls
    before=len(found)
    for sc in soup.find_all("script"):
        text=sc.string or sc.get_text(" ") or ""
        for raw in re.findall(r"https?://[^\s\"'<>\\]+", text):
            if not same_origin(raw,base_url): continue
            n=chapter_number("",raw)
            if n is None: continue
            class Dummy:
                def get(self,k,d=""): return raw if k in ("href","value") else d
                def get_text(self,*a,**k): return f"Chapitre {n:g}"
            add(Dummy(),"S4",1)
    if len(found)>before: engines.append("S4")

    items=[x for x in found.values() if x["score"]>=3]
    items.sort(key=lambda x:x["number"])
    return {"series":series_name,"chapters":items,"engine":"MULTI "+"-".join(dict.fromkeys(engines or ["S3"]))}


def analyze_series(url: str):
    html, final, session=fetch_html(url)
    result=analyze_series_html(html,final)
    if len(result["chapters"])<2:
        soup=BeautifulSoup(html,"html.parser")
        for series_url in candidate_series_pages(soup,final,result["series"]):
            try:
                h2,f2,_=fetch_html(series_url,session=session)
                r2=analyze_series_html(h2,f2)
                if len(r2["chapters"])>len(result["chapters"]):
                    result=r2; result["engine"] += "+BREADCRUMB"
            except Exception:
                pass
    result["source_url"]=final
    return result


def pick_image_url(img, base_url):
    attrs=("data-src","data-lazy-src","data-original","data-cfsrc","data-url","data-image","src")
    for a in attrs:
        u=(img.get(a) or "").strip()
        if u and not u.startswith("data:"):
            return urljoin(base_url,u.split()[0])
    srcset=(img.get("data-srcset") or img.get("srcset") or "").strip()
    if srcset:
        parts=[p.strip().split()[0] for p in srcset.split(",") if p.strip()]
        if parts: return urljoin(base_url,parts[-1])
    return ""


def bad_image_url(u):
    l=u.lower()
    if not is_http_url(u): return True
    return any(t in l for t in BAD_IMAGE_TOKENS)


def extract_images(html: str, base_url: str):
    soup=BeautifulSoup(html,"html.parser")
    selectors=[
        ".reading-content .page-break img", ".reading-content img", ".page-break img",
        "#readerarea img", ".reader-area img", ".readerarea img", ".ts_reader img",
        ".chapter-content img", ".chapter-images img", ".container-chapter-reader img",
        ".chapter-body img", ".manga-reader img", ".comic-reader img", ".viewer img", ".webtoon-reader img"
    ]
    best=[]; bestsel=""
    for sel in selectors:
        urls=[]
        for img in soup.select(sel):
            u=pick_image_url(img,base_url)
            if u and not bad_image_url(u): urls.append(u)
        urls=list(dict.fromkeys(urls))
        if len(urls)>len(best): best,bestsel=urls,sel
    if len(best)>=2:
        return best, f"APK40:{bestsel}"
    # Lite fallback: all plausible images but only same dominant host/path group
    allu=[]
    for img in soup.select("img"):
        u=pick_image_url(img,base_url)
        if u and not bad_image_url(u): allu.append(u)
    allu=list(dict.fromkeys(allu))
    groups={}
    for u in allu:
        p=urlparse(u)
        key=(p.netloc.lower(), str(Path(p.path).parent).lower())
        groups.setdefault(key,[]).append(u)
    if groups:
        best=max(groups.values(),key=len)
    return best, "JAVA5-LITE"


def validate_image_bytes(buf: bytes):
    h=hashlib.sha256(buf).hexdigest()
    try:
        im=Image.open(io.BytesIO(buf)); im.load()
        w,hgt=im.size
        fmt=(im.format or "").upper()
        if w<250 or hgt<350 or w*hgt<150_000: return None
        # reject tiny suspicious payloads unless dimensions clearly large
        if len(buf)<12_000 and w*hgt<500_000: return None
        return {"width":w,"height":hgt,"format":fmt,"sha256":h}
    except Exception:
        return None


def add_image_page(pdf, buf: bytes, meta):
    w,h=meta["width"],meta["height"]
    # points at 72 dpi while preserving ratio, cap width to A4-ish but page can be long
    page_w=595.0
    page_h=max(842.0, page_w*h/max(w,1))
    pdf.setPageSize((page_w,page_h))
    try:
        pdf.drawImage(ImageReader(io.BytesIO(buf)),0,0,width=page_w,height=page_h,preserveAspectRatio=True,anchor='c')
    except Exception:
        im=Image.open(io.BytesIO(buf)).convert("RGB")
        out=io.BytesIO(); im.save(out,"JPEG",quality=92,optimize=False); out.seek(0)
        pdf.drawImage(ImageReader(out),0,0,width=page_w,height=page_h,preserveAspectRatio=True,anchor='c')
    pdf.showPage()

@dataclass
class Task:
    id: str
    series: str
    number: float
    title: str
    url: str
    state: str="QUEUED"
    processed: int=0
    total: int=0
    valid: int=0
    ignored: int=0
    progress: float=0
    speed_bps: float=0
    error: str=""
    output: str=""
    engine: str=""
    created: float=field(default_factory=time.time)
    started: float=0
    ended: float=0
    pause: threading.Event=field(default_factory=threading.Event, repr=False)
    cancel: threading.Event=field(default_factory=threading.Event, repr=False)
    bytes_done: int=0
    _last_bytes: int=0
    _last_t: float=field(default_factory=time.time, repr=False)
    def public(self):
        d=asdict(self)
        d.pop("pause",None); d.pop("cancel",None); d.pop("_last_bytes",None); d.pop("_last_t",None)
        return d

class TaskManager:
    def __init__(self):
        self.tasks={}; self.lock=threading.RLock(); self.concurrency=DEFAULT_CONCURRENCY
        self.executor=ThreadPoolExecutor(max_workers=MAX_CONCURRENCY,thread_name_prefix="down")
        self.active=set(); self.scheduler=threading.Thread(target=self._loop,daemon=True); self.scheduler.start()
    def set_concurrency(self,n):
        self.concurrency=max(1,min(MAX_CONCURRENCY,int(n)))
    def add_many(self,series,chapters):
        ids=[]
        with self.lock:
            existing={(t.url,t.number) for t in self.tasks.values() if t.state not in ("DELETED",)}
            for c in chapters:
                key=(c["url"],float(c["number"]))
                if key in existing: continue
                tid=uuid.uuid4().hex[:10]
                t=Task(tid,series,float(c["number"]),c.get("title") or f"Chapitre {c['number']}",c["url"])
                self.tasks[tid]=t; ids.append(tid); existing.add(key)
        return ids
    def _loop(self):
        while True:
            try:
                with self.lock:
                    self.active={i for i in self.active if i in self.tasks and self.tasks[i].state in ("LOAD","ANALYZE","DOWNLOAD","PDF")}
                    slots=self.concurrency-len(self.active)
                    queued=[t for t in self.tasks.values() if t.state=="QUEUED"][:max(0,slots)]
                    for t in queued:
                        t.state="LOAD"; self.active.add(t.id); self.executor.submit(self._run,t.id)
            except Exception: pass
            time.sleep(.25)
    def _wait_pause(self,t):
        while t.pause.is_set() and not t.cancel.is_set():
            t.state="PAUSED"; time.sleep(.2)
        if not t.cancel.is_set() and t.state=="PAUSED": t.state="DOWNLOAD"
    def _run(self,tid):
        with self.lock: t=self.tasks.get(tid)
        if not t: return
        t.started=time.time(); tmp=None
        try:
            s=make_session(); t.state="LOAD"
            html,final,s=fetch_html(t.url,s); t.url=final
            if t.cancel.is_set(): raise InterruptedError("Arrêté")
            t.state="ANALYZE"
            urls,engine=extract_images(html,final); t.engine=engine; t.total=len(urls)
            if len(urls)<2: raise RuntimeError(f"Seulement {len(urls)} image(s) candidate(s)")
            series_dir=OUTPUT_ROOT/safe_name(t.series); series_dir.mkdir(parents=True,exist_ok=True)
            filename=f"{safe_name(t.series)} - Chapitre {t.number:g}.pdf"
            final_path=series_dir/filename; tmp=series_dir/(filename+".part")
            pdf=canvas.Canvas(str(tmp),pageCompression=1)
            seen=set(); valid_bytes=0; t.state="DOWNLOAD"
            for idx,u in enumerate(urls,1):
                self._wait_pause(t)
                if t.cancel.is_set(): raise InterruptedError("Arrêté")
                try:
                    r=s.get(u,headers={"Referer":final,"User-Agent":PHONE_UA,"Accept":"image/avif,image/webp,image/apng,image/*,*/*;q=0.8"},timeout=20)
                    if r.status_code==416:
                        r=s.get(u,headers={"Referer":final,"User-Agent":PHONE_UA,"Range":"bytes=0-"},timeout=20)
                    r.raise_for_status(); buf=r.content
                    meta=validate_image_bytes(buf)
                    if not meta or meta["sha256"] in seen:
                        t.ignored+=1
                    else:
                        seen.add(meta["sha256"]); add_image_page(pdf,buf,meta); t.valid+=1; valid_bytes+=len(buf)
                    t.bytes_done+=len(buf)
                except Exception:
                    t.ignored+=1
                t.processed=idx; t.progress=idx/max(t.total,1)
                now=time.time(); dt=max(.001,now-t._last_t)
                if dt>=.5:
                    t.speed_bps=(t.bytes_done-t._last_bytes)/dt; t._last_bytes=t.bytes_done; t._last_t=now
            t.state="PDF"; pdf.save()
            ratio=t.valid/max(t.total,1)
            avg=valid_bytes/max(t.valid,1)
            if t.valid<2 or (t.total>=5 and ratio<.60) or (t.valid>=10 and avg<18_000):
                raise RuntimeError(f"Qualité insuffisante: {t.valid}/{t.total} vraies pages")
            if final_path.exists(): final_path.unlink()
            tmp.replace(final_path); t.output=str(final_path); t.state="SAVED"; t.ended=time.time()
        except InterruptedError:
            t.state="STOPPED"; t.error="Arrêté"; t.ended=time.time()
            if tmp and tmp.exists(): tmp.unlink(missing_ok=True)
        except Exception as e:
            t.state="ERROR"; t.error=str(e); t.ended=time.time()
            try:
                if tmp and tmp.exists(): tmp.unlink(missing_ok=True)
            except: pass
        finally:
            with self.lock: self.active.discard(tid)
    def action(self,tid,action):
        with self.lock: t=self.tasks.get(tid)
        if not t: return False,"Tâche introuvable"
        if action=="pause": t.pause.set(); return True,"En pause"
        if action=="resume": t.pause.clear();
        if action=="retry":
            if t.state in ("ERROR","STOPPED","SAVED"):
                t.cancel=threading.Event(); t.pause.clear(); t.state="QUEUED"; t.error=""; t.processed=t.valid=t.ignored=0; t.progress=0; t.bytes_done=0
            return True,"Relancée"
        if action=="cancel": t.cancel.set(); return True,"Arrêt demandé"
        if action=="delete":
            t.cancel.set();
            with self.lock: self.tasks.pop(tid,None); self.active.discard(tid)
            return True,"Supprimée"
        return True,"OK"

MANAGER=TaskManager()
START_TIME=time.time(); PROC=psutil.Process(os.getpid()); _cpu_last=(time.time(), PROC.cpu_times().user+PROC.cpu_times().system)


def stats():
    global _cpu_last
    now=time.time(); c=PROC.cpu_times(); cur=c.user+c.system; dt=max(.001,now-_cpu_last[0]); cpu=max(0,min(100,(cur-_cpu_last[1])/dt*100/max(psutil.cpu_count() or 1,1))); _cpu_last=(now,cur)
    with MANAGER.lock:
        tasks=list(MANAGER.tasks.values())
    speed=sum(t.speed_bps for t in tasks if t.state=="DOWNLOAD")
    return {"cpu_app":round(cpu,1),"cpu_pc":psutil.cpu_percent(interval=None),"ram_app":PROC.memory_info().rss,"ram_pc":psutil.virtual_memory().percent,"speed":speed,"active":sum(t.state in ("LOAD","ANALYZE","DOWNLOAD","PDF") for t in tasks),"down":sum(t.state=="DOWNLOAD" for t in tasks),"queued":sum(t.state=="QUEUED" for t in tasks),"errors":sum(t.state=="ERROR" for t in tasks),"concurrency":MANAGER.concurrency,"uptime":now-START_TIME}


def load_sources():
    try: return json.loads((CONFIG_DIR/"sources.json").read_text(encoding="utf-8"))["sources"]
    except: return []


def search_sources(q):
    q=q.strip(); out=[]
    if not q: return out
    def one(src):
        if not src.get("enabled",True): return []
        try:
            u=src["search"].replace("{q}",requests.utils.quote(q)); h,final,_=fetch_html(u,timeout=12); soup=BeautifulSoup(h,"html.parser")
            res=[]; seen=set()
            for a in soup.select("a[href]"):
                txt=a.get_text(" ",strip=True); href=urljoin(final,a.get("href",""))
                if len(txt)<2 or not same_origin(href,src["base"]): continue
                if norm_text(q) not in norm_text(txt): continue
                key=(txt,href)
                if key in seen: continue
                seen.add(key); res.append({"source":src["name"],"title":txt[:120],"url":href})
                if len(res)>=8: break
            return res
        except: return []
    with ThreadPoolExecutor(max_workers=min(4,len(load_sources()) or 1)) as ex:
        for batch in ex.map(one,load_sources()): out.extend(batch)
    return out[:30]

class Handler(SimpleHTTPRequestHandler):
    server_version="ChapterSearchPDFWebLite/1.0"
    def translate_path(self,path):
        raw=super().translate_path(path)
        rel=os.path.relpath(raw,os.getcwd())
        return str(WEB_DIR/rel)
    def log_message(self,fmt,*args): pass
    def _json(self,obj,status=200):
        data=json.dumps(obj,ensure_ascii=False).encode("utf-8")
        self.send_response(status); self.send_header("Content-Type","application/json; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(data)
    def _body(self):
        n=int(self.headers.get("content-length","0") or 0); raw=self.rfile.read(n) if n else b"{}"
        return json.loads(raw.decode("utf-8") or "{}")
    def do_GET(self):
        p=urlparse(self.path)
        if p.path=="/api/health": return self._json({"ok":True,"app":APP_NAME,"version":VERSION})
        if p.path=="/api/tasks":
            with MANAGER.lock: arr=[t.public() for t in sorted(MANAGER.tasks.values(),key=lambda x:x.created,reverse=True)]
            return self._json(arr)
        if p.path=="/api/stats": return self._json(stats())
        if p.path=="/api/settings": return self._json({"concurrency":MANAGER.concurrency,"max":MAX_CONCURRENCY,"output":str(OUTPUT_ROOT)})
        if p.path=="/api/search": return self._json(search_sources(parse_qs(p.query).get("q",[""])[0]))
        if p.path.startswith("/api/pdf/"):
            tid=p.path.rsplit("/",1)[-1]
            with MANAGER.lock: t=MANAGER.tasks.get(tid)
            if not t or not t.output or not Path(t.output).exists(): return self._json({"error":"PDF introuvable"},404)
            data=Path(t.output).read_bytes(); self.send_response(200); self.send_header("Content-Type","application/pdf"); self.send_header("Content-Disposition",f'attachment; filename="{Path(t.output).name}"'); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        return super().do_GET()
    def do_POST(self):
        p=urlparse(self.path)
        try: b=self._body()
        except Exception as e: return self._json({"error":"JSON invalide"},400)
        if p.path=="/api/analyze":
            try: return self._json(analyze_series(b.get("url","").strip()))
            except Exception as e: return self._json({"error":str(e)},400)
        if p.path=="/api/queue":
            series=b.get("series") or "Série"; chapters=b.get("chapters") or []
            ids=MANAGER.add_many(series,chapters); return self._json({"added":len(ids),"ids":ids})
        if p.path=="/api/settings":
            MANAGER.set_concurrency(b.get("concurrency",DEFAULT_CONCURRENCY)); return self._json({"ok":True,"concurrency":MANAGER.concurrency})
        if p.path=="/api/open-folder":
            path=Path(b.get("path") or OUTPUT_ROOT)
            try:
                if os.name=="nt": subprocess.Popen(["explorer",str(path)])
                elif sys.platform=="darwin": subprocess.Popen(["open",str(path)])
                else: subprocess.Popen(["xdg-open",str(path)])
                return self._json({"ok":True})
            except Exception as e: return self._json({"error":str(e)},500)
        m=re.match(r"/api/tasks/([a-f0-9]+)/([a-z]+)$",p.path)
        if m:
            ok,msg=MANAGER.action(m.group(1),m.group(2)); return self._json({"ok":ok,"message":msg},200 if ok else 404)
        return self._json({"error":"Route inconnue"},404)


def find_port(start=DEFAULT_PORT):
    for p in range(start,start+30):
        with socket.socket() as s:
            try: s.bind((HOST,p)); return p
            except OSError: continue
    raise RuntimeError("Aucun port local disponible")


def main():
    port=find_port(int(os.getenv("CSPDF_PORT",DEFAULT_PORT)))
    os.chdir(WEB_DIR)
    server=ThreadingHTTPServer((HOST,port),Handler)
    url=f"http://{HOST}:{port}"
    print(f"{APP_NAME} {VERSION} -> {url}")
    if os.getenv("CSPDF_NO_BROWSER")!="1": threading.Timer(.7,lambda:webbrowser.open(url)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass

if __name__=="__main__": main()
