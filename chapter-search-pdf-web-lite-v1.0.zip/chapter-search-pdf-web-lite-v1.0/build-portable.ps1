$ErrorActionPreference = 'Stop'
python -m pip install -r requirements.txt
python tests/test_extract.py
pyinstaller --noconfirm --clean --onedir --name ChapterSearchPdfWebLite --add-data "web;web" --add-data "config;config" server.py
Write-Host "Portable build: dist/ChapterSearchPdfWebLite"
