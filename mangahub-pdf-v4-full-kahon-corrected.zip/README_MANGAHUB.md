# MangaHub PDF 4.0 — Full Kahon Edition

This ZIP is a complete Android project. `gradlew` is at the ZIP root.

Core behavior:
- full Kahon/Mihon source + extension manager/store runtime;
- install/update/remove compatible extension APKs dynamically;
- browse/search through installed extension sources;
- 10 concurrent chapter jobs with immediate slot refill;
- extension page parser first, MangaHub generic AUTO ENGINE fallback second;
- persistent Kahon temporary page downloads/resume;
- one PDF per chapter;
- `.part.pdf` -> `.pdf` finalization;
- existing PDF/CBZ recognized as already downloaded;
- manual Cloudflare/CAPTCHA behavior remains handled by Kahon; no bypass.

GitHub Actions workflow included: `.github/workflows/build-mangahub-pdf.yml` (JDK 25).
