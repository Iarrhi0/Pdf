const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const web=$('#web');
let sources=[], searchBuckets=[], currentChapters=[], batchPaused=false, engineScripts=null, currentChapterNumber=null;

function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function setStatus(s){$('#status').textContent=s;}
function toast(s,ms=3300){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove('show'),ms);}
function normalizeUrl(v){v=(v||'').trim();if(!v)return '';if(/^https?:\/\//i.test(v))return v;if(/^[a-z0-9.-]+\.[a-z]{2,}(?:\/.*)?$/i.test(v))return 'https://'+v;return 'https://www.google.com/search?q='+encodeURIComponent(v+' manga manhwa webtoon chapter');}
function currentUrl(){try{return web.getURL()||$('#urlBox').value.trim();}catch{return $('#urlBox').value.trim();}}
function extractNumber(s=''){let m=String(s).match(/(?:chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=String(s).match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?parseFloat(m[1]):null;}

function closeDrawers(){['metaDrawer','seriesDrawer','downloadsDrawer'].forEach(id=>$('#'+id).classList.remove('open'));$('#overlay').classList.remove('open');}
function openDrawer(id){closeDrawers();$('#'+id).classList.add('open');$('#overlay').classList.add('open');}
$$('[data-close]').forEach(b=>b.onclick=closeDrawers);$('#overlay').onclick=closeDrawers;
$('#seriesDrawerBtn').onclick=()=>openDrawer('seriesDrawer');$('#downloadsBtn').onclick=()=>openDrawer('downloadsDrawer');$('#metaBtn').onclick=()=>openDrawer('metaDrawer');

function home(){
  const html=`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#0b1020;color:#f5f7ff;font-family:Segoe UI,Arial,sans-serif;display:grid;place-items:center;min-height:100vh}.wrap{width:min(760px,90vw)}h1{font-size:34px;margin:0 0 8px}.sub{color:#9fb0cc;margin-bottom:26px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.c{background:#121a2e;border:1px solid #263455;border-radius:15px;padding:18px}.c b{display:block;margin-bottom:6px}.c span{font-size:13px;color:#9fb0cc}@media(max-width:700px){.cards{grid-template-columns:1fr}}</style><div class="wrap"><h1>Chapter Search PDF</h1><div class="sub">Navigue normalement. Quand tu es sur un chapitre, utilise les boutons de l’application au-dessus de la page.</div><div class="cards"><div class="c"><b>⬇ PDF du chapitre</b><span>Analyse les vraies pages du lecteur puis crée un PDF.</span></div><div class="c"><b>☰ Analyser la série</b><span>Détecte les chapitres numérotés et affiche la liste sans quitter le navigateur.</span></div><div class="c"><b>⇥ Télécharger la suite</b><span>Sélectionne le chapitre courant et les suivants pour le téléchargement multiple.</span></div></div></div>`;
  web.src='data:text/html;charset=utf-8,'+encodeURIComponent(html);$('#urlBox').value='';setStatus('Prêt');
}
function openInBrowser(raw){const url=normalizeUrl(raw);if(!url)return;closeDrawers();$('#urlBox').value=url;try{web.loadURL(url);}catch{web.src=url;}}
$('#goBtn').onclick=()=>openInBrowser($('#urlBox').value);$('#urlBox').addEventListener('keydown',e=>{if(e.key==='Enter')openInBrowser($('#urlBox').value);});
$('#backBtn').onclick=()=>{try{if(web.canGoBack())web.goBack();}catch{}};$('#forwardBtn').onclick=()=>{try{if(web.canGoForward())web.goForward();}catch{}};$('#reloadBtn').onclick=()=>{try{web.reload();}catch{}};$('#homeBtn').onclick=home;
web.addEventListener('did-start-loading',()=>{$('#loadingLine').classList.add('active');setStatus('Chargement…');});
web.addEventListener('did-stop-loading',()=>{$('#loadingLine').classList.remove('active');setStatus('Page chargée');});
web.addEventListener('did-navigate',e=>{$('#urlBox').value=e.url.startsWith('data:')?'':e.url;currentChapterNumber=extractNumber(e.url);});
web.addEventListener('did-navigate-in-page',e=>{$('#urlBox').value=e.url;currentChapterNumber=extractNumber(e.url);});
web.addEventListener('page-title-updated',e=>{currentChapterNumber=currentChapterNumber??extractNumber(e.title);});
web.addEventListener('did-fail-load',e=>{if(e.errorCode===-3)return;setStatus('Erreur de chargement');});

async function ensureScripts(){if(!engineScripts)engineScripts=await window.chapterAPI.getEngineScripts();return engineScripts;}
async function runOnVisible(script){if(!currentUrl()||currentUrl().startsWith('data:'))throw new Error('Ouvre d’abord une vraie page.');return web.executeJavaScript(script,true);}

async function analyzeChapterVisible(download=true){
  const url=currentUrl();if(!url||url.startsWith('data:')){toast('Ouvre d’abord un chapitre.');return null;}
  const btn=$('#chapterPdfBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Analyse du chapitre…';
  try{
    const s=await ensureScripts();setStatus('ANALYSE • rendu complet du chapitre…');
    await runOnVisible(s.force);await sleep(1800);await web.executeJavaScript("window.scrollTo(0,0);'ok';",true).catch(()=>null);await sleep(850);
    let p=await runOnVisible(s.chapter);if(typeof p==='string')p=JSON.parse(p);
    if(!p?.ok||!Array.isArray(p.images)||p.images.length<2)throw new Error(p?.reason||'Page non reconnue comme chapitre');
    currentChapterNumber=p.number?parseFloat(p.number):currentChapterNumber;setStatus(`ANALYSE OK • ${p.series} • ${p.chapter} • ${p.images.length} pages`);
    if(!download)return p;
    btn.textContent=`Création PDF • ${p.images.length} pages`;
    const target=await window.chapterAPI.downloadChapter(url,p);toast('PDF enregistré : '+target,5200);setStatus('PDF enregistré • '+p.chapter);return p;
  }catch(e){toast('Échec : '+(e.message||e),5200);setStatus('Échec analyse');return null;}finally{btn.disabled=false;btn.textContent=old;}
}
$('#chapterPdfBtn').onclick=()=>analyzeChapterVisible(true);

async function analyzeSeriesVisible(){
  const url=currentUrl();if(!url||url.startsWith('data:')){toast('Ouvre d’abord une page de série ou de chapitre.');return;}
  const btn=$('#seriesAnalyzeBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Analyse de la série…';
  try{
    const s=await ensureScripts();setStatus('ANALYSE SÉRIE • recherche des chapitres numérotés…');
    let list=await runOnVisible(s.series);if(typeof list==='string')list=JSON.parse(list);
    if(!Array.isArray(list)||!list.length)throw new Error('Aucun chapitre numéroté détecté sur cette page');
    currentChapters=list;const exact=currentChapters.find(c=>c.url===url);if(exact)currentChapterNumber=Number(exact.number);if(currentChapterNumber==null)currentChapterNumber=extractNumber(url);
    renderChapters();$('#chapterCount').textContent=currentChapters.length;$('#nextBatchBtn').disabled=false;openDrawer('seriesDrawer');setStatus(`SÉRIE • ${currentChapters.length} chapitres détectés`);
  }catch(e){toast('Échec : '+(e.message||e),5200);setStatus('Aucun chapitre fiable détecté');}finally{btn.disabled=false;btn.textContent=old;}
}
$('#seriesAnalyzeBtn').onclick=analyzeSeriesVisible;

function renderChapters(){
  const el=$('#chapters');if(!currentChapters.length){el.innerHTML='';$('#chapterSummary').innerHTML='<div class="small">Aucune série analysée.</div>';return;}
  const first=currentChapters[0],last=currentChapters[currentChapters.length-1];
  $('#chapterSummary').innerHTML=`<b>${esc(first.series||'Série')}</b><div class="small">${currentChapters.length} chapitres • ${esc(first.number)} → ${esc(last.number)}${currentChapterNumber!=null?` • chapitre courant ${esc(currentChapterNumber)}`:''}</div>`;
  el.innerHTML=currentChapters.map((c,i)=>`<div class="chapRow"><input type="checkbox" class="chapCheck" data-i="${i}"><b>#${esc(c.number)}</b><div><div>${esc(c.title||('Chapitre '+c.number))}</div><div class="chapUrl">${esc(c.url)}</div></div><button class="mini openChap" data-i="${i}">Ouvrir</button></div>`).join('');
  selectNext();$$('.openChap').forEach(b=>b.onclick=()=>{const c=currentChapters[+b.dataset.i];openInBrowser(c.url);closeDrawers();});
}
function selectNext(){const n=currentChapterNumber;$$('.chapCheck').forEach(x=>{const c=currentChapters[+x.dataset.i];x.checked=n==null?true:Number(c.number)>=Number(n);});}
$('#selectAll').onclick=()=>$$('.chapCheck').forEach(x=>x.checked=true);$('#selectNone').onclick=()=>$$('.chapCheck').forEach(x=>x.checked=false);$('#selectNext').onclick=selectNext;
async function startSelected(jobs){if(!jobs.length){toast('Aucun chapitre sélectionné.');return;}openDrawer('downloadsDrawer');$('#downloads').innerHTML='';$('#batchSummary').textContent=`0/${jobs.length} terminé • jusqu’à 10 simultanés`;setStatus(`Téléchargement série • ${jobs.length} chapitres`);await window.chapterAPI.startBatch(jobs);}
$('#downloadSelected').onclick=()=>{const jobs=$$('.chapCheck').filter(x=>x.checked).map(x=>currentChapters[+x.dataset.i]);startSelected(jobs);};
$('#nextBatchBtn').onclick=()=>{if(!currentChapters.length){analyzeSeriesVisible();return;}const n=currentChapterNumber;const jobs=currentChapters.filter(c=>n==null||Number(c.number)>=Number(n));startSelected(jobs);};

window.chapterAPI.onBatchProgress(p=>{let row=$(`#worker-${p.slot}`);if(!row){row=document.createElement('div');row.className='downloadRow';row.id=`worker-${p.slot}`;$('#downloads').appendChild(row);}const cls=p.state==='SAVED'?'goodText':p.state==='ERROR'?'badText':'';row.innerHTML=`<b>W${p.slot}</b><div><div>${esc(p.title||p.url||'')}</div><div class="small">${p.page?`page ${p.page}/${p.pages||'?'} • `:''}${esc(p.error||'')}</div></div><div class="downloadState ${cls}">${esc(p.state)}</div>`;$('#batchSummary').textContent=`Chapitre ${p.index}/${p.total} • ${p.state}`;});
window.chapterAPI.onBatchComplete(r=>{$('#batchSummary').textContent=`Terminé • ${r.done} OK • ${r.failed} erreur(s)${r.stopped?' • arrêté':''}`;setStatus('Téléchargement terminé');});
$('#pauseBtn').onclick=async()=>{batchPaused=!batchPaused;await window.chapterAPI.pauseBatch(batchPaused);$('#pauseBtn').textContent=batchPaused?'Reprendre':'Pause';};$('#stopBtn').onclick=()=>window.chapterAPI.stopBatch();
$('#openFolderBtn').onclick=$('#openFolderBtn2').onclick=()=>window.chapterAPI.openDownloads();

function updateActive(){const n=sources.filter(s=>s.enabled).length;$('#activeCount').textContent=n;}
function renderSources(){const el=$('#sourceList');el.innerHTML=sources.map((s,i)=>`<div class="sourceToggle"><div><b style="font-size:11px">${esc(s.name)}</b><div class="small">${esc(s.domain)} • ${esc(s.lang)}</div></div><div class="switch ${s.enabled?'on':''}" data-si="${i}"></div></div>`).join('');$$('[data-si]').forEach(sw=>sw.onclick=async()=>{const i=+sw.dataset.si;sources[i].enabled=!sources[i].enabled;await window.chapterAPI.saveSources(sources);renderSources();});updateActive();}
function renderMetaResults(){const arr=[];for(const b of searchBuckets)for(const r of b.results)arr.push({...r,source:b.source});$('#resCount').textContent=arr.length;$('#metaResults').innerHTML=arr.length?arr.map(r=>`<div class="result"><div class="resultTitle">${esc(r.title||r.source.name)}</div><div class="small">${esc(r.source.name)} • ${esc(r.source.domain)}</div><div class="resultActions"><button class="mini openMeta" data-url="${esc(r.url)}">Ouvrir</button><button class="mini primary analyzeMeta" data-url="${esc(r.url)}">Ouvrir + série</button></div></div>`).join(''):'<div class="small">Aucun résultat.</div>';$$('.openMeta').forEach(b=>b.onclick=()=>openInBrowser(b.dataset.url));$$('.analyzeMeta').forEach(b=>b.onclick=()=>{openInBrowser(b.dataset.url);closeDrawers();setTimeout(analyzeSeriesVisible,1800);});}
async function doMetaSearch(){const q=$('#metaQ').value.trim();if(!q)return;const active=sources.filter(s=>s.enabled);$('#scanned').textContent=`0/${active.length}`;$('#metaSearchBtn').disabled=true;searchBuckets=[];renderMetaResults();try{searchBuckets=await window.chapterAPI.metaSearch(q,sources);renderMetaResults();}finally{$('#metaSearchBtn').disabled=false;}}
$('#metaSearchBtn').onclick=doMetaSearch;$('#metaQ').addEventListener('keydown',e=>{if(e.key==='Enter')doMetaSearch();});window.chapterAPI.onMetaProgress(p=>$('#scanned').textContent=`${p.done}/${p.total}`);
$('#toggleAll').onclick=async()=>{const allOn=sources.every(s=>s.enabled);sources.forEach(s=>s.enabled=!allOn);await window.chapterAPI.saveSources(sources);renderSources();};
$('#injectBtn').onclick=()=>{$('#injectModal').style.display='flex';};$('#closeInject').onclick=()=>{$('#injectModal').style.display='none';};
$('#confirmInject').onclick=async()=>{const raw=$('#injectText').value.trim();let arr=[];try{if(raw.startsWith('[')||raw.startsWith('{')){const j=JSON.parse(raw);arr=Array.isArray(j)?j:[j];}else{arr=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map(x=>{try{const u=new URL(/^https?:\/\//i.test(x)?x:'https://'+x);return{name:u.hostname,domain:u.hostname.replace(/^www\./,''),lang:'?',type:'multi',enabled:true};}catch{return null}}).filter(Boolean);}sources=await window.chapterAPI.injectSources(arr);renderSources();$('#injectModal').style.display='none';toast('Sources ajoutées.');}catch(e){toast('Liste invalide : '+e.message);}};

(async()=>{sources=await window.chapterAPI.getSources();renderSources();await ensureScripts();home();})();
