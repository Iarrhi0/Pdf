# Chapter Search PDF PC v1.2

Version Windows orientée navigateur, alignée sur le fonctionnement de la version Android.

## Interface
- Navigateur plein écran comme vue principale.
- Barre Précédent / Suivant / Actualiser / Accueil / adresse ou recherche.
- `PDF du chapitre` : analyse la page actuellement ouverte et crée un PDF avec les images du lecteur.
- `Analyser la série` : détecte les chapitres numérotés sur la page et ouvre un panneau latéral sans quitter le navigateur.
- `Télécharger la suite` : sélectionne le chapitre courant et les chapitres suivants.
- Téléchargement par lots jusqu’à 10 chapitres en parallèle.
- Recherche multi-sites conservée dans un panneau secondaire.

## Correction importante v1.2
Le démarrage utilise maintenant un chemin absolu basé sur `__dirname` pour charger `index.html`. Cela corrige `ERR_FILE_NOT_FOUND` dans l’EXE portable/packagé.

## Build
```bash
npm install
npm run build:win
```

Les exécutables sont générés dans `dist/`.
