const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('chapterAPI', {
  getSources:()=>ipcRenderer.invoke('sources:get'),
  saveSources:s=>ipcRenderer.invoke('sources:save',s),
  injectSources:s=>ipcRenderer.invoke('sources:inject',s),
  metaSearch:(query,sources)=>ipcRenderer.invoke('meta:search',{query,sources}),
  analyzeChapter:url=>ipcRenderer.invoke('chapter:analyze',url),
  analyzeSeries:url=>ipcRenderer.invoke('series:analyze',url),
  downloadChapter:(url,payload)=>ipcRenderer.invoke('chapter:download',{url,payload}),
  pdfExists:(series,chapter)=>ipcRenderer.invoke('pdf:exists',{series,chapter}),
  openDownloads:()=>ipcRenderer.invoke('downloads:open'),
  openExternal:url=>ipcRenderer.invoke('external:open',url),
  startBatch:jobs=>ipcRenderer.invoke('batch:start',jobs),
  pauseBatch:v=>ipcRenderer.invoke('batch:pause',v),
  stopBatch:()=>ipcRenderer.invoke('batch:stop'),
  onMetaProgress:cb=>ipcRenderer.on('meta:progress',(_e,x)=>cb(x)),
  onBatchProgress:cb=>ipcRenderer.on('batch:progress',(_e,x)=>cb(x)),
  onBatchComplete:cb=>ipcRenderer.on('batch:complete',(_e,x)=>cb(x))
});
