const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { PDFDocument } = require('pdf-lib');
const sharp = require('sharp');
const { FORCE_LAZY_LOAD, EXTRACT_CHAPTER_PAYLOAD, EXTRACT_CHAPTERS } = require('./assets/engine-scripts');

const SEARCH_CONCURRENCY = 20;
const DOWNLOAD_CONCURRENCY = 10;
let mainWindow;
let batchState = { stopped: false, paused: false };

function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }
function sanitize(s){
  let x = String(s || 'Chapitre').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim();
  if (x.length > 140) x = x.slice(0, 140).trim();
  return x || 'Chapitre';
}
function buildPdfName(series, chapter){
  const s = sanitize(series || 'Série');
  const c = sanitize(chapter || 'Chapitre');
  return c.toLowerCase().startsWith(s.toLowerCase()) ? `${c}.pdf` : `${sanitize(`${s} - ${c}`)}.pdf`;
}
function downloadDir(){ return path.join(app.getPath('downloads'), 'Chapter Search PDF'); }
function ensureDir(){ fs.mkdirSync(downloadDir(), { recursive: true }); }
function userSourcesPath(){ return path.join(app.getPath('userData'), 'sources.json'); }
function defaultSourcesPath(){ return path.join(__dirname, 'assets', 'sources.json'); }
function loadSources(){
  const p = userSourcesPath();
  if (!fs.existsSync(p)) fs.copyFileSync(defaultSourcesPath(), p);
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return JSON.parse(fs.readFileSync(defaultSourcesPath(), 'utf8')); }
}
function saveSources(sources){ fs.writeFileSync(userSourcesPath(), JSON.stringify(sources, null, 2), 'utf8'); return sources; }
function decodeHtml(s=''){ return s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>'); }
function unwrapDdg(href){
  try {
    const u = new URL(decodeHtml(href), 'https://html.duckduckgo.com');
    if (u.searchParams.has('uddg')) return decodeURIComponent(u.searchParams.get('uddg'));
    return u.href;
  } catch { return decodeHtml(href); }
}
async function searchOneSource(source, query){
  const q = `site:${source.domain} ${query}`;
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 10000);
  try {
    const res = await session.defaultSession.fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'Mozilla/5.0 ChapterSearchPDF/1.0', 'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8' }
    });
    if (!res.ok) return { source, ok:false, status:res.status, results:[] };
    const html = await res.text();
    const rx = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    const out=[]; let m;
    while ((m=rx.exec(html)) && out.length < 5) {
      const link = unwrapDdg(m[1]);
      const title = decodeHtml(m[2].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
      try {
        const host = new URL(link).hostname.replace(/^www\./,'');
        if (host === source.domain || host.endsWith('.'+source.domain) || source.domain.endsWith('.'+host)) out.push({title, url:link});
      } catch {}
    }
    return { source, ok:true, results:out };
  } catch (e) { return { source, ok:false, error:String(e.message||e), results:[] }; }
  finally { clearTimeout(timer); }
}
async function pooled(items, concurrency, fn){
  let index=0; const out=new Array(items.length);
  async function worker(){ while(true){ const i=index++; if(i>=items.length) break; out[i]=await fn(items[i], i); } }
  await Promise.all(Array.from({length:Math.min(concurrency,items.length)}, worker));
  return out;
}
async function loadAndExtract(url, mode='chapter'){
  const win = new BrowserWindow({
    show:false, width:1000, height:800,
    webPreferences:{ contextIsolation:true, nodeIntegration:false, backgroundThrottling:false, images:true }
  });
  try {
    await win.loadURL(url, { userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36' });
    await sleep(800);
    await win.webContents.executeJavaScript(FORCE_LAZY_LOAD, true).catch(()=>null);
    await sleep(1000);
    const raw = await win.webContents.executeJavaScript(mode==='series' ? EXTRACT_CHAPTERS : EXTRACT_CHAPTER_PAYLOAD, true);
    return typeof raw === 'string' ? JSON.parse(raw) : raw;
  } finally { if (!win.isDestroyed()) win.destroy(); }
}
async function fetchImage(url, referer){
  const headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36' };
  if (referer) headers.Referer = referer;
  const res = await session.defaultSession.fetch(url, { headers });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const arr = await res.arrayBuffer();
  const buf = Buffer.from(arr);
  if (buf.length < 1024) throw new Error('Image trop petite/invalide');
  return buf;
}
async function createPdfFromImages(payload, sourceUrl, onProgress=()=>{}){
  ensureDir();
  const filename = buildPdfName(payload.series, payload.chapter);
  const target = path.join(downloadDir(), filename);
  const pdf = await PDFDocument.create();
  let done=0;
  for (let i=0;i<payload.images.length;i++){
    while(batchState.paused && !batchState.stopped) await sleep(250);
    if(batchState.stopped) throw new Error('Téléchargement arrêté');
    onProgress({state:'DOWNLOAD', current:i+1, total:payload.images.length});
    const raw = await fetchImage(payload.images[i], sourceUrl);
    const converted = await sharp(raw).rotate().jpeg({quality:92, mozjpeg:true}).toBuffer({ resolveWithObject:true });
    const img = await pdf.embedJpg(converted.data);
    const w = converted.info.width || img.width, h = converted.info.height || img.height;
    const page = pdf.addPage([w,h]); page.drawImage(img,{x:0,y:0,width:w,height:h}); done++;
  }
  onProgress({state:'PDF', current:done, total:payload.images.length});
  fs.writeFileSync(target, await pdf.save());
  return target;
}
async function downloadChapterJob(job, slot, index, total){
  const send = (state, extra={}) => mainWindow?.webContents.send('batch:progress',{slot,index,total,url:job.url,title:job.title,state,...extra});
  send('LOAD');
  const payload = await loadAndExtract(job.url, 'chapter');
  if (!payload?.ok || !Array.isArray(payload.images) || payload.images.length < 2) throw new Error(payload?.reason || 'Chapitre non reconnu');
  send('ANALYSE',{pages:payload.images.length,series:payload.series,chapter:payload.chapter});
  const target = await createPdfFromImages(payload, job.url, p=>send(p.state,{page:p.current,pages:p.total}));
  send('SAVED',{target}); return target;
}

function createWindow(){
  mainWindow = new BrowserWindow({
    width:1440, height:900, minWidth:980, minHeight:650,
    title:'Chapter Search PDF',
    webPreferences:{ preload:path.join(__dirname,'preload.js'), contextIsolation:true, nodeIntegration:false, webviewTag:true, backgroundThrottling:false }
  });
  mainWindow.loadFile('index.html');
}

app.whenReady().then(()=>{
  session.defaultSession.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));
  createWindow();
  app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});

ipcMain.handle('sources:get',()=>loadSources());
ipcMain.handle('sources:save',(_e,s)=>saveSources(s));
ipcMain.handle('sources:inject',(_e,incoming)=>{
  const base=loadSources(); const map=new Map(base.map(x=>[x.domain,x]));
  for(const x of incoming||[]){ if(x?.domain) map.set(x.domain,{enabled:true,lang:'?',type:'multi',...x}); }
  return saveSources([...map.values()]);
});
ipcMain.handle('meta:search',async(_e,{query,sources})=>{
  let done=0;
  const active=(sources||loadSources()).filter(s=>s.enabled);
  const results=await pooled(active,SEARCH_CONCURRENCY,async(source)=>{
    const r=await searchOneSource(source,query); done++;
    mainWindow?.webContents.send('meta:progress',{done,total:active.length,source:source.name,ok:r.ok,count:r.results.length});
    return r;
  });
  return results;
});
ipcMain.handle('chapter:analyze',async(_e,url)=>loadAndExtract(url,'chapter'));
ipcMain.handle('series:analyze',async(_e,url)=>loadAndExtract(url,'series'));
ipcMain.handle('chapter:download',async(_e,{url,payload})=>createPdfFromImages(payload,url));
ipcMain.handle('pdf:exists',(_e,{series,chapter})=>fs.existsSync(path.join(downloadDir(),buildPdfName(series,chapter))));
ipcMain.handle('downloads:open',()=>{ensureDir(); return shell.openPath(downloadDir());});
ipcMain.handle('external:open',(_e,url)=>shell.openExternal(url));
ipcMain.handle('batch:pause',(_e,v)=>{batchState.paused=!!v; return batchState;});
ipcMain.handle('batch:stop',()=>{batchState.stopped=true; return batchState;});
ipcMain.handle('batch:start',async(_e,jobs)=>{
  batchState={stopped:false,paused:false};
  let next=0, done=0, failed=0; const total=jobs.length;
  const workers=Array.from({length:Math.min(DOWNLOAD_CONCURRENCY,total)},(_,slot)=> (async()=>{
    while(true){
      if(batchState.stopped) break;
      const i=next++; if(i>=total) break;
      try{ await downloadChapterJob(jobs[i],slot+1,i+1,total); done++; }
      catch(err){ failed++; mainWindow?.webContents.send('batch:progress',{slot:slot+1,index:i+1,total,url:jobs[i].url,title:jobs[i].title,state:'ERROR',error:String(err.message||err)}); }
    }
  })());
  await Promise.all(workers);
  const result={done,failed,total,stopped:batchState.stopped};
  mainWindow?.webContents.send('batch:complete',result);
  return result;
});
