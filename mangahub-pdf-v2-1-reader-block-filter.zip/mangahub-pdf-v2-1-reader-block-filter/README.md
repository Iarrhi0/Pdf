# MangaHub PDF — Final V1

Application Android indépendante du Chapter PDF Downloader.

Fonctions incluses :
- Recherche réseau réelle SushiScan + OrtegaScans (plusieurs points d'entrée tolérants)
- Fiches séries et détection des chapitres
- Extraction des images de lecture depuis les URLs réelles présentes dans la page
- Téléchargements natifs concurrents (pool de 10 tâches)
- Cache page par page pour éviter de retélécharger les pages déjà présentes
- Génération PDF Android native sans marge, une image par page
- Sauvegarde immédiate dans Downloads/MangaHub PDF
- États ANALYSE / DOWNLOAD / PDF / SAVED / BLOQUE / ERREUR
- Bibliothèque locale
- Écran Sources et test des dépôts d'extensions Mihon/Kahon

Important : les sites externes peuvent modifier leur HTML, bloquer une requête ou imposer Cloudflare. L'app ne contourne ni CAPTCHA ni protections d'accès.
