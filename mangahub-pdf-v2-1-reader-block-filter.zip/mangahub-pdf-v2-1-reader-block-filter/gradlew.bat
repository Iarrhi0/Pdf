@echo off
set V=8.9
set D=%USERPROFILE%\.gradle\manual-wrapper\gradle-%V%
set Z=%USERPROFILE%\.gradle\manual-wrapper\gradle-%V%-bin.zip
if not exist "%D%\bin\gradle.bat" powershell -NoProfile -Command "New-Item -ItemType Directory -Force (Split-Path '%Z%'); Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%V%-bin.zip' -OutFile '%Z%'; Expand-Archive -Force '%Z%' (Split-Path '%D%')"
call "%D%\bin\gradle.bat" %*
