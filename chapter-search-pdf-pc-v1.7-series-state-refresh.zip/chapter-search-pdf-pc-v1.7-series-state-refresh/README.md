# Chapter Search PDF PC v1.7

## Correctif état des séries

- Quand tu ouvres une série différente, la liste de chapitres de l’ancienne série est vidée immédiatement.
- La navigation entre deux chapitres de la même série conserve la liste actuelle.
- Analyser la série vide d’abord l’ancienne analyse : si la nouvelle analyse échoue, aucun ancien chapitre n’est réaffiché.
- Nouveau bouton `Actualiser la série` dans la barre principale et dans le panneau des chapitres.
- Actualiser force une nouvelle analyse de la page courante et déduplique les URL détectées.
- Le compteur Chapitres revient à 0 lors d’un changement de série.

## Correction recherche multi-moteur

La recherche ne dépend plus uniquement d’un moteur web externe. Par source, l’application essaie maintenant :

1. API structurée quand disponible, notamment MangaDex et Comick
2. moteur de recherche interne du site
3. catalogue ou index natif, notamment SushiScan `/catalogue/list-mode/`
4. URL directe par slug pour plusieurs sources
5. index web externe uniquement en dernier recours

Les résultats sont scorés, dédupliqués et les pages de série sont favorisées par rapport aux chapitres isolés.

Cas de contrôle : une recherche `City Hunter` doit pouvoir remonter `City Hunter – Ultime` et `City Hunter Rebirth` sur SushiScan si le site est accessible.

# Chapter Search PDF PC v1.5

Version PC navigateur avec file persistante multi séries et extraction multi moteur.

## Multi moteur E1 → E5

- E1 : lecteur DOM connu / conteneur principal
- E2 : analyse géométrique des images rendues
- E3 : extraction depuis scripts / JSON embarqués
- E4 : ressources réellement chargées par le navigateur via Performance API
- E5 : fusion hybride, déduplication, scoring multi moteur et validation réseau réelle avant PDF

## Vitesse et concurrence

- 20 sources simultanées pour la méta recherche
- jusqu’à 10 chapitres simultanés
- jusqu’à 5 chapitres actifs par série pour éviter qu’une seule série monopolise la file
- 4 pages téléchargées simultanément par chapitre
- plafond global de 24 requêtes image simultanées
- extraction navigateur invisible limitée à 5 workers pour maîtriser RAM/CPU
- répartition round-robin entre séries

## File multi séries

1. Ouvre une série dans le navigateur.
2. Clique sur Analyser la série.
3. Sélectionne les chapitres.
4. Clique sur Ajouter à la file.
5. Navigue vers une deuxième ou troisième série et recommence.
6. Ouvre File séries puis Démarrer.

La file est enregistrée dans les données de l'application. Les tâches RUNNING redeviennent QUEUED après redémarrage.

## Sortie

`Téléchargements/Chapter Search PDF/<Nom de la série>/`

Chaque chapitre est écrit d'abord en `.part`, puis renommé en `.pdf` uniquement après assemblage complet.

Utilise uniquement des contenus que tu as le droit de télécharger.


## Correctifs v1.5
- Scheduler auto-réparant : plus d’état EN COURS avec 0 worker et des tâches en attente.
- Relance automatique des workers lors de l’ajout d’une nouvelle série ou d’un nouveau lot.
- Affichage des tâches en attente dans la file.
- Compteur de workers actifs.
- Diagnostic demandé/ajouté/doublons pour Télécharger la suite.
- Normalisation des URL pour éviter les doublons artificiels.
