const { app, BrowserWindow, ipcMain, shell, session } = require('electron');
const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');
const sharp = require('sharp');
const { FORCE_LAZY_LOAD, EXTRACT_CHAPTER_PAYLOAD, EXTRACT_CHAPTERS, FIND_SERIES_PAGE, EXTRACT_MULTI_ENGINE } = require('./assets/engine-scripts');

const SEARCH_CONCURRENCY = 20;
const CHAPTER_CONCURRENCY = 10;
const EXTRACT_CONCURRENCY = 5;
const PAGE_CONCURRENCY_PER_CHAPTER = 4;
const GLOBAL_IMAGE_CONCURRENCY = 24;
const MAX_ACTIVE_PER_SERIES = 5;
const MAX_ACTIVE_PER_HOST = 6;

let mainWindow;
let persistTimer=null;

class Semaphore {
  constructor(limit){ this.limit=limit; this.active=0; this.waiters=[]; }
  async acquire(){
    if(this.active < this.limit){ this.active++; return; }
    await new Promise(r=>this.waiters.push(r)); this.active++;
  }
  release(){ this.active=Math.max(0,this.active-1); const r=this.waiters.shift(); if(r)r(); }
  async use(fn){ await this.acquire(); try{return await fn();} finally{this.release();} }
}
const extractSem = new Semaphore(EXTRACT_CONCURRENCY);
const imageSem = new Semaphore(GLOBAL_IMAGE_CONCURRENCY);

const queue = {
  jobs: [], running:false, paused:false, stopped:false,
  nextId:1, seriesCursor:0,
  activeBySeries:new Map(), activeByHost:new Map(), workers:new Map()
};

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function sanitize(s){
  let x=String(s||'Chapitre').replace(/[\\/:*?"<>|]/g,' ').replace(/\s+/g,' ').trim();
  if(x.length>140)x=x.slice(0,140).trim(); return x||'Chapitre';
}
function buildPdfName(series, chapter){
  const s=sanitize(series||'Série'), c=sanitize(chapter||'Chapitre');
  return c.toLowerCase().startsWith(s.toLowerCase())?`${c}.pdf`:`${sanitize(`${s} - ${c}`)}.pdf`;
}
function downloadRoot(){ return path.join(app.getPath('downloads'),'Chapter Search PDF'); }
function seriesDir(series){ return path.join(downloadRoot(),sanitize(series||'Série')); }
function ensureDir(dir=downloadRoot()){ fs.mkdirSync(dir,{recursive:true}); }
function userSourcesPath(){ return path.join(app.getPath('userData'),'sources.json'); }
function defaultSourcesPath(){ return path.join(__dirname,'assets','sources.json'); }
function queuePath(){ return path.join(app.getPath('userData'),'download-queue.json'); }
function loadSources(){ const p=userSourcesPath(); if(!fs.existsSync(p))fs.copyFileSync(defaultSourcesPath(),p); try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return JSON.parse(fs.readFileSync(defaultSourcesPath(),'utf8'));} }
function saveSources(s){ fs.writeFileSync(userSourcesPath(),JSON.stringify(s,null,2),'utf8'); return s; }
function decodeHtml(s=''){ return s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>'); }
function unwrapDdg(href){ try{const u=new URL(decodeHtml(href),'https://html.duckduckgo.com'); if(u.searchParams.has('uddg'))return decodeURIComponent(u.searchParams.get('uddg')); return u.href;}catch{return decodeHtml(href);} }
function hostOf(url){try{return new URL(url).hostname.replace(/^www\./,'');}catch{return 'unknown';}}
function seriesKey(job){ return sanitize(job.series||'Série').toLowerCase(); }

function persistQueue(){
  try{
    const data={nextId:queue.nextId,jobs:queue.jobs.map(j=>({...j,state:j.state==='RUNNING'?'QUEUED':j.state,error:j.state==='RUNNING'?'Interrompu par fermeture':j.error}))};
    fs.writeFileSync(queuePath(),JSON.stringify(data,null,2),'utf8');
  }catch{}
}
function restoreQueue(){
  try{
    const raw=JSON.parse(fs.readFileSync(queuePath(),'utf8'));
    queue.nextId=Math.max(1,Number(raw.nextId)||1);
    queue.jobs=Array.isArray(raw.jobs)?raw.jobs.map(j=>({...j,state:j.state==='RUNNING'?'QUEUED':j.state})):[];
  }catch{ queue.jobs=[]; }
}
function queueSnapshot(){
  const counts={QUEUED:0,RUNNING:0,SAVED:0,ERROR:0,STOPPED:0};
  const groups={};
  for(const j of queue.jobs){
    counts[j.state]=(counts[j.state]||0)+1;
    const key=seriesKey(j); if(!groups[key])groups[key]={series:j.series||'Série',total:0,queued:0,running:0,saved:0,error:0,stopped:0};
    const g=groups[key]; g.total++;
    if(j.state==='QUEUED')g.queued++; else if(j.state==='RUNNING')g.running++; else if(j.state==='SAVED')g.saved++; else if(j.state==='ERROR')g.error++; else if(j.state==='STOPPED')g.stopped++;
  }
  return {running:queue.running,paused:queue.paused,stopped:queue.stopped,workerCount:queue.workers.size,total:queue.jobs.length,counts,series:Object.values(groups),jobs:queue.jobs.map(j=>({id:j.id,url:j.url,title:j.title,series:j.series,number:j.number,state:j.state,error:j.error,target:j.target,slot:j.slot,pages:j.pages,page:j.page,engine:j.engine,engineStats:j.engineStats}))};
}
function schedulePersist(){clearTimeout(persistTimer);persistTimer=setTimeout(()=>{persistTimer=null;persistQueue();},300);}
function emitQueue(){ schedulePersist(); mainWindow?.webContents.send('queue:update',queueSnapshot()); }

const SEARCH_TIMEOUT_MS = 6500;
const SEARCH_RESULTS_PER_SOURCE = 5;

function searchNorm(v=''){
  return decodeHtml(String(v||''))
    .replace(/<[^>]+>/g,' ')
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
}
function slugifySearch(v=''){
  return searchNorm(v).replace(/\s+/g,'-').replace(/-+/g,'-');
}
function canonicalSearchUrl(v){
  try{const u=new URL(v);u.hash='';['utm_source','utm_medium','utm_campaign','ref'].forEach(k=>u.searchParams.delete(k));if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/+$/,'/');return u.href;}catch{return String(v||'');}
}
function sourceHostMatches(source,url){
  try{const h=new URL(url).hostname.replace(/^www\./,'');const d=String(source.domain||'').replace(/^www\./,'');return h===d||h.endsWith('.'+d)||d.endsWith('.'+h);}catch{return false;}
}
function scoreSearchCandidate(query,title,url){
  const q=searchNorm(query),t=searchNorm(title),u=searchNorm(url),tokens=q.split(' ').filter(x=>x.length>1);
  if(!q||!tokens.length)return 0;
  let score=0,hit=0;
  for(const tok of tokens){if(t.includes(tok)){score+=18;hit++;}else if(u.includes(tok)){score+=9;hit++;}}
  if(t===q)score+=95;
  else if(t.startsWith(q))score+=72;
  else if(t.includes(q))score+=58;
  if(hit===tokens.length)score+=35;
  else if(hit<Math.ceil(tokens.length*.6))return 0;
  if(/\/(catalogue|manga|series|serie|title|comic|webtoon|book)\//i.test(url))score+=16;
  if(/(?:chapter|chapitre|tome|volume|vol-|episode|ep-)\D*\d/i.test(url+' '+title) && !/\d/.test(q))score-=24;
  if(/(?:tag|genre|author|login|register|privacy|contact|page\/\d+)/i.test(url))score-=18;
  return score;
}
function mergeSearchResults(target,incoming){
  const map=new Map(target.map(x=>[canonicalSearchUrl(x.url),x]));
  for(const x of incoming||[]){if(!x?.url)continue;const key=canonicalSearchUrl(x.url),prev=map.get(key);if(!prev||Number(x.score||0)>Number(prev.score||0))map.set(key,{...prev,...x,url:key});}
  return [...map.values()].sort((a,b)=>(b.score||0)-(a.score||0)).slice(0,SEARCH_RESULTS_PER_SOURCE);
}
function candidatesFromHtml(html,baseUrl,source,query,method){
  const out=[],rx=/<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;let m,n=0;
  while((m=rx.exec(html))&&n<7000){n++;let url;try{url=new URL(decodeHtml(m[1]),baseUrl).href;}catch{continue;}if(!sourceHostMatches(source,url))continue;
    const title=decodeHtml(m[2].replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());
    const score=scoreSearchCandidate(query,title,url);if(score>=38)out.push({title:title||query,url,score,method});
  }
  return mergeSearchResults([],out);
}
async function fetchSearchText(url,timeoutMs=SEARCH_TIMEOUT_MS){
  const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{
    const res=await session.defaultSession.fetch(url,{signal:ctrl.signal,headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8','Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8','Cache-Control':'no-cache'}});
    if(!res.ok){const e=new Error(`HTTP ${res.status}`);e.statusCode=res.status;throw e;}return await res.text();
  }finally{clearTimeout(timer);}
}
async function searchMangaDex(source,query){
  if(source.domain!=='mangadex.org')return [];
  try{
    const url=`https://api.mangadex.org/manga?title=${encodeURIComponent(query)}&limit=${SEARCH_RESULTS_PER_SOURCE}`;
    const raw=await fetchSearchText(url),j=JSON.parse(raw),arr=Array.isArray(j.data)?j.data:[];
    return arr.map(x=>{const a=x.attributes||{},titles=a.title||{},title=titles.en||titles.fr||Object.values(titles)[0]||query;return{title,url:`https://mangadex.org/title/${x.id}`,score:scoreSearchCandidate(query,title,`https://mangadex.org/title/${x.id}`)+40,method:'API MangaDex'};}).filter(x=>x.score>=40).slice(0,SEARCH_RESULTS_PER_SOURCE);
  }catch{return [];}
}
async function searchComick(source,query){
  if(source.domain!=='comick.io')return [];
  try{
    const raw=await fetchSearchText(`https://api.comick.fun/v1.0/search/?q=${encodeURIComponent(query)}&limit=${SEARCH_RESULTS_PER_SOURCE}&page=1&t=false`),j=JSON.parse(raw),arr=Array.isArray(j)?j:(Array.isArray(j.results)?j.results:[]);
    return arr.map(x=>{const title=x.title||x.md_titles?.[0]?.title||x.name||query,slug=x.slug||x.hid;if(!slug)return null;const url=`https://comick.io/comic/${slug}`;return{title,url,score:scoreSearchCandidate(query,title,url)+38,method:'API Comick'};}).filter(Boolean).filter(x=>x.score>=40).slice(0,SEARCH_RESULTS_PER_SOURCE);
  }catch{return [];}
}
function customSearchUrls(source,query){
  const d=source.domain,q=encodeURIComponent(query),slug=slugifySearch(query),base=`https://${d}`;
  const special={
    'sushiscan.fr': [`${base}/catalogue/list-mode/`,`${base}/?s=${q}`],
    'mangabuddy.com': [`${base}/${slug}`,`${base}/search?q=${q}`],
    'mangapill.com': [`${base}/search?q=${q}`,`${base}/manga/${slug}`],
    'mangafire.to': [`${base}/filter?keyword=${q}`,`${base}/manga/${slug}`],
    'mangapark.net': [`${base}/search?word=${q}`,`${base}/title/${slug}`],
    'toonily.com': [`${base}/?s=${q}`,`${base}/webtoon/${slug}`],
    'webtoon.xyz': [`${base}/?s=${q}`,`${base}/read/${slug}`],
    'readallcomics.com': [`${base}/?s=${q}`],
    'readcomiconline.li': [`${base}/Search/Comic?keyword=${q}`]
  };
  if(special[d])return special[d];
  return [`${base}/?s=${q}`,`${base}/search?q=${q}`,`${base}/search?keyword=${q}`];
}
async function searchInternalSource(source,query){
  let out=[];const urls=customSearchUrls(source,query).slice(0,3);
  const settled=await Promise.allSettled(urls.map(async url=>{
    const html=await fetchSearchText(url);return candidatesFromHtml(html,url,source,query,url.includes('catalogue/list-mode')?'Catalogue':'Recherche interne');
  }));
  for(const r of settled)if(r.status==='fulfilled')out=mergeSearchResults(out,r.value);
  return out;
}
async function searchDuckDuckGoFallback(source,query){
  const q=`site:${source.domain} ${query}`,url=`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`;
  try{
    const html=await fetchSearchText(url,7000),rx=/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,out=[];let m;
    while((m=rx.exec(html))&&out.length<SEARCH_RESULTS_PER_SOURCE){const link=unwrapDdg(m[1]),title=decodeHtml(m[2].replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim());if(!sourceHostMatches(source,link))continue;const score=scoreSearchCandidate(query,title,link);if(score>=30)out.push({title,url:link,score,method:'Index web'});}
    return mergeSearchResults([],out);
  }catch{return [];}
}
async function searchOneSource(source,query){
  const started=Date.now();let out=[];const errors=[];
  try{
    const primary=await Promise.allSettled([searchMangaDex(source,query),searchComick(source,query),searchInternalSource(source,query)]);
    for(const r of primary){if(r.status==='fulfilled')out=mergeSearchResults(out,r.value);else errors.push(String(r.reason?.message||r.reason||''));}
    if(out.length<2)out=mergeSearchResults(out,await searchDuckDuckGoFallback(source,query));
    return{source,ok:true,results:out,elapsedMs:Date.now()-started,methods:[...new Set(out.map(x=>x.method).filter(Boolean))],errors};
  }catch(e){return{source,ok:false,error:String(e.message||e),results:out,elapsedMs:Date.now()-started,errors};}
}
async function pooled(items,concurrency,fn){ let index=0,out=new Array(items.length); async function worker(){while(true){const i=index++;if(i>=items.length)break;out[i]=await fn(items[i],i);}} await Promise.all(Array.from({length:Math.min(concurrency,items.length)},worker)); return out; }

async function loadAndExtract(url,mode='chapter'){
  return extractSem.use(async()=>{
    const ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36';
    const win=new BrowserWindow({show:false,width:1100,height:900,webPreferences:{contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,images:true}});
    try{
      await win.loadURL(url,{userAgent:ua}); await sleep(850);
      if(mode==='chapter'){
        await win.webContents.executeJavaScript(FORCE_LAZY_LOAD,true).catch(()=>null); await sleep(1150);
        await win.webContents.executeJavaScript("window.scrollTo(0,document.body.scrollHeight);'ok';",true).catch(()=>null); await sleep(650);
        await win.webContents.executeJavaScript("window.scrollTo(0,0);'ok';",true).catch(()=>null); await sleep(350);
      }
      const script=mode==='seriesPage'?FIND_SERIES_PAGE:(mode==='series'?EXTRACT_CHAPTERS:EXTRACT_MULTI_ENGINE);
      const raw=await win.webContents.executeJavaScript(script,true),parsed=typeof raw==='string'?JSON.parse(raw):raw;
      if(parsed&&!Array.isArray(parsed)&&typeof parsed==='object')parsed.__userAgent=win.webContents.getUserAgent()||ua;
      return parsed;
    }finally{if(!win.isDestroyed())win.destroy();}
  });
}

function isHttpUrl(v){try{const u=new URL(v);return u.protocol==='http:'||u.protocol==='https:';}catch{return false;}}
function sameOrigin(a,b){try{return new URL(a).origin===new URL(b).origin;}catch{return false;}}
async function cookieHeaderFor(targetUrl,sourceUrl){
  const jar=new Map(); const add=async u=>{if(!u||!isHttpUrl(u))return;try{for(const c of await session.defaultSession.cookies.get({url:u}))jar.set(c.name,c.value);}catch{}};
  await add(targetUrl); if(sourceUrl&&sameOrigin(targetUrl,sourceUrl))await add(sourceUrl); return[...jar.entries()].map(([k,v])=>`${k}=${v}`).join('; ');
}
function nodeRequestBuffer(url,headers,redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>7)return reject(new Error('Trop de redirections')); let u; try{u=new URL(url);}catch{return reject(new Error('URL image invalide'));}
    if(!['http:','https:'].includes(u.protocol))return reject(new Error(`Schéma non pris en charge: ${u.protocol}`)); const transport=u.protocol==='https:'?https:http;
    const req=transport.request(u,{method:'GET',headers,timeout:22000,rejectUnauthorized:true},res=>{
      const code=res.statusCode||0;
      if(code>=300&&code<400&&res.headers.location){res.resume();const next=new URL(res.headers.location,u).href;nodeRequestBuffer(next,headers,redirects+1).then(resolve,reject);return;}
      if(code<200||code>=400){res.resume();const e=new Error(`HTTP ${code}`);e.statusCode=code;reject(e);return;}
      const type=String(res.headers['content-type']||'').toLowerCase();if(type.includes('text/html')){res.resume();reject(new Error('HTML au lieu d’une image'));return;}
      const chunks=[];let size=0;const MAX=55*1024*1024;res.on('data',c=>{size+=c.length;if(size>MAX){req.destroy(new Error('Image trop volumineuse'));return;}chunks.push(c);});res.on('end',()=>{const b=Buffer.concat(chunks);if(b.length<512)return reject(new Error('Image invalide'));resolve(b);});res.on('error',reject);
    }); req.on('timeout',()=>req.destroy(new Error('Délai réseau dépassé')));req.on('error',reject);req.end();
  });
}
async function fetchImage(url,referer,userAgent){
  return imageSem.use(async()=>{
    if(!isHttpUrl(url))throw new Error('URL image non HTTP'); const cookies=await cookieHeaderFor(url,referer);
    const base={'User-Agent':userAgent||'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36','Accept':'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8','Accept-Language':'fr-FR,fr;q=0.9,en;q=0.8','Accept-Encoding':'identity','Cache-Control':'no-cache','Pragma':'no-cache'}; if(cookies)base.Cookie=cookies;
    const variants=[];if(referer)variants.push({...base,Referer:referer});try{if(referer)variants.push({...base,Referer:new URL(referer).origin+'/'});}catch{}variants.push({...base}); let lastErr;
    for(let attempt=0;attempt<variants.length;attempt++){
      try{return await nodeRequestBuffer(url,variants[attempt]);}catch(e){lastErr=e;if(e.statusCode===404)break;if(e.statusCode===429)await sleep(650*(attempt+1));else if(e.statusCode===403)await sleep(220*(attempt+1));}
    }
    try{const headers={...base};if(referer)headers.Referer=referer;const res=await session.defaultSession.fetch(url,{headers});if(!res.ok)throw new Error(`HTTP ${res.status}`);const buf=Buffer.from(await res.arrayBuffer());if(buf.length<512)throw new Error('Image invalide');return buf;}catch(e){throw lastErr||e;}
  });
}

async function createPdfFromImages(payload,sourceUrl,onProgress=()=>{},userAgent=null,control=null){
  const outDir=seriesDir(payload.series);ensureDir(outDir);const filename=buildPdfName(payload.series,payload.chapter),target=path.join(outDir,filename),total=Array.isArray(payload.images)?payload.images.length:0;
  const converted=new Array(total),errors=[];let cursor=0,done=0,valid=0,skipped=0;
  const worker=async()=>{while(true){const i=cursor++;if(i>=total)break;while(control?.paused&&!control?.stopped)await sleep(180);if(control?.stopped)throw new Error('Téléchargement arrêté');try{const raw=await fetchImage(payload.images[i],sourceUrl,userAgent||payload.__userAgent);const c=await sharp(raw).rotate().jpeg({quality:90,mozjpeg:true}).toBuffer({resolveWithObject:true});if(!c.info.width||!c.info.height)throw new Error('Image non décodable');converted[i]=c;valid++;}catch(e){skipped++;errors.push(`page ${i+1}: ${String(e.message||e)}`);}done++;onProgress({state:'DOWNLOAD',current:done,total,valid,skipped});}};
  await Promise.all(Array.from({length:Math.min(PAGE_CONCURRENCY_PER_CHAPTER,total)},worker));
  if(control?.stopped)throw new Error('Téléchargement arrêté');if(valid<2)throw new Error(`Chapitre rejeté : ${valid}/${total} page(s) récupérée(s). ${errors.slice(0,3).join(' | ')}`.trim());
  onProgress({state:'PDF',current:0,total:valid,valid,skipped});const pdf=await PDFDocument.create();let pno=0;for(let i=0;i<converted.length;i++){const c=converted[i];if(!c)continue;const img=await pdf.embedJpg(c.data),w=c.info.width||img.width,h=c.info.height||img.height,page=pdf.addPage([w,h]);page.drawImage(img,{x:0,y:0,width:w,height:h});pno++;onProgress({state:'PDF',current:pno,total:valid,valid,skipped});}
  const tmp=target+'.part';fs.writeFileSync(tmp,await pdf.save());if(fs.existsSync(target))fs.unlinkSync(target);fs.renameSync(tmp,target);onProgress({state:'SAVED',current:valid,total:valid,valid,skipped,target});return target;
}

async function downloadChapterJob(job,slot){
  const send=(state,extra={})=>{Object.assign(job,{state,slot,...extra});emitQueue();mainWindow?.webContents.send('queue:progress',{id:job.id,slot,url:job.url,title:job.title,series:job.series,state,...extra});};
  let payload,lastErr;
  for(let attempt=1;attempt<=2;attempt++){
    try{send('LOAD',{attempt});payload=await loadAndExtract(job.url,'chapter');if(!payload?.ok||!Array.isArray(payload.images)||payload.images.length<2)throw new Error(payload?.reason||'Chapitre non reconnu');break;}catch(e){lastErr=e;if(attempt<2)await sleep(700);}
  }
  if(!payload)throw lastErr||new Error('Extraction impossible');
  job.series=job.series||payload.series;job.title=job.title||payload.chapter;job.engine=payload.engine||'E5-HYBRID';job.engineStats=payload.engineStats;job.pages=payload.images.length;
  send('ANALYSE',{pages:payload.images.length,engine:job.engine,engineStats:job.engineStats});
  const target=await createPdfFromImages(payload,job.url,p=>send(p.state,{page:p.current,pages:p.total,valid:p.valid,skipped:p.skipped,error:p.error}),payload.__userAgent,queue);
  send('SAVED',{target});return target;
}

function inc(map,key,delta){const n=(map.get(key)||0)+delta;if(n<=0)map.delete(key);else map.set(key,n);}
function takeNextQueued(){
  const queued=queue.jobs.filter(j=>j.state==='QUEUED');if(!queued.length)return null;
  // Auto-réparation : aucune tâche RUNNING => les compteurs actifs doivent être vides.
  if(!queue.jobs.some(j=>j.state==='RUNNING')){queue.activeBySeries.clear();queue.activeByHost.clear();}
  const series=[...new Set(queued.map(seriesKey))];if(!series.length)return null;
  for(let n=0;n<series.length;n++){
    const idx=(queue.seriesCursor+n)%series.length,key=series[idx];if((queue.activeBySeries.get(key)||0)>=MAX_ACTIVE_PER_SERIES)continue;
    const j=queued.find(x=>seriesKey(x)===key&&(queue.activeByHost.get(hostOf(x.url))||0)<MAX_ACTIVE_PER_HOST);if(!j)continue;
    queue.seriesCursor=(idx+1)%series.length;return j;
  }
  return null;
}
async function queueWorker(slot){
  while(!queue.stopped){
    while(queue.paused&&!queue.stopped)await sleep(180);if(queue.stopped)break;
    const job=takeNextQueued();
    if(!job){
      if(queue.jobs.some(j=>j.state==='RUNNING')){await sleep(160);continue;}
      await sleep(420);
      if(queue.jobs.some(j=>j.state==='QUEUED'))continue;
      break;
    }
    const sk=seriesKey(job),hk=hostOf(job.url);job.state='RUNNING';job.error='';job.slot=slot;inc(queue.activeBySeries,sk,1);inc(queue.activeByHost,hk,1);emitQueue();
    try{await downloadChapterJob(job,slot);}catch(e){job.state=queue.stopped?'STOPPED':'ERROR';job.error=String(e.message||e);mainWindow?.webContents.send('queue:progress',{id:job.id,slot,url:job.url,title:job.title,series:job.series,state:job.state,error:job.error});}
    finally{inc(queue.activeBySeries,sk,-1);inc(queue.activeByHost,hk,-1);job.slot=null;emitQueue();}
  }
}
function spawnQueueWorkers(){
  if(queue.stopped||queue.paused)return;
  if(!queue.jobs.some(j=>j.state==='QUEUED')){
    if(!queue.jobs.some(j=>j.state==='RUNNING')&&queue.workers.size===0){queue.running=false;emitQueue();}
    return;
  }
  queue.running=true;
  for(let slot=1;slot<=CHAPTER_CONCURRENCY;slot++){
    if(queue.workers.has(slot))continue;
    const promise=queueWorker(slot).catch(()=>{}).finally(()=>{
      queue.workers.delete(slot);
      if(queue.jobs.some(j=>j.state==='QUEUED')&&!queue.stopped&&!queue.paused){setImmediate(spawnQueueWorkers);return;}
      if(!queue.jobs.some(j=>j.state==='RUNNING')&&queue.workers.size===0){
        queue.running=false;emitQueue();mainWindow?.webContents.send('queue:complete',queueSnapshot());
      }
    });
    queue.workers.set(slot,promise);
  }
  emitQueue();
}
async function runQueue(){
  queue.stopped=false;queue.paused=false;
  if(!queue.jobs.some(j=>j.state==='QUEUED'||j.state==='RUNNING')){queue.running=false;emitQueue();return queueSnapshot();}
  spawnQueueWorkers();
  return queueSnapshot();
}
function normalizeQueueUrl(raw){try{const u=new URL(String(raw||''));u.hash='';u.pathname=u.pathname.replace(/\/{2,}/g,'/');if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/$/,'');return u.href;}catch{return String(raw||'').trim();}}
function addQueueJobs(jobs){
  const requested=Array.isArray(jobs)?jobs.length:0;
  const existing=new Set(queue.jobs.filter(j=>j.state!=='ERROR'&&j.state!=='STOPPED').map(j=>normalizeQueueUrl(j.url)));let added=0,skipped=0;
  for(const raw of jobs||[]){const normalized=normalizeQueueUrl(raw?.url);if(!normalized||existing.has(normalized)){skipped++;continue;}const series=raw.series||'Série';queue.jobs.push({id:queue.nextId++,url:raw.url,title:raw.title||`Chapitre ${raw.number??''}`.trim(),series,number:raw.number??null,state:'QUEUED',error:'',target:'',engine:'',engineStats:null,addedAt:Date.now()});existing.add(normalized);added++;}
  emitQueue();
  if(added>0&&queue.running&&!queue.paused&&!queue.stopped)setImmediate(spawnQueueWorkers);
  return{requested,added,skipped,snapshot:queueSnapshot()};
}

function createWindow(){mainWindow=new BrowserWindow({width:1440,height:900,minWidth:980,minHeight:650,title:'Chapter Search PDF',webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,webviewTag:true,backgroundThrottling:false}});mainWindow.loadFile(path.join(__dirname,'index.html'));}

app.whenReady().then(()=>{restoreQueue();session.defaultSession.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{persistQueue();if(process.platform!=='darwin')app.quit();});

ipcMain.handle('engine:scripts',()=>({force:FORCE_LAZY_LOAD,chapter:EXTRACT_CHAPTER_PAYLOAD,multiChapter:EXTRACT_MULTI_ENGINE,series:EXTRACT_CHAPTERS,seriesPage:FIND_SERIES_PAGE}));
ipcMain.handle('sources:get',()=>loadSources());
ipcMain.handle('sources:save',(_e,s)=>saveSources(s));
ipcMain.handle('sources:inject',(_e,incoming)=>{const base=loadSources(),map=new Map(base.map(x=>[x.domain,x]));for(const x of incoming||[])if(x?.domain)map.set(x.domain,{enabled:true,lang:'?',type:'multi',...x});return saveSources([...map.values()]);});
ipcMain.handle('meta:search',async(_e,{query,sources})=>{let done=0;const active=(sources||loadSources()).filter(s=>s.enabled),results=await pooled(active,SEARCH_CONCURRENCY,async source=>{const r=await searchOneSource(source,query);done++;mainWindow?.webContents.send('meta:progress',{done,total:active.length,source:source.name,ok:r.ok,count:r.results.length});return r;});return results;});
ipcMain.handle('chapter:analyze',async(_e,url)=>loadAndExtract(url,'chapter'));
ipcMain.handle('series:analyze',async(_e,url)=>loadAndExtract(url,'series'));
ipcMain.handle('series:page',async(_e,url)=>loadAndExtract(url,'seriesPage'));
ipcMain.handle('chapter:download',async(_e,{url,payload,userAgent})=>createPdfFromImages(payload,url,()=>{},userAgent,{paused:false,stopped:false}));
ipcMain.handle('pdf:exists',(_e,{series,chapter})=>fs.existsSync(path.join(seriesDir(series),buildPdfName(series,chapter))));
ipcMain.handle('downloads:open',()=>{ensureDir();return shell.openPath(downloadRoot());});
ipcMain.handle('external:open',(_e,url)=>shell.openExternal(url));

ipcMain.handle('queue:get',()=>queueSnapshot());
ipcMain.handle('queue:add',(_e,jobs)=>addQueueJobs(jobs));
ipcMain.handle('queue:add-start',(_e,jobs)=>{const r=addQueueJobs(jobs);setImmediate(()=>runQueue());return r;});
ipcMain.handle('queue:start',()=>{setImmediate(()=>runQueue());return queueSnapshot();});
ipcMain.handle('queue:pause',(_e,v)=>{queue.paused=!!v;emitQueue();return queueSnapshot();});
ipcMain.handle('queue:stop',()=>{queue.stopped=true;queue.paused=false;for(const j of queue.jobs)if(j.state==='QUEUED')j.state='STOPPED';emitQueue();return queueSnapshot();});
ipcMain.handle('queue:retry-errors',()=>{for(const j of queue.jobs)if(j.state==='ERROR'||j.state==='STOPPED'){j.state='QUEUED';j.error='';}queue.stopped=false;emitQueue();return queueSnapshot();});
ipcMain.handle('queue:clear-done',()=>{queue.jobs=queue.jobs.filter(j=>j.state!=='SAVED');emitQueue();return queueSnapshot();});
ipcMain.handle('queue:remove-series',(_e,series)=>{const key=sanitize(series).toLowerCase();queue.jobs=queue.jobs.filter(j=>seriesKey(j)!==key||j.state==='RUNNING');emitQueue();return queueSnapshot();});

// Compatibilité avec les anciennes interfaces.
ipcMain.handle('batch:start',(_e,jobs)=>{addQueueJobs(jobs);setImmediate(()=>runQueue());return queueSnapshot();});
ipcMain.handle('batch:pause',(_e,v)=>{queue.paused=!!v;emitQueue();return queueSnapshot();});
ipcMain.handle('batch:stop',()=>{queue.stopped=true;emitQueue();return queueSnapshot();});
