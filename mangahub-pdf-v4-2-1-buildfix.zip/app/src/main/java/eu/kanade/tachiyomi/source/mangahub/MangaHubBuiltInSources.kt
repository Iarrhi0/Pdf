package eu.kanade.tachiyomi.source.mangahub

import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SChapterImpl
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaImpl
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import eu.kanade.tachiyomi.source.online.HttpSource
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Sources shipped directly inside MangaHub PDF.
 * No extension repository or APK installation is required for these sources.
 *
 * The parsers deliberately use broad HTML patterns because these sites change themes often.
 * MangaHub's downloader still keeps its AUTO ENGINE fallback for page extraction.
 */
object MangaHubBuiltInSources {
    fun create(): List<HttpSource> = listOf(
        BuiltInWebSource("SushiScan", "https://sushiscan.fr", "fr", SearchStyle.MADARA, "/catalogue/"),
        BuiltInWebSource("SushiScan .net", "https://sushiscan.net", "fr", SearchStyle.MADARA, "/catalogue/"),
        BuiltInWebSource("OrtegaScans", "https://ortegascans.fr", "fr", SearchStyle.SLUG_FIRST, "/serie/"),
        BuiltInWebSource("Mangas-Origines", "https://mangas-origines.fr", "fr", SearchStyle.MADARA, "/oeuvre/"),
        BuiltInWebSource("ToonFR", "https://toonfr.com", "fr", SearchStyle.MADARA, "/webtoon/"),
        BuiltInWebSource("HentaiZone", "https://hentaizone.xyz", "fr", SearchStyle.MADARA, "/manga/"),
    )
}

private enum class SearchStyle { MADARA, SLUG_FIRST }

private class BuiltInWebSource(
    override val name: String,
    override val baseUrl: String,
    override val lang: String,
    private val searchStyle: SearchStyle,
    private val seriesPath: String,
) : HttpSource() {

    override val supportsLatest: Boolean = true

    override suspend fun getPopularManga(page: Int): MangasPage {
        if (page > 1) return MangasPage(emptyList(), false)
        val doc = fetchDocument(baseUrl)
        return MangasPage(extractSeries(doc, null).take(40), false)
    }

    override suspend fun getLatestUpdates(page: Int): MangasPage = getPopularManga(page)

    override suspend fun getSearchManga(page: Int, query: String, filters: FilterList): MangasPage {
        if (page > 1 || query.isBlank()) return MangasPage(emptyList(), false)
        val encoded = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8.name())
        val slug = slugify(query)
        val candidates = LinkedHashMap<String, SManga>()

        val urls = when (searchStyle) {
            SearchStyle.MADARA -> listOf("$baseUrl/?s=$encoded")
            SearchStyle.SLUG_FIRST -> listOf("$baseUrl$seriesPath$slug", "$baseUrl/?s=$encoded")
        }

        for (url in urls) {
            runCatching {
                val doc = fetchDocument(url)
                extractSeries(doc, query).forEach { candidates[it.url] = it }
                // Exact slug pages often don't render a search-result card.
                if (doc.location().contains(seriesPath) && titleMatches(extractTitle(doc), query)) {
                    mangaFromSeriesPage(doc)?.let { candidates[it.url] = it }
                }
            }
        }

        val ranked = candidates.values.sortedWith(
            compareByDescending<SManga> { relevance(it.title, query) }.thenBy { it.title.lowercase() },
        )
        return MangasPage(ranked.take(60), false)
    }

    override suspend fun getMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        val absolute = absoluteUrl(manga.url)
        val doc = fetchDocument(absolute)
        val details = if (fetchDetails) mangaFromSeriesPage(doc, manga) ?: manga else manga
        val chapterList = if (fetchChapters) extractChapters(doc) else chapters
        return SMangaUpdate(details, chapterList)
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        val doc = fetchDocument(absoluteUrl(chapter.url))
        val candidates = LinkedHashSet<String>()
        val selectors = listOf(
            ".reading-content img", ".chapter-content img", ".reader-area img", ".reader-content img",
            ".entry-content img", "main img", "article img", "img[data-src]", "img[data-lazy-src]",
            "img[data-original]", "img[src]",
        )
        for (selector in selectors) {
            doc.select(selector).forEach { img ->
                listOf("data-src", "data-lazy-src", "data-original", "data-url", "src").forEach { attr ->
                    val raw = img.attr(attr).trim()
                    if (raw.isNotBlank()) normalizeImage(raw, doc.location())?.let(candidates::add)
                }
                img.attr("srcset").split(',').forEach { part ->
                    val raw = part.trim().substringBefore(' ')
                    if (raw.isNotBlank()) normalizeImage(raw, doc.location())?.let(candidates::add)
                }
            }
        }

        val filtered = candidates.filterNot(::isDecorative)
        return filtered.mapIndexed { index, url -> Page(index, imageUrl = url) }
    }

    private fun fetchDocument(url: String): Document {
        val req = Request.Builder().url(url).headers(headers).build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code} - $name")
            val body = response.body.string()
            return Jsoup.parse(body, response.request.url.toString())
        }
    }

    private fun extractSeries(doc: Document, query: String?): List<SManga> {
        val out = LinkedHashMap<String, SManga>()
        val anchors = doc.select("a[href*='$seriesPath']")
        for (a in anchors) {
            val href = a.absUrl("href").ifBlank { absoluteUrl(a.attr("href")) }
            if (href.isBlank() || href.removeSuffix("/") == baseUrl.removeSuffix("/")) continue
            val title = extractAnchorTitle(a)
            if (title.length < 2) continue
            if (query != null && relevance(title, query) <= 0) continue
            val m = SMangaImpl().apply {
                url = href
                this.title = title
                thumbnail_url = findImage(a)
            }
            out[href] = m
        }
        return out.values.toList()
    }

    private fun mangaFromSeriesPage(doc: Document, previous: SManga? = null): SManga? {
        val title = extractTitle(doc).ifBlank { previous?.title.orEmpty() }
        if (title.isBlank()) return null
        return SMangaImpl().apply {
            url = doc.location()
            this.title = title
            thumbnail_url = doc.selectFirst("meta[property=og:image]")?.attr("content")
                ?.takeIf { it.isNotBlank() }
                ?: doc.selectFirst(".summary_image img, .tab-summary img, article img")?.let { findImage(it) }
                ?: previous?.thumbnail_url
            description = doc.selectFirst("meta[name=description]")?.attr("content")
                ?.takeIf { it.isNotBlank() }
                ?: doc.selectFirst(".summary__content, .description-summary, .entry-content p")?.text()
            author = doc.selectFirst(".author-content a, .author-content")?.text()
            artist = doc.selectFirst(".artist-content a, .artist-content")?.text()
            genre = doc.select(".genres-content a, .genre a, a[href*=genre]").joinToString(", ") { it.text() }
            initialized = true
        }
    }

    private fun extractChapters(doc: Document): List<SChapter> {
        val out = LinkedHashMap<String, SChapter>()
        val selectors = "a[href*='/chapter/'], a[href*='/chapitre/'], a[href*='/chapters/'], .wp-manga-chapter a, .chapter-link"
        doc.select(selectors).forEach { a ->
            val href = a.absUrl("href").ifBlank { absoluteUrl(a.attr("href")) }
            if (href.isBlank()) return@forEach
            val label = a.text().trim().ifBlank { href.substringAfterLast('/').replace('-', ' ') }
            if (label.length < 2) return@forEach
            val number = Regex("(?i)(?:chapter|chapitre|chap|ch)[^0-9]*([0-9]+(?:\\.[0-9]+)?)")
                .find(label)?.groupValues?.getOrNull(1)?.toFloatOrNull()
                ?: Regex("([0-9]+(?:\\.[0-9]+)?)").find(label)?.value?.toFloatOrNull()
                ?: -1f
            out[href] = SChapterImpl().apply {
                url = href
                name = label
                chapter_number = number
            }
        }
        return out.values.sortedWith(compareByDescending<SChapter> { it.chapter_number }.thenByDescending { it.name })
    }

    private fun extractAnchorTitle(a: Element): String {
        val local = a.selectFirst("h1,h2,h3,h4,.post-title,.manga-title,.title")?.text()?.trim().orEmpty()
        if (local.length >= 2) return local
        val imgAlt = a.selectFirst("img[alt]")?.attr("alt")?.trim().orEmpty()
        if (imgAlt.length >= 2) return imgAlt
        val text = a.text().trim()
        if (text.length >= 2) return text
        return a.attr("title").trim()
    }

    private fun extractTitle(doc: Document): String {
        return doc.selectFirst("h1, .post-title h1, .post-title, .manga-title, .serie-title")?.text()?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: doc.selectFirst("meta[property=og:title]")?.attr("content")?.substringBefore(" - ")?.trim().orEmpty()
    }

    private fun findImage(el: Element): String? {
        val img = if (el.tagName() == "img") el else el.selectFirst("img") ?: return null
        val raw = listOf("data-src", "data-lazy-src", "data-original", "src")
            .asSequence().map { img.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: return null
        return normalizeImage(raw, img.ownerDocument()?.location().orEmpty())
    }

    private fun absoluteUrl(url: String): String {
        val s = url.trim()
        if (s.startsWith("http://") || s.startsWith("https://")) return s
        return if (s.startsWith('/')) baseUrl + s else "$baseUrl/$s"
    }

    private fun normalizeImage(raw: String, pageUrl: String): String? {
        var s = raw.trim().replace("&amp;", "&")
        if (s.startsWith("//")) s = "https:$s"
        if (s.startsWith("data:") || s.startsWith("blob:")) return null
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = runCatching { java.net.URI(pageUrl).resolve(s).toString() }.getOrDefault(absoluteUrl(s))
        }
        return s.takeIf { it.startsWith("http") }
    }

    private fun isDecorative(url: String): Boolean {
        val s = url.lowercase()
        return listOf("logo", "avatar", "icon", "emoji", "banner", "adsense", "/ads/", "advert", "publicite", "promo", "sponsor", "sprite", "placeholder", "loading", "spacer", "favicon", "thumbnail", "thumb-").any { it in s }
    }

    private fun slugify(text: String): String = java.text.Normalizer.normalize(text.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), "-")
        .trim('-')

    private fun relevance(title: String, query: String): Int {
        val t = normalize(title)
        val q = normalize(query)
        if (t == q) return 100
        if (t.startsWith(q)) return 80
        if (q in t) return 60
        val tokens = q.split(' ').filter { it.length > 1 }
        val matched = tokens.count { it in t }
        return if (matched == 0) 0 else 20 + (40 * matched / tokens.size.coerceAtLeast(1))
    }

    private fun titleMatches(title: String, query: String) = relevance(title, query) >= 60

    private fun normalize(text: String): String = java.text.Normalizer.normalize(text.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
}
