# Chapter PDF Android

Application Android native avec WebView intégrée.

## Fonctionnement
1. Colle l'URL du chapitre de départ.
2. Appuie sur `DÉMARRER / REPRENDRE`.
3. La vraie page du site est chargée dans la WebView.
4. L'app détecte les images du chapitre.
5. Le PDF est créé dans `Téléchargements/PDF_CONVERTIS/CHAPITRES/`.
6. L'app cherche automatiquement `Suivant / Next / Chapitre suivant`.
7. Elle charge la suite dans la même session WebView.
8. Si un CAPTCHA apparaît, tu le fais manuellement directement dans la WebView. L'app reprend lorsque la page normale revient.
9. Les URL déjà terminées sont mémorisées et peuvent être ignorées automatiquement.

## Construire l'APK sur GitHub
1. Crée un dépôt GitHub vide.
2. Upload tout le contenu de ce ZIP à la racine du dépôt.
3. Va dans `Actions`.
4. Ouvre `Build Android APK`.
5. Attends le statut vert.
6. Ouvre l'exécution terminée.
7. Dans `Artifacts`, télécharge `Chapter-PDF-APK`.
8. Décompresse l'archive puis installe `app-debug.apk`.

## Notes
- Aucun CAPTCHA n'est contourné automatiquement.
- Certains sites peuvent encore empêcher l'extraction ou protéger fortement leurs images.
- Le build est volontairement sans Gradle Wrapper : GitHub Actions installe Gradle 8.9 automatiquement.
