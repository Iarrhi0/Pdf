package com.example.chapterpdf

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var webView: WebView
    private lateinit var autoNextCheck: CheckBox
    private lateinit var skipDoneCheck: CheckBox

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    @Volatile private var running = false
    @Volatile private var awaitingHuman = false
    private var chapterCounter = 0
    private val seenUrls = mutableSetOf<String>()

    private val history by lazy {
        getSharedPreferences("chapter_history", MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        configureWebView()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
        }

        val title = TextView(this).apply {
            text = "Chapitre → PDF → Suivant"
            textSize = 24f
            setTextColor(Color.WHITE)
        }

        urlInput = EditText(this).apply {
            hint = "https://site.com/serie/chapter/1"
            setSingleLine(true)
        }

        autoNextCheck = CheckBox(this).apply {
            text = "Continuer automatiquement"
            isChecked = true
        }

        skipDoneCheck = CheckBox(this).apply {
            text = "Ignorer les chapitres déjà terminés"
            isChecked = true
        }

        startButton = Button(this).apply {
            text = "DÉMARRER / REPRENDRE"
        }

        stopButton = Button(this).apply {
            text = "ARRÊTER"
        }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progress = 0
        }

        statusText = TextView(this).apply {
            text = "Prêt."
            textSize = 16f
            setPadding(0, 12, 0, 12)
        }

        webView = WebView(this)

        root.addView(title)
        root.addView(urlInput)
        root.addView(autoNextCheck)
        root.addView(skipDoneCheck)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(progressBar, LinearLayout.LayoutParams.MATCH_PARENT, 24)
        root.addView(statusText)

        val webParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0
        ).apply { weight = 1f }

        root.addView(webView, webParams)
        setContentView(root)

        startButton.setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                setStatus("Colle une URL de chapitre valide.")
                return@setOnClickListener
            }
            if (!running) {
                chapterCounter = 0
                seenUrls.clear()
            }
            running = true
            awaitingHuman = false
            loadChapter(url)
        }

        stopButton.setOnClickListener {
            running = false
            awaitingHuman = false
            setStatus("Arrêt demandé.")
        }
    }

    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString + " ChapterPdfAndroid/1.0"
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(PageBridge(), "ChapterPdfBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                if (!running) return
                lifecycleScope.launch {
                    delay(1200)
                    inspectLoadedPage()
                }
            }
        }
    }

    private fun loadChapter(url: String) {
        if (!running) return
        if (!seenUrls.add(url)) {
            setStatus("Boucle détectée. Arrêt.")
            running = false
            return
        }
        chapterCounter += 1
        progressBar.progress = 10
        setStatus("Chapitre $chapterCounter : chargement…\n$url")
        webView.visibility = View.VISIBLE
        webView.loadUrl(url)
    }

    private fun inspectLoadedPage() {
        val js = """
            (function(){
              function abs(u){ try{return new URL(u,location.href).href}catch(e){return ''} }
              function captcha(){
                const t=(document.body?.innerText||'').toLowerCase();
                return /captcha|verify you are human|checking your browser|just a moment|vérif(ier|ication).*(humain|robot)/i.test(t)
                  || !!document.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],[class*="captcha"],[id*="captcha"],[class*="turnstile"]');
              }
              function images(){
                const attrs=['data-src','data-lazy-src','data-original','src'];
                const seen=new Set(), out=[];
                document.querySelectorAll('img').forEach(img=>{
                  let u='';
                  for(const a of attrs){ const v=img.getAttribute(a); if(v){u=v;break;} }
                  if(!u && img.srcset) u=(img.srcset.split(',')[0]||'').trim().split(/\s+/)[0]||'';
                  u=abs(u);
                  if(!u || u.startsWith('data:') || seen.has(u)) return;
                  const r=img.getBoundingClientRect();
                  const w=img.naturalWidth||r.width||0, h=img.naturalHeight||r.height||0;
                  if(w<120 || h<120) return;
                  seen.add(u); out.push(u);
                });
                return out;
              }
              function nextUrl(){
                const links=[...document.querySelectorAll('a[href]')].map(a=>{
                  const text=((a.innerText||'')+' '+(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'')+' '+(a.rel||'')).toLowerCase();
                  let score=0;
                  if(/\b(chapitre suivant|next chapter|chapter next|suivant|next)\b/.test(text))score+=10;
                  if(/\b(précédent|precedent|previous|prev)\b/.test(text))score-=20;
                  if(/\bnext\b/.test((a.rel||'').toLowerCase()))score+=12;
                  const href=abs(a.getAttribute('href'));
                  if(/chapter|chapitre|episode|\/ch[\/_-]?\d/i.test(href))score+=4;
                  return {href,score};
                }).filter(x=>x.href && x.href!==location.href && x.score>0);
                links.sort((a,b)=>b.score-a.score);
                return links[0]?.href||'';
              }
              function endState(){
                const t=(document.body?.innerText||'').toLowerCase();
                if(/coming soon|to be continued|à suivre|a suivre|suite.*bient[oô]t|prochain chapitre.*bient[oô]t/i.test(t)) return 'waiting';
                if(/fin de (la )?(série|serie|manga|manhwa|webtoon)|the end|completed|terminé|termine/i.test(t)) return 'finished';
                return 'unknown';
              }
              ChapterPdfBridge.onPageData(JSON.stringify({
                url:location.href,
                title:document.title||'Chapitre',
                captcha:captcha(),
                images:images(),
                next:nextUrl(),
                end:endState()
              }));
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    inner class PageBridge {
        @JavascriptInterface
        fun onPageData(json: String) {
            runOnUiThread {
                try {
                    val data = JSONObject(json)
                    if (data.optBoolean("captcha", false)) {
                        awaitingHuman = true
                        running = true
                        progressBar.progress = 15
                        setStatus(
                            "Vérification humaine nécessaire.\n" +
                            "Fais le CAPTCHA directement dans la page affichée. " +
                            "Dès que la vraie page du chapitre se charge, l’app reprendra automatiquement."
                        )
                        // WebView remains visible and interactive.
                        lifecycleScope.launch {
                            monitorHumanVerification()
                        }
                        return@runOnUiThread
                    }
                    processChapterData(data)
                } catch (e: Exception) {
                    setStatus("Erreur d’analyse : ${e.message}")
                    running = false
                }
            }
        }
    }

    private suspend fun monitorHumanVerification() {
        while (running && awaitingHuman) {
            delay(2000)
            inspectLoadedPage()
            delay(1000)
            // onPageData will clear awaitingHuman when captcha disappears
        }
    }

    private fun processChapterData(data: JSONObject) {
        if (!running) return
        awaitingHuman = false

        val url = data.optString("url")
        val title = data.optString("title", "Chapitre")
        val next = data.optString("next")
        val end = data.optString("end", "unknown")
        val imagesJson = data.optJSONArray("images") ?: JSONArray()

        val historyKey = sha256(url)
        if (skipDoneCheck.isChecked && history.getBoolean(historyKey, false)) {
            setStatus("Déjà terminé : $title\nPassage au chapitre suivant…")
            if (autoNextCheck.isChecked && next.isNotBlank()) {
                loadChapter(next)
            } else {
                finishFlow(end, next)
            }
            return
        }

        val images = mutableListOf<String>()
        for (i in 0 until imagesJson.length()) {
            images.add(imagesJson.optString(i))
        }

        if (images.isEmpty()) {
            setStatus("Aucune image de lecture détectée sur cette page.")
            running = false
            return
        }

        lifecycleScope.launch {
            progressBar.progress = 30
            setStatus("$title\n${images.size} image(s) détectée(s). Téléchargement…")

            val bitmaps = downloadImages(images, url)
            if (bitmaps.isEmpty()) {
                setStatus("Toutes les images ont échoué.")
                running = false
                return@launch
            }

            progressBar.progress = 70
            setStatus("$title\nCréation du PDF…")

            val file = withContext(Dispatchers.IO) {
                createPdf(title, bitmaps)
            }

            bitmaps.forEach { if (!it.isRecycled) it.recycle() }

            history.edit().putBoolean(historyKey, true).apply()
            progressBar.progress = 100
            setStatus("PDF terminé : ${file.name}\n${file.absolutePath}")

            if (running && autoNextCheck.isChecked && next.isNotBlank()) {
                delay(900)
                loadChapter(next)
            } else {
                finishFlow(end, next)
            }
        }
    }

    private suspend fun downloadImages(urls: List<String>, referer: String): List<Bitmap> =
        withContext(Dispatchers.IO) {
            val cookie = CookieManager.getInstance().getCookie(referer).orEmpty()
            val result = mutableListOf<Bitmap>()

            urls.forEachIndexed { index, imageUrl ->
                try {
                    val req = Request.Builder()
                        .url(imageUrl)
                        .header("Referer", referer)
                        .header("User-Agent", webView.settings.userAgentString)
                        .apply {
                            if (cookie.isNotBlank()) header("Cookie", cookie)
                        }
                        .build()

                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val bytes = resp.body?.bytes()
                            if (bytes != null) {
                                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                if (bmp != null) result.add(bmp)
                            }
                        }
                    }
                } catch (_: Exception) {}

                withContext(Dispatchers.Main) {
                    progressBar.progress = 30 + ((index + 1) * 35 / urls.size.coerceAtLeast(1))
                }
            }
            result
        }

    private fun createPdf(title: String, bitmaps: List<Bitmap>): File {
        val safeTitle = title
            .replace(Regex("""[\\/:*?"<>|]+"""), "_")
            .take(100)
            .ifBlank { "Chapitre_$chapterCounter" }

        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "PDF_CONVERTIS/CHAPITRES"
        )
        dir.mkdirs()

        val outFile = File(dir, "$safeTitle.pdf")
        val pdf = PdfDocument()

        // Stable mobile width. Height is split into 16:9-ish vertical screens.
        val pageWidth = 1080
        val pageHeight = 1920

        bitmaps.forEach { src ->
            val scale = pageWidth.toFloat() / src.width.toFloat()
            val scaledHeight = (src.height * scale).roundToInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(src, pageWidth, scaledHeight, true)

            var y = 0
            while (y < scaled.height) {
                val sliceH = minOf(pageHeight, scaled.height - y)
                val page = pdf.startPage(
                    PdfDocument.PageInfo.Builder(pageWidth, sliceH, pdf.pages.size + 1).create()
                )
                val canvas: Canvas = page.canvas
                val slice = Bitmap.createBitmap(scaled, 0, y, pageWidth, sliceH)
                canvas.drawBitmap(slice, 0f, 0f, null)
                slice.recycle()
                pdf.finishPage(page)
                y += sliceH
            }

            if (scaled !== src && !scaled.isRecycled) scaled.recycle()
        }

        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return outFile
    }

    private fun finishFlow(end: String, next: String) {
        running = false
        when {
            next.isNotBlank() -> setStatus("Chapitre terminé. Suivant détecté mais continuation automatique désactivée.\n$next")
            end == "finished" -> setStatus("Fin de série détectée.")
            end == "waiting" -> setStatus("En attente de la suite.")
            else -> setStatus("Aucun chapitre suivant disponible.")
        }
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun sha256(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
