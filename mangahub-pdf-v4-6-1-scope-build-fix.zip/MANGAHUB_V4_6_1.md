# MangaHub PDF V4.6.1

Build fix verified from GitHub Actions run #88.

- Fixes Kotlin unresolved reference `effectiveChapterUrl` in Downloader.kt.
- The effective chapter URL now exists before candidate normalization and is updated after WebView redirects.
- Keeps V4.6 full fallback behavior: rendered WebView, multi-engine extraction, session refresh, retry before final error.
