# MangaHub PDF V4.5 — Rendered Chapter Engine

This version fixes the architectural difference with Chapter PDF Downloader:

1. Chapter pages are loaded in a real Android WebView first.
2. JavaScript/lazy-loading is allowed to build the reader DOM.
3. The rendered DOM is fed to MangaHub's multi-engine extractor.
4. WebView User-Agent + cookies + Referer are persisted per validated image.
5. The native downloader reuses that exact session for the real image download.
6. Raw OkHttp HTML remains only as a fallback when WebView rendering fails.
7. HTTP 403/429 remain errors, never FIN.
