# v2.5 Multi Download

- Jusqu’à 6 chapitres actifs et téléchargés en parallèle.
- Un seul renderer Chromium APK40 pour l’analyse, réutilisé entre les chapitres.
- Jusqu’à 6 requêtes image réseau simultanées globalement.
- Chaque chapitre garde son PDF streaming sur disque, sans charger le tome entier en RAM.
- Les JPEG sont intégrés directement au PDF sans Sharp.
- Les conversions WebP/PNG/AVIF restent limitées à une à la fois pour éviter les pics CPU.
- Max 6 tâches par série et par hôte.
