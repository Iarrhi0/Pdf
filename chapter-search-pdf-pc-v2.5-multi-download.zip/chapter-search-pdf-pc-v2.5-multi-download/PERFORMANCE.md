# v2.3 Performance Edition

Fonctions conservées : navigateur, recherche multi-moteur, analyse série, téléchargement d'un chapitre, téléchargement de la suite, file multi-séries, jusqu'à 10 tâches dans la file, PDF, reprise et dossiers par série.

Optimisations internes :
- 10 workers logiques conservés, mais 2 rendus Chromium lourds maximum.
- 2 pipelines téléchargement/PDF lourds maximum.
- 6 requêtes image réseau globales maximum.
- Sharp limité à 1 thread et cache mémoire réduit à 16 Mo.
- JPEG et PNG ne sont plus recompressés avec Sharp avant le PDF.
- WebView invisibles sans peinture initiale et avec throttling arrière-plan.
- rafraîchissement de la file limité à ~1,4 fois/s pour les phases très bavardes.
- compression electron-builder réglée sur maximum.

Le but est d'éviter que 10 chapitres déclenchent 10 Chromium + 10 conversions PDF lourdes en même temps.
