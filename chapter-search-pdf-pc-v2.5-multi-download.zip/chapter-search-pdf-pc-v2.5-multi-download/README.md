# Chapter Search PDF PC v2.5 — APK40 Multi Download

Même fonctions que la v2.4, mais plusieurs chapitres téléchargent réellement en même temps.

## Parallélisme
- 6 chapitres actifs maximum
- 6 pipelines de téléchargement/PDF simultanés
- 6 requêtes image simultanées globales
- 1 renderer Chromium APK40 réutilisé pour l’analyse
- 1 conversion lourde d’image à la fois pour contenir le CPU

Les PDF restent streamés page par page vers le disque afin de contenir la RAM.
