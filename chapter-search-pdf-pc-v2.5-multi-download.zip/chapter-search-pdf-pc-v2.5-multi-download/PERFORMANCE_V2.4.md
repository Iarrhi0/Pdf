# v2.4 Real Low Resource

Corrections par rapport à v2.3 :

- v2.3 lançait encore 10 queue workers et autorisait 10 tâches actives par série/site. v2.4 limite réellement à 3 jobs actifs, 2 par série/site.
- Un seul BrowserWindow APK40 est créé puis réutilisé. La page est vidée et remplacée par about:blank après extraction.
- Le PDF n'accumule plus toutes les pages en mémoire. Un writer PDF JPEG écrit chaque page directement dans le fichier .part puis libère le buffer.
- JPEG original conservé sans recompression quand possible. Les autres formats sont convertis une page à la fois avec Sharp mono-thread.
- Sharp cache : 8 MB.
- UI queue : throttling 1.2 s.
- Recherche multi-site : 8 sources concurrentes maximum.

Les fonctions utilisateur restent : navigateur, PDF chapitre, analyse série, téléchargement de la suite, file multi-séries, pause/reprise, recherche multi-moteur et dossier PDF.
