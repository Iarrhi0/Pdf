const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const web=$('#web');
let sources=[],searchBuckets=[],currentChapters=[],batchPaused=false,engineScripts=null,currentChapterNumber=null,lastQueue=null,analyzedSeriesKey='',analyzedSeriesUrl='';

function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function setStatus(s){$('#status').textContent=s;}
function toast(s,ms=3300){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>t.classList.remove('show'),ms);}
function normalizeUrl(v){v=(v||'').trim();if(!v)return '';if(/^https?:\/\//i.test(v))return v;if(/^[a-z0-9.-]+\.[a-z]{2,}(?:\/.*)?$/i.test(v))return 'https://'+v;return 'https://www.google.com/search?q='+encodeURIComponent(v+' manga manhwa webtoon chapter');}
function currentUrl(){try{return web.getURL()||$('#urlBox').value.trim();}catch{return $('#urlBox').value.trim();}}
function extractNumber(s=''){let m=String(s).match(/(?:tome|volume|vol\.?|chapter|chapitre|ch\.?|episode|ep\.?|scan)[-_:# \/]*(\d+(?:\.\d+)?)/i);if(!m)m=String(s).match(/[-_\/](\d+(?:\.\d+)?)(?:[-_\/?#]|$)/);return m?parseFloat(m[1]):null;}
function engineLabel(p){if(!p)return '';const st=p.engineStats||{};const e5=st.E5??st.E5Selected??st.E5Validated??p.images?.length??0;return `${p.engine||'JAVA5'} • E1 ${st.E1||0} • E2 ${st.E2||0} • E3 ${st.E3||0} • E4 ${st.E4||0} → E5 ${e5} • ${st.method||''}`;}

function seriesKeyFromUrl(raw=''){
  try{
    const u=new URL(raw);
    let p=decodeURIComponent(u.pathname||'').toLowerCase().replace(/\/+$/,'');
    p=p.replace(/(?:[-_/](?:tome|volume|vol|chapter|chapitre|ch|episode|ep|scan)[-_: ]*\d+(?:\.\d+)?).*$/i,'');
    p=p.replace(/(?:[-_/](?:page|reader)[-_: ]*\d+(?:\.\d+)?).*$/i,'');
    return (u.hostname.replace(/^www\./,'')+p).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  }catch{return '';}
}
function setSeriesEmpty(message='Aucune série analysée.'){
  currentChapters=[];
  analyzedSeriesKey='';
  analyzedSeriesUrl='';
  $('#chapterCount').textContent='0';
  $('#nextBatchBtn').disabled=true;
  $('#chapters').innerHTML='';
  $('#chapterSummary').innerHTML=`<div class="small">${esc(message)}</div>`;
}
function belongsToCurrentSeries(raw=''){
  if(!currentChapters.length)return true;
  const c=canon(raw);
  if(currentChapters.some(x=>canon(x.url)===c))return true;
  const key=seriesKeyFromUrl(raw);
  return !!(key&&analyzedSeriesKey&&key===analyzedSeriesKey);
}
function handleSeriesNavigation(raw=''){
  currentChapterNumber=extractNumber(raw);
  if(!currentChapters.length)return;
  if(belongsToCurrentSeries(raw))return;
  const oldName=currentChapters[0]?.series||'la série précédente';
  setSeriesEmpty('Nouvelle série détectée. Clique sur Analyser la série ou Actualiser la série.');
  toast(`Série changée • ancienne liste ${oldName} effacée`,3600);
}

function closeDrawers(){['metaDrawer','seriesDrawer','downloadsDrawer'].forEach(id=>$('#'+id).classList.remove('open'));$('#overlay').classList.remove('open');}
function openDrawer(id){closeDrawers();$('#'+id).classList.add('open');$('#overlay').classList.add('open');}
$$('[data-close]').forEach(b=>b.onclick=closeDrawers);$('#overlay').onclick=closeDrawers;
$('#seriesDrawerBtn').onclick=()=>openDrawer('seriesDrawer');$('#downloadsBtn').onclick=()=>openDrawer('downloadsDrawer');$('#metaBtn').onclick=()=>openDrawer('metaDrawer');

function home(){
  const html=`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#0b1020;color:#f5f7ff;font-family:Segoe UI,Arial,sans-serif;display:grid;place-items:center;min-height:100vh}.wrap{width:min(820px,90vw)}h1{font-size:34px;margin:0 0 8px}.sub{color:#9fb0cc;margin-bottom:26px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.c{background:#121a2e;border:1px solid #263455;border-radius:15px;padding:18px}.c b{display:block;margin-bottom:6px}.c span{font-size:13px;color:#9fb0cc}@media(max-width:700px){.cards{grid-template-columns:1fr}}</style><div class="wrap"><h1>Chapter Search PDF</h1><div class="sub">Navigateur PC v2.4 • moteur APK40 conservé • file multi séries • 1 renderer Chromium réutilisé • PDF écrit page par page pour réduire RAM et CPU.</div><div class="cards"><div class="c"><b>⬇ PDF du chapitre</b><span>Chromium rend la page, puis le moteur Java original exécute E1 à E4. E5 isole le bloc lecteur/API et trie numériquement les pages avant le téléchargement.</span></div><div class="c"><b>☰ Analyser la série</b><span>Sélectionne des chapitres puis ajoute-les à la file. Tu peux ensuite naviguer vers une autre série.</span></div><div class="c"><b>⚡ File multi séries</b><span>Les séries restent en file parallèle, tandis que les phases lourdes sont régulées automatiquement pour garder le PC fluide.</span></div></div></div>`;
  setSeriesEmpty('Aucune série analysée.');web.src='data:text/html;charset=utf-8,'+encodeURIComponent(html);$('#urlBox').value='';setStatus('Prêt • Moteur 5 session réelle');
}
function openInBrowser(raw){const url=normalizeUrl(raw);if(!url)return;if(currentChapters.length&&!belongsToCurrentSeries(url))setSeriesEmpty('Nouvelle navigation. Analyse la nouvelle série pour charger ses chapitres.');closeDrawers();$('#urlBox').value=url;try{web.loadURL(url);}catch{web.src=url;}}
$('#goBtn').onclick=()=>openInBrowser($('#urlBox').value);$('#urlBox').addEventListener('keydown',e=>{if(e.key==='Enter')openInBrowser($('#urlBox').value);});
$('#backBtn').onclick=()=>{try{if(web.canGoBack())web.goBack();}catch{}};$('#forwardBtn').onclick=()=>{try{if(web.canGoForward())web.goForward();}catch{}};$('#reloadBtn').onclick=()=>{try{web.reload();}catch{}};$('#homeBtn').onclick=home;
web.addEventListener('did-start-loading',()=>{$('#loadingLine').classList.add('active');setStatus('Chargement…');});
web.addEventListener('did-stop-loading',()=>{$('#loadingLine').classList.remove('active');setStatus('Page chargée • Moteur 5 prêt');});
web.addEventListener('did-navigate',e=>{$('#urlBox').value=e.url.startsWith('data:')?'':e.url;if(!e.url.startsWith('data:'))handleSeriesNavigation(e.url);else currentChapterNumber=null;});
web.addEventListener('did-navigate-in-page',e=>{$('#urlBox').value=e.url;handleSeriesNavigation(e.url);});
web.addEventListener('page-title-updated',e=>{currentChapterNumber=currentChapterNumber??extractNumber(e.title);});
web.addEventListener('did-fail-load',e=>{if(e.errorCode===-3)return;setStatus('Erreur de chargement');});

async function ensureScripts(){if(!engineScripts)engineScripts=await window.chapterAPI.getEngineScripts();return engineScripts;}
async function runOnVisible(script){if(!currentUrl()||currentUrl().startsWith('data:'))throw new Error('Ouvre d’abord une vraie page.');return web.executeJavaScript(script,true);}

async function analyzeChapterVisible(download=true){
  const url=currentUrl();if(!url||url.startsWith('data:')){toast('Ouvre d’abord un chapitre.');return null;}
  const btn=$('#chapterPdfBtn'),old=btn.textContent;btn.disabled=true;btn.textContent='Moteur 5 session…';
  try{
    setStatus('M5 • rendu Chromium réel + session + validation réseau…');
    let p=await window.chapterAPI.analyzeChapter(url);if(typeof p==='string')p=JSON.parse(p);
    if(!p?.ok||!Array.isArray(p.images)||p.images.length<2)throw new Error(p?.reason||'Page non reconnue comme chapitre');
    currentChapterNumber=p.number?parseFloat(p.number):currentChapterNumber;
    setStatus(`JAVA5 OK • ${p.series} • ${p.chapter} • ${p.images.length} pages détectées`);toast(engineLabel(p),5200);
    if(!download)return p;
    btn.textContent=`PDF • ${p.images.length} pages`;
    const target=await window.chapterAPI.downloadChapter(url,p,p.__userAgent||null);toast('PDF enregistré : '+target,5200);setStatus('PDF enregistré • '+p.chapter);return p;
  }catch(e){toast('Échec PDF : '+(e.message||e),7000);setStatus('Échec téléchargement PDF');return null;}finally{btn.disabled=false;btn.textContent=old;}
}
$('#chapterPdfBtn').onclick=()=>analyzeChapterVisible(true);

async function analyzeSeriesVisible(force=false){
  const url=currentUrl();if(!url||url.startsWith('data:')){toast('Ouvre d’abord une page de série ou de chapitre.');return;}
  const btn=$('#seriesAnalyzeBtn'),refresh=$('#seriesRefreshBtn'),old=btn.textContent,oldRefresh=refresh?.textContent;
  btn.disabled=true;if(refresh)refresh.disabled=true;btn.textContent=force?'Actualisation…':'Analyse série…';
  setSeriesEmpty(force?'Actualisation de la série en cours…':'Analyse de la nouvelle série en cours…');
  $('#chapterSummary').innerHTML='<div class="small">Analyse en cours… l’ancienne liste a été vidée.</div>';
  try{
    const s=await ensureScripts();setStatus('ANALYSE SÉRIE • DOM + scripts…');let list=await runOnVisible(s.series);if(typeof list==='string')list=JSON.parse(list);if(!Array.isArray(list))list=[];
    if(list.length<=3&&s.seriesPage){try{let hint=await runOnVisible(s.seriesPage);if(typeof hint==='string')hint=JSON.parse(hint);const candidate=hint?.candidate?.url;if(candidate&&canon(candidate)!==canon(url)){setStatus('ANALYSE SÉRIE • page mère en arrière-plan…');let expanded=await window.chapterAPI.analyzeSeries(candidate);if(typeof expanded==='string')expanded=JSON.parse(expanded);if(Array.isArray(expanded)&&expanded.length>list.length)list=expanded;}}catch{}}
    const dedup=[];const seen=new Set();for(const c of list){const k=canon(c?.url);if(!k||seen.has(k))continue;seen.add(k);dedup.push(c);}list=dedup;
    if(!list.length)throw new Error('Aucun chapitre ou tome numéroté détecté');
    currentChapters=list;
    analyzedSeriesUrl=url;
    analyzedSeriesKey=seriesKeyFromUrl(currentChapters[0]?.url||url)||seriesKeyFromUrl(url);
    const exact=currentChapters.find(c=>canon(c.url)===canon(url));if(exact)currentChapterNumber=Number(exact.number);if(currentChapterNumber==null)currentChapterNumber=extractNumber(url);
    renderChapters();$('#chapterCount').textContent=currentChapters.length;$('#nextBatchBtn').disabled=false;openDrawer('seriesDrawer');setStatus(`SÉRIE • ${currentChapters.length} éléments détectés`);toast(`${currentChapters[0]?.series||'Série'} • ${currentChapters.length} élément(s) actualisé(s)`,3600);
  }catch(e){setSeriesEmpty('Aucune liste fiable pour cette page. Tu peux actualiser après chargement complet.');toast('Échec : '+(e.message||e),5200);setStatus('Aucune série fiable détectée');}
  finally{btn.disabled=false;btn.textContent=old;if(refresh){refresh.disabled=false;refresh.textContent=oldRefresh;}}
}
$('#seriesAnalyzeBtn').onclick=()=>analyzeSeriesVisible(false);
$('#seriesRefreshBtn').onclick=()=>analyzeSeriesVisible(true);$('#seriesRefreshBtnDrawer').onclick=()=>analyzeSeriesVisible(true);

function renderChapters(){
  const el=$('#chapters');if(!currentChapters.length){el.innerHTML='';$('#chapterCount').textContent='0';$('#nextBatchBtn').disabled=true;if(!$('#chapterSummary').textContent.trim())$('#chapterSummary').innerHTML='<div class="small">Aucune série analysée.</div>';return;}
  const first=currentChapters[0],last=currentChapters[currentChapters.length-1];$('#chapterSummary').innerHTML=`<b>${esc(first.series||'Série')}</b><div class="small">${currentChapters.length} éléments • ${esc(first.number)} → ${esc(last.number)}${currentChapterNumber!=null?` • courant ${esc(currentChapterNumber)}`:''}</div>`;
  el.innerHTML=currentChapters.map((c,i)=>`<div class="chapRow"><input type="checkbox" class="chapCheck" data-i="${i}"><b>#${esc(c.number)}</b><div><div>${esc(c.title||('Chapitre '+c.number))}</div><div class="chapUrl">${esc(c.url)}</div></div><button class="mini openChap" data-i="${i}">Ouvrir</button></div>`).join('');selectNext();$$('.openChap').forEach(b=>b.onclick=()=>{const c=currentChapters[+b.dataset.i];openInBrowser(c.url);closeDrawers();});
}
function selectNext(){const n=currentChapterNumber;$$('.chapCheck').forEach(x=>{const c=currentChapters[+x.dataset.i];x.checked=n==null?true:Number(c.number)>=Number(n);});}
function canon(u){try{const x=new URL(u);x.hash='';if(x.pathname.length>1)x.pathname=x.pathname.replace(/\/$/,'');return x.href;}catch{return String(u||'');}}
function uniqueJobs(arr){const seen=new Set();return (arr||[]).filter(j=>{const k=canon(j?.url);if(!k||seen.has(k))return false;seen.add(k);return true;});}
function selectedJobs(){return uniqueJobs($$('.chapCheck').filter(x=>x.checked).map(x=>currentChapters[+x.dataset.i]));}
$('#selectAll').onclick=()=>$$('.chapCheck').forEach(x=>x.checked=true);$('#selectNone').onclick=()=>$$('.chapCheck').forEach(x=>x.checked=false);$('#selectNext').onclick=selectNext;
$('#queueSelected').onclick=async()=>{const jobs=selectedJobs();if(!jobs.length){toast('Aucun chapitre sélectionné.');return;}const r=await window.chapterAPI.addQueue(jobs);toast(`${r.added}/${jobs.length} ajouté(s) à la file${r.skipped?` • ${r.skipped} doublon(s) ignoré(s)`:''}.`,4200);openDrawer('downloadsDrawer');};
$('#downloadSelected').onclick=async()=>{const jobs=selectedJobs();if(!jobs.length){toast('Aucun chapitre sélectionné.');return;}const r=await window.chapterAPI.addQueueAndStart(jobs);toast(`${r.added}/${jobs.length} ajouté(s) • démarrage automatique`,3600);openDrawer('downloadsDrawer');};
$('#nextBatchBtn').onclick=async()=>{if(!currentChapters.length){analyzeSeriesVisible();return;}const n=currentChapterNumber;let jobs=uniqueJobs(currentChapters.filter(c=>n==null||Number(c.number)>=Number(n)));const cur=canon(currentUrl()),idx=currentChapters.findIndex(c=>canon(c.url)===cur);if(idx>=0&&currentChapters.length>3&&jobs.length<=2){const asc=Number(currentChapters[0]?.number)<=Number(currentChapters[currentChapters.length-1]?.number);jobs=uniqueJobs(asc?currentChapters.slice(idx):currentChapters.slice(0,idx+1));}if(!jobs.length){toast('Aucun chapitre suivant détecté.');return;}const r=await window.chapterAPI.addQueueAndStart(jobs);toast(`${r.added}/${jobs.length} chapitre(s) ajouté(s) • file démarrée`,4200);openDrawer('downloadsDrawer');};

function renderQueue(q){
  lastQueue=q||lastQueue;if(!lastQueue)return;const c=lastQueue.counts||{},active=(c.QUEUED||0)+(c.RUNNING||0)+(c.WAIT_PDF||0);$('#queueCount').textContent=active;batchPaused=!!lastQueue.paused;$('#pauseBtn').textContent=batchPaused?'Reprendre':'Pause';
  const state=lastQueue.paused?'PAUSE':(lastQueue.running?'EN COURS':((c.QUEUED||0)?'PRÊT':'ARRÊTÉ/PRÊT'));$('#batchSummary').innerHTML=`<b>${state}</b><div class="small">${lastQueue.series?.length||0} série(s) • ${lastQueue.total||0} tâche(s) • ${(c.RUNNING||0)+(c.WAIT_PDF||0)} actives • ${c.QUEUED||0} en attente • ${c.SAVED||0} OK • ${c.ERROR||0} erreur(s)</div><div class="small" style="margin-top:5px">${lastQueue.workerCount||0} chapitre(s) actif(s) • pool ${lastQueue.poolCount||0} • 3 slots • 2 max/série/site • 1 renderer Chromium réutilisé • PDF streaming</div>`;
  $('#seriesQueue').innerHTML=(lastQueue.series||[]).map(g=>{const done=g.saved||0,p=Math.round(done/Math.max(1,g.total)*100);return`<div class="seriesQueueCard"><div class="seriesQueueTop"><b>${esc(g.series)}</b><button class="mini removeSeries" data-series="${esc(g.series)}">Retirer</button></div><div class="queueNums">${g.running} actif • ${g.queued} attente • ${g.saved} OK • ${g.error} erreur • ${g.total} total</div><div class="queueBar"><span style="width:${p}%"></span></div></div>`;}).join('')||'<div class="small">File vide. Analyse une série puis ajoute des chapitres.</div>';
  $$('.removeSeries').forEach(b=>b.onclick=()=>window.chapterAPI.removeSeries(b.dataset.series));
  const jobs=(lastQueue.jobs||[]).filter(j=>j.state==='QUEUED'||j.state==='RUNNING'||j.state==='WAIT_PDF'||j.state==='ERROR'||j.state==='STOPPED').slice(-40);$('#downloads').innerHTML=jobs.map(j=>{const cls=j.state==='SAVED'?'goodText':j.state==='ERROR'||j.state==='STOPPED'?'badText':(j.state==='RUNNING'||j.state==='WAIT_PDF')?'warnText':'';const eng=j.engine?` • ${esc(j.engine)}`:'';const phase=j.phase||j.state;return`<div class="downloadRow"><b>${j.slot?'W'+j.slot:'•'}</b><div><div>${esc(j.series||'')} • ${esc(j.title||j.url||'')}</div><div class="small">${j.page?`page ${j.page}/${j.pages||'?'} • `:''}${esc(j.error||'')}${eng}</div></div><div class="downloadState ${cls}">${esc(phase)}</div></div>`;}).join('')||'<div class="small">Aucun worker actif.</div>';
}
let selfHealTimer=null;window.chapterAPI.onQueueUpdate(q=>{renderQueue(q);const c=q?.counts||{};if(q?.running&&!q?.paused&&(c.QUEUED||0)>0&&(q.workerCount||0)===0){clearTimeout(selfHealTimer);selfHealTimer=setTimeout(()=>window.chapterAPI.startQueue(),250);}});window.chapterAPI.onQueueProgress(()=>{});window.chapterAPI.onQueueComplete(q=>{renderQueue(q);setStatus(`File terminée • ${q.counts?.SAVED||0} PDF • ${q.counts?.ERROR||0} erreur(s)`);});
$('#startQueueBtn').onclick=()=>window.chapterAPI.startQueue();$('#pauseBtn').onclick=async()=>{batchPaused=!batchPaused;await window.chapterAPI.pauseQueue(batchPaused);};$('#stopBtn').onclick=()=>window.chapterAPI.stopQueue();$('#retryBtn').onclick=async()=>{await window.chapterAPI.retryQueue();await window.chapterAPI.startQueue();};$('#clearDoneBtn').onclick=()=>window.chapterAPI.clearDone();$('#openFolderBtn').onclick=$('#openFolderBtn2').onclick=()=>window.chapterAPI.openDownloads();

function updateActive(){const n=sources.filter(s=>s.enabled).length;$('#activeCount').textContent=n;}
function renderSources(){const el=$('#sourceList');el.innerHTML=sources.map((s,i)=>`<div class="sourceToggle"><div><b style="font-size:11px">${esc(s.name)}</b><div class="small">${esc(s.domain)} • ${esc(s.lang)}</div></div><div class="switch ${s.enabled?'on':''}" data-si="${i}"></div></div>`).join('');$$('[data-si]').forEach(sw=>sw.onclick=async()=>{const i=+sw.dataset.si;sources[i].enabled=!sources[i].enabled;await window.chapterAPI.saveSources(sources);renderSources();});updateActive();}
function renderMetaResults(){const arr=[];for(const b of searchBuckets)for(const r of b.results)arr.push({...r,source:b.source});$('#resCount').textContent=arr.length;$('#metaResults').innerHTML=arr.length?arr.map(r=>`<div class="result"><div class="resultTitle">${esc(r.title||r.source.name)}</div><div class="small">${esc(r.source.name)} • ${esc(r.source.domain)}${r.method?` • ${esc(r.method)}`:''}</div><div class="resultActions"><button class="mini openMeta" data-url="${esc(r.url)}">Ouvrir</button><button class="mini primary analyzeMeta" data-url="${esc(r.url)}">Ouvrir + série</button></div></div>`).join(''):'<div class="small">Aucun résultat.</div>';$$('.openMeta').forEach(b=>b.onclick=()=>openInBrowser(b.dataset.url));$$('.analyzeMeta').forEach(b=>b.onclick=()=>{openInBrowser(b.dataset.url);closeDrawers();setTimeout(analyzeSeriesVisible,1800);});}
async function doMetaSearch(){const q=$('#metaQ').value.trim();if(!q)return;const active=sources.filter(s=>s.enabled);$('#scanned').textContent=`0/${active.length}`;$('#metaSearchBtn').disabled=true;searchBuckets=[];renderMetaResults();setStatus(`Recherche multi-moteur • ${active.length} sources…`);try{searchBuckets=await window.chapterAPI.metaSearch(q,sources);renderMetaResults();const found=searchBuckets.filter(b=>b.results?.length).length,total=searchBuckets.reduce((n,b)=>n+(b.results?.length||0),0);setStatus(`Recherche terminée • ${found}/${active.length} source(s) avec résultat • ${total} résultat(s)`);}finally{$('#metaSearchBtn').disabled=false;}}
$('#metaSearchBtn').onclick=doMetaSearch;$('#metaQ').addEventListener('keydown',e=>{if(e.key==='Enter')doMetaSearch();});window.chapterAPI.onMetaProgress(p=>$('#scanned').textContent=`${p.done}/${p.total}`);
$('#toggleAll').onclick=async()=>{const allOn=sources.every(s=>s.enabled);sources.forEach(s=>s.enabled=!allOn);await window.chapterAPI.saveSources(sources);renderSources();};
$('#injectBtn').onclick=()=>{$('#injectModal').style.display='flex';};$('#closeInject').onclick=()=>{$('#injectModal').style.display='none';};
$('#confirmInject').onclick=async()=>{const raw=$('#injectText').value.trim();let arr=[];try{if(raw.startsWith('[')||raw.startsWith('{')){const j=JSON.parse(raw);arr=Array.isArray(j)?j:[j];}else{arr=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map(x=>{try{const u=new URL(/^https?:\/\//i.test(x)?x:'https://'+x);return{name:u.hostname,domain:u.hostname.replace(/^www\./,''),lang:'?',type:'multi',enabled:true};}catch{return null;}}).filter(Boolean);}sources=await window.chapterAPI.injectSources(arr);renderSources();$('#injectModal').style.display='none';toast('Sources ajoutées.');}catch(e){toast('Liste invalide : '+e.message);}};

(async()=>{sources=await window.chapterAPI.getSources();renderSources();await ensureScripts();renderQueue(await window.chapterAPI.getQueue());home();})();
