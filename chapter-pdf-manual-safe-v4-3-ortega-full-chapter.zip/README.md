# Chapter PDF Manual Safe V4.3 — Ortega Full Chapter

## Correctifs
- Ortega : ne fait plus confiance au nombre d'images visible dans le HTML initial.
- Détecte la base API réelle du chapitre.
- Teste séquentiellement `image/1`, `image/2`, `image/3`, etc.
- Continue jusqu'à 3 images consécutives absentes.
- Plafond de sécurité : 250 images sources.
- Conserve l'ordre numérique des images.
- Découpage mobile des très longues images toujours actif.
- Aucun chargement du chapitre suivant en arrière-plan.

## Nom de fichier
Exemple :
`Set_It_Chapitre_001.pdf`
`Set_It_Chapitre_002.pdf`

Le numéro est lu prioritairement dans `/chapter/<numero>`.

## Statut final
Affiche :
- nombre de sources réellement trouvées ;
- nombre de sources converties ;
- nombre de pages PDF générées ;
- doublons ;
- échecs.

## Sortie
Téléchargements/PDF_CONVERTIS/

Compatible avec `unzip-and-build-apk.yml`.
