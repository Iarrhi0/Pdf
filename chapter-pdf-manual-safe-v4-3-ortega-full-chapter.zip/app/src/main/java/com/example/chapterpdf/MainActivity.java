package com.example.chapterpdf;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 9090;

    private File transferTemp;
    private FileOutputStream transferOut;
    private long transferExpected;
    private String transferName;
    private String transferMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStorageIfNeeded();
        createWebView();
    }

    private void requestStorageIfNeeded() {
        if (Build.VERSION.SDK_INT <= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    440
            );
        }
    }

    private void createWebView() {
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        if (Build.VERSION.SDK_INT >= 26) {
            web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new AndroidFilesBridge(), "AndroidFiles");
        web.addJavascriptInterface(new AndroidBrowserBridge(), "AndroidBrowser");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQ);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                boolean crashed = detail != null && detail.didCrash();

                runOnUiThread(() -> {
                    try {
                        view.removeJavascriptInterface("AndroidFiles");
                        view.removeJavascriptInterface("AndroidBrowser");
                        view.destroy();
                    } catch (Exception ignored) {
                    }

                    createWebView();
                    web.loadUrl("file:///android_asset/index.html");

                    web.postDelayed(() -> {
                        String msg = crashed
                                ? "Le moteur WebView a redémarré après un crash. Aucun chapitre distant n’est rendu dans cette version."
                                : "Android a redémarré le moteur WebView pour libérer de la mémoire.";
                        web.evaluateJavascript(
                                "(function(){const e=document.querySelector('.panel.active .status');if(e)e.textContent="
                                        + JSONObject.quote(msg) + ";})();",
                                null
                        );
                    }, 800);
                });

                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBrowserBridge {
        @JavascriptInterface
        public void open(String url) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    showMessage("Impossible d’ouvrir le navigateur : " + e.getMessage());
                }
            });
        }
    }

    private class AndroidFilesBridge {
        @JavascriptInterface
        public void begin(String name, String mime, long size) {
            synchronized (MainActivity.this) {
                closeTransferQuietly();

                try {
                    transferName = sanitizeName(name);
                    transferMime = (mime == null || mime.isEmpty())
                            ? "application/octet-stream"
                            : mime;
                    transferExpected = size;
                    transferTemp = new File(
                            getCacheDir(),
                            "web_" + System.currentTimeMillis() + ".tmp"
                    );
                    transferOut = new FileOutputStream(transferTemp);

                } catch (Exception e) {
                    showMessage("Erreur création fichier : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void chunk(String base64) {
            synchronized (MainActivity.this) {
                try {
                    if (transferOut == null) {
                        throw new IllegalStateException("Transfert non initialisé");
                    }

                    byte[] bytes = android.util.Base64.decode(
                            base64,
                            android.util.Base64.DEFAULT
                    );

                    transferOut.write(bytes);

                } catch (Exception e) {
                    closeTransferQuietly();
                    showMessage("Erreur transfert : " + e.getMessage());
                }
            }
        }

        @JavascriptInterface
        public void progress(long sent, long total) {
            // Le moteur Web garde son propre état d'avancement.
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(() -> {
                try {
                    synchronized (MainActivity.this) {
                        if (transferOut != null) {
                            transferOut.flush();
                            transferOut.close();
                            transferOut = null;
                        }
                    }

                    if (transferTemp == null || !transferTemp.exists()) {
                        throw new IllegalStateException("Fichier temporaire absent");
                    }

                    if (transferExpected > 0 && transferTemp.length() != transferExpected) {
                        throw new IllegalStateException(
                                "Transfert incomplet : "
                                        + transferTemp.length()
                                        + "/"
                                        + transferExpected
                        );
                    }

                    boolean ok = saveToDownloads(
                            transferTemp,
                            transferName,
                            transferMime
                    );

                    if (!ok) {
                        throw new IllegalStateException("Enregistrement Android impossible");
                    }

                    transferTemp.delete();
                    transferTemp = null;

                } catch (Exception e) {
                    showMessage("Erreur finalisation : " + e.getMessage());
                } finally {
                    closeTransferQuietly();
                }
            });
        }

        @JavascriptInterface
        public void cancel(String message) {
            closeTransferQuietly();
            showMessage("Téléchargement annulé : " + message);
        }
    }

    private boolean saveToDownloads(File source, String name, String mime) {
        String relativeSubdir = "PDF_CONVERTIS/";

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    "Download/" + relativeSubdir
            );
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
            );

            if (uri == null) return false;

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 FileInputStream in = new FileInputStream(source)) {

                if (out == null) {
                    throw new IllegalStateException("Sortie indisponible");
                }

                byte[] buf = new byte[65536];
                int n;

                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                return true;

            } catch (Exception e) {
                getContentResolver().delete(uri, null, null);
                return false;
            }
        }

        File downloads = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
        );
        File folder = new File(downloads, relativeSubdir);
        folder.mkdirs();

        File output = new File(folder, name);

        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(output)) {

            byte[] buf = new byte[65536];
            int n;

            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }

            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private void showMessage(String message) {
        runOnUiThread(() -> {
            if (web == null) return;

            web.evaluateJavascript(
                    "(function(){const e=document.querySelector('.panel.active .status');if(e)e.textContent="
                            + JSONObject.quote(message == null ? "" : message)
                            + ";})();",
                    null
            );
        });
    }

    private synchronized void closeTransferQuietly() {
        try {
            if (transferOut != null) transferOut.close();
        } catch (Exception ignored) {
        }

        transferOut = null;
        transferExpected = 0;
    }

    private static String sanitizeName(String name) {
        String n = name == null ? "fichier.bin" : name;
        n = n.replaceAll("[\\\\/:*?\"<>|]+", "_").trim();
        return n.isEmpty() ? "fichier.bin" : n;
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        if (requestCode == FILE_CHOOSER_REQ) {
            Uri[] results = null;

            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];

                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }

                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }

            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }

            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        closeTransferQuietly();

        if (web != null) {
            try {
                web.removeJavascriptInterface("AndroidFiles");
                web.removeJavascriptInterface("AndroidBrowser");
                web.destroy();
            } catch (Exception ignored) {
            }
        }

        super.onDestroy();
    }
}
