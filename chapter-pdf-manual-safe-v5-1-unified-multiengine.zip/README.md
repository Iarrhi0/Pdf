# V5.1 — Unified Multi-Engine

Le chapitre 10 passait encore par l'ancien pipeline manuel.

V5.1 impose le Multi-Engine sur tous les boutons utilisateur :

- Télécharger ce chapitre -> Multi-Engine
- Chapitre suivant -> Multi-Engine
- Réessayer -> Multi-Engine
- Reprendre -> Multi-Engine
- Série ×2 -> deux Multi-Engine indépendants

Chaque chapitre exécute ses propres blocs :
Moteur 1 = 1-5
Moteur 2 = 6-10
Moteur 3 = 11-15
etc.

L'ancien code manuel reste présent uniquement comme code inactif de compatibilité,
mais aucun bouton ne peut encore l'appeler.
